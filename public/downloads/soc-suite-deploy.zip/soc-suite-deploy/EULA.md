# Contratto di licenza con l'utente finale (EULA) - SOC Suite

**Versione 1.0 - in vigore dal 2026-07-06**

Il presente Contratto di Licenza con l'Utente Finale ("Contratto") e' stipulato
tra Nicholas Arcari ("Licenziante") e la persona fisica o giuridica che installa
o utilizza il software SOC Suite ("Licenziatario"). Installando o utilizzando il
software, il Licenziatario accetta integralmente i termini seguenti. Se non li
accetta, non deve installare ne' utilizzare il software.

> Nota: questo documento e' un modello fornito a scopo pratico e non costituisce
> consulenza legale. Per un utilizzo commerciale si raccomanda di farlo
> revisionare da un professionista legale.

## 1. Definizioni

- **Software**: la suite "SOC Suite", comprendente SOC Toolkit e OSINT Toolkit,
  distribuita come immagini Docker, insieme alla documentazione allegata.
- **Chiave di licenza**: il token firmato dal Licenziante che abilita l'uso del
  Software su un determinato deployment.
- **Deployment**: una singola installazione del Software identificata dal valore
  `LICENSE_DEPLOYMENT_ID` scelto dal Licenziatario al momento dell'installazione.

## 2. Concessione della licenza

Il Licenziante concede al Licenziatario una licenza non esclusiva, non
trasferibile, non cedibile in sublicenza e revocabile, a:

- installare e utilizzare il Software sul deployment per il quale e' stata
  emessa la Chiave di licenza;
- per la durata di validita' indicata nella Chiave di licenza (scadenza inclusa).

La licenza e' vincolata al Deployment: la Chiave di licenza e' valida solo per il
`LICENSE_DEPLOYMENT_ID` per cui e' stata emessa.

## 3. Restrizioni

Il Licenziatario non puo':

1. copiare, distribuire, rivendere, noleggiare, concedere in leasing o in
   sublicenza il Software o la Chiave di licenza a terzi;
2. modificare, decompilare, disassemblare o effettuare reverse engineering del
   Software, salvo nei limiti inderogabili previsti dalla legge;
3. rimuovere, disattivare o aggirare il meccanismo di verifica della licenza o
   qualsiasi misura tecnica di protezione;
4. rimuovere o alterare le note di copyright, i marchi o gli avvisi di
   proprieta';
5. utilizzare il Software oltre la scadenza della Chiave di licenza senza un
   rinnovo valido.

## 4. Proprieta'

Il Software e' concesso in licenza, non venduto. Il Licenziante conserva ogni
diritto, titolo e interesse sul Software, inclusi tutti i diritti di proprieta'
intellettuale. Il presente Contratto non trasferisce alcun diritto di proprieta'
al Licenziatario.

## 5. Uso lecito ed etico

Il Software e' uno strumento di sicurezza informatica destinato ad attivita'
difensive, di analisi e di test autorizzati. Il Licenziatario si impegna a
utilizzarlo esclusivamente nel rispetto delle leggi applicabili e delle
condizioni descritte nel documento `ETHICS.md` allegato. Ogni responsabilita'
per un uso illecito, non etico o non autorizzato del Software ricade
esclusivamente sul Licenziatario e non sul Licenziante.

## 6. Dati e riservatezza

Il Software funziona interamente sull'infrastruttura del Licenziatario. Il
Licenziante non raccoglie ne' riceve dati dal Software: la verifica della licenza
avviene in locale, senza alcuna comunicazione verso l'esterno.

## 7. Rinnovo e cessazione

La licenza cessa automaticamente alla scadenza della Chiave di licenza, salvo
rinnovo. Il Licenziante puo' risolvere il Contratto in caso di violazione dei
termini da parte del Licenziatario. Alla cessazione, il Licenziatario deve
interrompere l'uso del Software. I dati generati dal Licenziatario restano di sua
proprieta' e sul suo server.

## 8. Esclusione di garanzie

Il Software e' fornito "cosi' com'e'", senza garanzie di alcun tipo, esplicite o
implicite, incluse tra l'altro le garanzie di commerciabilita', idoneita' per un
fine particolare e non violazione di diritti di terzi.

## 9. Limitazione di responsabilita'

Nella misura massima consentita dalla legge, il Licenziante non e' responsabile
per alcun danno diretto, indiretto, incidentale, speciale o consequenziale
derivante dall'uso o dall'impossibilita' di usare il Software. La responsabilita'
complessiva del Licenziante non superera' in alcun caso l'importo pagato dal
Licenziatario per la licenza.

## 10. Legge applicabile e foro competente

Il presente Contratto e' regolato dalla legge italiana. Per ogni controversia e'
competente in via esclusiva il foro del luogo di residenza del Licenziante,
salvo diversa norma inderogabile a tutela del consumatore.

## 11. Contatti

Per licenze, rinnovi o richieste: **arcari.nicholas0@gmail.com**
