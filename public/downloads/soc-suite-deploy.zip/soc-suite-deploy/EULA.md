# Contratto di licenza con l'utente finale (EULA) - SOC Suite

**Versione 1.1 - in vigore dal 2026-07-06**

Il presente Contratto di Licenza con l'Utente Finale ("Contratto") e' stipulato
tra:

**Licenziante:** Nicholas Arcari - C.F. / P. IVA: `[DA COMPILARE]` - sede /
indirizzo: `[DA COMPILARE]` - email: arcari.nicholas0@gmail.com - PEC:
`[DA COMPILARE, se disponibile]`

e la persona giuridica o il professionista che installa o utilizza il software
SOC Suite ("Licenziatario"). Installando o utilizzando il software, il
Licenziatario accetta integralmente i termini seguenti. Se non li accetta, non
deve installare ne' utilizzare il software.

> Destinatari: il Software e' un prodotto professionale destinato ad aziende,
> enti e professionisti (uso B2B). Non e' rivolto ai consumatori. In caso di
> vendita a un consumatore ai sensi del Codice del Consumo si applicano tutele
> inderogabili ulteriori (tra cui informativa precontrattuale, diritto di
> recesso e garanzia legale di conformita') che questo Contratto non disciplina.

> Nota: questo documento e' un modello fornito a scopo pratico e non costituisce
> consulenza legale. Prima dell'uso commerciale se ne raccomanda la revisione da
> parte di un professionista legale, in particolare per i campi `[DA COMPILARE]`.

## 1. Definizioni

- **Software**: la suite "SOC Suite", comprendente SOC Toolkit e OSINT Toolkit,
  distribuita come immagini Docker, insieme alla documentazione allegata.
- **Chiave di licenza**: il token firmato dal Licenziante che abilita l'uso del
  Software su un determinato deployment.
- **Deployment**: una singola installazione del Software identificata dal valore
  `LICENSE_DEPLOYMENT_ID` scelto dal Licenziatario al momento dell'installazione.
- **Documentazione**: i documenti allegati al Software, tra cui `README.md`,
  `ETHICS.md` e `THIRD_PARTY_NOTICES.md`.

## 2. Concessione della licenza

Il Licenziante concede al Licenziatario una licenza non esclusiva, non
trasferibile, non cedibile in sublicenza e revocabile, a:

- installare e utilizzare il Software sul deployment per il quale e' stata
  emessa la Chiave di licenza;
- per la durata di validita' indicata nella Chiave di licenza (scadenza inclusa).

La licenza e' vincolata al Deployment: la Chiave di licenza e' valida solo per il
`LICENSE_DEPLOYMENT_ID` per cui e' stata emessa.

## 3. Restrizioni

Il Licenziatario non puo':

1. copiare, distribuire, rivendere, noleggiare, concedere in leasing o in
   sublicenza il Software o la Chiave di licenza a terzi;
2. modificare, decompilare, disassemblare o effettuare reverse engineering del
   Software, salvo nei limiti inderogabili previsti dalla legge;
3. rimuovere, disattivare o aggirare il meccanismo di verifica della licenza o
   qualsiasi misura tecnica di protezione;
4. rimuovere o alterare le note di copyright, i marchi o gli avvisi di
   proprieta';
5. utilizzare il Software oltre la scadenza della Chiave di licenza senza un
   rinnovo valido.

## 4. Proprieta' e componenti di terze parti

Il Software e' concesso in licenza, non venduto. Il Licenziante conserva ogni
diritto, titolo e interesse sul Software, inclusi tutti i diritti di proprieta'
intellettuale. Il presente Contratto non trasferisce alcun diritto di proprieta'
al Licenziatario.

Il Software incorpora componenti software di terze parti (open source), ciascuno
soggetto alla propria licenza, elencati nel documento `THIRD_PARTY_NOTICES.md`
allegato. Tali componenti restano dei rispettivi titolari e sono forniti ai
termini delle rispettive licenze, che prevalgono sul presente Contratto per la
sola parte relativa a ciascun componente.

## 5. Uso lecito ed etico

Il Software e' uno strumento di sicurezza informatica destinato ad attivita'
difensive, di analisi e di test autorizzati. Il Licenziatario si impegna a
utilizzarlo esclusivamente nel rispetto delle leggi applicabili e delle
condizioni descritte nel documento `ETHICS.md` allegato. In particolare, il
Licenziatario e' l'unico responsabile di disporre delle autorizzazioni
necessarie per le attivita' svolte tramite il Software. Ogni responsabilita' per
un uso illecito, non etico o non autorizzato del Software ricade esclusivamente
sul Licenziatario e non sul Licenziante.

## 6. Dati personali e protezione dei dati

Il Software funziona interamente sull'infrastruttura del Licenziatario. Il
Licenziante non raccoglie, non riceve e non ha accesso ai dati trattati con il
Software: la verifica della licenza avviene in locale, senza alcuna
comunicazione verso l'esterno.

Utilizzando il Software - in particolare i moduli OSINT e di analisi - il
Licenziatario puo' trattare dati personali di terzi. Rispetto a tali
trattamenti il **Licenziatario agisce come autonomo titolare del trattamento**
ai sensi del Regolamento (UE) 2016/679 (GDPR) e della normativa applicabile, ed
e' l'unico responsabile: dell'individuazione di una idonea base giuridica, del
rispetto dei principi di liceita', minimizzazione e limitazione delle finalita',
dell'informativa agli interessati e dell'esercizio dei loro diritti. Poiche' il
Licenziante non tratta tali dati per conto del Licenziatario, non ricorre tra le
parti un rapporto di responsabile del trattamento e non e' richiesto un accordo
ai sensi dell'art. 28 GDPR. Il Licenziatario terra' indenne il Licenziante da
ogni pretesa di terzi derivante da un trattamento dati effettuato tramite il
Software in violazione della normativa.

## 7. Corrispettivo e condizioni economiche

Prezzo, durata, modalita' di pagamento, fatturazione, rinnovo ed eventuali
condizioni di rimborso sono disciplinati dalle **Condizioni di Vendita**
(`CONDIZIONI_VENDITA.md`) o dall'offerta/ordine sottoscritti tra le parti, che
integrano il presente Contratto. In caso di contrasto, per i profili economici
prevalgono le Condizioni di Vendita o l'ordine, per i profili d'uso prevale il
presente Contratto.

## 8. Rinnovo e cessazione

La licenza cessa automaticamente alla scadenza della Chiave di licenza, salvo
rinnovo. Il Licenziante puo' risolvere di diritto il Contratto in caso di
violazione dei termini da parte del Licenziatario. Alla cessazione, il
Licenziatario deve interrompere l'uso del Software. I dati generati dal
Licenziatario restano di sua proprieta' e sul suo server.

## 9. Esclusione di garanzie

Nella misura massima consentita dalla legge, il Software e' fornito "cosi'
com'e'", senza garanzie di alcun tipo, esplicite o implicite, incluse tra
l'altro le garanzie di commerciabilita', idoneita' per un fine particolare e non
violazione di diritti di terzi. Restano ferme le garanzie e i diritti
inderogabili eventualmente previsti dalla legge a favore del Licenziatario, che
il presente Contratto non intende escludere ne' limitare.

## 10. Limitazione di responsabilita'

Nella misura massima consentita dalla legge, il Licenziante non e' responsabile
per alcun danno diretto, indiretto, incidentale, speciale o consequenziale
derivante dall'uso o dall'impossibilita' di usare il Software. La responsabilita'
complessiva del Licenziante non superera' in alcun caso l'importo pagato dal
Licenziatario per la licenza nei dodici mesi precedenti l'evento. Le presenti
esclusioni e limitazioni **non si applicano in caso di dolo o colpa grave del
Licenziante, ne' negli altri casi in cui la responsabilita' non e' escludibile o
limitabile per legge** (art. 1229 c.c.).

## 11. Legge applicabile e foro competente

Il presente Contratto e' regolato dalla legge italiana. Per ogni controversia e'
competente in via esclusiva il foro del luogo in cui ha sede il Licenziante.

## 12. Approvazione specifica delle clausole (artt. 1341-1342 c.c.)

Ai sensi e per gli effetti degli artt. 1341 e 1342 del Codice Civile, il
Licenziatario dichiara di approvare specificamente, dopo attenta lettura, le
seguenti clausole: art. 2 (divieto di cessione e sublicenza; revocabilita'),
art. 3 (restrizioni d'uso), art. 8 (risoluzione di diritto), art. 9 (esclusione
di garanzie), art. 10 (limitazione di responsabilita'), art. 11 (foro
competente esclusivo). L'approvazione specifica e' resa mediante la seconda
sottoscrizione nel modulo di accettazione.

## 13. Contatti

Per licenze, rinnovi o richieste: **arcari.nicholas0@gmail.com**
