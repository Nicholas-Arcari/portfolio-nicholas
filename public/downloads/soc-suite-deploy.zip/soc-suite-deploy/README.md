# SOC Suite - Guida di installazione

Suite on-premise per security operations: **SOC Toolkit** (triage phishing,
analisi log, IOC, YARA/Sigma, file inspector) + **OSINT Toolkit** (attack
surface e OSINT investigativo). Tutto gira sul TUO server: nessun dato lascia
la tua infrastruttura e la licenza si verifica in locale, senza connessioni
verso l'esterno.

## Requisiti

- Un server Linux (o macOS/Windows con WSL2) con **Docker** e **Docker Compose**
- 4 GB di RAM consigliati
- Accesso a internet solo per il primo download delle immagini

## Installazione (4 passi)

1. **Accedi al registry** con il token in sola lettura ricevuto all'acquisto:

   ```bash
   docker login ghcr.io -u <utente-github> -p <token>
   ```

2. **Configura** il file `.env` in questa cartella:
   - `LICENSE_DEPLOYMENT_ID`: scegli un nome per questa installazione
     (es. `acme-prod-01`)
   - `AUTH_SECRET`: un segreto casuale di almeno 32 caratteri
     (`openssl rand -hex 32`)

3. **Avvia**:

   ```bash
   docker compose up -d
   ```

4. **Attiva la licenza**: apri http://localhost:3000 - compare la schermata
   "Licenza richiesta".

   Per ottenere la chiave invia una email a **arcari.nicholas0@gmail.com**
   indicando il tuo `LICENSE_DEPLOYMENT_ID`: la chiave viene consegnata via
   email **in maniera sicura e tracciata**, emessa esclusivamente per il tuo
   deployment. Incollala una volta nella schermata: sblocca **entrambe** le
   applicazioni e resta salvata (`data/license.key`).

Fatto. SOC Toolkit su **http://localhost:3000**, OSINT Toolkit su
**http://localhost:3001**. Il primo utente registrato diventa amministratore.

## Rinnovo licenza

La licenza ha una scadenza. Prima della scadenza richiedi il rinnovo alla
stessa email: ricevi una chiave nuova da incollare sopra la vecchia nella
stessa schermata. Alla scadenza l'app si blocca ma **nessun dato viene perso**.

## Aggiornamenti

```bash
docker compose pull && docker compose up -d
```

## Esposizione in rete (opzionale)

Di default la suite ascolta su localhost. Per esporla nella tua rete mettila
dietro il tuo reverse proxy con TLS (nginx, Traefik, Caddy) puntando alle
porte 3000 e 3001, e imposta `AUTH_SECRET` per richiedere il login.

## Supporto

Problemi o domande: **arcari.nicholas0@gmail.com** (indica sempre il tuo
deployment id).
