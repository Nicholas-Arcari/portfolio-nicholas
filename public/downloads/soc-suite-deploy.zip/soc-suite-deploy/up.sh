#!/bin/sh
# One-command start for Linux and macOS.
#
# Registers the hostnames the suite is served on (soctoolkit, osinttoolkit) in
# your hosts file, then brings the containers up. Run this instead of
# `docker compose up -d` - it does the hosts step for you, once, and is safe to
# run again (it never adds a duplicate line). Any extra arguments are passed
# through to docker compose.
set -e
cd "$(dirname "$0")"

HOSTS="${DEPLOY_HOSTS_FILE:-/etc/hosts}"
ENTRY="127.0.0.1 soctoolkit osinttoolkit"

if grep -qiE "^[[:space:]]*127\.0\.0\.1[[:space:]].*(soctoolkit|osinttoolkit)" "$HOSTS" 2>/dev/null; then
  echo "Hostnames already registered in $HOSTS."
else
  echo "Registering 'soctoolkit' and 'osinttoolkit' in $HOSTS (may ask for your password)..."
  if [ -w "$HOSTS" ]; then
    printf '%s\n' "$ENTRY" >> "$HOSTS"
  else
    printf '%s\n' "$ENTRY" | sudo tee -a "$HOSTS" >/dev/null
  fi
fi

echo "Starting the suite..."
docker compose up -d "$@"

echo ""
echo "Done. Open  https://soctoolkit  (and https://osinttoolkit)."
echo "First visit shows a certificate warning (self-signed) - accept it to proceed."
