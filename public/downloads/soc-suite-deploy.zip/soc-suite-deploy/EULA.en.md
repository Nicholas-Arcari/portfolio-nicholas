# End User Licence Agreement (EULA) - SOC Suite

**Version 1.3 - effective from 2026-07-24**

> This is the official English translation of the Italian `EULA.md`. It is
> provided for the Licensee's benefit. In case of any discrepancy the Italian
> version prevails and is the sole binding text (see art. 13).

This End User Licence Agreement ("Agreement") is entered into between:

**Licensor:** Nicholas Arcari - email: arcari.nicholas0@gmail.com

and the natural or legal person who installs or uses the SOC Suite software
("Licensee"). By installing or using the software, the Licensee fully accepts
the terms below. If the Licensee does not accept them, it must not install or
use the software.

> **The software is licensed free of charge.** No consideration is due, either
> for the licence or for its renewal (see art. 7).

> Note: this document is a practical template and does not constitute legal
> advice. For continued use, review by a legal professional is recommended.

## 1. Definitions

- **Software**: the "SOC Suite" suite, comprising SOC Toolkit and OSINT Toolkit,
  distributed as Docker images, together with the accompanying documentation.
- **Licence key**: the token signed by the Licensor that enables use of the
  Software on a given deployment.
- **Deployment**: a single installation of the Software identified by the
  `LICENSE_DEPLOYMENT_ID` value chosen by the Licensee at installation time.
- **Documentation**: the documents accompanying the Software, including
  `README.md`, `ETHICS.md` and `THIRD_PARTY_NOTICES.md`.

## 2. Grant of licence

The Licensor grants the Licensee, **free of charge**, a non-exclusive,
non-transferable, non-sublicensable and revocable licence to:

- install and use the Software on the deployment for which the Licence key was
  issued;
- for the validity period stated in the Licence key (expiry included).

The licence is bound to the Deployment: the Licence key is valid only for the
`LICENSE_DEPLOYMENT_ID` for which it was issued.

## 3. Restrictions

The Licensee may not:

1. copy, distribute, resell, rent, lease or sublicense the Software or the
   Licence key to third parties;
2. modify, decompile, disassemble or reverse engineer the Software, save within
   the mandatory limits allowed by law;
3. remove, disable or circumvent the licence verification mechanism or any
   technical protection measure;
4. remove or alter copyright notices, trademarks or proprietary notices;
5. use the Software beyond the expiry of the Licence key without a valid renewal.

## 4. Ownership and third-party components

The Software is licensed, not assigned. The Licensor retains all right, title
and interest in the Software, including all intellectual property rights. This
Agreement transfers no ownership right to the Licensee.

The Software incorporates third-party (open source) software components, each
subject to its own licence, listed in the accompanying `THIRD_PARTY_NOTICES.md`
document. Such components remain the property of their respective holders and
are provided under the terms of their respective licences, which prevail over
this Agreement for the part relating to each component.

## 5. Lawful and ethical use

The Software is a cybersecurity tool intended for defensive activities, analysis
and authorised testing. The Licensee undertakes to use it solely in compliance
with applicable laws and with the conditions described in the accompanying
`ETHICS.md` document. In particular, the Licensee is solely responsible for
holding the authorisations required for the activities carried out through the
Software. All liability for any unlawful, unethical or unauthorised use of the
Software rests solely with the Licensee and not with the Licensor.

## 6. Personal data and data protection

The Software runs entirely on the Licensee's infrastructure. The Licensor does
not collect, receive or have access to the data processed with the Software: the
licence check is performed locally, with no outbound communication.

By using the Software - in particular the OSINT and analysis modules - the
Licensee may process personal data of third parties. With respect to such
processing, the **Licensee acts as an independent data controller** under
Regulation (EU) 2016/679 (GDPR) and applicable law, and is solely responsible
for: identifying a suitable legal basis; complying with the principles of
lawfulness, data minimisation and purpose limitation; providing information to
data subjects and handling the exercise of their rights. Since the Licensor does
not process such data on the Licensee's behalf, there is no processor
relationship between the parties and no agreement under Article 28 GDPR is
required. The Licensee shall indemnify the Licensor against any third-party
claim arising from data processing carried out through the Software in breach of
applicable law.

The only personal data processed by the Licensor are the email address and the
`LICENSE_DEPLOYMENT_ID` provided by the Licensee for the issuance of the Licence
key, processed solely to manage the licence and kept for as long as necessary
for that purpose.

## 7. Free of charge, support and availability

The Software is licensed **free of charge**: no consideration is due for the
licence, its activation or its renewal.

The Licensor is not obliged to provide support, maintenance, updates or fixes.
Any support activity is provided as a courtesy, with no obligation of result and
no guaranteed response times.

The Licensor may at any time modify, suspend or discontinue distribution of the
Software, or decline to issue new Licence keys, without this giving rise to any
obligation to compensate or indemnify. Licence keys already issued remain valid
until their natural expiry.

## 8. Renewal and termination

The licence terminates automatically on expiry of the Licence key. Renewal,
also free of charge, is subject to the issuance of a new key by the Licensor,
who is not obliged to grant it. The Licensor may terminate the Agreement as of
right in the event of a breach of the terms by the Licensee. On termination, the
Licensee must cease using the Software. Data generated by the Licensee remains
its property and on its server.

## 9. Disclaimer of warranties

To the maximum extent permitted by law, and given the gratuitous nature of the
grant, the Software is provided "as is", without warranties of any kind, express
or implied, including without limitation the warranties of merchantability,
fitness for a particular purpose and non-infringement of third-party rights. The
Licensor does not warrant that the Software is error-free or fit for the
Licensee's specific needs. Any mandatory warranties and rights provided by law
in favour of the Licensee remain unaffected; this Agreement does not intend to
exclude or limit them.

## 10. Limitation of liability

To the maximum extent permitted by law, the Licensor is not liable for any
direct, indirect, incidental, special or consequential damage arising from the
use or inability to use the Software, including loss of data, business
interruption or loss of profit.

As this is a gratuitous grant, the Licensor is liable only within the limits
provided by law for services rendered without consideration. These exclusions
and limitations **do not apply in the event of the Licensor's wilful misconduct
or gross negligence, nor in any other case where liability cannot be excluded or
limited by law** (art. 1229 of the Italian Civil Code).

## 11. Governing law and jurisdiction

This Agreement is governed by Italian law. Any dispute is subject to the
exclusive jurisdiction of the court of the place where the Licensor is resident,
save for the application of the mandatory consumer-protection rules that apply
where the Licensee acts for purposes outside its trade or profession.

## 12. Specific approval of clauses (arts. 1341-1342 Italian Civil Code)

Under and for the purposes of arts. 1341 and 1342 of the Italian Civil Code,
the Licensee declares that, after careful reading, it specifically approves the
following clauses: art. 2 (prohibition of assignment and sublicensing;
revocability), art. 3 (use restrictions), art. 7 (right to discontinue
distribution and absence of support obligations), art. 8 (termination as of
right and absence of any renewal obligation), art. 9 (disclaimer of warranties),
art. 10 (limitation of liability), art. 11 (exclusive jurisdiction). Specific
approval is given by the second signature in the acceptance form.

## 13. Language

This Agreement is drafted in Italian. An English translation (`EULA.en.md`) is
provided for the Licensee's benefit. In the event of any discrepancy,
inconsistency or interpretive doubt between the two versions, the Italian
version prevails and constitutes the sole binding text.

## 14. Contact

For licences, renewals or requests: **arcari.nicholas0@gmail.com**
