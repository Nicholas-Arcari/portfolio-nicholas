# Stop the suite (Windows/PowerShell). Extra arguments pass through to docker
# compose, e.g. `.\down.ps1 -v` also removes the data volumes.
#
# The soctoolkit/osinttoolkit lines in the hosts file are left in place: they
# are harmless and let the next .\up.ps1 start without asking again.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
docker compose down @args
