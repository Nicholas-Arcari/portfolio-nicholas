# Restore SOC Suite data from a backup archive (Windows/PowerShell).
# Mirrors restore.sh. Overwrites the current volumes with the backup contents.
#
# Usage:  .\restore.ps1 <soc-suite-backup-YYYYmmdd-HHmmss.tar.gz>
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# Honour COMPOSE_PROJECT_NAME so a second deployment on the same host
# backs up its own volumes and not another stack's.
$project = if ($env:COMPOSE_PROJECT_NAME) { $env:COMPOSE_PROJECT_NAME } else { "soc-suite" }
if ($args.Count -lt 1) {
  Write-Host "usage: .\restore.ps1 <backup-file.tar.gz>"; exit 1
}
$archive = $args[0]
if (-not (Test-Path $archive)) { Write-Host "file not found: $archive"; exit 1 }
$archiveAbs = (Resolve-Path $archive).Path
$archiveDir = Split-Path -Parent $archiveAbs
$archiveName = Split-Path -Leaf $archiveAbs

$reply = Read-Host "This overwrites current data with '$archiveName'. Continue? [y/N]"
if ($reply -ne "y" -and $reply -ne "Y") { Write-Host "Aborted."; exit 0 }

Write-Host "Stopping the suite..."
docker compose stop

Write-Host "Restoring volumes..."
docker run --rm `
  -v "${project}_soc-data:/data/soc-data" `
  -v "${project}_osint-data:/data/osint-data" `
  -v "${project}_license-data:/data/license-data" `
  -v "${archiveDir}:/backup:ro" `
  alpine sh -c "cd /data && tar xzf /backup/$archiveName"

Write-Host "Restore complete. Start the suite again with:  .\up.ps1"
