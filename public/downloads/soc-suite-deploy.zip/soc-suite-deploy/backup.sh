#!/bin/sh
# Back up all SOC Suite data into a single timestamped archive.
#
# Saves the three Docker volumes the suite uses - user accounts and cache
# (soc-data, osint-data) and the activated licence (license-data) - into one
# .tar.gz you can copy off the server. Safe to run while the suite is up:
# SQLite tolerates a hot copy for backup purposes, but for a fully consistent
# snapshot run `docker compose stop` first.
#
# Usage:  ./backup.sh [output-dir]     (default: ./backups)
set -e

# Compose derives volume names from the project name, which defaults to the
# folder the stack runs from. Honour COMPOSE_PROJECT_NAME so a second
# deployment on the same host backs up its own volumes and not another
# stack's.
PROJECT="${COMPOSE_PROJECT_NAME:-soc-suite}"
OUT="${1:-./backups}"
mkdir -p "$OUT"
OUT_ABS=$(cd "$OUT" && pwd)
TS=$(date +%Y%m%d-%H%M%S)
NAME="soc-suite-backup-${TS}.tar.gz"

echo "Backing up volumes ${PROJECT}_{soc-data,osint-data,license-data}..."
docker run --rm \
  -v "${PROJECT}_soc-data:/data/soc-data:ro" \
  -v "${PROJECT}_osint-data:/data/osint-data:ro" \
  -v "${PROJECT}_license-data:/data/license-data:ro" \
  -v "${OUT_ABS}:/backup" \
  alpine tar czf "/backup/${NAME}" -C /data .

echo "Backup created: ${OUT_ABS}/${NAME}"
echo "Copy it somewhere safe, off this server."
