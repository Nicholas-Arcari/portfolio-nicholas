# Back up all SOC Suite data (Windows/PowerShell). Mirrors backup.sh.
#
# Saves the three Docker volumes (accounts, cache, activated licence) into one
# .tar.gz. Safe to run while the suite is up.
#
# Usage:  .\backup.ps1 [output-dir]     (default: .\backups)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

# Honour COMPOSE_PROJECT_NAME so a second deployment on the same host
# backs up its own volumes and not another stack's.
$project = if ($env:COMPOSE_PROJECT_NAME) { $env:COMPOSE_PROJECT_NAME } else { "soc-suite" }
$out = if ($args.Count -ge 1) { $args[0] } else { "backups" }
New-Item -ItemType Directory -Force -Path $out | Out-Null
$outAbs = (Resolve-Path $out).Path
$ts = Get-Date -Format "yyyyMMdd-HHmmss"
$name = "soc-suite-backup-$ts.tar.gz"

Write-Host "Backing up volumes ${project}_{soc-data,osint-data,license-data}..."
docker run --rm `
  -v "${project}_soc-data:/data/soc-data:ro" `
  -v "${project}_osint-data:/data/osint-data:ro" `
  -v "${project}_license-data:/data/license-data:ro" `
  -v "${outAbs}:/backup" `
  alpine tar czf "/backup/$name" -C /data .

Write-Host "Backup created: $outAbs\$name"
Write-Host "Copy it somewhere safe, off this server."
