#!/bin/sh
# Generate self-signed TLS certificates for the reverse proxy on first start.
#
# Runs once (the reverse-proxy waits for it). Creates a tiny local CA and a
# server certificate valid for both hostnames, so the suite is served over
# HTTPS at https://soctoolkit and https://osinttoolkit with no external tools.
# The browser will warn about the self-signed certificate until the customer
# installs certs/ca.crt (optional). Idempotent: if the certs already exist it
# does nothing, so restarts and `docker compose up` are safe.
set -e

CERT_DIR=/certs
NAMES="soctoolkit osinttoolkit"

if [ -f "$CERT_DIR/soctoolkit.pem" ] && [ -f "$CERT_DIR/osinttoolkit.pem" ]; then
  echo "TLS certificates already present in $CERT_DIR - nothing to do."
  exit 0
fi

command -v openssl >/dev/null 2>&1 || apk add --no-cache openssl
mkdir -p "$CERT_DIR"
cd "$CERT_DIR"

echo "Generating a local CA and a self-signed certificate for: $NAMES"

# Local CA (used to sign the server cert; install ca.crt to remove the warning).
openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
  -keyout ca.key -out ca.crt -subj "/CN=SOC Suite Local CA"

# Server key + CSR, signed by the CA with both hostnames as SANs.
openssl req -newkey rsa:2048 -nodes -keyout server.key -out server.csr \
  -subj "/CN=soctoolkit"
printf "subjectAltName=DNS:soctoolkit,DNS:osinttoolkit\n" > san.cnf
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
  -days 825 -extfile san.cnf -out server.crt

# The proxy config expects one cert/key pair per hostname; the same server
# certificate covers both names (SANs), so point both at it.
for name in $NAMES; do
  cp server.crt "$name.pem"
  cp server.key "$name-key.pem"
done

rm -f server.csr san.cnf
echo "Done. Certificates are in $CERT_DIR. To trust them (optional, removes the"
echo "browser warning), install ca.crt on the client machines."
