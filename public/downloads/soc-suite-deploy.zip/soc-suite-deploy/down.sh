#!/bin/sh
# Stop the suite (Linux/macOS). Extra arguments pass through to docker compose,
# e.g. `./down.sh -v` also removes the data volumes.
#
# The soctoolkit/osinttoolkit lines in your hosts file are left in place: they
# are harmless and let the next `./up.sh` start without asking again. To remove
# them, delete the "127.0.0.1 soctoolkit osinttoolkit" line from your hosts file.
set -e
cd "$(dirname "$0")"
docker compose down "$@"
