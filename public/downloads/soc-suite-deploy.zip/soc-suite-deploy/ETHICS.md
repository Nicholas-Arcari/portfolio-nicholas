# Politica di uso etico

> **Questo toolkit e' destinato esclusivamente ad attivita' autorizzate di security testing,
> incident response e ricerca.** Utilizzarlo contro sistemi, reti, account o persone senza un
> permesso documentato e' illecito nella maggior parte degli ordinamenti e **non e' un caso d'uso
> supportato** da questo progetto.

Questo documento integra - ma **non deroga** - la licenza proprietaria contenuta in
[`LICENSE`](./LICENSE). Esprime l'intento dell'autore su come il software debba essere utilizzato e
richiama il quadro normativo che disciplina gli abusi. Non costituisce consulenza legale. Se non
hai la certezza che un determinato utilizzo sia lecito nel tuo ordinamento, consulta un
professionista qualificato prima di eseguire qualsiasi scansione.

> Questa e' la traduzione italiana di `ETHICS.md`. E' la versione applicabile ai licenziatari
> italiani ed e' il documento richiamato dall'art. 5 dell'EULA.

## A chi si rivolge

Il progetto distribuisce due toolkit:

- **`soc-toolkit`** - flussi di lavoro difensivi eseguiti su elementi di cui gia' disponi (email di
  phishing recapitate alla tua casella abuse, file di log della tua infrastruttura, IOC che stai
  analizzando nell'ambito di un incident response). La maggior parte dei suoi moduli non si collega
  affatto a internet.
- **`osint-toolkit`** - ricognizione su un perimetro definito, con arricchimento da fonti pubbliche
  (passive DNS, certificate transparency) per impostazione predefinita. Il probing attivo e'
  subordinato a un flag di configurazione esplicito.

Entrambi i toolkit presuppongono che l'operatore agisca in uno dei ruoli seguenti:

1. **Difensore interno** - analisi di asset di proprieta' del proprio datore di lavoro,
   nell'ambito delle proprie mansioni.
2. **Pentester / red teamer sotto contratto** - operante sulla base di un incarico sottoscritto
   che individua gli asset in perimetro.
3. **Ricercatore bug bounty** - operante entro l'ambito e le regole di ingaggio pubblicate da un
   programma di bug bounty pubblico o privato.
4. **Ricercatore / docente** - che utilizza dati di esempio, ambienti di laboratorio o bersagli
   esplicitamente autorizzati (ad esempio `scanme.nmap.org`, macchine virtuali volutamente
   vulnerabili).

Qualunque altro impiego - scansioni di sistemi altrui mosse dalla curiosita', il "vediamo un po'
cosa c'e' in giro", l'enumerazione passiva delle tracce online di un ex partner, la ricognizione ai
danni di un'azienda che semplicemente non ti sta simpatica - e' **fuori dall'ambito** di questo
progetto e puo' costituire reato.

## Quadro normativo

L'accesso non autorizzato a sistemi informatici e' penalmente rilevante in ogni ordinamento in cui
questo progetto possa verosimilmente essere utilizzato. Elenco non esaustivo e non vincolante delle
norme rilevanti:

- **Italia** - *Legge 23 dicembre 1993, n. 547*, che ha introdotto l'art. **615-ter** del Codice
  Penale ("Accesso abusivo ad un sistema informatico o telematico"). Le pene vanno dalla multa alla
  reclusione fino a tre anni, con circostanze aggravanti per i sistemi di interesse pubblico.
  L'art. **617-quater** riguarda l'intercettazione abusiva di comunicazioni; l'art. **635-bis** il
  danneggiamento di sistemi informatici.
- **Unione Europea** - **GDPR (Regolamento 2016/679)**. Il trattamento di dati personali raccolti o
  enumerati durante attivita' OSINT richiede una base giuridica ai sensi dell'**art. 6**
  (tipicamente il 6(1)(f), "legittimo interesse", per la ricerca in ambito sicurezza, da bilanciare
  con i diritti degli interessati). L'OSINT che fa emergere dati personali - username, email,
  credenziali esposte in violazioni - e' trattamento regolato, non un'attivita' libera. Si vedano i
  test di bilanciamento previsti dall'art. 6(1)(f) e, ove pertinente, l'esenzione per uso
  domestico, che **non** copre l'attivita' professionale o commerciale in ambito sicurezza.
- **Stati Uniti** - **Computer Fraud and Abuse Act (18 U.S.C. § 1030)**. L'accesso non autorizzato
  a un "protected computer" (nozione ampia) e' reato federale. La giurisprudenza recente
  (*Van Buren v. United States*, 2021) ha ristretto la nozione di "eccesso rispetto all'accesso
  autorizzato", ma non quella di accesso non autorizzato.
- **Regno Unito** - **Computer Misuse Act 1990**. Sezione 1 (accesso non autorizzato), sezione 3
  (atti non autorizzati con intento di danneggiamento), sezione 3A (produzione e fornitura di
  strumenti destinati alla commissione di reati: da leggere con attenzione se si distribuiscono
  build).
- Molti altri ordinamenti prevedono norme analoghe (Germania, StGB §§ 202a-202c; Francia, Code
  penal art. 323-1; Australia, Criminal Code Division 477). Se esegui scansioni che attraversano
  piu' giurisdizioni, presumi che si applichi il regime piu' restrittivo.

## Cosa fa e cosa non fa questo toolkit

**Passivo per impostazione predefinita.** L'enumerazione dei sottodomini dell'OSINT toolkit, nella
configurazione di base, consulta i log di certificate transparency e gli aggregatori di passive
DNS: nessun traffico viene mai inviato al bersaglio. Eseguirla su `example.com` non comporta alcun
costo per `example.com`. Questa e' la modalita' prevista per la build pubblica.

**La scansione attiva e' subordinata a controlli.** Il flag di configurazione
`enable_active_scanning` e' l'interruttore generale; l'avvio delle singole scansioni richiede
inoltre che il bersaglio sia contrassegnato come "autorizzato alla scansione" nell'interfaccia. In
modalita' attiva il sistema si appoggia ad Amass o Subfinder, se installati: nessuno dei due e'
incluso nel pacchetto. La finestra di conferma richiede all'operatore di digitare il nome del
bersaglio per esteso. Questi attriti sono voluti: esistono affinche' "ho premuto il pulsante
sbagliato" non possa diventare "ho mandato in DDoS uno sconosciuto".

**Qui non c'e' nulla che sia uno zero-day, un C2 o un framework di exploitation.** Il progetto
acquisisce evidenze e arricchisce indicatori. Non recapita payload.

**Le funzionalita' investigative della v1.0.2 restano entro questi limiti.** Alcune capacita'
aggiunte in questa release meritano una menzione esplicita:

- **Investigazione su persona** (`osint-toolkit`) correla un'email o un nome esclusivamente su
  fonti *pubbliche*: Gravatar, controlli MX e su domini usa e getta, candidati username derivati e
  verificati su pagine di profilo pubbliche, e ricerche su violazioni note (HIBP). I link "dork"
  verso i motori di ricerca che produce sono **link che l'operatore clicca**, mai oggetto di
  scraping automatico. Non fa emergere alcun dato che l'interessato non abbia gia' reso pubblico,
  applica la minimizzazione dei dati e l'interfaccia richiede all'operatore di dichiarare una base
  giuridica prima dell'esecuzione. Profilare una persona privata rispetto alla quale non hai alcun
  legittimo interesse a indagare e' esattamente l'abuso del tipo "tracce online dell'ex partner"
  che questa politica vieta.
- **Fingerprinting di siti web** (`osint-toolkit`) e' ricognizione *attiva*: invia richieste HTTP
  al bersaglio per identificarne lo stack software. Per questo e' subordinato a una
  **dichiarazione di autorizzazione per singola richiesta** (l'API risponde `403` in sua assenza) e
  a una protezione anti-SSRF che rifiuta indirizzi privati, di loopback, link-local e riservati.
- **Analisi di link e QR code** (`soc-toolkit`) e' difensiva: esamina per conto dell'analista un
  URL o un payload QR sospetto. Il tracciatore di redirect e' protetto da SSRF e limitato nel
  numero di salti, cosi' che il server non possa essere trasformato in un proxy di scansione
  aperto.
- **Ispezione dei file** (`soc-toolkit`) e' interamente statica: individua incongruenze di tipo,
  IOC incorporati ed euristiche su macro e file polyglot senza mai eseguire il campione.

## Regole di ingaggio che ci aspettiamo vengano rispettate

1. **Disciplina del perimetro.** Non proporre funzionalita' che rendano piu' semplice operare al di
   fuori di un perimetro definito (ad esempio l'individuazione automatica di bersagli che spazzoli
   intervalli CIDR arbitrari senza intervento dell'operatore).
2. **Nessuna ritorsione o hack-back.** Non saranno accettate funzionalita' che generino traffico
   verso l'infrastruttura di un attaccante. Analisi si', ritorsione no.
3. **Nessuna messinscena di evasione dei controlli per attaccare altri.** Le funzioni di OPSEC che
   proteggono un legittimo difensore dai propri stessi allarmi vanno bene. Non vanno bene le
   funzioni il cui unico impiego sia eludere le difese del bersaglio mentre lo si attacca.
4. **Rispetto dei rate limit e dei termini di servizio** delle API integrate. Se una fonte dichiara
   "non utilizzare questi dati per X", noi lo rispettiamo, anche quando e' improbabile che venga
   fatto valere.
5. **Minimizzazione della raccolta.** Se una funzione puo' rispondere alla domanda dell'analista
   con meno dati personali, deve farlo.

## Segnalare abusi o vulnerabilita'

- **Vulnerabilita' in questo toolkit**: scrivi al manutentore (vedi i metadati del repository). Non
  aprire una issue pubblica per bug di sicurezza non ancora corretti.
- **Prove che qualcuno stia usando impropriamente questo toolkit contro di te o la tua
  organizzazione**: conserva i log e rivolgiti alle autorita' competenti. L'autore non e' nella
  posizione di mediare tra operatori e bersagli.

---

*Questa politica si applica alla versione corrente e a tutte le versioni future di `sec-toolkit`,
salvo espressa sostituzione. Ultima revisione: 2026-07-24.*
