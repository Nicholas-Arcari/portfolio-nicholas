# SOC Suite - Installation guide

> Versione italiana: `README.md`

On-premise suite for security operations: **SOC Toolkit** (phishing triage, log
analysis, IOC, YARA/Sigma, file inspector) + **OSINT Toolkit** (attack surface
and investigative OSINT). Everything runs on YOUR server: no data leaves your
infrastructure and the licence is verified locally, with no outbound
connections.

## Requirements

- A Linux server (or macOS/Windows with WSL2) with **Docker** and **Docker Compose**
- 4 GB of RAM recommended
- Internet access only for the first image download

## Installation (4 steps)

1. **Configure** the `.env` file in this folder:
   - `LICENSE_DEPLOYMENT_ID`: choose a name for this installation
     (e.g. `acme-prod-01`)
   - `AUTH_SECRET`: a random secret of at least 32 characters
     (`openssl rand -hex 32`)

2. **Add the names** to your machine's hosts file, so the browser knows where to
   find `soctoolkit` and `osinttoolkit`:

   - Linux/macOS: `echo "127.0.0.1 soctoolkit osinttoolkit" | sudo tee -a /etc/hosts`
   - Windows: open `C:\Windows\System32\drivers\etc\hosts` as administrator and
     add the line `127.0.0.1 soctoolkit osinttoolkit`

   (If you install it on a server and access it from other PCs, use the server's
   IP instead of `127.0.0.1`, or add the two names to your internal DNS.)

3. **Start** (the images are downloaded automatically, no login required). On
   first start the HTTPS certificates are generated:

   ```bash
   docker compose up -d
   ```

4. **Activate the licence**: open **https://soctoolkit** in your browser. The
   first time, the browser shows a security warning (the certificate is
   self-signed): accept it to proceed. The "Licence required" screen appears.

   To get the key, send an email to **arcari.nicholas0@gmail.com** with your
   `LICENSE_DEPLOYMENT_ID`: the key is delivered by email **securely and with
   tracking**, issued exclusively for your deployment. Paste it once on the
   screen: it unlocks **both** applications and stays saved (`data/license.key`).

Done. SOC Toolkit at **https://soctoolkit**, OSINT Toolkit at
**https://osinttoolkit**. The first registered user becomes the administrator.

### Removing the browser warning (optional)

The first start creates a `certs/` folder with a `ca.crt` file. Installing it
among the "trusted root certification authorities" of the machines you connect
from removes the warning. It is optional: the connection stays encrypted even if
you just accept the warning.

## Licence renewal

The licence has an expiry date. Before it expires, request a renewal at the same
email: you receive a new key to paste over the old one on the same screen. When
it expires the app locks but **no data is lost**.

## Updates

```bash
docker compose pull && docker compose up -d
```

## Network exposure

The suite is already served over HTTPS by the included reverse proxy (ports 80
and 443). To access it from other PCs on the network, use the server's IP in the
clients' hosts file (or your internal DNS) and set `AUTH_SECRET` to require
login. If you wish, you can replace the self-signed certificates in `certs/`
with your own corporate certificates (same file names).

## Licence and documents

Use of the software is governed by the licence agreement in `EULA.md`, included
in this folder. By installing or using the suite you accept its terms. This
folder also contains:

- `EULA.md` - end user licence agreement (binding text); `EULA.en.md` is its
  official English translation
- `ETHICS.md` - lawful and ethical use policy (referenced by the EULA: the suite
  must only be used on systems and data you are authorised to test)
- `THIRD_PARTY_NOTICES.md` - third-party open source components included in the
  product and their licences

## Support

Problems or questions: **arcari.nicholas0@gmail.com** (always include your
deployment id).
