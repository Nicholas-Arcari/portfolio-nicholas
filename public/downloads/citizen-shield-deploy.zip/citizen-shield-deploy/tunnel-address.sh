#!/bin/sh
# Scrive l'indirizzo pubblico che il tunnel ha ricevuto, dove il backend lo legge.
#
# Perche' serve. Un tunnel "al volo" (senza account e senza dominio) riceve un
# nome diverso a ogni avvio: oggi cinque-parole-a-caso.trycloudflare.com, domani
# un altro. Se quell'indirizzo dovesse finire a mano nel .env, ogni riavvio del
# PC vorrebbe dire riaprire un file e rifare ./up.sh - e nel frattempo i link
# esca appena creati punterebbero a un posto che non esiste piu'.
#
# Come. cloudflared espone le proprie metriche su una porta interna, e fra
# quelle il nome che gli e' stato assegnato. Qui viene interrogato quello, non
# il log: il formato del log e' una cornice di trattini fatta per gli occhi e
# cambia fra le versioni, l'endpoint no.
#
# Chi ha un tunnel con nome (con un proprio dominio) non ha niente da scoprire:
# l'indirizzo e' sempre lo stesso e sta gia' in DECOY_PUBLIC_BASE. In quel caso
# questo script se ne accorge e smette, senza rumore.
set -eu

METRICS="${TUNNEL_METRICS_URL:-http://decoy-tunnel:2000/quicktunnel}"
OUT="${DECOY_PUBLIC_BASE_FILE:-/run/decoy/public-base}"
TMP="${OUT}.new"

# Il file e' la sola cosa che dice "l'esca e' raggiungibile da fuori". Se questo
# processo se ne va - tunnel fermato, stack spento - deve sparire con lui,
# altrimenti il pannello continuerebbe a dichiarare raggiungibile un indirizzo
# che non risponde piu' e l'utente consegnerebbe link morti convinto del
# contrario.
cleanup() {
    rm -f "$TMP" "$OUT"
    echo "indirizzo pubblico ritirato: il tunnel non e' piu' attivo"
}
trap cleanup EXIT INT TERM

mkdir -p "$(dirname "$OUT")"
rm -f "$OUT"

current=""
missing=0

while :; do
    body="$(wget -q -T 5 -O - "$METRICS" 2>/dev/null || true)"
    host="$(printf '%s' "$body" | sed -n 's/.*"hostname":"\([^"]*\)".*/\1/p')"

    # Deve somigliare a un nome di host e nient'altro: quello che esce di qui
    # finisce in un URL, in un QR code e poi in una denuncia.
    case "$host" in
        *[!a-zA-Z0-9.-]* | "" | *..* | .* | -*)
            host=""
            ;;
        *.*) ;;
        *) host="" ;;
    esac

    if [ -n "$host" ]; then
        missing=0
        if [ "$host" != "$current" ]; then
            # Scrittura atomica: il backend legge questo file a ogni richiesta e
            # non deve mai incontrarlo a meta'.
            printf 'https://%s\n' "$host" > "$TMP"
            mv -f "$TMP" "$OUT"
            current="$host"
            echo "i link esca ora escono da https://${host}"
        fi
    else
        missing=$((missing + 1))
        if [ -n "$current" ]; then
            rm -f "$OUT"
            current=""
            echo "il tunnel non risponde piu': i link esca tornano validi solo in rete locale"
        fi
        # Un tunnel con nome non ha un indirizzo "al volo" da dichiarare, quindi
        # questo endpoint resta vuoto per sempre: dirlo una volta e restare in
        # ascolto e' meglio che riempire il log di allarmi su una cosa normale.
        if [ "$missing" = 6 ]; then
            if [ -n "${DECOY_PUBLIC_BASE:-}" ]; then
                echo "tunnel con nome: l'indirizzo e' quello in DECOY_PUBLIC_BASE, niente da scoprire"
                # Il trap cancellerebbe il file, che qui non e' nostro: non ne
                # abbiamo mai scritto uno.
                trap - EXIT INT TERM
                exit 0
            fi
            echo "ATTENZIONE: il tunnel non ha ancora comunicato un indirizzo pubblico." >&2
            echo "            Controlla i log con: docker compose logs decoy-tunnel" >&2
        fi
    fi

    sleep 10
done
