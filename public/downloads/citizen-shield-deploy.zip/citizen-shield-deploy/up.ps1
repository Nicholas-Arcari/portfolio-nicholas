# One-command start for Windows (PowerShell).
#
# Registers the hostname the control plane is served on (citizenshield) in the
# Windows hosts file, then brings the containers up. Run this instead of
# `docker compose up -d`. Editing the hosts file needs administrator rights, so
# the script re-launches itself elevated the first time (accept the UAC prompt).
# Safe to run again - it never adds a duplicate line.
#
# If PowerShell blocks the script, start it with:
#   powershell -ExecutionPolicy Bypass -File .\up.ps1
#
#   .\up.ps1            solo rete locale
#   .\up.ps1 -Tunnel    pubblica anche il link esca, per chi deve aprirlo da
#                       fuori casa (vedi docker-compose.tunnel.yml)
param([switch]$Tunnel)

$ErrorActionPreference = "Stop"

$composeFiles = @("-f", "docker-compose.yml")
if ($Tunnel) {
  $composeFiles += @("-f", "docker-compose.tunnel.yml")
}

$hostsPath = Join-Path $env:SystemRoot "System32\drivers\etc\hosts"
$entry = "127.0.0.1 citizenshield"

$isAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent() `
  ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

$already = (Test-Path $hostsPath) -and `
  (Select-String -Path $hostsPath -Pattern "citizenshield" -Quiet)

if (-not $already) {
  if (-not $isAdmin) {
    Write-Host "Registering the hostname needs administrator rights - elevating (accept the prompt)..."
    # -Tunnel va riportato nella copia elevata: senza, chi lancia il tunnel al
    # primo avvio lo vedrebbe sparire proprio nel passaggio dei permessi, e lo
    # stack ripartirebbe in sola rete locale senza dire niente.
    $relaunch = @("-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"")
    if ($Tunnel) { $relaunch += "-Tunnel" }
    Start-Process powershell -Verb RunAs -ArgumentList $relaunch
    exit
  }
  Write-Host "Registering 'citizenshield' in the hosts file..."
  Add-Content -Path $hostsPath -Value $entry
} else {
  Write-Host "Hostname already registered in the hosts file."
}

Set-Location $PSScriptRoot
Write-Host "Starting the control plane..."
docker compose @composeFiles up -d @args

Write-Host ""
Write-Host "Done. Open  https://citizenshield"
Write-Host "First visit shows a certificate warning (self-signed) - accept it to proceed."

if ($Tunnel) {
  Write-Host ""
  Write-Host "Tunnel attivo: il link esca si apre anche da fuori casa."
  Write-Host "L'indirizzo assegnato compare nella pagina Difesa Attiva del pannello."
  Write-Host "Il pannello di controllo NON e' pubblicato: dal tunnel passa solo /s/."
}
