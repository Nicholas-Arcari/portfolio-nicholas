#!/bin/sh
# Generate a self-signed TLS certificate for the reverse proxy on first start.
#
# Runs once (the reverse-proxy waits for it). Creates a tiny local CA and a
# server certificate for the hostname, so the control plane is served over
# HTTPS at https://citizenshield with no external tools. The browser warns
# about the self-signed certificate until the customer installs certs/ca.crt
# (optional). Idempotent: if the certs already exist it does nothing.
set -e

CERT_DIR=/certs
NAME=citizenshield

if [ -f "$CERT_DIR/$NAME.pem" ]; then
  echo "TLS certificate already present in $CERT_DIR - nothing to do."
  exit 0
fi

command -v openssl >/dev/null 2>&1 || apk add --no-cache openssl
mkdir -p "$CERT_DIR"
cd "$CERT_DIR"

echo "Generating a local CA and a self-signed certificate for: $NAME"

# Local CA (used to sign the server cert; install ca.crt to remove the warning).
# keyUsage is not optional here even though browsers tolerate its absence:
# OpenSSL's strict verification - the path Python and Go clients take - rejects
# a CA without it ("CA cert does not include key usage extension"), which is
# what stopped the local agent from ever reaching the API.
openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
  -keyout ca.key -out ca.crt -subj "/CN=Citizen Shield Local CA" \
  -addext "basicConstraints=critical,CA:TRUE" \
  -addext "keyUsage=critical,keyCertSign,cRLSign"

# Server key + CSR, signed by the CA with the hostname as SAN.
openssl req -newkey rsa:2048 -nodes -keyout server.key -out server.csr \
  -subj "/CN=$NAME"
# Same reasoning for the leaf: a strict verifier wants to be told this is not
# a CA and that the key may be used for server authentication.
{
  printf "subjectAltName=DNS:%s\n" "$NAME"
  printf "basicConstraints=critical,CA:FALSE\n"
  printf "keyUsage=critical,digitalSignature,keyEncipherment\n"
  printf "extendedKeyUsage=serverAuth\n"
} > san.cnf
openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key -CAcreateserial \
  -days 825 -extfile san.cnf -out server.crt

cp server.crt "$NAME.pem"
cp server.key "$NAME-key.pem"

rm -f server.csr san.cnf
echo "Done. Certificates are in $CERT_DIR. To trust them (optional, removes the"
echo "browser warning), install ca.crt on the client machines."
