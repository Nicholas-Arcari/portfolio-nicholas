#!/bin/sh
# Stop the control plane (Linux/macOS). Extra arguments pass through to docker
# compose, e.g. `./down.sh -v` also removes the data volumes (Postgres + data).
#
# The citizenshield line in your hosts file is left in place: it is harmless and
# lets the next `./up.sh` start without asking again.
set -e
cd "$(dirname "$0")"
# Anche il file del tunnel, sempre: senza, `./down.sh -v` non saprebbe che il
# volume con l'indirizzo pubblico esiste e lo lascerebbe indietro. Elencarlo
# quando il tunnel non e' mai partito non fa alcun danno.
docker compose -f docker-compose.yml -f docker-compose.tunnel.yml down "$@"
