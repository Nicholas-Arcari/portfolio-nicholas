#!/bin/sh
# One-command start for Linux and macOS.
#
# Registers the hostname the control plane is served on (citizenshield) in your
# hosts file, then brings the containers up. Run this instead of
# `docker compose up -d` - it does the hosts step for you, once, and is safe to
# run again (it never adds a duplicate line). Extra arguments pass through to
# docker compose.
#
#   ./up.sh              solo rete locale
#   ./up.sh --tunnel     pubblica anche il link esca, per chi deve aprirlo da
#                        fuori casa (vedi docker-compose.tunnel.yml)
set -e
cd "$(dirname "$0")"

# --tunnel non e' un'opzione di docker compose: va tolta dagli argomenti prima
# di passargli il resto.
COMPOSE_FILES="-f docker-compose.yml"
TUNNEL=0
ARGS=""
for arg in "$@"; do
  if [ "$arg" = "--tunnel" ]; then
    TUNNEL=1
  else
    ARGS="$ARGS $arg"
  fi
done
if [ "$TUNNEL" = 1 ]; then
  COMPOSE_FILES="$COMPOSE_FILES -f docker-compose.tunnel.yml"
fi

HOSTS="${DEPLOY_HOSTS_FILE:-/etc/hosts}"
ENTRY="127.0.0.1 citizenshield"

if grep -qiE "^[[:space:]]*127\.0\.0\.1[[:space:]].*citizenshield" "$HOSTS" 2>/dev/null; then
  echo "Hostname already registered in $HOSTS."
else
  echo "Registering 'citizenshield' in $HOSTS (may ask for your password)..."
  if [ -w "$HOSTS" ]; then
    printf '%s\n' "$ENTRY" >> "$HOSTS"
  else
    printf '%s\n' "$ENTRY" | sudo tee -a "$HOSTS" >/dev/null
  fi
fi

echo "Starting the control plane..."
# shellcheck disable=SC2086 # gli argomenti vanno divisi apposta
docker compose $COMPOSE_FILES up -d $ARGS

echo ""
echo "Done. Open  https://citizenshield"
echo "First visit shows a certificate warning (self-signed) - accept it to proceed."

if [ "$TUNNEL" = 1 ]; then
  echo ""
  echo "Tunnel attivo: il link esca si apre anche da fuori casa."
  echo "L'indirizzo assegnato compare nella pagina Difesa Attiva del pannello."
  echo "Il pannello di controllo NON e' pubblicato: dal tunnel passa solo /s/."
fi
