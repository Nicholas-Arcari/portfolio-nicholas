# Stop the control plane (Windows/PowerShell). Extra arguments pass through to
# docker compose, e.g. `.\down.ps1 -v` also removes the data volumes.
#
# The citizenshield line in the hosts file is left in place: it is harmless and
# lets the next .\up.ps1 start without asking again.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
# Anche il file del tunnel, sempre: senza, `.\down.ps1 -v` non saprebbe che il
# volume con l'indirizzo pubblico esiste e lo lascerebbe indietro. Elencarlo
# quando il tunnel non e' mai partito non fa alcun danno.
docker compose -f docker-compose.yml -f docker-compose.tunnel.yml down @args
