# Restore Citizen Shield data from a backup folder (Windows/PowerShell).
# Mirrors restore.sh. Replaces the current database and backend data.
#
# Usage:  .\restore.ps1 <citizen-shield-backup-YYYYmmdd-HHmmss>
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$project = "citizen-shield"
if ($args.Count -lt 1) {
  Write-Host "usage: .\restore.ps1 <backup-folder>"; exit 1
}
$dir = (Resolve-Path $args[0]).Path
if (-not (Test-Path "$dir\db.sql.gz") -or -not (Test-Path "$dir\backend-data.tar.gz")) {
  Write-Host "backup folder must contain db.sql.gz and backend-data.tar.gz"; exit 1
}

$reply = Read-Host "This overwrites the current database and data. Continue? [y/N]"
if ($reply -ne "y" -and $reply -ne "Y") { Write-Host "Aborted."; exit 0 }

Write-Host "Restoring the Postgres database..."
docker compose cp "$dir\db.sql.gz" postgres:/tmp/db.sql.gz
docker compose exec -T postgres sh -c "gunzip -c /tmp/db.sql.gz | psql -U shield -d citizen_shield" | Out-Null
docker compose exec -T postgres rm -f /tmp/db.sql.gz

Write-Host "Stopping the backend to replace its data volume..."
docker compose stop backend
docker run --rm `
  -v "${project}_backend-data:/data" `
  -v "${dir}:/backup:ro" `
  alpine sh -c "cd /data && tar xzf /backup/backend-data.tar.gz"

Write-Host "Restore complete. Restart everything with:  .\up.ps1"
