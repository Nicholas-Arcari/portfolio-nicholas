# Ethical Use Policy — Citizen Shield

> **Citizen Shield is a self-defense tool for people who are being harassed,
> stalked, or spied on.** It is meant to help you check *your own* devices,
> accounts and online footprint, and to organise evidence of what is being done
> *to you* — so you can take it to a lawyer or the police. Using it to
> investigate, surveil, locate, or "hack back" another person is **not a
> supported use case** and is illegal in most jurisdictions.

> Italian version: `ETHICS.md` (the binding one, referenced by article 5 of
> the EULA).

This document supplements — but does **not** override — the license in
[`LICENSE`](./LICENSE) and the [`EULA.md`](./EULA.md). It is a statement of
author intent, not legal advice. If you are unsure whether a specific use is
lawful where you live, consult qualified counsel.

## Who this is for

Citizen Shield assumes the operator is a **victim (or someone helping a victim
with their consent)** acting on assets and data they are entitled to examine:

1. **Your own devices** — your phone, your laptop, your home network.
2. **Your own accounts** — your Google/Apple/Microsoft identity, your browser
   profiles, your email forwarding rules.
3. **Your own online footprint** — accounts and data about *you* that are
   publicly reachable.
4. **Evidence directed at you** — messages, links, images, canary-link hits and
   metadata relating to harassment you are receiving.

Anything else — profiling an ex-partner, geolocating the person you're afraid
of, breaking into someone else's account "to get proof", retaliating against
attacker infrastructure — is **out of scope** and may be a crime, even when you
are the victim.

## The line between defense and offense

Being a victim does **not** create a legal right to attack back. Concretely:

- **Investigate inward, not outward.** Citizen Shield checks *your* machine for
  RATs (Module 9), *your* network for rogue devices (Module 4), *your* browser
  and cloud identity (Module 7), *your* phone for stalkerware (Module 8). It does
  not scan, probe, or enumerate the other person's systems.
- **Canary tokens are traps, not tracking of an innocent.** The Active Defense
  module (Module 10) creates decoy links *you* place where an intruder might
  look. It records who fetches *your* trap. Do not use it to bait or entrap an
  uninvolved third party.
- **No hack-back.** There is deliberately no feature that sends traffic against
  attacker infrastructure. Collect and preserve; do not retaliate.
- **Do not confront the attacker with the output.** Beyond the legal risk, it
  can escalate the danger to you. Take the report to professionals instead.

## Legal landscape (non-exhaustive, non-authoritative)

- **Italy** — *stalking* is punished under **art. 612-bis c.p.**; unauthorised
  access to a computer system under **art. 615-ter c.p.**; unlawful interception
  under **art. 617-quater c.p.**; non-consensual sharing of sexually explicit
  images under **art. 612-ter c.p.**. Evidence of these offences committed
  against you is exactly what this tool helps you preserve for a *denuncia*.
- **EU — GDPR (Reg. 2016/679).** Data you collect about the person harassing you
  is personal data. When collected to establish, exercise or defend a legal
  claim, the lawful basis is typically **art. 6(1)(f)** (legitimate interest)
  and, for special categories, **art. 9(2)(f)** (legal claims). Minimise what you
  collect and keep it only as long as needed for the proceedings.
- **Reporting.** Bring your findings to the **Polizia Postale** (or your local
  cybercrime unit) and/or a lawyer. In Italy, anti-violence and stalking support:
  **1522** (free, 24/7). Immediate danger: **112**.

## What the tool does and does not claim

- **Preliminary triage, not certified forensics.** It runs without hardware
  write-blockers on your own (possibly compromised) device. Its reports help
  establish probable cause for a *formal* forensic acquisition performed by a
  certified expert — they are not themselves a certified chain of custody.
- **Best-effort detection.** Signature lists (stalkerware, RATs, malicious
  extensions) are small and public. A negative result is reassuring but **not a
  guarantee** that nothing is wrong. Trust your instincts and seek help anyway.
- **Not an exploitation or surveillance framework.** It ingests and organises
  evidence you already have access to. It does not deliver payloads or track
  people.

## If you are in danger right now

Stop and get to safety first. Use the **Quick Exit** button (or press `Esc`
three times) to leave the app and wipe it from the browser. If you think the
computer you're on is being watched, use a **clean device** you trust, or boot a
live USB (Tails/Ubuntu), before running anything.

---

*This policy applies to the current and all future versions of Citizen Shield
unless explicitly superseded. Last reviewed: 2026-07-24.*
