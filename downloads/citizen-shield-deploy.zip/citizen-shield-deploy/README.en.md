# Citizen Shield - Installation guide (on-premise)

> Versione italiana: `README.md`

An **OPSEC, privacy and personal-defense** platform for victims of
cyberstalking, doxxing, sextortion and device compromise. In on-premise mode the
**control plane** (web dashboard + database) runs on YOUR server: no data leaves
your infrastructure and the licence is verified locally, with no outbound
connections.

The **local agents** (the nmap / sherlock / adb scans) stay a separate
component that users run on their own PCs: the dashboard shows the commands to
run. No scan ever originates from your server.

## Requirements

- A Linux server (or macOS/Windows with WSL2) with **Docker** and **Docker Compose**
- 4 GB of RAM recommended (the Postgres database is bundled in the package)
- Internet access only for the first image download

## Installation (3 steps)

1. **Configure**: copy `.env.example` to `.env` and fill it in:
   - `LICENSE_DEPLOYMENT_ID`: choose a name for this installation
     (e.g. `acme-prod-01`)
   - `AUTH_SECRET`, `APP_SECRET_KEY`: random secrets (`openssl rand -hex 32`)
   - `POSTGRES_PASSWORD`: a password of your choice for the database

2. **Start** with the included launcher: it registers the `citizenshield` name
   in your machine's hosts file for you and brings the containers up (pulling
   the images and generating the HTTPS certificates on first start). One
   command:

   - Linux/macOS: `./up.sh`  (asks for your password to write the hosts file)
   - Windows: right-click `up.ps1` -> "Run with PowerShell", or
     `powershell -ExecutionPolicy Bypass -File .\up.ps1` (accept the
     administrator prompt, needed for the hosts file)

   The launcher is safe to re-run and never duplicates the hosts line. To stop:
   `./down.sh` (Windows: `.\down.ps1`).

   > Manual method, as an alternative: add `127.0.0.1 citizenshield` to your
   > hosts file and run `docker compose up -d`. If you access it from other PCs
   > on the network, use the server's IP instead of `127.0.0.1` (or your
   > internal DNS).

3. **Activate the licence**: open **https://citizenshield** in your browser. The
   first time, the browser shows a security warning (self-signed certificate):
   accept it to proceed. The "Licence required" screen appears.

   To get the key, email **arcari.nicholas0@gmail.com** with your
   `LICENSE_DEPLOYMENT_ID`: the key is delivered by email securely and with
   tracking, issued exclusively for your deployment. Paste it once on the
   screen: it unlocks the application and stays saved.

Done. Control plane at **https://citizenshield**. The first registered user
becomes the administrator.

### Removing the browser warning (optional)

The first start creates a `certs/` folder with a `ca.crt` file. Installing it
among the "trusted root certification authorities" of the machines you connect
from removes the warning. The connection stays encrypted even if you just accept
the warning.

## Local agents

Scans do not run on the server: they run with the Docker agent on the users'
PCs. From the dashboard, the agent connection section generates the `docker run`
command to launch, with the API key and the chosen module. The agent image is
set by `SHIELD_AGENT_IMAGE` in `.env`.

## Changing the configuration (.env)

If you change a value in the `.env` file after installation (for example adding
an API key), apply it by re-running the same start command: `./up.sh`
(Windows: `.\up.ps1`). It recreates the containers with the new values in
seconds, without rebuilding the images and without losing data.

## Licence renewal

The licence has an expiry date. Before it expires, request a renewal at the same
email: you receive a new key to paste over the old one. When it expires the app
locks but **no data is lost**.

## Updates

```bash
docker compose pull && ./up.sh
```

## Auto-start after a reboot

The containers are already set to come back on their own when Docker restarts.
For that to happen after the computer reboots too, Docker just needs to start at
boot. To set it up (once):

- Linux/macOS: `./enable-autostart.sh`
- Windows: `powershell -ExecutionPolicy Bypass -File .\enable-autostart.ps1`

On Linux it enables the Docker service at boot; on Windows/macOS it sets Docker
Desktop to start at login. After that, the control plane comes back up by itself
every time you turn the machine on.

## Backup and restore

Your data lives in the Postgres database and in the backend volume (the
activated licence). To save it all into one timestamped folder:

```bash
./backup.sh
```

It creates `backups/citizen-shield-backup-<date>/` with the database dump and
the data: copy it somewhere safe, off the server. To restore:

```bash
./restore.sh backups/citizen-shield-backup-<date>
```

On Windows use `.\backup.ps1` and `.\restore.ps1` (same arguments).

## Network exposure

The suite is already served over HTTPS by the included reverse proxy (ports 80
and 443). To access it from other PCs on the network, use the server's IP in the
clients' hosts file (or your internal DNS). If you wish, you can replace the
self-signed certificates in `certs/` with your own corporate certificates (same
file names).

## Licence and documents

Use of the software is governed by the licence agreement in `EULA.md`, included
in this folder. This folder also contains `ETHICS.md` (lawful and ethical use
policy) and `THIRD_PARTY_NOTICES.md` (third-party open source components and
their licences).

## Support

Problems or questions: **arcari.nicholas0@gmail.com** (always include your
deployment id).
