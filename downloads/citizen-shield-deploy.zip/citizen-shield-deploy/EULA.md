# Contratto di licenza con l'utente finale (EULA) - Citizen Shield on-premise

**Versione 2.0 - in vigore dal 2026-08-08**

> **Ambito di questo documento.** Disciplina la distribuzione **on-premise** di
> Citizen Shield, quella che il Licenziatario installa e ospita su un proprio
> server e che e' concessa **a titolo gratuito**. L'eventuale servizio in
> modalita' SaaS ospitato dal Licenziante e' regolato dal contratto separato
> `EULA.md` presente nel repository del prodotto.

> English version: `EULA.en.md` (traduzione ufficiale; in caso di discrepanza
> fa fede la presente versione italiana - vedi art. 15).

Il presente Contratto di Licenza con l'Utente Finale ("Contratto") e' stipulato
tra:

**Licenziante:** Nicholas Arcari - email: arcari.nicholas0@gmail.com

e la persona fisica o giuridica che installa o utilizza il software Citizen
Shield ("Licenziatario"). Installando o utilizzando il software, il
Licenziatario accetta integralmente i termini seguenti. Se non li accetta, non
deve installare ne' utilizzare il software.

> **Natura dello strumento.** Citizen Shield e' uno strumento di **triage
> preliminare e supporto** per la sicurezza personale (OPSEC) e per la raccolta
> ordinata di elementi utili a una eventuale denuncia. **Non e' uno strumento di
> digital forensics certificato e non sostituisce ne' un perito informatico
> certificato (CTU/CTP) ne' l'Autorita' Giudiziaria o le Forze dell'Ordine**
> (es. Polizia Postale). Vedi art. 5, art. 7 e art. 10.

> **Il Software e' concesso a titolo gratuito.** Non e' previsto alcun
> corrispettivo, ne' per la licenza ne' per il suo rinnovo (vedi art. 8).

> Nota: questo documento e' un modello fornito a scopo pratico e non costituisce
> consulenza legale. Per un utilizzo continuativo se ne raccomanda la revisione
> da parte di un professionista legale.

## 1. Definizioni

- **Software**: "Citizen Shield" in modalita' on-premise, comprendente il
  control plane (cruscotto web e backend) e l'Agent locale, distribuito come
  immagini Docker, insieme alla documentazione allegata.
- **Agent**: il componente che il Licenziatario esegue sui propri dispositivi
  per effettuare le analisi locali e trasmetterne i risultati al control plane.
- **Chiave di licenza**: il token firmato dal Licenziante che abilita l'uso del
  Software su un determinato deployment.
- **Deployment**: una singola installazione del Software identificata dal valore
  `LICENSE_DEPLOYMENT_ID` scelto dal Licenziatario al momento dell'installazione.
- **Documentazione**: i documenti allegati al Software, tra cui `README.md`,
  `ETHICS.md` e `THIRD_PARTY_NOTICES.md`.

## 2. Concessione della licenza

Il Licenziante concede al Licenziatario, **a titolo gratuito**, una licenza non
esclusiva, non trasferibile, non cedibile in sublicenza e revocabile, a:

- installare e utilizzare il Software sul deployment per il quale e' stata
  emessa la Chiave di licenza;
- per la durata di validita' indicata nella Chiave di licenza (scadenza inclusa).

La licenza e' vincolata al Deployment: la Chiave di licenza e' valida solo per il
`LICENSE_DEPLOYMENT_ID` per cui e' stata emessa.

## 3. Restrizioni

Il Licenziatario non puo':

1. copiare, distribuire, rivendere, noleggiare, concedere in leasing o in
   sublicenza il Software o la Chiave di licenza a terzi;
2. modificare, decompilare, disassemblare o effettuare reverse engineering del
   Software, salvo nei limiti inderogabili previsti dalla legge;
3. rimuovere, disattivare o aggirare il meccanismo di verifica della licenza o
   qualsiasi misura tecnica di protezione;
4. rimuovere o alterare le note di copyright, i marchi o gli avvisi di
   proprieta';
5. utilizzare il Software oltre la scadenza della Chiave di licenza senza un
   rinnovo valido.

## 4. Proprieta' e componenti di terze parti

Il Software e' concesso in licenza, non ceduto. Il Licenziante conserva ogni
diritto, titolo e interesse sul Software, inclusi tutti i diritti di proprieta'
intellettuale. Il presente Contratto non trasferisce alcun diritto di proprieta'
al Licenziatario.

Il Software incorpora componenti software di terze parti (open source), ciascuno
soggetto alla propria licenza, elencati nel documento `THIRD_PARTY_NOTICES.md`
allegato. Tali componenti restano dei rispettivi titolari e sono forniti ai
termini delle rispettive licenze, che prevalgono sul presente Contratto per la
sola parte relativa a ciascun componente.

## 5. Uso lecito ed etico - ambito consentito e delega di responsabilita'

Il Software e' destinato **esclusivamente all'auto-tutela**: il Licenziatario
puo' utilizzarlo per analizzare **dispositivi, account, reti e la propria
impronta online che gli appartengono o che e' legittimamente autorizzato ad
esaminare**, e per raccogliere in modo ordinato elementi relativi a condotte
illecite **subite** (es. stalking, molestie, accesso abusivo, diffusione non
consensuale di immagini).

Il Licenziatario si impegna a **NON** utilizzare il Software per:

- sorvegliare, geolocalizzare, profilare o "hackerare di rimando" ("hack-back")
  l'autore delle molestie o qualsiasi terzo;
- accedere a dispositivi, account o dati che non gli appartengono o per i quali
  non ha un titolo legittimo;
- qualsiasi finalita' ritorsiva, persecutoria o comunque illecita.

**Ogni responsabilita' per un uso illecito, non etico o non autorizzato del
Software ricade esclusivamente sul Licenziatario e non sul Licenziante.** Il
Licenziatario e' l'unico responsabile di disporre delle autorizzazioni necessarie
e di verificare la liceita' del proprio utilizzo nella propria giurisdizione, ivi
comprese le analisi eseguite dall'Agent su dispositivi e reti. Il Licenziatario
terra' indenne e manlevera' il Licenziante da ogni pretesa di terzi o
dell'Autorita' derivante da un uso del Software difforme dal presente articolo.
Le condizioni d'uso sono descritte in dettaglio in `ETHICS.md`.

## 6. Dati personali e protezione dei dati

Il Software funziona interamente sull'infrastruttura del Licenziatario. Il
Licenziante non raccoglie, non riceve e non ha accesso ai dati trattati con il
Software: la verifica della licenza avviene in locale, senza alcuna
comunicazione verso l'esterno.

Utilizzando il Software - in particolare tramite le analisi eseguite dall'Agent
- il Licenziatario puo' trattare dati personali, anche appartenenti a categorie
particolari e anche riferiti a terzi. Rispetto a tali trattamenti il
**Licenziatario agisce come autonomo titolare del trattamento** ai sensi del
Regolamento (UE) 2016/679 (GDPR) e della normativa applicabile, ed e' l'unico
responsabile: dell'individuazione di una idonea base giuridica, del rispetto dei
principi di liceita', minimizzazione e limitazione delle finalita',
dell'informativa agli interessati e dell'esercizio dei loro diritti. Poiche' il
Licenziante non tratta tali dati per conto del Licenziatario, non ricorre tra le
parti un rapporto di responsabile del trattamento e non e' richiesto un accordo
ai sensi dell'art. 28 GDPR. Il Licenziatario terra' indenne il Licenziante da
ogni pretesa di terzi derivante da un trattamento dati effettuato tramite il
Software in violazione della normativa.

**Registro delle attivita'.** Il Software mantiene, sul server del
Licenziatario, un registro in sola aggiunta delle azioni rilevanti per la
sicurezza (accessi riusciti e falliti, creazione di account, modifica delle
chiavi di integrazione, attivazione della licenza). Tale registro contiene nomi
utente e indirizzi IP ed e' quindi un trattamento di dati personali di cui il
Licenziatario e' titolare: la durata di conservazione e' configurabile e vale
quanto previsto al presente articolo.

Gli unici dati personali trattati dal Licenziante sono l'indirizzo email e il
`LICENSE_DEPLOYMENT_ID` comunicati dal Licenziatario per l'emissione della
Chiave di licenza, trattati per la sola gestione della licenza e conservati per
il tempo necessario a tale scopo.

## 7. Valore probatorio e limiti forensi

Il Licenziatario prende atto e accetta che i report e i "fascicoli" generati dal
Software:

- sono prodotti in modo automatizzato, **senza write-blocker hardware** e senza
  la supervisione di un perito certificato;
- costituiscono **materiale di triage preliminare** utile a fornire elementi e a
  supportare l'individuazione del *fumus* per una acquisizione forense formale,
  ma **non costituiscono una catena di custodia certificata ne' una perizia**
  valida in giudizio;
- l'hashing SHA-256 e la marca temporale RFC 3161 attestano l'integrita' dei
  dati dal momento della loro raccolta, ma non ne garantiscono da soli
  l'ammissibilita' processuale, che dipende dal processo di raccolta e dalla
  valutazione dell'Autorita'.

Il passo raccomandato e' consegnare il materiale a un avvocato o alle Forze
dell'Ordine affinche' dispongano, ove necessario, una acquisizione forense
formale.

## 8. Gratuita', assistenza e disponibilita'

Il Software e' concesso **a titolo gratuito**: non e' dovuto alcun corrispettivo
per la licenza, per la sua attivazione o per il suo rinnovo.

Il Licenziante non e' tenuto a fornire assistenza, manutenzione, aggiornamenti o
correzioni. Eventuali attivita' di supporto sono prestate a mera cortesia, senza
obblighi di risultato ne' tempi di intervento garantiti.

Il Licenziante puo' in qualsiasi momento modificare, sospendere o cessare la
distribuzione del Software, o non emettere nuove Chiavi di licenza, senza che
cio' comporti alcun obbligo di indennizzo o risarcimento. Le Chiavi di licenza
gia' emesse restano valide fino alla loro naturale scadenza.

## 9. Rinnovo e cessazione

La licenza cessa automaticamente alla scadenza della Chiave di licenza. Il
rinnovo, anch'esso gratuito, e' subordinato all'emissione di una nuova Chiave da
parte del Licenziante, che non e' obbligato a concederlo. Il Licenziante puo'
risolvere di diritto il Contratto in caso di violazione dei termini da parte del
Licenziatario. Alla cessazione, il Licenziatario deve interrompere l'uso del
Software. I dati generati dal Licenziatario restano di sua proprieta' e sul suo
server.

## 10. Esclusione di garanzie

Nella misura massima consentita dalla legge, e tenuto conto della natura
gratuita della concessione, il Software e' fornito "cosi' com'e'", senza
garanzie di alcun tipo, esplicite o implicite, incluse tra l'altro le garanzie
di commerciabilita', idoneita' per un fine particolare e non violazione di
diritti di terzi. **Il Licenziante non garantisce che il Software rilevi ogni
minaccia (es. stalkerware, accessi abusivi) ne' che sia privo di falsi positivi
o falsi negativi**, ne' che sia idoneo alle specifiche esigenze del
Licenziatario. Restano ferme le garanzie e i diritti inderogabili eventualmente
previsti dalla legge a favore del Licenziatario, che il presente Contratto non
intende escludere ne' limitare.

## 11. Limitazione di responsabilita'

Nella misura massima consentita dalla legge, il Licenziante non e' responsabile
per alcun danno diretto, indiretto, incidentale, speciale o consequenziale
derivante dall'uso o dall'impossibilita' di usare il Software, ivi compresi
perdita di dati, interruzione di attivita' o mancato guadagno.

Trattandosi di concessione a titolo gratuito, il Licenziante risponde nei soli
limiti previsti dalla legge per le prestazioni rese senza corrispettivo. Le
presenti esclusioni e limitazioni **non si applicano in caso di dolo o colpa
grave del Licenziante, ne' negli altri casi in cui la responsabilita' non e'
escludibile o limitabile per legge** (art. 1229 c.c.).

## 12. Sicurezza personale

Il Software include avvisi di sicurezza (es. uso di un "dispositivo pulito",
pulsante di uscita rapida, protocollo host compromesso). Tali misure sono di
supporto e **non garantiscono l'incolumita' del Licenziatario**. In caso di
pericolo immediato il Licenziatario deve contattare il numero di emergenza (112)
o i servizi antiviolenza competenti (in Italia: 1522).

## 13. Legge applicabile e foro competente

Il presente Contratto e' regolato dalla legge italiana. Per ogni controversia e'
competente in via esclusiva il foro del luogo di residenza del Licenziante,
salvo l'applicazione delle norme inderogabili a tutela del consumatore quando il
Licenziatario agisca per scopi estranei alla propria attivita' professionale.

## 14. Approvazione specifica delle clausole (artt. 1341-1342 c.c.)

Ai sensi e per gli effetti degli artt. 1341 e 1342 del Codice Civile, il
Licenziatario dichiara di approvare specificamente, dopo attenta lettura, le
seguenti clausole: art. 2 (divieto di cessione e sublicenza; revocabilita'),
art. 3 (restrizioni d'uso), art. 5 (delega di responsabilita' e manleva),
art. 7 (limiti forensi e valore probatorio), art. 8 (facolta' di cessare la
distribuzione e assenza di obblighi di assistenza), art. 9 (risoluzione di
diritto e assenza di obbligo di rinnovo), art. 10 (esclusione di garanzie),
art. 11 (limitazione di responsabilita'), art. 13 (foro competente esclusivo).

## 15. Lingua

Il presente Contratto e' redatto in lingua italiana. Una traduzione in lingua
inglese (`EULA.en.md`) e' fornita a beneficio del Licenziatario. In caso di
discrepanza, incoerenza o dubbio interpretativo tra le due versioni, prevale la
versione italiana, che costituisce l'unico testo vincolante.

## 16. Contatti

Per licenze, rinnovi o richieste: **arcari.nicholas0@gmail.com**
