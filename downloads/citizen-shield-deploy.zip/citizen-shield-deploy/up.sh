#!/bin/sh
# One-command start for Linux and macOS.
#
# Registers the hostname the control plane is served on (citizenshield) in your
# hosts file, then brings the containers up. Run this instead of
# `docker compose up -d` - it does the hosts step for you, once, and is safe to
# run again (it never adds a duplicate line). Extra arguments pass through to
# docker compose.
set -e
cd "$(dirname "$0")"

HOSTS="${DEPLOY_HOSTS_FILE:-/etc/hosts}"
ENTRY="127.0.0.1 citizenshield"

if grep -qiE "^[[:space:]]*127\.0\.0\.1[[:space:]].*citizenshield" "$HOSTS" 2>/dev/null; then
  echo "Hostname already registered in $HOSTS."
else
  echo "Registering 'citizenshield' in $HOSTS (may ask for your password)..."
  if [ -w "$HOSTS" ]; then
    printf '%s\n' "$ENTRY" >> "$HOSTS"
  else
    printf '%s\n' "$ENTRY" | sudo tee -a "$HOSTS" >/dev/null
  fi
fi

echo "Starting the control plane..."
docker compose up -d "$@"

echo ""
echo "Done. Open  https://citizenshield"
echo "First visit shows a certificate warning (self-signed) - accept it to proceed."
