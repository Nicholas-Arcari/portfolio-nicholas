#!/bin/sh
# Make the suite come back on its own after the PC restarts (Linux/macOS).
#
# The containers already restart automatically (restart: unless-stopped in the
# compose file), so the only missing piece is the Docker engine itself starting
# at boot. This configures that. Run it once.
set -e

OS=$(uname -s)
case "$OS" in
  Linux)
    echo "Enabling the Docker service to start at boot (systemd)..."
    sudo systemctl enable docker.service 2>/dev/null || true
    sudo systemctl enable docker.socket  2>/dev/null || true
    sudo systemctl enable containerd.service 2>/dev/null || true
    echo "Done. After a reboot Docker starts on its own and the containers come back up."
    echo "(If your system doesn't use systemd, enable Docker at boot with your init system.)"
    ;;
  Darwin)
    echo "Setting Docker Desktop to start when you log in..."
    if [ -d "/Applications/Docker.app" ]; then
      osascript -e 'tell application "System Events" to make login item at end with properties {path:"/Applications/Docker.app", hidden:false}' >/dev/null 2>&1 \
        && echo "Done. Docker Desktop starts at login and the containers come back up." \
        || echo "Could not set it automatically - turn on 'Start Docker Desktop when you log in' in Docker Desktop > Settings > General."
    else
      echo "Docker Desktop not found in /Applications - turn on 'Start Docker Desktop when you log in' in its Settings > General."
    fi
    ;;
  *)
    echo "Unsupported OS here. On Windows run enable-autostart.ps1 instead."
    ;;
esac
