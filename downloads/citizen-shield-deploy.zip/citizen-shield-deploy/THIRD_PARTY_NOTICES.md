# Note sulle licenze di terze parti (Third-Party Notices)

**Citizen Shield** - control plane + local agent (on-premise)

Questo prodotto e' distribuito come immagini Docker che includono componenti software di terze parti, ciascuno soggetto alla propria licenza. I diritti sui componenti di terze parti restano dei rispettivi titolari. Il software proprietario Citizen Shield resta regolato dalla sua licenza (vedi `LICENSE` ed `EULA.md`). Elenco generato dalle immagini effettivamente distribuite.

## Nota importante sull'agent e i componenti copyleft

L'**agent** locale orchestra strumenti da riga di comando esterni (nmap, holehe, usbmuxd, usbutils, iproute2, ...), alcuni dei quali distribuiti con licenze copyleft (GPL). Tali strumenti sono **eseguiti come programmi separati** (sottoprocessi), non collegati ne' incorporati staticamente nel codice dell'agent (che e' compilato con Nuitka e resta proprietario). Si tratta quindi di **mera aggregazione**: le licenze GPL si applicano ai rispettivi strumenti, non estendono i propri obblighi al codice di Citizen Shield. Gli strumenti restano open source sotto le rispettive licenze e non sono modificati.

## Riepilogo

- Backend (Python): 96 componenti
- Frontend (JavaScript): 12 componenti diretti
- Agent: 14 strumenti/componenti
- Immagini di base: 5

Licenze backend: UNKNOWN 34, MIT 33, BSD 13, Apache-2.0 9, MPL 2, PSF/Python 2, ISC 2, Dual License 1.

## Componenti backend (Python)

| Componente | Versione | Licenza |
|---|---|---|
| aiosqlite | 0.20.0 | MIT License |
| alembic | 1.18.5 | UNKNOWN |
| annotated-types | 0.8.0 | MIT License |
| anyio | 4.14.2 | UNKNOWN |
| APScheduler | 3.11.3 | MIT |
| asn1crypto | 1.5.1 | MIT |
| asyncpg | 0.30.0 | Apache License, Version 2.0 |
| backports.zstd | 1.6.0 | UNKNOWN |
| bcrypt | 4.3.0 | Apache-2.0 |
| brotli | 1.2.0 | MIT |
| build | 1.5.0 | UNKNOWN |
| CacheControl | 0.14.4 | UNKNOWN |
| certifi | 2026.7.22 | MPL-2.0 |
| cffi | 2.1.0 | UNKNOWN |
| charset-normalizer | 3.4.9 | MIT |
| cleo | 2.1.0 | MIT |
| click | 8.4.2 | UNKNOWN |
| crashtest | 0.4.1 | MIT |
| cryptography | 49.0.0 | UNKNOWN |
| cssselect2 | 0.9.0 | BSD License |
| defusedxml | 0.7.1 | PSFL |
| distlib | 0.4.3 | PSF-2.0 |
| dnspython | 2.8.0 | ISC |
| dulwich | 1.2.12 | UNKNOWN |
| fastapi | 0.115.14 | MIT License |
| fastjsonschema | 2.22.1 | BSD-3-Clause |
| filelock | 3.32.0 | MIT License |
| findpython | 0.7.1 | MIT |
| fonttools | 4.63.0 | MIT |
| greenlet | 3.5.4 | UNKNOWN |
| h11 | 0.16.0 | MIT |
| httpcore | 1.0.9 | BSD License |
| httptools | 0.8.0 | UNKNOWN |
| httpx | 0.28.1 | BSD-3-Clause |
| idna | 3.18 | UNKNOWN |
| installer | 0.7.0 | MIT License |
| ipwhois | 1.3.0 | BSD |
| jaraco.classes | 3.4.0 | MIT License |
| jaraco.context | 6.1.2 | UNKNOWN |
| jaraco.functools | 4.6.0 | UNKNOWN |
| jeepney | 0.9.0 | UNKNOWN |
| Jinja2 | 3.1.6 | BSD License |
| keyring | 25.7.0 | UNKNOWN |
| Mako | 1.3.12 | MIT |
| MarkupSafe | 3.0.3 | UNKNOWN |
| more-itertools | 11.1.0 | UNKNOWN |
| msgpack | 1.2.1 | UNKNOWN |
| packaging | 26.2 | UNKNOWN |
| pbs-installer | 2026.7.28 | MIT |
| pillow | 12.3.0 | UNKNOWN |
| pip | 25.0.1 | MIT |
| pkginfo | 1.12.1.2 | MIT |
| platformdirs | 4.11.0 | MIT License |
| poetry | 2.3.4 | UNKNOWN |
| poetry-core | 2.3.2 | UNKNOWN |
| prometheus_client | 0.21.1 | Apache Software License 2.0 |
| pycparser | 3.0 | UNKNOWN |
| pydantic | 2.13.4 | UNKNOWN |
| pydantic-settings | 2.14.2 | MIT License |
| pydantic_core | 2.46.4 | UNKNOWN |
| pydyf | 0.12.1 | BSD License |
| PyJWT | 2.13.0 | UNKNOWN |
| pyphen | 0.17.2 | GNU General Public License v2 or later (GPLv2+) / GNU Lesser General Public License v2 or later (LGPLv2+) / Mozilla Public License 1.1 (MPL 1.1) |
| pyproject_hooks | 1.2.0 | MIT License |
| python-dateutil | 2.9.0.post0 | Dual License |
| python-discovery | 1.5.0 | MIT License |
| python-dotenv | 1.2.2 | BSD-3-Clause |
| python-multipart | 0.0.18 | Apache-2.0 |
| python-whois | 0.9.6 | MIT |
| PyYAML | 6.0.3 | MIT |
| RapidFuzz | 3.14.5 | UNKNOWN |
| requests | 2.34.2 | Apache-2.0 |
| requests-toolbelt | 1.0.0 | Apache 2.0 |
| SecretStorage | 3.5.0 | UNKNOWN |
| shellingham | 1.5.4 | ISC License |
| six | 1.17.0 | MIT |
| SQLAlchemy | 2.0.51 | MIT |
| starlette | 0.46.2 | BSD License |
| stripe | 11.6.0 | MIT |
| structlog | 24.4.0 | Apache Software License / MIT License |
| tinycss2 | 1.5.1 | BSD License |
| tinyhtml5 | 2.1.0 | MIT License |
| tomlkit | 0.15.1 | MIT |
| trove-classifiers | 2026.6.1.19 | Apache Software License |
| typing-inspection | 0.4.2 | UNKNOWN |
| typing_extensions | 4.16.0 | UNKNOWN |
| tzlocal | 5.4.4 | UNKNOWN |
| urllib3 | 2.7.0 | UNKNOWN |
| uvicorn | 0.34.3 | BSD License |
| uvloop | 0.22.1 | MIT License |
| virtualenv | 21.7.0 | MIT License |
| watchfiles | 1.2.0 | MIT |
| weasyprint | 69.0 | BSD License |
| webencodings | 0.5.1 | BSD |
| websockets | 17.0.1 | UNKNOWN |
| zopfli | 0.4.3 | Apache-2.0 |

## Componenti frontend (JavaScript)

| Componente | Versione | Licenza |
|---|---|---|
| axios | 1.18.1 | MIT |
| clsx | 2.1.1 | MIT |
| cytoscape | 3.34.0 | MIT |
| i18next | 23.16.8 | MIT |
| i18next-browser-languagedetector | 8.2.1 | MIT |
| lucide-react | 0.460.0 | ISC |
| react | 18.3.1 | MIT |
| react-cytoscapejs | 2.0.0 | MIT |
| react-dom | 18.3.1 | MIT |
| react-i18next | 15.7.4 | MIT |
| react-router-dom | 6.30.4 | MIT |
| tailwind-merge | 2.6.1 | MIT |

Le dipendenze transitive del frontend sono distribuite sotto le medesime licenze permissive (MIT, BSD, ISC, Apache-2.0).

## Componenti dell'agent locale

| Componente | Licenza | Ruolo |
|---|---|---|
| nmap | NPSL (GPLv2-derived) | network discovery (Smart Home) |
| android-tools-adb | Apache-2.0 | Android enumeration (Mobile) |
| libimobiledevice-utils | LGPL-2.1+ | iOS device query (Mobile) |
| usbmuxd | GPL-2.0/3.0 | USB multiplexing daemon |
| usbutils | GPL-2.0+ | USB utilities |
| iproute2 | GPL-2.0 | routing / discovery |
| iputils-ping | BSD-3-Clause | ping |
| ca-certificates | MPL-2.0 | CA bundle |
| sherlock-project | MIT | username OSINT (Digital Footprint) |
| holehe | GPL-3.0 | email OSINT (Digital Footprint) |
| Nuitka | Apache-2.0 | compiler (build-time only) |
| httpx | BSD-3-Clause | HTTP client |
| cryptography | Apache-2.0 / BSD | cryptography |
| ordered-set | MIT | build-time dependency |

## Immagini di base

| Immagine | Licenza | Uso |
|---|---|---|
| python:3.12-slim | Python Software Foundation License; Debian base | backend + agent builder |
| debian:bookworm-slim | Debian (components under their own free licences) | agent runtime |
| node:20-alpine | Node.js: MIT; Alpine/musl: MIT | frontend build (not shipped) |
| nginxinc/nginx-unprivileged:alpine | nginx: BSD-2-Clause; Alpine: MIT | frontend runtime |
| postgres:16-alpine | PostgreSQL License (permissive); Alpine: MIT | database |


---

Per i componenti che referenziano licenze standard (MIT, BSD, ISC, Apache-2.0, LGPL, MPL, GPL) si applica il testo ufficiale della rispettiva licenza, che include l'obbligo di riprodurre l'avviso di copyright dei rispettivi autori.