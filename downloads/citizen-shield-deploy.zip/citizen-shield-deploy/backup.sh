#!/bin/sh
# Back up all Citizen Shield data (Linux/macOS).
#
# Produces a timestamped folder with a Postgres dump (accounts, cases, results)
# and an archive of the backend data volume (the activated licence and any
# generated files). Safe to run while the stack is up. Requires the stack to be
# running (it dumps from the live Postgres container).
#
# Usage:  ./backup.sh [output-dir]     (default: ./backups)
set -e
cd "$(dirname "$0")"

PROJECT=citizen-shield
OUT="${1:-./backups}"
mkdir -p "$OUT"
OUT_ABS=$(cd "$OUT" && pwd)
TS=$(date +%Y%m%d-%H%M%S)
DIR="$OUT_ABS/citizen-shield-backup-${TS}"
mkdir -p "$DIR"

echo "Dumping the Postgres database..."
# Dump + gzip inside the container, then copy the file out. No host-side pipe,
# so this behaves identically on Linux, macOS and Windows (backup.ps1).
docker compose exec -T postgres sh -c \
  "pg_dump -U shield --clean --if-exists citizen_shield | gzip -9 > /tmp/db.sql.gz"
docker compose cp postgres:/tmp/db.sql.gz "$DIR/db.sql.gz"
docker compose exec -T postgres rm -f /tmp/db.sql.gz

echo "Archiving the backend data volume (licence + files)..."
docker run --rm \
  -v "${PROJECT}_backend-data:/data:ro" \
  -v "${DIR}:/backup" \
  alpine tar czf /backup/backend-data.tar.gz -C /data .

echo "Backup created in: ${DIR}"
echo "Copy it somewhere safe, off this server."
