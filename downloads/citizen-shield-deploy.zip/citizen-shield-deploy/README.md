# Citizen Shield - Guida di installazione (on-premise)

> English version: `README.en.md`

Piattaforma di **OPSEC, privacy e difesa personale** per vittime di
cyberstalking, doxxing, sextortion e compromissione dei dispositivi. In modalita'
on-premise il **control plane** (cruscotto web + database) gira sul TUO server:
nessun dato lascia la tua infrastruttura e la licenza si verifica in locale,
senza connessioni verso l'esterno.

Gli **agent locali** (le scansioni con nmap, sherlock, adb, ...) restano un
componente separato che gli utenti eseguono sui propri PC: il cruscotto mostra i
comandi da lanciare. Nessuna scansione parte dal tuo server.

## Requisiti

- Un server Linux (o macOS/Windows con WSL2) con **Docker** e **Docker Compose**
- 4 GB di RAM consigliati (il database Postgres e' incluso nel pacchetto)
- Accesso a internet solo per il primo download delle immagini

## Installazione (3 passi)

1. **Configura**: copia `.env.example` in `.env` e compila:
   - `LICENSE_DEPLOYMENT_ID`: scegli un nome per questa installazione
     (es. `acme-prod-01`)
   - `AUTH_SECRET`, `APP_SECRET_KEY`: segreti casuali (`openssl rand -hex 32`)
   - `POSTGRES_PASSWORD`: una password a tua scelta per il database

2. **Avvia** con lo script incluso: registra da solo il nome `citizenshield`
   nel file hosts della macchina e avvia i container (scarica le immagini e
   genera i certificati HTTPS al primo avvio). Un solo comando:

   - Linux/macOS: `./up.sh`  (chiede la password per scrivere nel file hosts)
   - Windows: tasto destro su `up.ps1` -> "Esegui con PowerShell", oppure
     `powershell -ExecutionPolicy Bypass -File .\up.ps1` (accetta il prompt di
     amministratore, serve per il file hosts)

   Lo script e' sicuro da rieseguire e non duplica la riga hosts. Per fermare:
   `./down.sh` (Windows: `.\down.ps1`).

   > Metodo manuale, in alternativa: aggiungi `127.0.0.1 citizenshield` al file
   > hosts e lancia `docker compose up -d`. Se accedi da altri PC della rete,
   > usa l'IP del server al posto di `127.0.0.1` (oppure il DNS interno).

3. **Attiva la licenza**: apri **https://citizenshield** nel browser. La prima
   volta il browser mostra un avviso di sicurezza (certificato self-signed):
   accettalo per proseguire. Comparira' la schermata "Licenza richiesta".

   Per ottenere la chiave invia una email a **arcari.nicholas0@gmail.com**
   indicando il tuo `LICENSE_DEPLOYMENT_ID`: la chiave viene consegnata via
   email in maniera sicura e tracciata, emessa esclusivamente per il tuo
   deployment. Incollala una volta nella schermata: sblocca l'applicazione e
   resta salvata.

Fatto. Control plane su **https://citizenshield**. Il primo utente registrato
diventa amministratore.

### Togliere l'avviso del browser (opzionale)

Il primo avvio crea una cartella `certs/` con un file `ca.crt`. Installandolo
tra le "autorita' di certificazione radice attendibili" delle macchine da cui
accedi, l'avviso sparisce. La connessione resta comunque cifrata anche
accettando l'avviso.

## Agent locali

Le scansioni non girano sul server: si eseguono con l'agent Docker sui PC degli
utenti. Dal cruscotto, la sezione di connessione dell'agent genera il comando
`docker run` da lanciare, con la API key e il modulo scelto. L'immagine
dell'agent e' indicata da `SHIELD_AGENT_IMAGE` nel `.env`.

## Modificare la configurazione (.env)

Se dopo l'installazione cambi un valore nel file `.env` (per esempio aggiungi
una API key), applica la modifica rilanciando lo stesso comando di avvio:
`./up.sh` (Windows: `.\up.ps1`). Ricrea i container con i nuovi valori in pochi
secondi, senza ricostruire le immagini e senza perdere i dati.

## Rinnovo licenza

La licenza ha una scadenza. Prima della scadenza richiedi il rinnovo alla stessa
email: ricevi una chiave nuova da incollare sopra la vecchia. Alla scadenza
l'app si blocca ma **nessun dato viene perso**.

## Aggiornamenti

```bash
docker compose pull && ./up.sh
```

## Avvio automatico dopo il riavvio del PC

I container sono gia' configurati per ripartire da soli quando Docker riparte.
Perche' questo avvenga anche dopo un riavvio del computer basta che Docker parta
all'accensione. Per configurarlo (una volta sola):

- Linux/macOS: `./enable-autostart.sh`
- Windows: `powershell -ExecutionPolicy Bypass -File .\enable-autostart.ps1`

Su Linux abilita il servizio Docker al boot; su Windows/macOS imposta Docker
Desktop per avviarsi al login. Dopo, a ogni accensione il control plane torna su
da solo, senza dover rilanciare nulla.

## Backup e ripristino

I tuoi dati stanno nel database Postgres e nel volume del backend (la licenza
attivata). Per salvarli in un unico archivio con timestamp:

```bash
./backup.sh
```

Crea `backups/citizen-shield-backup-<data>/` con il dump del database e i dati:
copialo in un luogo sicuro, fuori dal server. Per ripristinare:

```bash
./restore.sh backups/citizen-shield-backup-<data>
```

Su Windows usa `.\backup.ps1` e `.\restore.ps1` (stessi argomenti).

## Esposizione in rete

La suite e' gia' servita in HTTPS dal reverse proxy incluso (porte 80 e 443).
Per accedervi da altri PC della rete, usa l'IP del server nel file hosts dei
client (o il DNS interno). Volendo puoi sostituire i certificati self-signed in
`certs/` con i tuoi certificati aziendali (stessi nomi file).

### Se la porta 80 o la 443 sono gia' occupate

L'avvio si ferma con `address already in use` quando un altro programma tiene
gia' quelle porte (un altro reverse proxy, un web server di sistema, un altro
stack Docker). Cambiale nel `.env`:

    HTTP_PORT=8081
    HTTPS_PORT=443

La porta 80 fa solo il redirect verso HTTPS, quindi spostarla non toglie
funzionalita'. Se invece cambi `HTTPS_PORT`, l'indirizzo da aprire diventa
`https://citizenshield:PORTA`. Per sapere quali porte sono libere: `ss -ltn`
(Linux e macOS) oppure `netstat -ano` (Windows).

## Licenza e documenti

L'utilizzo del software e' regolato dal contratto di licenza in `EULA.md`,
incluso in questa cartella. In questa cartella trovi anche `ETHICS.md`
(condizioni di uso lecito ed etico) e `THIRD_PARTY_NOTICES.md` (componenti open
source di terze parti e relative licenze).

## Supporto

Problemi o domande: **arcari.nicholas0@gmail.com** (indica sempre il tuo
deployment id).
