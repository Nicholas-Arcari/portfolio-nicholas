# Make the suite come back on its own after the PC restarts (Windows).
#
# The containers already restart automatically (restart: unless-stopped), so
# this just makes Docker Desktop start when you log in. The containers then come
# back on their own. Run it once.
$ErrorActionPreference = "Stop"

$candidates = @(
  "$env:ProgramFiles\Docker\Docker\Docker Desktop.exe",
  "${env:ProgramFiles(x86)}\Docker\Docker\Docker Desktop.exe"
)
$docker = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $docker) {
  Write-Host "Docker Desktop not found at the usual path."
  Write-Host "Turn on 'Start Docker Desktop when you sign in' in Docker Desktop > Settings > General."
  exit
}

$startup = [Environment]::GetFolderPath('Startup')
$shortcut = Join-Path $startup "Docker Desktop.lnk"
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut($shortcut)
$lnk.TargetPath = $docker
$lnk.Save()

Write-Host "Done. Docker Desktop will start when you log in, and the containers will come back up."
