# Politica di uso etico - Citizen Shield

> **Citizen Shield e' uno strumento di autodifesa per chi subisce molestie,
> stalking o sorveglianza.** Serve a controllare i *tuoi* dispositivi, i *tuoi*
> account e la *tua* impronta online, e a mettere in ordine le prove di cio' che
> viene fatto *a te*, cosi' da poterle portare a un avvocato o alle Forze
> dell'Ordine. Usarlo per indagare, sorvegliare, localizzare o "attaccare di
> rimando" un'altra persona **non e' un caso d'uso supportato** ed e' illecito
> nella maggior parte degli ordinamenti.

Questo documento integra - ma **non deroga** - la licenza in
[`LICENSE`](./LICENSE) e l'[`EULA.md`](./EULA.md). Esprime l'intento dell'autore,
non e' consulenza legale. Se non hai la certezza che un determinato utilizzo sia
lecito dove vivi, rivolgiti a un professionista qualificato.

> Versione inglese: `ETHICS.en.md`. Questa versione italiana e' quella
> applicabile ai licenziatari italiani ed e' il documento richiamato dall'art. 5
> dell'EULA.

## A chi si rivolge

Citizen Shield presuppone che chi lo usa sia una **vittima (o una persona che
aiuta una vittima con il suo consenso)** e che agisca su beni e dati che ha
titolo di esaminare:

1. **I tuoi dispositivi** - il tuo telefono, il tuo computer, la tua rete di casa.
2. **I tuoi account** - la tua identita' Google/Apple/Microsoft, i profili del
   browser, le regole di inoltro della posta.
3. **La tua impronta online** - account e dati che riguardano *te* e sono
   pubblicamente raggiungibili.
4. **Le prove dirette a te** - messaggi, link, immagini, accessi ai link-esca e
   metadati relativi alle molestie che stai ricevendo.

Qualunque altra cosa - profilare un ex partner, geolocalizzare la persona di cui
hai paura, entrare nell'account di qualcun altro "per avere le prove", ritorcersi
contro l'infrastruttura di chi ti attacca - e' **fuori ambito** e puo'
costituire reato, anche quando la vittima sei tu.

## Il confine tra difesa e attacco

Essere vittima **non** crea il diritto di attaccare a propria volta. In concreto:

- **Indaga verso l'interno, non verso l'esterno.** Citizen Shield controlla *il
  tuo* computer alla ricerca di RAT (Modulo 9), *la tua* rete per dispositivi
  estranei (Modulo 4), *il tuo* browser e la tua identita' cloud (Modulo 7), *il
  tuo* telefono per stalkerware (Modulo 8). Non scansiona ne' sonda i sistemi
  dell'altra persona.
- **I canary token sono trappole, non tracciamento di un innocente.** Il modulo
  di difesa attiva (Modulo 10) crea link-esca che *tu* collochi dove un intruso
  potrebbe guardare. Registra chi apre *la tua* trappola. Non usarlo per attirare
  o incastrare un terzo estraneo.
- **Nessun contrattacco.** Non esiste, deliberatamente, alcuna funzione che
  invii traffico verso l'infrastruttura di chi ti attacca. Raccogli e conserva;
  non ritorcerti.
- **Non affrontare l'aggressore con i risultati.** Oltre al rischio legale, puo'
  aumentare il pericolo per te. Porta il report ai professionisti.

## Quadro normativo (non esaustivo e non vincolante)

- **Italia** - lo *stalking* e' punito dall'**art. 612-bis c.p.**; l'accesso
  abusivo a un sistema informatico dall'**art. 615-ter c.p.**; l'intercettazione
  illecita dall'**art. 617-quater c.p.**; la diffusione non consensuale di
  immagini sessualmente esplicite dall'**art. 612-ter c.p.**. Le prove di questi
  reati commessi contro di te sono esattamente cio' che questo strumento ti aiuta
  a conservare per una denuncia.
- **UE - GDPR (Reg. 2016/679).** I dati che raccogli sulla persona che ti
  molesta sono dati personali. Quando li raccogli per accertare, esercitare o
  difendere un diritto in sede giudiziaria, la base giuridica e' tipicamente
  l'**art. 6(1)(f)** (legittimo interesse) e, per le categorie particolari,
  l'**art. 9(2)(f)** (accertamento di un diritto in sede giudiziaria). Raccogli
  il minimo indispensabile e conservalo solo per il tempo necessario al
  procedimento.
- **Denuncia.** Porta quanto hai trovato alla **Polizia Postale** (o all'unita'
  competente per i reati informatici) e/o a un avvocato. In Italia, supporto
  antiviolenza e stalking: **1522** (gratuito, 24 ore su 24). Pericolo immediato:
  **112**.

## Cosa lo strumento fa e cosa non promette

- **Triage preliminare, non perizia certificata.** Lavora senza write-blocker
  hardware e sul tuo dispositivo (che potrebbe essere compromesso). I suoi report
  aiutano a fondare i presupposti per una acquisizione forense *formale* svolta
  da un perito certificato: non sono di per se' una catena di custodia
  certificata.
- **Rilevamento secondo il possibile.** Gli elenchi di firme (stalkerware, RAT,
  estensioni malevole) sono limitati e pubblici. Un esito negativo e'
  rassicurante ma **non e' una garanzia** che sia tutto a posto. Fidati del tuo
  istinto e chiedi comunque aiuto.
- **Non e' uno strumento di attacco o di sorveglianza.** Acquisisce e organizza
  prove a cui hai gia' accesso. Non recapita payload e non traccia persone.

## Se sei in pericolo adesso

Fermati e mettiti al sicuro prima di tutto. Usa il pulsante **Uscita rapida**
(oppure premi `Esc` tre volte) per lasciare l'applicazione e cancellarla dal
browser. Se pensi che il computer che stai usando sia sorvegliato, usa un
**dispositivo pulito** di cui ti fidi, o avvia una chiavetta live (Tails/Ubuntu),
prima di eseguire qualsiasi cosa.

---

*Questa politica si applica alla versione corrente e a tutte le versioni future
di Citizen Shield, salvo espressa sostituzione. Ultima revisione: 2026-08-08.*
