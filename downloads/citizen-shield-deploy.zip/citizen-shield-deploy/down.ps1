# Stop the control plane (Windows/PowerShell). Extra arguments pass through to
# docker compose, e.g. `.\down.ps1 -v` also removes the data volumes.
#
# The citizenshield line in the hosts file is left in place: it is harmless and
# lets the next .\up.ps1 start without asking again.
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
docker compose down @args
