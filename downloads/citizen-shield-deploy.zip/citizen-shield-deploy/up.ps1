# One-command start for Windows (PowerShell).
#
# Registers the hostname the control plane is served on (citizenshield) in the
# Windows hosts file, then brings the containers up. Run this instead of
# `docker compose up -d`. Editing the hosts file needs administrator rights, so
# the script re-launches itself elevated the first time (accept the UAC prompt).
# Safe to run again - it never adds a duplicate line.
#
# If PowerShell blocks the script, start it with:
#   powershell -ExecutionPolicy Bypass -File .\up.ps1
$ErrorActionPreference = "Stop"

$hostsPath = Join-Path $env:SystemRoot "System32\drivers\etc\hosts"
$entry = "127.0.0.1 citizenshield"

$isAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent() `
  ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

$already = (Test-Path $hostsPath) -and `
  (Select-String -Path $hostsPath -Pattern "citizenshield" -Quiet)

if (-not $already) {
  if (-not $isAdmin) {
    Write-Host "Registering the hostname needs administrator rights - elevating (accept the prompt)..."
    Start-Process powershell -Verb RunAs -ArgumentList `
      "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`""
    exit
  }
  Write-Host "Registering 'citizenshield' in the hosts file..."
  Add-Content -Path $hostsPath -Value $entry
} else {
  Write-Host "Hostname already registered in the hosts file."
}

Set-Location $PSScriptRoot
Write-Host "Starting the control plane..."
docker compose up -d @args

Write-Host ""
Write-Host "Done. Open  https://citizenshield"
Write-Host "First visit shows a certificate warning (self-signed) - accept it to proceed."
