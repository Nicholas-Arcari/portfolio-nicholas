# Back up all Citizen Shield data (Windows/PowerShell). Mirrors backup.sh.
#
# Produces a timestamped folder with a Postgres dump and an archive of the
# backend data volume (the activated licence). Safe to run while the stack is
# up; requires the stack to be running.
#
# Usage:  .\backup.ps1 [output-dir]     (default: .\backups)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$project = "citizen-shield"
$out = if ($args.Count -ge 1) { $args[0] } else { "backups" }
New-Item -ItemType Directory -Force -Path $out | Out-Null
$outAbs = (Resolve-Path $out).Path
$ts = Get-Date -Format "yyyyMMdd-HHmmss"
$dir = Join-Path $outAbs "citizen-shield-backup-$ts"
New-Item -ItemType Directory -Force -Path $dir | Out-Null

Write-Host "Dumping the Postgres database..."
# Dump + gzip inside the container, then copy the file out (no host-side pipe).
docker compose exec -T postgres sh -c "pg_dump -U shield --clean --if-exists citizen_shield | gzip -9 > /tmp/db.sql.gz"
docker compose cp postgres:/tmp/db.sql.gz "$dir\db.sql.gz"
docker compose exec -T postgres rm -f /tmp/db.sql.gz

Write-Host "Archiving the backend data volume (licence + files)..."
docker run --rm `
  -v "${project}_backend-data:/data:ro" `
  -v "${dir}:/backup" `
  alpine tar czf /backup/backend-data.tar.gz -C /data .

Write-Host "Backup created in: $dir"
Write-Host "Copy it somewhere safe, off this server."
