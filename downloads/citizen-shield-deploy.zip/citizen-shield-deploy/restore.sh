#!/bin/sh
# Restore Citizen Shield data from a folder created by backup.sh (Linux/macOS).
#
# Replaces the current database and backend data with the backup's contents.
# The stack must be running (Postgres up) so the dump can be loaded; the backend
# is stopped while its data volume is replaced, then you restart everything.
#
# Usage:  ./restore.sh <citizen-shield-backup-YYYYmmdd-HHMMSS>
set -e
cd "$(dirname "$0")"

PROJECT=citizen-shield
DIR="$1"
if [ -z "$DIR" ] || [ ! -f "$DIR/db.sql.gz" ] || [ ! -f "$DIR/backend-data.tar.gz" ]; then
  echo "usage: $0 <backup-folder>   (must contain db.sql.gz and backend-data.tar.gz)" >&2
  exit 1
fi
DIR_ABS=$(cd "$DIR" && pwd)

printf "This overwrites the current database and data with '%s'. Continue? [y/N] " "$(basename "$DIR")"
read -r reply
case "$reply" in
  y|Y) ;;
  *) echo "Aborted."; exit 0 ;;
esac

echo "Restoring the Postgres database..."
# Copy the dump into the container and load it there. No host-side pipe, so this
# behaves identically on Linux, macOS and Windows (restore.ps1).
docker compose cp "$DIR_ABS/db.sql.gz" postgres:/tmp/db.sql.gz
docker compose exec -T postgres sh -c \
  "gunzip -c /tmp/db.sql.gz | psql -U shield -d citizen_shield" >/dev/null
docker compose exec -T postgres rm -f /tmp/db.sql.gz

echo "Stopping the backend to replace its data volume..."
docker compose stop backend
docker run --rm \
  -v "${PROJECT}_backend-data:/data" \
  -v "${DIR_ABS}:/backup:ro" \
  alpine sh -c "cd /data && tar xzf /backup/backend-data.tar.gz"

echo "Restore complete. Restart everything with:  ./up.sh"
