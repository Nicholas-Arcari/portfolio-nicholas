/*
 * Homework #2 - Statistics - Nicholas Arcari
 * Sapienza University of Rome, MSc in Cybersecurity
 *
 * Interface and texts (Italian and English). Needs homework2a.js, loaded first.
 *
 * Generated from the sources of the online page,
 * https://nicholas-arcari.github.io/portfolio-nicholas/#/statistics/homework-2a
 */

(function () {
'use strict';

var kitView$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitView.js
// La matematica delle viste di un grafico interattivo: quale parte degli
// assi si vede, come cambia con lo zoom e con lo spostamento, e la
// conversione fra i pixel del riquadro e i valori. Niente DOM: sono funzioni
// pure, che servono identiche alla pagina e al programma scaricabile.
//
// Una vista e' { x: [lo, hi] o null, y: [lo, hi] o null } nelle unita' degli
// assi; null su un asse vuol dire "tutto". Il riquadro (frame) e' quello che
// la libreria di ogni homework descrive con chartFrame(): { plot: { x, y, w,
// h }, x: { min, max, log } o null, y: { min, max, log }, zoom: 'xy' o 'y' }.
// Sugli assi logaritmici i conti si fanno sui logaritmi, cosi' lo zoom e lo
// spostamento hanno lo stesso effetto in ogni punto dell'asse.

/** How far the view can be enlarged: a thousandth of the whole axis. */
const MIN_SPAN = 1e-3;

const fwd = (axis, v) => (axis.log ? Math.log10(v) : v);
const back = (axis, t) => (axis.log ? 10 ** t : t);

/** The pixel of the value v on an axis drawn from p0 (its min) to p1 (its max). */
function toPixel(axis, v, p0, p1) {
  const lo = fwd(axis, axis.min);
  const hi = fwd(axis, axis.max);
  return p0 + ((fwd(axis, v) - lo) / (hi - lo)) * (p1 - p0);
}

/** The value of the pixel p on an axis drawn from p0 (its min) to p1 (its max). */
function toValue(axis, p, p0, p1) {
  const lo = fwd(axis, axis.min);
  const hi = fwd(axis, axis.max);
  return back(axis, lo + ((p - p0) / (p1 - p0)) * (hi - lo));
}

/** Whether the point (x, y), in CSS pixels of the canvas, lies in the plot. */
const inPlot = (frame, x, y, slack = 0) => !!frame && x >= frame.plot.x - slack && x <= frame.plot.x + frame.plot.w + slack && y >= frame.plot.y - slack && y <= frame.plot.y + frame.plot.h + slack;

/** The values under the point (x, y): { x, y }, with null on an axis without values (categories). */
function valueAt(frame, x, y) {
  const { plot } = frame;
  return {
    x: frame.x ? toValue(frame.x, x, plot.x, plot.x + plot.w) : null,
    y: toValue(frame.y, y, plot.y + plot.h, plot.y),
  };
}

/** The pixels of the values { x, y } (either may be null). */
function pixelAt(frame, x, y) {
  const { plot } = frame;
  return {
    x: x === null || !frame.x ? null : toPixel(frame.x, x, plot.x, plot.x + plot.w),
    y: y === null ? null : toPixel(frame.y, y, plot.y + plot.h, plot.y),
  };
}

/** The whole extent of the data of a frame drawn without a view: the limits zoom and panning stay within. */
const fullView = (frame) => ({ x: frame.x ? [frame.x.min, frame.x.max] : null, y: [frame.y.min, frame.y.max] });

const axesOf = (zoom) => ({ x: zoom === 'xy' || zoom === 'x', y: zoom === 'xy' || zoom === 'y' });

/** One axis of a view, kept inside the whole axis and no narrower than MIN_SPAN of it; the full axis becomes null. */
function clampAxis(range, full, axis) {
  if (!range || !full) return null;
  const f0 = fwd(axis, full[0]);
  const f1 = fwd(axis, full[1]);
  const whole = f1 - f0;
  let a = fwd(axis, range[0]);
  let b = fwd(axis, range[1]);
  if (b - a >= whole * (1 - 1e-9)) return null;
  const span = Math.max(b - a, whole * MIN_SPAN);
  const mid = (a + b) / 2;
  a = mid - span / 2;
  b = mid + span / 2;
  if (a < f0) [a, b] = [f0, f0 + span];
  if (b > f1) [a, b] = [f1 - span, f1];
  return [back(axis, a), back(axis, b)];
}

/** A view kept inside the whole data; null when it shows everything. */
function clampView(view, frameAxes, full) {
  if (!view) return null;
  const x = frameAxes.x ? clampAxis(view.x, full.x, frameAxes.x) : null;
  const y = clampAxis(view.y, full.y, frameAxes.y);
  return x || y ? { x, y } : null;
}

/** The range an axis shows now: the view's, or the whole one. */
const current = (view, full, key) => (view && view[key]) || full[key];

/** Zooms one axis by k (k > 1 enlarges) about the value c. */
function zoomAxis(range, axis, c, k) {
  const a = fwd(axis, range[0]);
  const b = fwd(axis, range[1]);
  const t = fwd(axis, c);
  return [back(axis, t - (t - a) / k), back(axis, t + (b - t) / k)];
}

/**
 * The view zoomed by k (k > 1 enlarges, k < 1 shrinks) about the pixel (px,
 * py) of the plot, on the axes the chart allows (frame.zoom); `frame` is
 * the frame of the chart as drawn now, `full` its whole extent.
 */
function zoomView(view, frame, full, px, py, k) {
  const allowed = axesOf(frame.zoom);
  const at = valueAt(frame, px, py);
  const next = { x: null, y: null };
  if (allowed.x && frame.x) next.x = zoomAxis(current(view, full, 'x'), frame.x, at.x, k);
  else if (view && view.x) next.x = view.x;
  if (allowed.y) next.y = zoomAxis(current(view, full, 'y'), frame.y, at.y, k);
  else if (view && view.y) next.y = view.y;
  return clampView(next, frame, full);
}

/** The view moved by (dx, dy) pixels of the plot: the data follow the pointer. */
function panView(view, frame, full, dx, dy) {
  if (!view) return null;
  const allowed = axesOf(frame.zoom);
  const shift = (range, axis, pixels, size) => {
    const a = fwd(axis, range[0]);
    const b = fwd(axis, range[1]);
    const d = (pixels / size) * (b - a);
    return [back(axis, a - d), back(axis, b - d)];
  };
  const next = { x: view.x, y: view.y };
  if (allowed.x && frame.x && view.x) next.x = shift(view.x, frame.x, dx, frame.plot.w);
  if (allowed.y && view.y) next.y = shift(view.y, frame.y, -dy, frame.plot.h);
  // keep the span while moving: clampAxis would shrink a view pushed against the edge
  const keep = (range, full, axis) => {
    if (!range) return null;
    const f0 = fwd(axis, full[0]);
    const f1 = fwd(axis, full[1]);
    let a = fwd(axis, range[0]);
    let b = fwd(axis, range[1]);
    if (a < f0) [a, b] = [f0, f0 + (b - a)];
    if (b > f1) [a, b] = [f1 - (b - a), f1];
    return [back(axis, a), back(axis, b)];
  };
  return { x: frame.x ? keep(next.x, full.x, frame.x) : null, y: keep(next.y, full.y, frame.y) };
}

/** The view of the rectangle selected from (x0, y0) to (x1, y1), in pixels, on the axes the chart allows. */
function boxView(view, frame, full, x0, y0, x1, y1) {
  const allowed = axesOf(frame.zoom);
  const a = valueAt(frame, Math.min(x0, x1), Math.max(y0, y1));
  const b = valueAt(frame, Math.max(x0, x1), Math.min(y0, y1));
  return clampView(
    {
      x: allowed.x && frame.x ? [a.x, b.x] : (view && view.x) || null,
      y: allowed.y ? [a.y, b.y] : (view && view.y) || null,
    },
    frame,
    full,
  );
}

/** Whether a view shows less than the whole data. */
const isZoomed = (view) => !!view && (!!view.x || !!view.y);

return { toPixel, toValue, inPlot, valueAt, pixelAt, fullView, clampView, zoomView, panView, boxView, isZoomed };
})();

var kitGestures$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitGestures.js
// I gesti su un elemento: il puntatore (mouse, penna, dito), la rotella e i
// tasti, tradotti in quello che vogliono dire: passare sopra, premere e
// trascinare, il doppio clic, la rotella con Ctrl, il pizzico a due dita.
// Non sa niente di grafici: chi lo usa decide, con il valore che restituisce,
// se un gesto lo riguarda (press, wheel, pinch e key restituiscono true per
// tenerlo). Le coordinate sono in pixel CSS dall'angolo in alto a sinistra
// dell'elemento.

/**
 * Listens to `el` and calls `handlers`:
 *   hover(p)                     the pointer moves over it (not while a drag is on)
 *   leave()                      it leaves
 *   press(p) -> boolean          a button or a finger goes down; true starts a drag
 *   drag(p, start)               the pointer moves during that drag
 *   release(p, start)            the drag ends (or is cancelled)
 *   dblclick(p) -> boolean       double click
 *   wheel(p, { deltaY, ctrl }) -> boolean   true stops the page from scrolling
 *   pinch({ x, y, scale, dx, dy }) -> boolean   two fingers: the centre, the change of their distance and of the centre
 *   key(event) -> boolean        a key while the element has the focus; true stops its default action
 * p is { x, y, pointerType, button, shift, ctrl }. Returns the function that stops listening.
 */
function attachGestures(el, handlers) {
  const at = (e) => {
    const r = el.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top, pointerType: e.pointerType || 'mouse', button: e.button ?? 0, shift: !!e.shiftKey, ctrl: !!(e.ctrlKey || e.metaKey) };
  };
  const touches = new Map(); // pointerId -> { x, y } of the fingers down
  let drag = null; // { id, start } while a press holds the pointer
  let pinch = null; // { distance, x, y } while two fingers are down

  const twoFingers = () => {
    const [a, b] = [...touches.values()];
    return { distance: Math.hypot(a.x - b.x, a.y - b.y), x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
  };

  const onDown = (e) => {
    const p = at(e);
    if (e.pointerType === 'touch') {
      touches.set(e.pointerId, p);
      if (touches.size === 2) {
        // two fingers: the drag of one finger, if any, ends and the pinch begins
        if (drag && handlers.release) handlers.release(p, drag.start);
        drag = null;
        pinch = twoFingers();
        return;
      }
      if (touches.size > 2) return;
    }
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    if (handlers.press && handlers.press(p)) {
      drag = { id: e.pointerId, start: p };
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        // a pointer that is already gone cannot be captured: the drag still works while it stays on the element
      }
      e.preventDefault();
    }
  };

  const onMove = (e) => {
    const p = at(e);
    if (e.pointerType === 'touch' && touches.has(e.pointerId)) {
      touches.set(e.pointerId, p);
      if (pinch && touches.size === 2) {
        const now = twoFingers();
        const used = handlers.pinch && handlers.pinch({ x: now.x, y: now.y, scale: now.distance / Math.max(1, pinch.distance), dx: now.x - pinch.x, dy: now.y - pinch.y });
        pinch = now;
        if (used) e.preventDefault();
        return;
      }
    }
    if (drag && e.pointerId === drag.id) {
      if (handlers.drag) handlers.drag(p, drag.start);
      return;
    }
    if (!drag && handlers.hover && e.pointerType !== 'touch') handlers.hover(p);
  };

  const onUp = (e) => {
    const p = at(e);
    if (e.pointerType === 'touch') {
      touches.delete(e.pointerId);
      if (touches.size < 2) pinch = null;
    }
    if (drag && e.pointerId === drag.id) {
      const { start } = drag;
      drag = null;
      if (handlers.release) handlers.release(p, start);
    }
  };

  const onLeave = (e) => {
    if (!drag && e.pointerType !== 'touch' && handlers.leave) handlers.leave();
  };

  const onDouble = (e) => {
    if (handlers.dblclick && handlers.dblclick(at(e))) e.preventDefault();
  };

  const onWheel = (e) => {
    if (handlers.wheel && handlers.wheel(at(e), { deltaY: e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY, ctrl: !!(e.ctrlKey || e.metaKey) })) e.preventDefault();
  };

  const onKey = (e) => {
    if (handlers.key && handlers.key(e)) e.preventDefault();
  };

  // With touch-action: pan-y a finger moving up or down scrolls the page, and the browser takes the
  // gesture away from the chart (pointercancel). A finger that grabbed something (press returned
  // true: a line to drag) and a second finger (the pinch) keep the gesture for the chart: the
  // pointerdown comes before its touchstart, so the decision is taken when the browser asks.
  const onTouchStart = (e) => {
    if (drag || e.touches.length > 1) e.preventDefault();
  };
  const onTouchMove = (e) => {
    if ((drag || pinch) && e.cancelable) e.preventDefault();
  };

  el.addEventListener('pointerdown', onDown);
  el.addEventListener('pointermove', onMove);
  el.addEventListener('pointerup', onUp);
  el.addEventListener('pointercancel', onUp);
  el.addEventListener('pointerleave', onLeave);
  el.addEventListener('dblclick', onDouble);
  el.addEventListener('wheel', onWheel, { passive: false });
  el.addEventListener('keydown', onKey);
  el.addEventListener('touchstart', onTouchStart, { passive: false });
  el.addEventListener('touchmove', onTouchMove, { passive: false });
  return () => {
    el.removeEventListener('pointerdown', onDown);
    el.removeEventListener('pointermove', onMove);
    el.removeEventListener('pointerup', onUp);
    el.removeEventListener('pointercancel', onUp);
    el.removeEventListener('pointerleave', onLeave);
    el.removeEventListener('dblclick', onDouble);
    el.removeEventListener('wheel', onWheel);
    el.removeEventListener('keydown', onKey);
    el.removeEventListener('touchstart', onTouchStart);
    el.removeEventListener('touchmove', onTouchMove);
  };
}

return { attachGestures };
})();

var kitChart$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitChart.js
// Un grafico interattivo: il canvas disegnato dalla libreria dell'homework,
// una tela trasparente sopra per i segni delle interazioni (il rettangolo
// dello zoom, le maniglie da trascinare), la vista (quale parte degli assi
// si vede), le parti nascoste dalla legenda e l'etichetta sotto il
// puntatore.
//
// Il controllore non sa che grafico sia: lo sanno le funzioni che riceve
// (draw, frame, withView, height, hitTest, hitAt, pointerLabel), che ogni
// libreria fornisce (Dependency Inversion). Le interazioni sono plugin
// (kitPlugins.js): un'interazione nuova e' un plugin nuovo, il controllore
// non cambia (Open/Closed). I gesti passano ai plugin in ordine, e il primo
// che ne tiene uno lo segue fino alla fine.
const { attachGestures } = kitGestures$;
const { clampView, fullView, isZoomed, zoomView } = kitView$;

const requestFrame = (fn) => (typeof requestAnimationFrame === 'function' ? requestAnimationFrame(fn) : setTimeout(fn, 16));
const cancelFrame = (id) => (typeof cancelAnimationFrame === 'function' ? cancelAnimationFrame(id) : clearTimeout(id));

/**
 * Makes `canvas` an interactive chart. `deps`:
 *   draw, data, palette        the chart and what it draws
 *   frame(draw, data, width)   where the plot lies and what it shows (null: no zoom)
 *   withView(draw, data, view) the same data in another view
 *   height(draw, data, width)  the height of the canvas at this width
 *   hitTest, hitAt, pointerLabel   the label under the pointer (as attachChartTooltip)
 *   describe(hit, hidden)      its text, or null for none; link: the linked table, or null
 *   hidden                     the parts hidden by the legend
 *   plugins                    the interactions, in order of priority
 *   schedule(job)              where the first drawing goes (a queue of frames), optional
 * Returns the controller: setData, setPalette, setHidden, setDescribe,
 * resize, getFrame, getView, setView, zoomBy, resetView, isZoomed, on,
 * requestOverlay, setCursor, destroy.
 */
function createChart(canvas, deps) {
  const { draw, frame: frameOf, withView, height: heightOf, hitTest, hitAt, pointerLabel, schedule = null } = deps;
  let data = deps.data;
  let palette = deps.palette;
  let hidden = deps.hidden || [];
  let describe = deps.describe || null;
  let link = deps.link || null;
  let width = -1;
  let view = null;
  let viewed = data; // the data as drawn now: hidden parts and view applied
  let frame = null; // where the plot lies now
  let full = null; // the whole extent of the data, without a view
  let frameRequest = 0;
  let firstDrawn = false;
  let destroyed = false;
  const listeners = {};
  const plugins = deps.plugins || [];

  // the transparent canvas over the chart, for the marks of the interactions
  const overlay = document.createElement('canvas');
  overlay.setAttribute('aria-hidden', 'true');
  Object.assign(overlay.style, { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px' });
  canvas.after(overlay);

  const emit = (name, payload) => (listeners[name] || []).forEach((fn) => fn(payload));
  const shown = () => (hidden.length ? { ...data, hidden } : data);

  const drawOverlay = () => {
    const dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    Object.assign(overlay.style, { left: `${canvas.offsetLeft}px`, top: `${canvas.offsetTop}px`, width: `${w}px`, height: `${h}px` });
    if (overlay.width !== Math.round(w * dpr) || overlay.height !== Math.round(h * dpr)) {
      overlay.width = Math.round(w * dpr);
      overlay.height = Math.round(h * dpr);
    }
    const ctx = overlay.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    if (!frame) return;
    for (const plugin of plugins) if (plugin.overlay) plugin.overlay(ctx, frame, palette);
  };

  const render = () => {
    frameRequest = 0;
    if (destroyed || width <= 0) return;
    const base = shown();
    const fullFrame = frameOf(draw, base, width);
    full = fullFrame ? fullView(fullFrame) : null;
    // a view that the new data no longer allows (other limits) is brought back inside them
    if (view && fullFrame) view = clampView(view, fullFrame, full);
    if (!fullFrame) view = null;
    viewed = view ? withView(draw, base, view) : base;
    canvas.style.height = `${heightOf(draw, viewed, width)}px`;
    draw(canvas, { ...viewed, width }, palette);
    frame = frameOf(draw, viewed, width);
    canvas.tabIndex = frame ? 0 : -1;
    drawOverlay();
    // the label under a still pointer follows the chart that changed under it
    if (detachLabel && detachLabel.refresh) detachLabel.refresh();
    emit('render', { frame, view });
  };

  /** Draws again at the next frame (several changes in the same frame draw once). */
  const redraw = () => {
    if (!frameRequest && !destroyed) frameRequest = requestFrame(render);
  };

  // the label under the pointer, attached once: it always reads the data as drawn now
  let detachLabel = null;
  const attachLabel = () => {
    if (detachLabel || !describe) return;
    detachLabel = pointerLabel(
      canvas,
      (x, y, w) => {
        if (!describe) return null;
        const hit = hitTest(draw, viewed, w, x, y);
        const text = hit && describe(hit, hidden);
        return text ? { rect: hit.rect, text, row: link ? link.row(hit) : -1 } : null;
      },
      link && {
        table: () => (link ? link.table() : null),
        locate: (row, w) => {
          const hit = link && hitAt(draw, viewed, w, link.point(row));
          return hit && hit.rect;
        },
      },
    );
  };
  attachLabel();

  const api = {
    canvas,
    overlay,
    get palette() {
      return palette;
    },
    setData(next) {
      data = next;
      redraw();
    },
    setPalette(next) {
      palette = next;
      redraw();
    },
    setHidden(parts) {
      hidden = parts || [];
      redraw();
    },
    setDescribe(fn) {
      describe = fn;
      attachLabel();
    },
    setLink(next) {
      link = next;
    },
    /** The width the canvas gets in the page (from a ResizeObserver): the first drawing goes through the queue, if any. */
    resize(next) {
      if (next <= 0 || next === width) return;
      width = next;
      if (!firstDrawn && schedule) {
        firstDrawn = true;
        canvas.style.height = `${heightOf(draw, shown(), width)}px`;
        schedule(() => {
          if (!destroyed && canvas.isConnected) render();
        });
        return;
      }
      firstDrawn = true;
      render();
    },
    redraw,
    requestOverlay: () => drawOverlay(),
    getFrame: () => frame,
    getFullView: () => full,
    getView: () => view,
    setView(next) {
      const before = JSON.stringify(view);
      view = next && frame ? clampView(next, frame, full) : null;
      if (JSON.stringify(view) !== before) {
        emit('view', view);
        redraw();
      }
    },
    /** Zooms about the centre of the plot (k > 1 enlarges). */
    zoomBy(k) {
      if (!frame || !full) return;
      api.setView(zoomView(view, frame, full, frame.plot.x + frame.plot.w / 2, frame.plot.y + frame.plot.h / 2, k));
    },
    resetView() {
      api.setView(null);
    },
    isZoomed: () => isZoomed(view),
    canZoom: () => !!frame,
    setCursor(cursor) {
      canvas.style.cursor = cursor || '';
    },
    on(name, fn) {
      (listeners[name] = listeners[name] || []).push(fn);
      return () => {
        listeners[name] = (listeners[name] || []).filter((f) => f !== fn);
      };
    },
    emit,
    destroy() {
      destroyed = true;
      cancelFrame(frameRequest);
      detachGestures();
      if (detachLabel) detachLabel();
      for (const plugin of plugins) if (plugin.uninstall) plugin.uninstall();
      overlay.remove();
    },
  };

  // the gestures go to the plugins in order: the first that takes a press follows it to the end
  let active = null;
  const detachGestures = attachGestures(canvas, {
    hover(p) {
      let cursor = '';
      for (const plugin of plugins) {
        const c = plugin.hover && plugin.hover(p);
        if (c) {
          cursor = c;
          break;
        }
      }
      api.setCursor(cursor);
    },
    leave() {
      for (const plugin of plugins) if (plugin.leave) plugin.leave();
      api.setCursor('');
    },
    press(p) {
      active = plugins.find((plugin) => plugin.pointerDown && plugin.pointerDown(p)) || null;
      // the label waits while a plugin follows the drag
      if (active && detachLabel && detachLabel.suspend) detachLabel.suspend(true);
      return !!active;
    },
    drag(p, start) {
      if (active && active.pointerMove) active.pointerMove(p, start);
    },
    release(p, start) {
      if (active && active.pointerUp) active.pointerUp(p, start);
      if (active && detachLabel && detachLabel.suspend) detachLabel.suspend(false);
      active = null;
    },
    dblclick: (p) => plugins.some((plugin) => plugin.doubleClick && plugin.doubleClick(p)),
    wheel: (p, w) => plugins.some((plugin) => plugin.wheel && plugin.wheel(p, w)),
    pinch: (g) => plugins.some((plugin) => plugin.pinch && plugin.pinch(g)),
    key: (e) => plugins.some((plugin) => plugin.key && plugin.key(e)),
  });
  for (const plugin of plugins) if (plugin.install) plugin.install(api);
  return api;
}

return { createChart };
})();

var kitPlugins$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitPlugins.js
// Le interazioni di un grafico (kitChart.js), una per plugin. Un plugin e'
// un oggetto con i soli metodi che gli servono (Interface Segregation):
//   install(chart), uninstall()
//   hover(p) -> cursore o '', leave()
//   pointerDown(p) -> true per tenere il gesto, pointerMove(p, start), pointerUp(p, start)
//   doubleClick(p), wheel(p, { deltaY, ctrl }), pinch({ x, y, scale, dx, dy }), key(event) -> true se usati
//   overlay(ctx, frame, palette): i suoi segni sulla tela trasparente sopra il grafico
// Un'interazione nuova e' un plugin nuovo: il controllore non cambia.
const { boxView, inPlot, panView, pixelAt, valueAt, zoomView } = kitView$;

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/**
 * Zoom and panning: ctrl (or cmd) + wheel and two fingers zoom about the
 * pointer; a drag selects the rectangle to enlarge, or moves the view once
 * it is enlarged (with shift it always selects); a double click and the
 * keys 0 or Escape go back to the whole chart; + and - zoom, the arrows
 * move. A plain wheel scrolls the page, and the chart says (event 'hint')
 * how to zoom instead.
 */
function zoomPan() {
  let chart = null;
  let mode = null; // 'pan' or 'box' during a drag
  let box = null;
  let last = null;
  return {
    name: 'zoomPan',
    install(c) {
      chart = c;
    },
    hover(p) {
      const f = chart.getFrame();
      if (!inPlot(f, p.x, p.y)) return '';
      return chart.isZoomed() && !p.shift ? 'grab' : 'zoom-in';
    },
    pointerDown(p) {
      const f = chart.getFrame();
      if (!f || p.pointerType === 'touch' || !inPlot(f, p.x, p.y)) return false;
      if (chart.isZoomed() && !p.shift) {
        mode = 'pan';
        last = p;
        chart.setCursor('grabbing');
        return true;
      }
      mode = 'box';
      box = { x0: p.x, y0: p.y, x1: p.x, y1: p.y };
      return true;
    },
    pointerMove(p) {
      const f = chart.getFrame();
      if (!f) return;
      if (mode === 'pan') {
        chart.setView(panView(chart.getView(), f, chart.getFullView(), p.x - last.x, p.y - last.y));
        last = p;
      } else if (mode === 'box') {
        box.x1 = clamp(p.x, f.plot.x, f.plot.x + f.plot.w);
        box.y1 = clamp(p.y, f.plot.y, f.plot.y + f.plot.h);
        chart.requestOverlay();
      }
    },
    pointerUp() {
      const f = chart.getFrame();
      if (mode === 'box' && box && f) {
        const wide = Math.abs(box.x1 - box.x0) > 6 && f.zoom !== 'y';
        const tall = Math.abs(box.y1 - box.y0) > 6 && f.zoom !== 'x';
        if (wide || tall) {
          const { plot } = f;
          // a thin selection enlarges one axis only, the other one stays as it is
          const x0 = wide ? box.x0 : plot.x;
          const x1 = wide ? box.x1 : plot.x + plot.w;
          const y0 = tall ? box.y0 : plot.y;
          const y1 = tall ? box.y1 : plot.y + plot.h;
          const next = boxView(chart.getView(), f, chart.getFullView(), x0, y0, x1, y1);
          const view = chart.getView();
          chart.setView({ x: wide ? next && next.x : view && view.x, y: tall ? next && next.y : view && view.y });
        }
      }
      mode = null;
      box = null;
      chart.requestOverlay();
      chart.setCursor('');
    },
    doubleClick() {
      if (!chart.isZoomed()) return false;
      chart.resetView();
      return true;
    },
    wheel(p, w) {
      const f = chart.getFrame();
      if (!f || !inPlot(f, p.x, p.y)) return false;
      if (!w.ctrl) {
        chart.emit('hint');
        return false;
      }
      chart.setView(zoomView(chart.getView(), f, chart.getFullView(), p.x, p.y, Math.exp(-w.deltaY * 0.0025)));
      return true;
    },
    pinch(g) {
      const f = chart.getFrame();
      if (!f) return false;
      const zoomed = zoomView(chart.getView(), f, chart.getFullView(), g.x, g.y, g.scale);
      chart.setView(zoomed ? panView(zoomed, f, chart.getFullView(), g.dx, g.dy) : null);
      return true;
    },
    key(e) {
      const f = chart.getFrame();
      if (!f) return false;
      if (e.key === '+' || e.key === '=') {
        chart.zoomBy(1.5);
        return true;
      }
      if (e.key === '-' || e.key === '_') {
        if (!chart.isZoomed()) return false;
        chart.zoomBy(1 / 1.5);
        return true;
      }
      if (e.key === '0' || e.key === 'Escape') {
        if (!chart.isZoomed()) return false;
        chart.resetView();
        return true;
      }
      const step = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
      if (!step || !chart.isZoomed()) return false;
      chart.setView(panView(chart.getView(), f, chart.getFullView(), -step[0] * f.plot.w * 0.1, -step[1] * f.plot.h * 0.1));
      return true;
    },
    overlay(ctx, f, pal) {
      if (mode !== 'box' || !box) return;
      const yOnly = f.zoom === 'y';
      const xOnly = f.zoom === 'x';
      const x = yOnly ? f.plot.x : Math.min(box.x0, box.x1);
      const w = yOnly ? f.plot.w : Math.abs(box.x1 - box.x0);
      const y = xOnly ? f.plot.y : Math.min(box.y0, box.y1);
      const h = xOnly ? f.plot.h : Math.abs(box.y1 - box.y0);
      ctx.fillStyle = pal.highlight;
      ctx.globalAlpha = 0.1;
      ctx.fillRect(x, y, w, h);
      ctx.globalAlpha = 1;
      ctx.strokeStyle = pal.highlight;
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.strokeRect(x + 0.5, y + 0.5, w, h);
      ctx.setLineDash([]);
    },
  };
}

/**
 * Lines to drag on the chart, bound to the parameters of its spec: specs
 * [{ id, axis: 'x' (a vertical line) or 'y' (a horizontal one), value,
 * min, max, step?, values? (the allowed ones), label? }], in the units of
 * the axes. onChange(id, value) receives the new value while dragging; the
 * line itself moves when the spec gives the new value back (setSpecs).
 */
function handles({ onChange, onEnd = null }) {
  let chart = null;
  let specs = [];
  let grabbed = null;
  const where = (f, spec) => {
    const at = spec.axis === 'x' ? pixelAt(f, spec.value, null).x : pixelAt(f, null, spec.value).y;
    if (at === null || !Number.isFinite(at)) return null;
    const inside = spec.axis === 'x' ? at >= f.plot.x - 1 && at <= f.plot.x + f.plot.w + 1 : at >= f.plot.y - 1 && at <= f.plot.y + f.plot.h + 1;
    return inside ? at : null;
  };
  const near = (p) => {
    const f = chart && chart.getFrame();
    if (!f || !inPlot(f, p.x, p.y, 8)) return null;
    const reach = p.pointerType === 'touch' ? 14 : 7;
    let best = null;
    let distance = reach;
    for (const spec of specs) {
      const at = where(f, spec);
      if (at === null) continue;
      const d = Math.abs((spec.axis === 'x' ? p.x : p.y) - at);
      if (d <= distance) {
        best = spec;
        distance = d;
      }
    }
    return best;
  };
  const snap = (spec, v) => {
    if (spec.values && spec.values.length) {
      // on a logarithmic axis the nearest value is the nearest in the logarithms, as the eye sees it
      const f = chart && chart.getFrame();
      const axis = f && f[spec.axis];
      const t = axis && axis.log ? (u) => Math.log10(u) : (u) => u;
      return spec.values.reduce((a, b) => (Math.abs(t(b) - t(v)) < Math.abs(t(a) - t(v)) ? b : a));
    }
    let out = clamp(v, spec.min ?? -Infinity, spec.max ?? Infinity);
    if (spec.step) out = Math.round(out / spec.step) * spec.step;
    return Number(out.toPrecision(12));
  };
  return {
    name: 'handles',
    install(c) {
      chart = c;
    },
    setSpecs(next) {
      specs = next || [];
      if (chart) chart.requestOverlay();
    },
    hover(p) {
      const spec = near(p);
      if (!spec) return '';
      return spec.axis === 'x' ? 'ew-resize' : 'ns-resize';
    },
    pointerDown(p) {
      grabbed = near(p);
      if (!grabbed) return false;
      chart.setCursor(grabbed.axis === 'x' ? 'ew-resize' : 'ns-resize');
      return true;
    },
    pointerMove(p) {
      const f = chart.getFrame();
      if (!grabbed || !f) return;
      const v = valueAt(f, p.x, p.y)[grabbed.axis];
      if (v === null || !Number.isFinite(v)) return;
      const next = snap(grabbed, v);
      if (next !== grabbed.value) {
        grabbed = { ...grabbed, value: next };
        onChange(grabbed.id, next);
      }
    },
    pointerUp() {
      if (grabbed && onEnd) onEnd(grabbed.id);
      grabbed = null;
      chart.setCursor('');
    },
    overlay(ctx, f, pal) {
      for (const spec of specs) {
        const at = where(f, spec);
        if (at === null) continue;
        const active = grabbed && grabbed.id === spec.id;
        ctx.strokeStyle = pal.highlight;
        ctx.fillStyle = pal.highlight;
        ctx.lineWidth = active ? 2.5 : 1.8;
        ctx.beginPath();
        if (spec.axis === 'x') {
          ctx.moveTo(at, f.plot.y);
          ctx.lineTo(at, f.plot.y + f.plot.h);
        } else {
          ctx.moveTo(f.plot.x, at);
          ctx.lineTo(f.plot.x + f.plot.w, at);
        }
        ctx.stroke();
        // the knob to grab, with the label beside it: at the left of a horizontal line, away from
        // the zoom buttons in the top right corner, and at the top of a vertical one, above the bars
        // (at its bottom when the line runs under the zoom buttons)
        const low = spec.axis === 'x' && at > f.plot.x + f.plot.w - 96;
        const kx = spec.axis === 'x' ? at : f.plot.x + 9;
        let ky = at;
        if (spec.axis === 'x') ky = low ? f.plot.y + f.plot.h - 9 : f.plot.y + 9;
        ctx.beginPath();
        ctx.arc(kx, ky, active ? 7 : 6, 0, 2 * Math.PI);
        ctx.fill();
        ctx.strokeStyle = pal.background;
        ctx.lineWidth = 1.5;
        ctx.stroke();
        if (spec.label) {
          ctx.font = '11px sans-serif';
          ctx.fillStyle = pal.text;
          const right = spec.axis === 'x' && at > f.plot.x + f.plot.w * 0.7;
          ctx.textAlign = right ? 'right' : 'left';
          const tx = spec.axis === 'x' ? at + (right ? -10 : 10) : kx + 11;
          // above the line, or below it when the line is at the top of the plot
          let ty = spec.axis === 'x' ? ky + 4 : at - 7;
          if (spec.axis === 'y' && at - f.plot.y < 16) ty = at + 15;
          ctx.fillText(spec.label, tx, ty);
        }
      }
    },
  };
}

return { zoomPan, handles };
})();

var kitPlayer$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitPlayer.js
// Il lettore delle animazioni: un tempo t da 0 a frames - 1 che avanza a
// una certa velocita', con avvio, pausa, un passo avanti o indietro e un
// punto qualsiasi. Non sa niente di grafici: a ogni passo chiama
// onFrame(t), e chi lo usa ridisegna. All'inizio sta sull'ultimo passo, cosi'
// chi non preme Avvia vede il grafico completo, e non parte mai da solo:
// rispetta anche chi ha chiesto meno movimento.

const requestFrame = (fn) => (typeof requestAnimationFrame === 'function' ? requestAnimationFrame(fn) : setTimeout(() => fn(Date.now()), 16));
const cancelFrame = (id) => (typeof cancelAnimationFrame === 'function' ? cancelAnimationFrame(id) : clearTimeout(id));

/**
 * A player of `frames` steps, one every `ms` milliseconds at speed 1.
 * onFrame(t) draws step t; onChange(state) tells the interface { t,
 * frames, playing, speed }. Returns { play, pause, toggle, step, seek,
 * setSpeed, setFrames, setMs, state, destroy }.
 */
function createPlayer({ frames = 1, ms: stepMs = 60, loop = false, onFrame, onChange = null }) {
  let ms = stepMs;
  let count = Math.max(1, frames);
  let t = count - 1;
  let playing = false;
  let speed = 1;
  let request = 0;
  let last = 0;
  let elapsed = 0;
  const state = () => ({ t, frames: count, playing, speed });
  const notify = () => {
    if (onChange) onChange(state());
  };
  const tick = (now) => {
    if (!playing) return;
    if (!last) last = now;
    elapsed += (now - last) * speed;
    last = now;
    let moved = false;
    while (elapsed >= ms && playing) {
      elapsed -= ms;
      if (t < count - 1) {
        t += 1;
        moved = true;
      } else if (loop) {
        t = 0;
        moved = true;
      } else {
        playing = false;
      }
    }
    if (moved) onFrame(t);
    notify();
    if (playing) request = requestFrame(tick);
  };
  const api = {
    play() {
      if (playing || count < 2) return;
      // at the end, play starts again from the beginning
      if (t >= count - 1) {
        t = 0;
        onFrame(t);
      }
      playing = true;
      last = 0;
      elapsed = 0;
      request = requestFrame(tick);
      notify();
    },
    pause() {
      if (!playing) return;
      playing = false;
      cancelFrame(request);
      notify();
    },
    toggle() {
      if (playing) api.pause();
      else api.play();
    },
    step(by = 1) {
      api.pause();
      const next = Math.min(count - 1, Math.max(0, t + by));
      if (next !== t) {
        t = next;
        onFrame(t);
      }
      notify();
    },
    seek(at) {
      const next = Math.min(count - 1, Math.max(0, Math.round(at)));
      if (next !== t) {
        t = next;
        onFrame(t);
      }
      notify();
    },
    setSpeed(next) {
      speed = next;
      notify();
    },
    /** A new number of steps (the parameters changed): when stopped, the player goes to the end, where the chart is complete. */
    setFrames(next) {
      count = Math.max(1, next);
      if (!playing || t > count - 1) t = count - 1;
      notify();
    },
    /** Another length of a step, in milliseconds at speed 1 (a new animation). */
    setMs(next) {
      ms = Math.max(1, next);
    },
    state,
    destroy() {
      playing = false;
      cancelFrame(request);
    },
  };
  return api;
}

return { createPlayer };
})();

var kitSpec$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitSpec.js
// I comandi di una sezione e il suo modello: i parametri che i comandi
// cambiano e, quando una simulazione dipende da loro, il suo risultato. Il
// modello e' della sezione, non del grafico: grafici e tabelle della stessa
// sezione leggono gli stessi parametri e la stessa simulazione, e non
// possono raccontare cose diverse. Non sa niente di React ne' del DOM: la
// pagina lo usa con useModel.js, il programma scaricabile direttamente.
//
//   control = { key, kind: 'slider', values: [...], label(value) }
//           | { key, kind: 'choice', options: [[value, name], ...], label }
//           | { key, kind: 'toggle', label }
//           | { kind: 'action', label, run(params) -> params }
// Le etichette sono gia' nella lingua della pagina; il modello tiene solo i
// parametri, che non dipendono dalla lingua.

/** The position of a slider: the index of the value closest to the parameter. */
function sliderIndex(control, params) {
  const v = params[control.key];
  let best = 0;
  control.values.forEach((x, i) => {
    if (Math.abs(x - v) < Math.abs(control.values[best] - v)) best = i;
  });
  return best;
}

/** The parameters after a control is used: a slider gives the index of its value, a choice its value, a toggle true or false, an action nothing. */
function applyControl(control, params, input) {
  if (control.kind === 'slider') return { ...params, [control.key]: control.values[input] };
  if (control.kind === 'choice') return { ...params, [control.key]: input };
  if (control.kind === 'toggle') return { ...params, [control.key]: !!input };
  if (control.kind === 'action') return control.run(params);
  return params;
}

const keyOf = (params) => JSON.stringify(params);
const KEPT = 6;

/**
 * The state of a section with controls: { params, sim, pending, error }.
 *   params            the parameters at the start
 *   simulate(params)  optional: the steps (a generator) of a simulation, whose return value is its result
 *   simKey(params)    which parameters the simulation depends on (default: all of them)
 *   runner            the library's runStepsAsync: the simulation runs in slices of a few milliseconds
 * While a simulation runs, `sim` stays the last result (so nothing goes
 * blank) and `pending` is true; the results of the last parameters seen
 * are kept, and a simulation nobody wants any more stops between two slices.
 * Returns { get, setParams, provide, subscribe, destroy }.
 */
function createModel({ params, simulate = null, simKey = keyOf, runner = null }) {
  let state = { params: { ...params }, sim: null, pending: false, error: null };
  const cache = new Map();
  const listeners = new Set();
  let job = null;
  const set = (patch) => {
    state = { ...state, ...patch };
    listeners.forEach((fn) => fn());
  };
  const remember = (key, value) => {
    cache.delete(key);
    cache.set(key, value);
    while (cache.size > KEPT) cache.delete(cache.keys().next().value);
  };
  const run = (p) => {
    if (!simulate) return;
    const key = simKey(p);
    if (cache.has(key)) {
      if (job) job.cancel();
      job = null;
      set({ sim: cache.get(key), pending: false, error: null });
      return;
    }
    if (job && job.key === key) return;
    if (job) job.cancel();
    if (!runner) return;
    let cancelled = false;
    function* guarded() {
      const steps = simulate(p);
      let step = steps.next();
      while (!step.done) {
        if (cancelled) throw new Error('cancelled');
        yield;
        step = steps.next();
      }
      return step.value;
    }
    job = {
      key,
      cancel: () => {
        cancelled = true;
      },
    };
    set({ pending: true });
    runner(guarded).then(
      (value) => {
        if (cancelled) return;
        remember(key, value);
        job = null;
        set({ sim: value, pending: false, error: null });
      },
      (error) => {
        if (cancelled) return;
        job = null;
        set({ pending: false, error: error instanceof Error ? error.message : String(error) });
      },
    );
  };
  return {
    get: () => state,
    setParams(next) {
      set({ params: next });
      run(next);
    },
    /** A result computed elsewhere (the worker of the page) for the parameters `forParams`: used now if they are the current ones. */
    provide(value, forParams = params) {
      if (!simulate || !value) return;
      const key = simKey(forParams);
      if (!cache.has(key)) remember(key, value);
      if (simKey(state.params) === key && state.sim !== value) {
        if (job && job.key === key) {
          job.cancel();
          job = null;
        }
        set({ sim: value, pending: false, error: null });
      }
    },
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    destroy() {
      if (job) job.cancel();
      job = null;
      listeners.clear();
    },
  };
}

return { sliderIndex, applyControl, createModel };
})();

var kitLabels$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitLabels.js
// I testi dei comandi dei grafici interattivi, uguali in ogni homework: lo
// zoom, il suggerimento, il lettore delle animazioni.

const KIT_LABELS = Object.freeze({
  it: Object.freeze({
    tools: 'Zoom del grafico',
    zoomIn: 'Ingrandisci',
    zoomOut: 'Riduci',
    reset: 'Vista intera',
    hint: 'Ctrl + rotella per ingrandire; oppure trascinate per scegliere una zona, doppio clic per tornare alla vista intera',
    touchHint: 'Due dita per ingrandire',
    player: 'Animazione',
    play: 'Avvia',
    pause: 'Pausa',
    back: 'Un passo indietro',
    forward: 'Un passo avanti',
    speed: 'Velocità',
    position: (t, n) => `Passo ${t} di ${n}`,
    pending: 'Simulazione in corso...',
  }),
  en: Object.freeze({
    tools: 'Chart zoom',
    zoomIn: 'Zoom in',
    zoomOut: 'Zoom out',
    reset: 'Whole chart',
    hint: 'Ctrl + wheel to zoom; or drag to pick an area, double click to go back to the whole chart',
    touchHint: 'Two fingers to zoom',
    player: 'Animation',
    play: 'Play',
    pause: 'Pause',
    back: 'One step back',
    forward: 'One step forward',
    speed: 'Speed',
    position: (t, n) => `Step ${t} of ${n}`,
    pending: 'Simulating...',
  }),
});

/** The labels in a language, English when it is not known. */
const kitLabels = (lang) => KIT_LABELS[lang] || KIT_LABELS.en;

return { KIT_LABELS, kitLabels };
})();

var kitReveal$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitReveal.js
// L'animazione piu' comune dei grafici degli homework: una curva disegnata
// punto per punto, al crescere della sua x (n che cresce, i giorni, i
// tentativi). Vale per i dati dei grafici a linee di ogni libreria, { x,
// series: [{ values, band?, fixed? }] }: le serie `fixed` (riferimenti,
// bande, soglie) restano intere.

/** An animation that draws a line chart point by point, as its x grows: { frames, at(t), ms }. */
function reveal(chart, ms = 110) {
  return {
    frames: chart.x.length,
    ms,
    at: (t) => ({
      ...chart,
      series: chart.series.map((s) => (s.fixed ? s : { ...s, values: s.values.map((v, i) => (i <= t ? v : null)), band: s.band ? s.band.map((b, i) => (i <= t ? b : null)) : s.band })),
    }),
  };
}

return { reveal };
})();

var kitDom$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitDom.js
// L'adattatore del kit dei grafici interattivi per i programmi scaricabili:
// lo stesso grafico della pagina (ChartFigure.jsx), costruito con il DOM, senza
// React. Un grafico e' una <figure> con, dall'alto: il riquadro del canvas
// con i pulsanti dello zoom, il lettore dell'animazione, la legenda a
// pulsanti, la nota e la didascalia. I comandi di una sezione (controlsOf,
// modelControls) stanno sopra i suoi grafici e seguono il suo modello
// (kitSpec.createModel). Le classi sono quelle di style.css dei programmi.
//
// Ogni testo entra con textContent, mai come HTML.
const { createChart } = kitChart$;
const { kitLabels } = kitLabels$;
const { createPlayer } = kitPlayer$;
const { handles: handlesPlugin, zoomPan } = kitPlugins$;
const { applyControl, createModel: makeModel, sliderIndex } = kitSpec$;

const HINT_MS = 2200;

/** The model of a section with controls (kitSpec.createModel), for the programs. */
const createModel = makeModel;
let uid = 0;

/** el('p', { class: 'note', text: '...' }, child, ...): the text always through textContent. */
function el(tag, attrs, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key === 'style') Object.assign(node.style, value);
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? '' : String(value));
  }
  for (const child of children.flat(Infinity)) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

/** The parts of the drawing covered by the hidden items of a legend. */
const partsOf = (items, hidden) => items.flatMap((item, i) => (hidden.has(i) ? item.parts || [] : []));

/** Hides the cells, columns and rows of a table that belong to hidden parts (data-part), and shows the others. */
function hideParts(table, parts) {
  if (!table) return;
  for (const node of table.querySelectorAll('[data-part]')) node.hidden = parts.includes(node.dataset.part);
}

/**
 * The legend of a chart: { label, color? | paletteKey?, dashed?, box?,
 * parts }. Every item is a button: pressed its parts are on screen,
 * released they are hidden; onChange(parts) receives the hidden parts.
 * `hidden`, the set of the hidden items, outlives the legend.
 */
function legend(items, onChange, hidden, palette) {
  return el(
    'ul',
    { class: 'series-legend' },
    items.map((item, i) => {
      const color = item.paletteKey ? palette[item.paletteKey] : palette.series[(item.color ?? i) % palette.series.length];
      let swatch = null;
      if (item.box) swatch = 'is-box';
      else if (item.dashed) swatch = 'is-dashed';
      const button = el(
        'button',
        {
          type: 'button',
          'aria-pressed': String(!hidden.has(i)),
          class: hidden.has(i) ? 'is-off' : null,
          onclick: () => {
            if (hidden.has(i)) hidden.delete(i);
            else hidden.add(i);
            button.setAttribute('aria-pressed', String(!hidden.has(i)));
            button.classList.toggle('is-off', hidden.has(i));
            onChange(partsOf(items, hidden));
          },
        },
        el('span', { class: swatch, 'aria-hidden': 'true', style: { borderColor: color, backgroundColor: item.box ? color : 'transparent' } }),
        item.label,
      );
      return el('li', null, button);
    }),
  );
}

/**
 * The controls of a section (kitSpec), with the classes of the programs:
 * getParams() gives the parameters, onChange(params) receives them after
 * every use. box.update() moves the controls to the current parameters
 * without rebuilding them (a slider keeps the focus while it moves).
 */
function controlsOf(controls, getParams, onChange, pendingLabel = '') {
  const id = `kitc${(uid += 1)}`;
  const actions = controls.filter((c) => c.kind === 'action');
  const pending = el('p', { class: 'kit-pending note', role: 'status', text: pendingLabel, hidden: true });
  const params = getParams();
  const blocks = controls
    .map((c, i) => {
      if (c.kind === 'slider') {
        const index = sliderIndex(c, params);
        const text = c.label(c.values[index]);
        return el(
          'div',
          { class: 'slider' },
          el('label', { for: `${id}-${c.key}`, text }),
          el('input', { id: `${id}-${c.key}`, type: 'range', min: 0, max: c.values.length - 1, step: 1, value: index, 'aria-valuetext': text, oninput: (e) => onChange(applyControl(c, getParams(), Number(e.target.value))) }),
        );
      }
      if (c.kind === 'choice') {
        return el(
          'div',
          { class: 'choices', role: 'group', 'aria-label': c.label },
          el('span', { class: 'choices-label', text: c.label }),
          c.options.map(([value, name]) => el('button', { type: 'button', class: 'btn alt', 'aria-pressed': String(params[c.key] === value), text: name, onclick: () => onChange(applyControl(c, getParams(), value)) })),
        );
      }
      if (c.kind === 'toggle') {
        return el('label', { class: 'kit-toggle' }, el('input', { type: 'checkbox', checked: !!params[c.key], onchange: (e) => onChange(applyControl(c, getParams(), e.target.checked)) }), ` ${c.label}`);
      }
      if (i !== controls.indexOf(actions[0])) return null;
      return el('p', { class: 'kit-actions' }, actions.map((a) => el('button', { type: 'button', class: 'btn alt small', text: a.label, onclick: () => onChange(applyControl(a, getParams())) })));
    })
    .filter(Boolean);
  const box = el('div', { class: 'kit-controls' }, blocks, pending);
  box.update = (busy = false) => {
    const now = getParams();
    let k = 0;
    for (const c of controls) {
      if (c.kind === 'action' && c !== actions[0]) continue;
      const block = blocks[k];
      k += 1;
      if (c.kind === 'slider') {
        const index = sliderIndex(c, now);
        const text = c.label(c.values[index]);
        block.querySelector('label').textContent = text;
        const input = block.querySelector('input');
        if (Number(input.value) !== index) input.value = String(index);
        input.setAttribute('aria-valuetext', text);
      } else if (c.kind === 'choice') {
        block.querySelectorAll('button').forEach((b, j) => b.setAttribute('aria-pressed', String(now[c.key] === c.options[j][0])));
      } else if (c.kind === 'toggle') {
        block.querySelector('input').checked = !!now[c.key];
      }
    }
    pending.hidden = !busy;
  };
  return box;
}

/** The controls bound to the model of a section (kitSpec.createModel): they follow it, and are released with their region (releaseFigures). */
function modelControls(model, controls, lang = 'en') {
  const box = controlsOf(controls, () => model.get().params, (next) => model.setParams(next), kitLabels(lang).pending);
  box.kitRelease = model.subscribe(() => box.update(model.get().pending));
  box.update(model.get().pending);
  return box;
}

/** The player of an animation: back, play or pause, forward, the position and the speed. */
function playerBar(id, player, labels) {
  const back = el('button', { type: 'button', class: 'btn alt small', 'aria-label': labels.back, title: labels.back, text: '‹', onclick: () => player.step(-1) });
  const play = el('button', { type: 'button', class: 'btn small kit-play', onclick: () => player.toggle() });
  const forward = el('button', { type: 'button', class: 'btn alt small', 'aria-label': labels.forward, title: labels.forward, text: '›', onclick: () => player.step(1) });
  const position = el('input', { id: `${id}-t`, class: 'kit-position', type: 'range', min: 0, step: 1, oninput: (e) => player.seek(Number(e.target.value)) });
  const where = el('span', { class: 'kit-step', 'aria-hidden': 'true' });
  const speeds = [1, 2, 4].map((s) => el('button', { type: 'button', class: 'btn alt small', text: `×${s}`, onclick: () => player.setSpeed(s) }));
  const bar = el('div', { class: 'kit-player', role: 'group', 'aria-label': labels.player }, back, play, forward, position, where, el('span', { class: 'kit-speed', role: 'group', 'aria-label': labels.speed }, speeds));
  bar.update = (state) => {
    play.textContent = state.playing ? labels.pause : labels.play;
    play.setAttribute('aria-pressed', String(state.playing));
    back.disabled = state.t <= 0;
    forward.disabled = state.t >= state.frames - 1;
    position.max = String(state.frames - 1);
    position.value = String(state.t);
    const text = labels.position(state.t + 1, state.frames);
    position.setAttribute('aria-label', text);
    position.setAttribute('aria-valuetext', text);
    where.textContent = text;
    speeds.forEach((b, i) => b.setAttribute('aria-pressed', String(state.speed === [1, 2, 4][i])));
  };
  return bar;
}

// one observer for every chart of the page: the width of each canvas, measured after layout
const sizes = typeof ResizeObserver === 'function'
  ? new ResizeObserver((entries) => {
    for (const entry of entries) {
      const width = Math.round(entry.contentRect.width);
      const figure = entry.target.closest('figure');
      if (figure && figure.kit && width > 0) figure.kit.chart.resize(width);
    }
  })
  : null;

/**
 * An interactive chart for the programs. `options`:
 *   label, draw, data, palette, lang
 *   lib (the library of the homework), schedule (the queue of the first drawings)
 *   tip (describe(hit, hidden)), link, items (the legend), keep (the set of hidden items that outlives the chart),
 *   table (the id of the linked table: the legend hides its parts too), onHide(parts) (anything else the legend hides), note, wide
 *   animation ({ frames, at(t) -> data, ms }: the chart step by step, with the player)
 *   handles ({ items, onChange(id, value) }: the lines to drag), pending (a simulation is running)
 * Returns the <figure>, with figure.kit = { chart, setData, setTip, setLabel,
 * setNote, relabel, setHidden, setAnimation, setHandles, setPending, destroy }.
 */
function createFigure(options) {
  const { label, draw, palette, lib, schedule = null, lang = 'en', items = null, note = null, link = null, table = null, wide = true } = options;
  const labels = kitLabels(lang);
  const id = `kit${(uid += 1)}`;
  const hidden = options.keep || new Set();
  let given = options.data;
  let animation = options.animation || null;
  let onHandle = options.handles ? options.handles.onChange : null;
  let t = animation ? Math.max(1, animation.frames) - 1 : 0;
  const frames = () => (animation ? Math.max(1, animation.frames) : 1);
  const dataNow = () => (animation && t < frames() - 1 ? animation.at(t) : given);

  const canvas = el('canvas', { class: 'chart', role: 'img', 'aria-label': label });
  const plot = el('div', { class: 'kit-plot' }, canvas);
  const zoomIn = el('button', { type: 'button', 'aria-label': labels.zoomIn, title: labels.zoomIn, text: '+' });
  const zoomOut = el('button', { type: 'button', 'aria-label': labels.zoomOut, title: labels.zoomOut, text: '-', disabled: true });
  const reset = el('button', { type: 'button', 'aria-label': labels.reset, title: labels.reset, text: '⤢', disabled: true });
  const tools = el('div', { class: 'kit-tools', role: 'group', 'aria-label': labels.tools, hidden: true }, zoomIn, zoomOut, reset);
  const hint = el('p', { class: 'kit-hint', 'aria-live': 'polite', text: labels.hint, hidden: true });
  const busy = el('p', { class: 'kit-busy', role: 'status', text: labels.pending, hidden: !options.pending });
  const caption = el('figcaption', { text: label });
  const noteEl = el('p', { class: 'figure-note', text: note || '', hidden: !note });

  const handles = options.handles ? handlesPlugin({ onChange: (key, value) => onHandle && onHandle(key, value) }) : null;
  const chart = createChart(canvas, {
    draw,
    data: dataNow(),
    palette,
    frame: lib.chartFrame,
    withView: lib.withView,
    height: lib.chartHeight,
    hitTest: lib.chartHitTest,
    hitAt: lib.chartHitAt,
    pointerLabel: lib.attachPointerLabel,
    describe: options.tip || null,
    link,
    hidden: items ? partsOf(items, hidden) : [],
    plugins: handles ? [handles, zoomPan()] : [zoomPan()],
    schedule,
  });
  if (handles) handles.setSpecs(options.handles.items);
  zoomIn.addEventListener('click', () => chart.zoomBy(1.5));
  zoomOut.addEventListener('click', () => chart.zoomBy(1 / 1.5));
  reset.addEventListener('click', () => chart.resetView());
  chart.on('render', ({ frame }) => {
    tools.hidden = !frame;
  });
  chart.on('view', () => {
    const zoomed = chart.isZoomed();
    tools.classList.toggle('is-zoomed', zoomed);
    zoomOut.disabled = !zoomed;
    reset.disabled = !zoomed;
  });
  let hintTimer = 0;
  chart.on('hint', () => {
    hint.hidden = false;
    clearTimeout(hintTimer);
    hintTimer = setTimeout(() => {
      hint.hidden = true;
    }, HINT_MS);
  });

  // the animation: the player starts on the last step, where the chart is complete
  let bar = null;
  const player = createPlayer({
    frames: frames(),
    ms: (animation && animation.ms) || 60,
    onFrame: (step) => {
      t = step;
      chart.setData(dataNow());
    },
    onChange: (state) => bar && bar.update(state),
  });
  bar = playerBar(id, player, labels);
  bar.hidden = !animation;
  bar.update(player.state());

  const legendEl = items
    ? legend(
      items,
      (parts) => {
        chart.setHidden(parts);
        if (table) hideParts(document.getElementById(table), parts);
        if (options.onHide) options.onHide(parts);
      },
      hidden,
      palette,
    )
    : null;
  const figure = el(
    'figure',
    { class: `${wide ? 'figure wide' : 'figure'} kit-figure${options.pending ? ' is-pending' : ''}` },
    el('div', { class: 'kit-stage' }, plot, tools, hint, busy),
    bar,
    legendEl,
    noteEl,
    caption,
  );
  figure.kit = {
    chart,
    setData(next) {
      given = next;
      chart.setData(dataNow());
    },
    setTip: (next) => chart.setDescribe(next),
    setLabel(next) {
      canvas.setAttribute('aria-label', next);
      caption.textContent = next;
    },
    setNote(next) {
      noteEl.textContent = next || '';
      noteEl.hidden = !next;
    },
    /** New labels for the buttons of the legend (the same items, in the same order). */
    relabel(next) {
      if (!legendEl) return;
      legendEl.querySelectorAll('button').forEach((button, i) => {
        if (next[i]) button.lastChild.textContent = next[i].label;
      });
    },
    setHidden: (parts) => chart.setHidden(parts),
    /** A new animation (the parameters changed): when stopped, the player goes to the end, where the chart is complete. */
    setAnimation(next) {
      animation = next || null;
      bar.hidden = !animation;
      if (animation && animation.ms) player.setMs(animation.ms);
      player.setFrames(frames());
      t = player.state().t;
      chart.setData(dataNow());
    },
    setHandles(next) {
      if (!handles || !next) return;
      onHandle = next.onChange;
      handles.setSpecs(next.items);
    },
    setPending(on) {
      busy.hidden = !on;
      figure.classList.toggle('is-pending', !!on);
      canvas.setAttribute('aria-busy', on ? 'true' : 'false');
    },
    destroy() {
      clearTimeout(hintTimer);
      if (sizes) sizes.unobserve(canvas);
      player.destroy();
      chart.destroy();
    },
  };
  if (sizes) sizes.observe(canvas);
  // the table may come after the chart: its parts are hidden once both are on the page
  if (table && hidden.size && typeof requestAnimationFrame === 'function') requestAnimationFrame(() => hideParts(document.getElementById(table), partsOf(items, hidden)));
  return figure;
}

/** Releases the charts and the controls inside a region that is about to be replaced. */
function releaseFigures(region) {
  for (const figure of region.querySelectorAll('figure.kit-figure')) if (figure.kit) figure.kit.destroy();
  for (const box of region.querySelectorAll('.kit-controls')) if (box.kitRelease) box.kitRelease();
}

return { createModel, partsOf, hideParts, legend, controlsOf, modelControls, createFigure, releaseFigures };
})();

var view$ = (function () {
'use strict';

// src/pages/statistics/hw2a/view.js
// Logica di presentazione dell'Homework #2, condivisa fra la pagina del sito
// (React) e il programma scaricabile (DOM puro): le sezioni, la lettura dei
// campi, le righe delle tabelle e i dati dei grafici. Tenerla qui impedisce
// che le due versioni dicano cose diverse sugli stessi numeri.
const hw = Homework2a;
const { reveal: revealChart } = kitReveal$;

/** The sections of the homework, in page order: ids for the anchors, keys for the titles. */
const SECTIONS = [
  { id: 'hw2a-assignment', key: 'assignment', level: 0 },
  { id: 'hw2a-scheme', key: 'scheme', level: 0 },
  { id: 'hw2a-input', key: 'input', level: 1 },
  { id: 'hw2a-keys', key: 'keys', level: 1 },
  { id: 'hw2a-encrypt', key: 'encrypt', level: 1 },
  { id: 'hw2a-decrypt', key: 'decrypt', level: 1 },
  { id: 'hw2a-roles', key: 'roles', level: 1 },
  { id: 'hw2a-verify', key: 'verify', level: 1 },
  { id: 'hw2a-caesar', key: 'caesar', level: 0 },
  { id: 'hw2a-caesar-cipher', key: 'caesarCipher', level: 1 },
  { id: 'hw2a-compare', key: 'compare', level: 1 },
  { id: 'hw2a-properties', key: 'properties', level: 1 },
  { id: 'hw2a-cryptanalysis', key: 'cryptanalysis', level: 0 },
  { id: 'hw2a-corpus', key: 'corpus', level: 1 },
  { id: 'hw2a-algorithm', key: 'algorithm', level: 1 },
  { id: 'hw2a-lengths', key: 'lengths', level: 1 },
  { id: 'hw2a-methods', key: 'methods', level: 1 },
  { id: 'hw2a-limits', key: 'limits', level: 1 },
  { id: 'hw2a-attack', key: 'attack', level: 0 },
  { id: 'hw2a-exhaustive', key: 'exhaustive', level: 1 },
  { id: 'hw2a-bsgs', key: 'bsgs', level: 1 },
  { id: 'hw2a-kangaroo', key: 'kangaroo', level: 1 },
  { id: 'hw2a-scaling', key: 'scaling', level: 1 },
  { id: 'hw2a-differences', key: 'differences', level: 1 },
  { id: 'hw2a-real', key: 'real', level: 1 },
  { id: 'hw2a-weaknesses', key: 'weaknesses', level: 1 },
  { id: 'hw2a-tests', key: 'tests', level: 0 },
  { id: 'hw2a-history', key: 'history', level: 0 },
  { id: 'hw2a-conclusion', key: 'conclusion', level: 0 },
];

/** The entries of the index, with their titles in the chosen language. */
const tocEntries = (titles) => SECTIONS.map((s) => ({ ...s, title: titles[s.key] }));

// ---------------------------------------------------------------------------
// The fields: private key, message, shift
// ---------------------------------------------------------------------------

/** Longest texts the fields accept: the message is checked again in bytes. */
const KEY_MAX_LENGTH = 12;
const MESSAGE_MAX_LENGTH = hw.MESSAGE_MAX_BYTES;
const SHIFT_MAX_LENGTH = 3;

/** The values the page starts from, and returns to with "restore". */
const DEFAULT_INPUTS = Object.freeze({
  keyText: String(hw.DEFAULT_KEY),
  message: hw.DEFAULT_MESSAGE,
  shiftText: String(hw.DEFAULT_SHIFT),
});

/** The message typed by the user: not empty, and at most MESSAGE_MAX_BYTES bytes of UTF-8. */
function parseMessage(text) {
  if (text === '') return { ok: false, error: 'empty' };
  const bytes = hw.utf8(text).length;
  if (bytes > hw.MESSAGE_MAX_BYTES) return { ok: false, error: 'tooLong', bytes };
  return { ok: true, value: text, bytes };
}

/** The three fields, each read on its own: an error in one does not stop the sections that depend on the others. */
const readInputs = ({ keyText, message, shiftText }) => ({
  key: hw.parsePrivateKey(keyText),
  message: parseMessage(message),
  shift: hw.parseShift(shiftText),
});

/** Whether the fields hold the starting key and message, with the reproducible nonces. */
const isDefaultInput = (fields, nonces) => nonces === 'seeded' && fields.keyText.trim() === DEFAULT_INPUTS.keyText && fields.message === DEFAULT_INPUTS.message;

/** The line under the fields: the known values with their expected public key, and whether "restore" makes sense. */
function inputBadge(fields, nonces, I) {
  if (isDefaultInput(fields, nonces)) return { known: true, restore: fields.shiftText.trim() !== DEFAULT_INPUTS.shiftText, text: I.defaultBadge(hw.DEFAULT_PUBLIC_KEY) };
  return { known: false, restore: true, text: I.customBadge };
}

// ---------------------------------------------------------------------------
// 1. The toy scheme
// ---------------------------------------------------------------------------

/** Short form of a long hexadecimal string. */
const shortHex = (hex, keep = 8) => (hex.length > 2 * keep + 3 ? `${hex.slice(0, keep)}...${hex.slice(-keep)}` : hex);

const hex256 = (n) => n.toString(16).padStart(64, '0');

/** A byte as the tables show it: the character when it is printable ASCII, a middle dot otherwise. */
function charOf(byte) {
  if (byte === 32) return '␣';
  return byte > 32 && byte < 127 ? String.fromCharCode(byte) : '·';
}

/** The facts of section 1.2 about a key pair. */
function keyFacts(scheme) {
  const { k, K } = scheme;
  return {
    k: k.toString(),
    hex: `0x${k.toString(16)}`,
    bits: k.toString(2).length,
    binary: k.toString(2).padStart(hw.KEY_BITS, '0'),
    x: hex256(K.x),
    y: hex256(K.y),
    compressed: hw.pointHex(K),
    even: K.y % 2n === 0n,
    onCurve: hw.isOnSecp256k1(K),
    isDefault: k === hw.DEFAULT_KEY,
    matchesReference: hw.pointHex(K) === hw.DEFAULT_PUBLIC_KEY,
  };
}

/** One row per block of the ciphertext: position, byte, nonce and the two points. */
const blockRows = (blocks) =>
  blocks.map((b) => ({
    position: b.index + 1,
    byte: b.byte,
    char: charOf(b.byte),
    r: shortHex(hex256(b.r), 6),
    C1: shortHex(hw.pointHex(b.C1), 6),
    C2: shortHex(hw.pointHex(b.C2), 6),
  }));

/** The first block, step by step, for section 1.4: what the receiver computes. */
function firstBlock(blocks, decrypted) {
  if (!blocks.length) return null;
  const b = blocks[0];
  const d = decrypted.blocks[0];
  return {
    byte: b.byte,
    char: charOf(b.byte),
    C1: hw.pointHex(b.C1),
    C2: hw.pointHex(b.C2),
    S: hw.pointHex(d.S),
    M: hw.pointHex(d.M),
    decoded: d.byte,
    sameS: hw.pointsEqual(d.S, b.S),
  };
}

/** The size of the ciphertext: 66 bytes per byte of message. */
const ciphertextSize = (blocks) => ({ bytes: blocks.length, total: 66 * blocks.length });

/**
 * The line under the nonce buttons: the ciphertext of section 1.3 by its
 * size and SHA-256, so that a new draw shows next to the button that made
 * it, and whether k still decrypts it to the message.
 */
function cipherSummary(encryption, decryption, nonces, draw) {
  const bytes = hw.ciphertextBytes(encryption.blocks);
  return {
    mode: nonces,
    draw,
    total: bytes.length,
    digest: shortHex(hw.toHex(hw.sha256(bytes))),
    ok: decryption.ok && decryption.text === encryption.text,
  };
}

/** The rows of the checks of section 1.6, grouped. */
function checkGroups(rows) {
  const groups = [];
  for (const row of rows) {
    if (!groups.length || groups[groups.length - 1].group !== row.group) groups.push({ group: row.group, rows: [] });
    groups[groups.length - 1].rows.push(row);
  }
  return groups;
}

// ---------------------------------------------------------------------------
// 2. The Caesar cipher and the two ciphertexts
// ---------------------------------------------------------------------------

const UPPER = hw.ALPHABET.toUpperCase().split('');

/** The substitution table of a shift: the plain alphabet and the cipher alphabet. */
const substitution = (shift) => ({ plain: UPPER, cipher: UPPER.map((_, i) => UPPER[(i + shift) % 26]) });

/** The Caesar cipher on the message: ciphertext, decryption, and the most frequent letter with its image. */
function caesarFacts(message, shift) {
  const cipher = hw.caesar(message, shift);
  const decrypted = hw.caesarDecrypt(cipher, shift);
  const counts = hw.letterCounts(hw.letterIndices(message));
  const letters = counts.reduce((s, c) => s + c, 0);
  const top = counts.indexOf(Math.max(...counts));
  return {
    cipher,
    decrypted,
    ok: decrypted === message,
    letters,
    top: letters ? { letter: hw.ALPHABET[top], count: counts[top], image: hw.ALPHABET[(top + shift) % 26] } : null,
  };
}

/**
 * The letter counts of a text for a bar chart, with the counts expected
 * from the frequencies of the training chapters (L q) as the dashed
 * reference.
 */
function letterChart(text, decimal = '.') {
  const counts = hw.letterCounts(hw.letterIndices(text));
  const L = counts.reduce((s, c) => s + c, 0);
  return { values: counts, expected: hw.trainingFrequencies().map((q) => q * L), labels: UPPER, allLabels: true, decimal };
}

/** The table of section 2.3: entropy and index of coincidence of the plaintext and of the two ciphertexts. */
function cipherRows(s) {
  const c = s.ciphers;
  return [
    { key: 'plain', symbols: c.plain.letters, entropy: c.plain.entropy, max: Math.log2(26), ic: c.plain.ic, uniformIc: 1 / 26 },
    { key: 'caesar', symbols: c.plain.letters, entropy: c.caesar.entropy, max: Math.log2(26), ic: c.caesar.ic, uniformIc: 1 / 26 },
    { key: 'ec', symbols: c.ec.counts.reduce((a, b) => a + b, 0), entropy: c.ec.entropy, max: 8, ic: c.ec.ic, uniformIc: 1 / 256 },
  ];
}

/** The bytes of x(C1) and x(C2) of the toy ciphertext, against the uniform expectation. */
function ecBytesChart(s, decimal = '.') {
  const counts = s.ciphers.ec.counts;
  const N = counts.reduce((a, b) => a + b, 0);
  return { values: counts, expected: N / 256, labels: counts.map((_, i) => String(i)), decimal };
}

// ---------------------------------------------------------------------------
// 3. Statistical cryptanalysis
// ---------------------------------------------------------------------------

/** The role of every chapter of the corpus. */
function chapterRows(s) {
  const role = (n) => {
    if (hw.SPLIT.test.includes(n)) return 'test';
    return hw.SPLIT.validation.includes(n) ? 'validation' : 'fit';
  };
  return s.corpus.chapters.map((c) => ({ ...c, role: role(c.number) }));
}

/** The letter frequencies of the training chapters (bars) and of the test chapters (dashed). */
function corpusChart(s, decimal = '.') {
  const share = (counts) => {
    const N = counts.reduce((a, b) => a + b, 0);
    return counts.map((c) => c / N);
  };
  return { values: share(s.corpus.training.counts), expected: share(s.corpus.test.counts), labels: UPPER, allLabels: true, decimal };
}

/** One row per order of the language models: smoothing, cross-entropy on the test chapters, redundancy, unicity distance. */
const modelRows = (s) =>
  s.models.crossEntropy.map((h, i) => ({ order: i + 1, beta: s.models.betas[i], crossEntropy: h, redundancy: s.models.redundancy[i], unicity: s.models.unicity[i] }));

/** The candidate decryptions of the live attack, from the most to the least probable. */
function candidateRows(crack, limit = 5) {
  return crack.candidates
    .map((c) => ({ ...c, posterior: crack.posterior[c.shift] }))
    .sort((a, b) => b.posterior - a.posterior || b.logLikelihood - a.logLikelihood)
    .slice(0, limit);
}

/** The posterior of the 26 shifts, with the best one in another colour. */
const posteriorChart = (crack, decimal = '.') => ({
  values: crack.posterior,
  labels: Array.from({ length: 26 }, (_, s) => String(s)),
  allLabels: true,
  highlight: crack.key === null ? [] : [crack.key],
  max: 1,
  decimal,
});

/** The check of the live attack: the letters decrypted with the best shift, and with the second best, against the English frequencies. */
function fitChecks(crack, models) {
  if (crack.key === null) return null;
  const second = candidateRows(crack, 2)[1];
  return {
    best: { shift: crack.key, test: hw.letterFit(crack.counts, crack.key, models) },
    second: second ? { shift: second.shift, test: hw.letterFit(crack.counts, second.shift, models) } : null,
  };
}

/** An animation that draws a line chart point by point, as the length or the key grows (chartkit/kitReveal.js); the bounds and the lines of the theory stay whole. */
const reveal = revealChart;

/** The ticks of the length axis, on a logarithmic scale. */
const LENGTH_TICKS = [1, 2, 5, 10, 20, 50, 100, 200];
const PERCENT_TICKS = [0, 0.25, 0.5, 0.75, 1];

/** Success of maximum likelihood by length: the rate, its 95% interval and Chernoff's lower bound. */
function successChart(s, decimal = '.') {
  const c = s.caesar;
  return {
    x: c.lengths,
    logX: true,
    series: [
      { values: c.rates.unigram, band: c.intervals.unigram },
      { values: c.bound, dashed: true, fixed: true },
    ],
    yMin: 0,
    yMax: 1,
    yTicks: PERCENT_TICKS,
    xTicks: LENGTH_TICKS,
    yFormat: (v) => `${Math.round(100 * v)}%`,
    decimal,
  };
}

/** Success of every method by length. */
function methodsChart(s, decimal = '.') {
  const c = s.caesar;
  return {
    x: c.lengths,
    logX: true,
    series: hw.METHODS.map((m) => ({ values: c.rates[m] })),
    yMin: 0,
    yMax: 1,
    yTicks: PERCENT_TICKS,
    xTicks: LENGTH_TICKS,
    yFormat: (v) => `${Math.round(100 * v)}%`,
    decimal,
  };
}

/** The success levels of the comparison table. */
const LEVELS = [0.5, 0.9, 0.99];

/** For every method, the shortest length tried that reaches each success level (null if none does). */
function thresholds(s) {
  const c = s.caesar;
  return hw.METHODS.map((m) => ({
    method: m,
    levels: LEVELS.map((level) => {
      const i = c.rates[m].findIndex((r) => r >= level);
      return i < 0 ? null : c.lengths[i];
    }),
  }));
}

/** The success rate of one method at one length (null if that length was not tried). */
function rateAt(s, method, length) {
  const i = s.caesar.lengths.indexOf(length);
  return i < 0 ? null : s.caesar.rates[method][i];
}

/** One row per length: trials, rate of every method, interval of maximum likelihood, bound. */
const lengthRows = (s) =>
  s.caesar.lengths.map((L, i) => ({
    length: L,
    trials: s.caesar.trials[i],
    rates: Object.fromEntries(hw.METHODS.map((m) => [m, s.caesar.rates[m][i]])),
    interval: s.caesar.intervals.unigram[i],
    bound: s.caesar.bound[i],
  }));

// ---------------------------------------------------------------------------
// 4. The attacks
// ---------------------------------------------------------------------------

/** Exhaustive search on the key of section 1: speed, and the time it would take to reach k and to cover the whole range. */
function exhaustiveSummary(result, key) {
  const rate = result.ms > 0 ? (1000 * result.ops) / result.ms : NaN;
  return {
    ...result,
    rate,
    toKey: Number(key) / rate,
    toAll: Number(hw.KEY_MAX) / rate,
  };
}

/** Baby-step giant-step on the key of section 1: k = i m + j, with the counts of steps. */
function bsgsSummary(result) {
  if (!result.found) return { ...result, m: result.baby, i: null, j: null };
  const m = result.baby;
  const i = result.giant - 1;
  return { ...result, m, i, j: result.key - i * m };
}

/** All the sizes of the scaling experiment, in order. */
const scalingBits = (sc) => [...new Set(Object.values(sc.rows).flatMap((rows) => rows.map((r) => r.bits)))].sort((a, b) => a - b);

/** The three attacks of the scaling experiment, in the order of the charts and the tables. */
const ATTACKS = ['exhaustive', 'bsgs', 'kangaroo'];

/** log2 of the mean operations by key size, measured (points) and as the theory's line with the fitted constant (dashed). */
function scalingChart(sc, decimal = '.') {
  const bits = scalingBits(sc);
  const measured = ATTACKS.map((m) => ({ values: bits.map((b) => {
    const row = sc.rows[m].find((r) => r.bits === b);
    return row ? Math.log2(row.mean) : null;
  }) }));
  const theory = ATTACKS.map((m, i) => ({ values: bits.map((b) => sc.fits[m].constant + sc.fits[m].exponent * b), dashed: true, colorIndex: i, fixed: true }));
  return {
    x: bits,
    logX: false,
    series: [...measured, ...theory],
    yMin: 0,
    yMax: 34,
    yTicks: [0, 8, 16, 24, 32],
    xTicks: [8, 16, 24, 32],
    yFormat: (v) => String(v),
    decimal,
  };
}

/** The key sizes of the extrapolation table. */
const EXTRAPOLATION_BITS = [32, 64, 128, 256];

/** A fast machine, for the extrapolation: 10^12 group operations per second. */
const FAST_RATE = 1e12;

/**
 * The cost of every attack at larger key sizes, with the theory's exponent
 * and the fitted constant, as log2 of the group operations; the time of the
 * best attack at the speed measured here and at FAST_RATE; and the memory
 * of baby-step giant-step, in points.
 */
function extrapolationRows(sc) {
  return EXTRAPOLATION_BITS.map((bits) => {
    const log2 = Object.fromEntries(ATTACKS.map((m) => [m, sc.fits[m].constant + sc.fits[m].exponent * bits]));
    const best = Math.min(log2.bsgs, log2.kangaroo);
    return { bits, log2, best, here: 2 ** best / sc.rate, fast: 2 ** best / FAST_RATE, memory: bits / 2 };
  });
}

/** The flawed variant of section 4.7: the message with one nonce for every byte, and the attack that reads it without k. */
function reuseDemo(key, message) {
  const blocks = hw.toyScheme(key, { nonces: () => hw.REUSED_NONCE }).encrypt(message).blocks;
  return { blocks, attack: hw.nonceReuseAttack(blocks) };
}

/** The malleability of section 4.7: every C2 plus G, decrypted with k. */
const augustusDemo = (scheme, blocks) => scheme.decrypt(hw.shiftCiphertext(blocks, 1));

// ---------------------------------------------------------------------------
// 5. The hypothesis tests
// ---------------------------------------------------------------------------

/** The subjects of the tests, in page order. */
const TEST_GROUPS = ['corpus', 'caesar', 'ec', 'keys'];

/** What each test should say if everything works as explained: some rejections are the point. */
const EXPECTED_VERDICTS = Object.freeze({
  corpus: { homogeneity: 'either' },
  caesar: { uniform: 'reject', dependence: 'reject' },
  ec: { uniform: 'notReject', parity: 'notReject', independence: 'notReject' },
  keys: { small: 'notReject', full: 'notReject' },
});

/** Every hypothesis test of the exploration, by subject: [key, test]. The texts name each key. */
const statTests = hw.statisticalTests;

/** The tests as one list, with how many were rejected and how many as expected. */
function testSummary(s) {
  const all = TEST_GROUPS.flatMap((group) => statTests(s)[group].map(([key, result]) => ({ group, key, result, expected: EXPECTED_VERDICTS[group][key] })));
  return {
    all,
    count: all.length,
    rejected: all.filter((t) => t.result.verdict === 'reject').length,
    asExpected: all.filter((t) => t.expected === 'either' || t.expected === t.result.verdict).length,
  };
}

// ---------------------------------------------------------------------------
// Chart labels under the pointer
// ---------------------------------------------------------------------------

/**
 * What the label over each chart says for the bar or the point under the
 * pointer (hw.attachChartTooltip), from the same data the chart draws. P
 * is the `tips` part of the texts.
 */
// ---------------------------------------------------------------------------
// Le legende dei grafici, per la pagina e per il programma scaricabile: ogni
// voce { label, color | paletteKey, dashed?, box?, parts } e' un pulsante che
// nasconde le sue parti del disegno (`hidden` dei dati di ogni grafico)
// ---------------------------------------------------------------------------

const seriesItem = (label, color, i, extra = {}) => ({ label, color, parts: [`series:${i}`], ...extra });

// a bar chart: the counts and the expected values (dashed)
const barItems = (labels) => [
  { label: labels[0], paletteKey: 'bars', box: true, parts: ['bars'] },
  { label: labels[1], paletteKey: 'reference', dashed: true, parts: ['expected'] },
];

const legends = {
  letters: (text) => barItems(text.legends.letters),
  cipher: (text) => barItems(text.legends.cipher),
  bytes: (text) => barItems(text.legends.bytes),
  corpus: (text) => barItems(text.legends.corpus),
  posterior: (text) => [
    { label: text.legends.posterior[0], paletteKey: 'bars', box: true, parts: ['bars'] },
    { label: text.legends.posterior[1], paletteKey: 'highlight', box: true, parts: ['highlight'] },
  ],
  success: (text) => [seriesItem(text.lengths.legend[0], 0, 0), seriesItem(text.lengths.legend[1], 1, 1, { dashed: true })],
  methods: (text) => hw.METHODS.map((m, i) => seriesItem(text.methodNames[m], i, i)),
  // every attack: its measured points and its fitted line
  scaling: (text) => ATTACKS.map((m, i) => ({ label: text.scaling.legend[i], color: i, parts: [`series:${i}`, `series:${ATTACKS.length + i}`] })),
};

/** Whether series i of a chart is on screen: the reader can hide it from the legend. */
const seriesOn = (hidden, i) => !hidden.includes(`series:${i}`);

/**
 * The labels under the pointer, one factory per chart: each returns
 * (hit, hidden) => text, where `hidden` lists the parts of the chart that
 * the reader turned off in the legend, and the label leaves them out.
 */
const tips = {
  letters: (data, P) => ({ from }, hidden = []) => P.letter(UPPER[from], data.values[from], hidden.includes('expected') ? null : data.expected[from]),
  ecBytes: (data, P) => ({ from, to }, hidden = []) => {
    const part = data.values.slice(from, to);
    const expected = hidden.includes('expected') ? null : data.expected;
    return to - from === 1 ? P.byte(from, data.values[from], expected) : P.bytes(from, to - 1, Math.min(...part), Math.max(...part), expected);
  },
  corpus: (data, P) => ({ from }, hidden = []) => P.frequency(UPPER[from], data.values[from], hidden.includes('expected') ? null : data.expected[from]),
  posterior: (crack, P) => ({ from }) => P.shift(from, crack.posterior[from], crack.candidates[from].text),
  success: (s, P) => ({ index }, hidden = []) =>
    P.success(s.caesar.lengths[index], s.caesar.trials[index], seriesOn(hidden, 0) ? s.caesar.rates.unigram[index] : null, s.caesar.intervals.unigram[index], seriesOn(hidden, 1) ? s.caesar.bound[index] : null),
  methods: (s, P) => ({ index }, hidden = []) => P.methods(s.caesar.lengths[index], hw.METHODS.map((m, i) => (seriesOn(hidden, i) ? s.caesar.rates[m][index] : null))),
  scaling: (sc, P) => ({ index }, hidden = []) => {
    const bits = scalingBits(sc)[index];
    return P.scaling(bits, ATTACKS.map((m, i) => {
      if (!seriesOn(hidden, i)) return null;
      const row = sc.rows[m].find((r) => r.bits === bits);
      return row ? row.mean : null;
    }));
  },
};

// ---------------------------------------------------------------------------
// Tables tied to a chart
// ---------------------------------------------------------------------------

/** The id of every table tied to a chart: the page and the program find it by id. */
const LINKED_TABLES = Object.freeze({ candidates: 'hw2a-candidates-table', lengths: 'hw2a-lengths-table' });

const tableById = (id) => () => document.getElementById(id);

/**
 * The links of hw.attachChartTooltip, { table, row, point }: the bar or
 * the point under the pointer marks its row of the table, and a row under
 * the pointer outlines its bar or point.
 */
const links = {
  // the 26 shifts against the best candidates (candidateRows): a shift without a row marks nothing
  candidates: (rows) => ({
    table: tableById(LINKED_TABLES.candidates),
    row: ({ from }) => rows.findIndex((r) => r.shift === from),
    point: (row) => (rows[row] ? rows[row].shift : -1),
  }),
  // one row per length, in the order of the chart
  lengths: Object.freeze({ table: tableById(LINKED_TABLES.lengths), row: ({ index }) => index, point: (row) => row }),
};

// --- Drawing many charts without freezing the page ---------------------------

const frameJobs = [];
let frameRequested = false;

function runFrameJobs() {
  const start = Date.now();
  while (frameJobs.length && Date.now() - start < 8) frameJobs.shift()();
  frameRequested = frameJobs.length > 0;
  if (frameRequested) requestAnimationFrame(runFrameJobs);
}

/**
 * Runs drawing work a few milliseconds per frame: a page with many charts
 * would otherwise draw them all in one long task, and on a slow phone the
 * page would stop responding for a moment.
 */
function scheduleFrameJob(job) {
  frameJobs.push(job);
  if (!frameRequested) {
    frameRequested = true;
    requestAnimationFrame(runFrameJobs);
  }
}

return { SECTIONS, tocEntries, KEY_MAX_LENGTH, MESSAGE_MAX_LENGTH, SHIFT_MAX_LENGTH, DEFAULT_INPUTS, parseMessage, readInputs, isDefaultInput, inputBadge, shortHex, charOf, keyFacts, blockRows, firstBlock, ciphertextSize, cipherSummary, checkGroups, substitution, caesarFacts, letterChart, cipherRows, ecBytesChart, chapterRows, corpusChart, modelRows, candidateRows, posteriorChart, fitChecks, reveal, LENGTH_TICKS, successChart, methodsChart, LEVELS, thresholds, rateAt, lengthRows, exhaustiveSummary, bsgsSummary, scalingBits, ATTACKS, scalingChart, EXTRAPOLATION_BITS, FAST_RATE, extrapolationRows, reuseDemo, augustusDemo, TEST_GROUPS, EXPECTED_VERDICTS, statTests, testSummary, legends, tips, LINKED_TABLES, links, scheduleFrameJob };
})();

var texts$ = (function () {
'use strict';

// src/pages/statistics/hw2a/texts.js
// I testi dell'Homework #2 in italiano e in inglese. Li usano sia la pagina
// del sito sia il programma scaricabile, cosi' le due versioni dicono le
// stesse cose con le stesse parole. Ogni numero arriva dagli argomenti (lo
// schema calcolato, i risultati degli esperimenti) o dalle costanti della
// libreria: nessuna frase contiene un risultato scritto a mano.
const { DEFAULT_SHIFT, EXHAUSTIVE_LIMIT, EXPLORE_SEED, KEY_BITS, KEY_MAX, LENGTHS, MESSAGE_MAX_BYTES, SAMPLES, SIGNIFICANCE, SPLIT } = Homework2a;
const { FAST_RATE, rateAt, thresholds } = view$;

/**
 * Number formatting of one language: decimal and thousands separators, the
 * "not available" marker and the names of the units of time.
 */
function formatters(decimal, thousands, na, units, times) {
  const local = (s) => (decimal === '.' ? s : s.replace('.', decimal));
  const missing = (v) => v === null || v === undefined || Number.isNaN(v);
  const group = (digits) => digits.replace(/\B(?=(\d{3})+(?!\d))/g, thousands);
  const sci = (v, digits = 1) => {
    if (missing(v)) return na;
    if (v === 0) return '0';
    const e = Math.floor(Math.log10(Math.abs(v)));
    let m = v / 10 ** e;
    let exp = e;
    if (Number(m.toFixed(digits)) >= 10) {
      m /= 10;
      exp += 1;
    }
    return `${local(m.toFixed(digits))} ${times} 10^${exp}`;
  };
  return {
    na,
    decimal,
    int: (v) => (missing(v) ? na : `${v < 0 ? '-' : ''}${group(String(Math.round(Math.abs(Number(v)))))}`),
    big: (v) => group(String(v)),
    num: (v, digits = 3) => (missing(v) ? na : local((Math.abs(v) < 0.5 * 10 ** -digits ? 0 : v).toFixed(digits))),
    pval: (v) => (missing(v) ? na : v === 0 ? `< ${local('1e-300')}` : v < 0.001 ? local(v.toExponential(1)) : local(v.toFixed(3))),
    pct: (v, digits = 1) => (missing(v) ? na : `${local((100 * v).toFixed(digits))}%`),
    // a probability with four decimals, or a bound when it is smaller than that
    prob: (v) => (missing(v) ? na : v < 1e-4 ? `< ${local('0.0001')}` : local(v.toFixed(4))),
    sci,
    pow2: (e, digits = 1) => (missing(e) ? na : `2^${local(e.toFixed(digits))}`),
    ms: (v) => (missing(v) ? na : v >= 1000 ? `${local((v / 1000).toFixed(2))} s` : `${Math.max(1, Math.round(v))} ms`),
    // a duration in seconds, in the largest unit that keeps it readable
    duration: (s) => {
      if (missing(s) || !Number.isFinite(s)) return na;
      const scale = [[units.years, 365.25 * 86400], [units.days, 86400], [units.hours, 3600], [units.minutes, 60], [units.seconds, 1]];
      for (const [name, size] of scale) {
        if (s >= size) {
          const v = s / size;
          return v >= 1e6 ? `${sci(v)} ${name}` : `${local(v.toFixed(1))} ${name}`;
        }
      }
      return `${Math.max(1, Math.round(s * 1000))} ms`;
    },
  };
}

/**
 * The assignment as the professor wrote it, block by block. The only
 * change is the long dash after the title, written "-" as everywhere on
 * this site.
 */
const originalAssignment = () => [
  { type: 'title', text: 'Homework 2' },
  {
    type: 'p',
    text: 'Using the toy cryptographic scheme based on the secp256k1 elliptic curve developed in Part 1 of the previous homework, encrypt and decrypt a simple message. Describe the main steps of the algorithm and the role of the keys.',
  },
  { type: 'p', text: 'The Caesar Cipher: Implement the Caesar cipher to encrypt and decrypt the same message.' },
  { type: 'p', text: 'Discuss the similarities and differences between the two schemes, focusing on their encryption and decryption procedures, key spaces, and statistical properties.' },
  {
    type: 'p',
    text: 'Statistical Cryptanalysis of the Caesar Cipher: Given a sufficiently large corpus of text in a known language, design and implement a simple algorithm to recover the key of the Caesar cipher by exploiting the statistical distribution of letters.',
  },
  { type: 'p', text: 'Test the algorithm on ciphertexts of different lengths and discuss its effectiveness and limitations.' },
  { type: 'p', text: 'Optional: Compare alternative approaches, such as exhaustive key search, letter-frequency analysis, and n-gram scoring.' },
  {
    type: 'p',
    text: 'The toy scheme developed in Part 1 uses the secp256k1 elliptic curve but restricts the private key to a small range to make experiments computationally feasible. Design and implement a simple attack to recover the private key, or otherwise decrypt the message, exploiting this restricted key space. Discuss the differences between this attack and the statistical attack against the Caesar cipher. Explain why the same approach would not necessarily be feasible against a properly configured ECC scheme using a sufficiently large private-key space. Optional: Discuss alternative attacks and explain which weaknesses arise from the restricted key space and which, if any, could arise from the design of the toy scheme itself.',
  },
];

const chapterRange = (list) => `${list[0]}-${list[list.length - 1]}`;

// ---------------------------------------------------------------------------
// ITALIANO
// ---------------------------------------------------------------------------

const IT = formatters(',', '.', 'n/d', { years: 'anni', days: 'giorni', hours: 'ore', minutes: 'minuti', seconds: 'secondi' }, '×');

/** The line of numbers under a hypothesis test, whatever its kind. */
function testLineIt(t) {
  const F = IT;
  switch (t.kind) {
    case 'chi2':
      return t.classes === undefined
        ? `Σz² = ${F.num(t.chi2, 1)}, χ² con ${t.df} gradi di libertà, p = ${F.pval(t.pValue)}`
        : `χ² = ${F.num(t.chi2, 1)} su ${t.classes} classi (${t.df} gradi di libertà), p = ${F.pval(t.pValue)}`;
    case 'binomial':
      return `${F.int(t.successes)} su ${F.int(t.trials)} = ${F.pct(t.rate, 2)} (atteso ${F.pct(t.expectedRate, 2)}), z = ${F.num(t.z, 2)}, p = ${F.pval(t.pValue)}`;
    case 'independence':
      return `χ² = ${F.num(t.chi2, 1)} su una tabella ${t.rows} × ${t.cols} (${t.df} gradi di libertà, attesa minima ${F.num(t.minExpected, 1)}), V di Cramér = ${F.num(t.cramerV, 3)}, p = ${F.pval(t.pValue)}`;
    default:
      return `p = ${F.pval(t.pValue)}`;
  }
}

const methodNamesIt = {
  top: 'Lettera più frequente',
  chi2: 'χ² di Pearson',
  unigram: 'Massima verosimiglianza',
  bigram: 'Bigrammi',
  quadgram: 'Quadrigrammi',
  dictionary: 'Ricerca esaustiva con dizionario',
};

const it = {
  fmt: IT,
  ui: {
    index: 'Indice',
    indexTitle: 'Indice dell’homework',
    close: 'Chiudi',
    backToTop: 'Torna su',
    computing: 'Calcolo in corso...',
    language: 'Lingua',
    error: (m) => `Errore: ${m}`,
  },
  sections: {
    assignment: '0. La consegna',
    scheme: '1. TASK: lo schema giocattolo su secp256k1, cifrare e decifrare',
    input: '1.1 Chiave privata, messaggio e nonce',
    keys: '1.2 Generazione delle chiavi',
    encrypt: '1.3 Cifratura',
    decrypt: '1.4 Decifratura',
    roles: '1.5 Il ruolo delle chiavi',
    verify: '1.6 Verifiche',
    caesar: '2. Il cifrario di Cesare e il confronto fra i due schemi',
    caesarCipher: '2.1 Cifrare e decifrare lo stesso messaggio',
    compare: '2.2 Procedure e spazi delle chiavi',
    properties: '2.3 Le proprietà statistiche dei due cifrati',
    cryptanalysis: '3. Crittanalisi statistica del cifrario di Cesare',
    corpus: '3.1 Il corpus e i modelli della lingua',
    algorithm: '3.2 L’algoritmo: massima verosimiglianza',
    lengths: '3.3 Testi cifrati di lunghezza diversa',
    methods: '3.4 Ricerca esaustiva, frequenze e n-grammi a confronto',
    limits: '3.5 Efficacia e limiti',
    attack: '4. L’attacco allo schema giocattolo',
    exhaustive: '4.1 La ricerca esaustiva',
    bsgs: '4.2 Baby-step giant-step',
    kangaroo: '4.3 Il metodo del canguro di Pollard',
    scaling: '4.4 Il costo al crescere della chiave',
    differences: '4.5 Due attacchi a confronto',
    real: '4.6 Perché non funziona contro ECC ben configurato',
    weaknesses: '4.7 Altri attacchi: spazio delle chiavi o progetto?',
    tests: '5. Riepilogo dei test statistici',
    history: '6. Contesto storico',
    conclusion: '7. Conclusioni',
  },
  assignment: {
    intro: [
      'La consegna ha tre parti. La prima chiede di cifrare e decifrare un messaggio con lo schema giocattolo basato su secp256k1 dell’homework precedente, descrivendo i passaggi dell’algoritmo e il ruolo delle chiavi; poi di cifrare lo stesso messaggio con il cifrario di Cesare e di confrontare i due schemi: procedure di cifratura e decifratura, spazi delle chiavi, proprietà statistiche. La seconda chiede di rompere il cifrario di Cesare con la statistica: dato un corpus abbastanza grande in una lingua nota, un algoritmo che ritrovi la chiave dalla distribuzione delle lettere, provato su testi di lunghezza diversa e, facoltativamente, confrontato con la ricerca esaustiva, l’analisi delle frequenze e i punteggi a n-grammi. La terza chiede di rompere lo schema giocattolo sfruttando lo spazio ridotto delle chiavi private, di confrontare questo attacco con quello statistico, di spiegare perché non funzionerebbe contro una crittografia su curva ellittica ben configurata e, facoltativamente, di distinguere le debolezze dovute allo spazio ridotto da quelle del progetto dello schema.',
      `Lo schema "della parte 1" va precisato. L’esercizio 1 dell’Homework #1 calcolava K = kG su curve giocattolo (y² = x³ + 7 su F_17, come chiedevano i parametri della consegna, e su campi primi un po’ più grandi); l’esercizio 2 usava secp256k1 con chiavi di 256 bit, senza cifrare nulla. Lo schema che questa consegna presuppone sta in mezzo: la curva vera, secp256k1, con la chiave privata ristretta a un intervallo piccolo, qui gli interi da 1 a 2^${KEY_BITS} - 1; e per cifrare il metodo standard per una coppia di chiavi K = kG, ElGamal su curva ellittica. La sezione 1 lo definisce e lo usa.`,
      'La pagina segue l’ordine della consegna: la sezione 1 cifra e decifra con lo schema giocattolo, la 2 con il cifrario di Cesare e confronta i due cifrati, la 3 rompe il cifrario di Cesare con la statistica di un corpus inglese, la 4 rompe lo schema giocattolo con tre algoritmi per il logaritmo discreto e discute perché lo stesso attacco non basta contro una chiave vera. La 5 riassume i test statistici, la 6 colloca le idee nel tempo e la 7 trae le conclusioni. Tutti i numeri sono calcolati nel browser, e il programma scaricabile stampa gli stessi. I grafici si muovono: si ingrandiscono (Ctrl + rotella, oppure un rettangolo trascinato; doppio clic per tornare alla vista intera), le barre anche a gruppi, e le curve che seguono la lunghezza del messaggio o della chiave si disegnano punto per punto.',
    ],
    originalTitle: 'Il testo originale della consegna',
    originalNote: 'Com’è stato assegnato, in inglese.',
  },
  scheme: {
    intro: [
      'Lo schema è ElGamal su curva ellittica, proposto da Koblitz nel 1987 a partire dallo schema di ElGamal del 1985, sulla curva secp256k1 di Bitcoin ed Ethereum. Il ricevente sceglie una chiave privata k e pubblica K = kG. Per cifrare, il mittente trasforma ogni byte del messaggio in un punto M = bG, estrae un numero casuale r (il nonce) e invia la coppia C1 = rG, C2 = M + rK. Il ricevente calcola kC1 = k·rG = r·kG = rK, lo sottrae da C2 e ritrova M, e da M il byte. Chi non conosce né r né k vede due punti che, per quanto se ne sa, sono indistinguibili da punti casuali.',
      `Rispetto a uno schema reale ci sono due semplificazioni, entrambe volute. La chiave privata ha al più ${KEY_BITS} bit invece di 256: è la restrizione della consegna, che la sezione 4 sfrutta. E ogni byte è cifrato da solo, con un nonce suo: costa 66 byte di cifrato per ogni byte di messaggio, ma rende diretto il confronto con il cifrario di Cesare, che lavora una lettera alla volta.`,
    ],
    formulasTitle: 'Lo schema in tre passi',
    formulas: [
      `Generazione delle chiavi   k scelto a caso in [1, 2^${KEY_BITS} - 1]; K = kG`,
      'Cifratura del byte b       M = bG; r nuovo in [1, n - 1];',
      '                           C1 = rG, S = rK, C2 = M + S',
      'Decifratura                S = kC1 (= rK); M = C2 - S; b tale che bG = M',
    ].join('\n'),
    stale: 'Valori dell’ultimo input valido: i campi in 1.1 contengono un errore.',
  },
  input: {
    intro: 'La chiave privata iniziale è stata estratta una volta per tutte con un generatore crittografico; il messaggio è la frase con cui Svetonio descrive il cifrario di Cesare (Vita di Cesare, 56, nella traduzione inglese di J. C. Rolfe del 1914). Chiunque apra la pagina vede gli stessi valori, e node homework2a.js stampa gli stessi numeri. Chiave e messaggio si possono cambiare, e tutte le sezioni seguono, attacchi compresi.',
    keyLabel: `Chiave privata k (da 1 a ${IT.big(KEY_MAX)})`,
    keyHint: `Un intero di al più ${KEY_BITS} bit, in cifre decimali. Con una chiave piccola, per esempio 1000, anche la ricerca esaustiva della sezione 4.1 la trova.`,
    randomKey: 'Chiave casuale',
    keyError: {
      empty: 'Scrivi una chiave.',
      notInteger: (t) => `"${t}" non è un intero scritto in cifre decimali.`,
      range: `La chiave va da 1 a ${IT.big(KEY_MAX)} = 2^${KEY_BITS} - 1.`,
    },
    messageLabel: `Messaggio (al più ${MESSAGE_MAX_BYTES} byte in UTF-8)`,
    messageHint: (bytes) => `${bytes} byte su ${MESSAGE_MAX_BYTES}: ogni byte diventa un blocco del cifrato. Le lettere accentate occupano due byte.`,
    messageError: {
      empty: 'Scrivi un messaggio.',
      tooLong: (bytes) => `Il messaggio occupa ${bytes} byte in UTF-8: al più ${MESSAGE_MAX_BYTES}.`,
    },
    noncesLabel: 'Nonce',
    nonces: { seeded: 'Riproducibili', random: 'Casuali' },
    reroll: 'Nuovi nonce casuali',
    noncesHint: 'I nonce riproducibili vengono da SHA-256 di un seme fisso, così la pagina e il terminale mostrano lo stesso cifrato; per lo stesso motivo chiunque può ricalcolarli, ed è una delle debolezze della sezione 4.7. I nonce casuali vengono dal generatore crittografico del browser: il cifrato cambia a ogni estrazione, il messaggio decifrato no.',
    cipherNow: ({ mode, draw, total, digest, ok }) =>
      mode === 'random'
        ? `Estrazione ${IT.int(draw)}: il cifrato della sezione 1.3, ${IT.int(total)} byte, ha SHA-256 ${digest} e cambia a ogni estrazione; decifrato con k ${ok ? 'dà sempre il messaggio' : 'non dà il messaggio'}.`
        : `Il cifrato della sezione 1.3, ${IT.int(total)} byte, ha SHA-256 ${digest}: con i nonce riproducibili è sempre lo stesso, qui e nel terminale.`,
    defaultBadge: (pk) => `Valori iniziali: la chiave estratta per questo homework, la frase di Svetonio e i nonce riproducibili. Chiave pubblica attesa, ricalcolata anche con la libreria ethers 6.13.5: ${pk}.`,
    customBadge: 'Valori diversi da quelli iniziali.',
    restore: 'Ripristina i valori iniziali',
    stale: 'Finché un campo contiene un errore, le sezioni che ne dipendono restano all’ultimo valore valido.',
  },
  keys: {
    intro: [
      'La chiave privata k è un intero; la chiave pubblica è il punto K = kG, calcolato con la moltiplicazione scalare dell’esercizio 1 dell’Homework #1, qui sui numeri di 256 bit di secp256k1. Calcolare K da k costa al più 64 somme di punti con una tabella precalcolata dei multipli di G; tornare da K a k è il problema del logaritmo discreto.',
      `Su secp256k1, con k scelto fra 1 e n - 1, il miglior attacco noto richiede circa 2^128 operazioni. Con k di ${KEY_BITS} bit, come qui, ne bastano circa 2^17 (sezione 4): la curva è la stessa, cambia solo l’insieme in cui cercare k.`,
    ],
    kLabel: 'Chiave privata k (decimale)',
    hexLabel: 'k in esadecimale',
    binaryLabel: (bits) => `k in binario: ${bits} bit significativi su ${KEY_BITS}`,
    xLabel: 'Ascissa x di K',
    yLabel: 'Ordinata y di K',
    compressedLabel: (even) => `K in forma compressa (SEC 1): ${even ? '02, y pari' : '03, y dispari'}, poi x`,
    onCurve: (ok) => (ok ? 'K soddisfa y² = x³ + 7 (mod p): è un punto della curva. ✓' : 'K non è un punto della curva. ✗'),
    reference: (ok) => (ok ? 'Coincide con la chiave pubblica ricalcolata con ethers 6.13.5. ✓' : 'Non coincide con la chiave pubblica ricalcolata con ethers 6.13.5. ✗'),
    after: [
      `La chiave pubblica non tradisce la sua origine: x e y di K sembrano numeri casuali di 256 bit anche quando k ne ha solo ${KEY_BITS}, e il test della sezione 2.3 non distingue le chiavi pubbliche di chiavi private piccole da quelle di chiavi private di 256 bit. Il difetto dello schema giocattolo non è statistico ma algebrico: K = kG con k piccolo.`,
    ],
  },
  encrypt: {
    intro: [
      'Il messaggio diventa una sequenza di byte (UTF-8), e ogni byte b diventa il punto M = bG: il byte 0 è il punto all’infinito, il byte 255 è 255G. Per ogni byte si estrae un nonce r, intero fra 1 e n - 1, e si calcolano C1 = rG e il punto condiviso S = rK; il cifrato del byte è la coppia (C1, C2 = M + S), 66 byte in forma compressa.',
      'Il nonce si usa una volta e si dimentica: chi lo conoscesse calcolerebbe S = rK da K, che è pubblica, e decifrerebbe il blocco. C1 = rG lo trasmette senza rivelarlo, perché ricavare r da C1 è di nuovo un logaritmo discreto, e con r di 256 bit uno difficile.',
    ],
    tableTitle: 'I blocchi del cifrato',
    cols: { position: '#', byte: 'Byte', r: 'Nonce r', C1: 'C1 = rG', C2: 'C2 = bG + rK' },
    size: ({ bytes, total }) => `${IT.int(bytes)} byte di messaggio, ${IT.int(bytes)} blocchi, ${IT.int(total)} byte di cifrato.`,
    after: [
      'Lo stesso byte cifrato due volte dà due blocchi diversi, perché il nonce cambia: tutte le "e" del messaggio hanno un cifrato diverso. È la cifratura probabilistica (Goldwasser e Micali, 1984), la proprietà che manca al cifrario di Cesare e che la sezione 2.3 misura.',
    ],
  },
  decrypt: {
    intro: [
      'Il ricevente conosce k e nient’altro. Per ogni blocco calcola S = kC1, che coincide con rK perché kC1 = k(rG) = r(kG) = rK; sottrae S da C2 e ottiene M = bG. Resta da trovare b, ancora un logaritmo discreto, ma facile: b ha solo 256 valori, e una tabella dei punti 0G, ..., 255G, costruita una volta, lo dà con una ricerca.',
      `Con k di ${KEY_BITS} bit, kC1 costa una trentina di raddoppi e una quindicina di somme: la chiave piccola rende veloce anche la decifratura. È l’unico vantaggio, e lo paga la sicurezza.`,
    ],
    firstTitle: 'Il primo blocco, passo per passo',
    labels: {
      C1: 'C1, ricevuto',
      C2: 'C2, ricevuto',
      S: 'S = kC1',
      M: 'M = C2 - S',
    },
    decoded: (b, c) => (b < 0 ? 'M non è bG per nessun byte: il blocco non si decifra. ✗' : `M = ${b}G: il byte ${b}, "${c}". ✓`),
    sameS: (ok) => (ok ? 'kC1 coincide con il punto rK calcolato dal mittente. ✓' : 'kC1 non coincide con rK. ✗'),
    resultLabel: 'Il messaggio decifrato',
    check: (ok) => (ok ? 'Il messaggio decifrato coincide con l’originale. ✓' : 'Il messaggio decifrato non coincide con l’originale. ✗'),
  },
  roles: {
    intro: 'Ogni valore dello schema ha un proprietario e uno scopo, e ognuno, se trapela, fa un danno diverso.',
    cols: { value: 'Valore', who: 'Chi lo conosce', purpose: 'A cosa serve', leak: 'Se trapela' },
    rows: [
      {
        value: 'k, chiave privata',
        who: 'Solo il ricevente.',
        purpose: 'Decifrare: S = kC1.',
        leak: 'Chiunque decifra tutti i messaggi, passati e futuri, cifrati con K.',
      },
      {
        value: 'K = kG, chiave pubblica',
        who: 'Tutti.',
        purpose: 'Cifrare: S = rK. Chiunque può scrivere al ricevente.',
        leak: 'È pubblica per costruzione: protegge k finché il logaritmo discreto è difficile, e con k piccolo non lo è.',
      },
      {
        value: 'r, nonce',
        who: 'Solo il mittente, per il tempo di un blocco.',
        purpose: 'Rendere la cifratura probabilistica; C1 = rG lo trasmette senza rivelarlo.',
        leak: 'Chi conosce r calcola S = rK e decifra quel blocco. Un nonce riusato o prevedibile rompe lo schema anche con k sicuro (sezione 4.7).',
      },
      {
        value: 'S = rK = kC1, segreto condiviso',
        who: 'Mittente e ricevente.',
        purpose: 'La maschera che nasconde M: C2 = M + S. È uno scambio di Diffie-Hellman su curva.',
        leak: 'Decifra quel blocco, e solo quello.',
      },
      {
        value: 'M = bG, codifica',
        who: 'Non è un segreto.',
        purpose: 'Portare il byte nel gruppo dei punti, dove si può sommare S.',
        leak: 'Nulla: la tabella dei 256 punti è pubblica.',
      },
      {
        value: 'p, n, G, parametri della curva',
        who: 'Tutti.',
        purpose: 'Fissare il gruppo in cui si calcola.',
        leak: 'Nulla: sono pubblici per costruzione.',
      },
    ],
    after: 'La differenza con il cifrario di Cesare è già qui. Cesare ha una sola chiave, che cifra e decifra e deve restare segreta per entrambe le cose; lo schema su curva ne ha due, e quella che cifra può essere pubblicata. Il prezzo dell’asimmetria è un problema difficile che la sostenga: il logaritmo discreto, che la restrizione a 32 bit rende facile.',
  },
  verify: {
    intro: 'Tutto è scritto da zero, senza librerie. Prima di fidarsi dei numeri, la pagina li confronta con valori noti: i vettori di test di SHA-256 (FIPS 180-4), alcuni multipli di G ricalcolati con ethers 6.13.5 (calcolati sia con la tabella precalcolata sia con raddoppi e somme), nG = O, che dice che G ha ordine n, e il viaggio di andata e ritorno dei due cifrari sul messaggio iniziale.',
    summary: (ok, n) => `${ok} verifiche superate su ${n}.`,
    details: (n) => `Le ${n} verifiche`,
    groups: { sha256: 'SHA-256 (FIPS 180-4)', curve: 'secp256k1', scheme: 'Schema giocattolo', caesar: 'Cifrario di Cesare' },
    cols: { check: 'Verifica', expected: 'Valore atteso', result: 'Esito' },
    ok: 'superata',
    failed: 'fallita',
  },
  caesar: {
    intro: [
      'La seconda parte della consegna: lo stesso messaggio con il cifrario di Cesare, e il confronto fra i due schemi.',
    ],
  },
  caesarCipher: {
    intro: [
      `Il cifrario di Cesare sposta ogni lettera di s posti in avanti nell’alfabeto, ricominciando da A dopo Z: con s = ${DEFAULT_SHIFT}, lo spostamento che Svetonio attribuisce a Cesare, A diventa D, B diventa E, ..., Z diventa C. Decifrare vuol dire spostare indietro degli stessi s posti. In formule, con le lettere numerate da 0 (A) a 25 (Z): c = (p + s) mod 26 e p = (c - s) mod 26.`,
      'Qui maiuscole e minuscole restano tali, e tutto ciò che non è una lettera dalla A alla Z (spazi, punteggiatura, cifre, lettere accentate) resta com’è, come nella maggior parte delle implementazioni didattiche.',
    ],
    shiftLabel: 'Spostamento s (da 0 a 25)',
    shiftHint: 'Con s = 0 il testo resta in chiaro; s e 26 - s si annullano a vicenda.',
    shiftError: {
      empty: 'Scrivi uno spostamento.',
      notInteger: (t) => `"${t}" non è un intero scritto in cifre.`,
      range: 'Lo spostamento va da 0 a 25.',
    },
    tableTitle: 'La tabella di sostituzione',
    plainRow: 'Chiaro',
    cipherRow: 'Cifrato',
    cipherLabel: 'Il messaggio cifrato',
    decryptedLabel: 'Il messaggio decifrato',
    check: (ok) => (ok ? 'Il messaggio decifrato coincide con l’originale. ✓' : 'Il messaggio decifrato non coincide con l’originale. ✗'),
    top: (f) =>
      f.top
        ? `Il cifrato ha la stessa lunghezza, gli stessi spazi e la stessa punteggiatura del messaggio, e ogni lettera è sostituita sempre dalla stessa: la "${f.top.letter}", la lettera più frequente del messaggio (${f.top.count} volte su ${f.letters}), diventa sempre "${f.top.image}".`
        : 'Il messaggio non contiene lettere dalla A alla Z: il cifrario di Cesare lo lascia com’è.',
    stale: 'Valori dell’ultimo spostamento valido: il campo contiene un errore.',
  },
  compare: {
    intro: 'La tabella mette a confronto i due schemi e, per riferimento, ciò che si usa davvero per cifrare con una chiave su curva ellittica.',
    cols: ['', 'Cifrario di Cesare', 'Schema giocattolo (EC-ElGamal, k di 32 bit)', 'ECC ben configurato (ECIES)'],
    rows: (size) => [
      ['Tipo', 'Simmetrico: la stessa chiave cifra e decifra.', 'Asimmetrico: K cifra, k decifra.', 'Asimmetrico per la chiave, simmetrico per il messaggio (cifratura ibrida).'],
      ['Gruppo', 'Gli interi modulo 26, con la somma.', 'I punti di secp256k1, con la somma di punti; ordine n ≈ 2^256.', 'Lo stesso.'],
      ['Cifratura', 'c = p + s (mod 26), lettera per lettera, deterministica.', 'C1 = rG, C2 = bG + rK, byte per byte, con un nonce nuovo per ogni byte.', 'Un punto effimero rG, il segreto rK passato per una funzione di derivazione, e un cifrario autenticato (AES-GCM, ChaCha20-Poly1305) sull’intero messaggio.'],
      ['Decifratura', 'p = c - s (mod 26).', 'S = kC1, M = C2 - S, poi la tabella dei 256 punti.', 'S = k·rG, la stessa derivazione, e la verifica del tag prima di decifrare.'],
      ['Spazio delle chiavi', '26 spostamenti, uno dei quali (0) non cifra: log2 26 ≈ 4,7 bit.', `2^${KEY_BITS} - 1 chiavi private: ${KEY_BITS} bit, ma circa 16 di sicurezza contro baby-step giant-step e canguro.`, 'n - 1 ≈ 2^256 chiavi: circa 128 bit di sicurezza.'],
      ['Lunghezza del cifrato', 'Uguale al messaggio.', `66 byte per byte di messaggio: qui ${IT.int(size.bytes)} byte diventano ${IT.int(size.total)}.`, 'Il messaggio più 33 byte (il punto effimero) e 16 di tag.'],
      ['La stessa lettera due volte', 'Dà sempre la stessa lettera.', 'Dà due blocchi diversi.', 'Dà cifrati diversi.'],
      ['Che cosa trapela', 'Frequenze delle lettere, lunghezza delle parole, spazi, punteggiatura, lettere ripetute.', 'La lunghezza esatta in byte.', 'La lunghezza del messaggio.'],
      ['Integrità', 'Nessuna.', 'Nessuna: il cifrato è malleabile (sezione 4.7).', 'Il tag rifiuta ogni cifrato modificato.'],
      ['Miglior attacco', 'Statistico, dal solo cifrato: bastano poche lettere (sezione 3).', 'Algebrico, dalla sola chiave pubblica: circa 2^17 operazioni (sezione 4).', 'Algebrico: circa 2^128 operazioni, fuori portata.'],
    ],
    after: [
      'Le somiglianze sono strutturali. Entrambi cifrano sommando al chiaro un elemento di un gruppo e decifrano sottraendolo: Cesare somma s nel gruppo degli interi modulo 26, lo schema su curva somma S = rK nel gruppo dei punti. Entrambi lavorano un simbolo alla volta, e in entrambi la chiave sta in un insieme che si può elencare: 26 elementi in un caso, circa 4,3 miliardi nell’altro. In entrambi, decifrare con la chiave sbagliata dà un risultato senza senso, e chi attacca ha bisogno di un modo per riconoscere quella giusta.',
      'Le differenze stanno in tre punti. La chiave: Cesare ne ha una sola, segreta, che cifra e decifra; lo schema su curva separa chi può cifrare (chiunque, con K) da chi può decifrare (solo chi ha k), ed è questa asimmetria a richiedere un problema difficile come il logaritmo discreto. La traslazione: Cesare usa sempre la stessa, s, mentre lo schema su curva ne usa una nuova per ogni byte, S = rK con r casuale; è la differenza fra un cifrario a sostituzione e un one-time pad nel gruppo dei punti, e la sezione 4.7 mostra che basta riusare r per tornare a un cifrario di Cesare sui byte. E lo spazio delle chiavi: 26 contro 2^32, e soprattutto contro 2^256 in uno schema reale.',
    ],
  },
  properties: {
    intro: [
      'La consegna chiede di confrontare anche le proprietà statistiche. Il cifrario di Cesare è una permutazione fissa dell’alfabeto: le frequenze delle lettere del cifrato sono quelle del chiaro, ruotate di s posti. Lo schema su curva è probabilistico: il cifrato di ogni byte è una coppia di punti che, statisticamente, non dipende dal byte.',
    ],
    lettersChart: 'Le lettere del messaggio: conteggi (barre) e attese secondo le frequenze del corpus della sezione 3 (tratteggio)',
    cipherChart: (shift) => `Le lettere del cifrato di Cesare (barre), con le stesse attese (tratteggio): lo stesso profilo, spostato di ${shift} ${shift === 1 ? 'posto' : 'posti'}`,
    sampleIntro: (s) => `Un messaggio breve è poco per dei test. Per questi si usano i primi ${IT.int(s.ciphers.bytes)} byte dei capitoli di test del corpus (sezione 3.1), ${IT.int(s.ciphers.plain.letters)} lettere, cifrati con entrambi gli schemi: con Cesare (s = ${s.ciphers.shift}) e con lo schema giocattolo, con la chiave iniziale e nonce riproducibili da un seme diverso da quello della sezione 1.`,
    bytesChart: (s) => `I byte delle ascisse x(C1) e x(C2) del cifrato su curva: ${IT.int(s.ciphers.ec.counts.reduce((a, b) => a + b, 0))} byte, conteggi (barre) e attesa uniforme (tratteggio)`,
    tableTitle: 'Entropia e indice di coincidenza',
    cols: { text: 'Testo', symbols: 'Simboli', entropy: 'Entropia (bit per simbolo)', ic: 'Indice di coincidenza' },
    rowNames: { plain: 'Chiaro (lettere)', caesar: 'Cifrato di Cesare (lettere)', ec: 'Cifrato su curva (byte di x(C1) e x(C2))' },
    entropyCell: (v, max) => `${IT.num(v, 3)} su ${IT.num(max, 3)}`,
    icCell: (v, uniform) => `${IT.num(v, 5)} (uniforme: ${IT.num(uniform, 5)})`,
    repeated: (s) => {
      const r = s.ciphers.repeated;
      const letter = 'abcdefghijklmnopqrstuvwxyz'[r.letter];
      return `La lettera "${letter}" compare ${r.occurrences} volte nel testo: il cifrario di Cesare la trasforma ${r.occurrences} volte nella stessa lettera (${r.caesarDistinct} ${r.caesarDistinct === 1 ? 'cifrato diverso' : 'cifrati diversi'}), lo schema su curva in ${r.ecDistinct} blocchi tutti diversi.`;
    },
    explain: (s) => [
      `Le entropie e gli indici di coincidenza del chiaro e del cifrato di Cesare sono identici, non circa uguali: una permutazione dei simboli non cambia la distribuzione, ne rinomina i valori. Per questo l’indice di coincidenza (Friedman, 1922) dice che un testo è cifrato con un’unica sostituzione, ma non dice quale: la chiave si trova confrontando le frequenze con quelle della lingua (sezione 3). I test lo confermano: le lettere del cifrato sono tutt’altro che uniformi, e la lettera del cifrato dipende completamente da quella del chiaro (V di Cramér = ${IT.num(s.ciphers.caesar.dependence.cramerV, 3)}).`,
      `Il cifrato su curva ha un’entropia di ${IT.num(s.ciphers.ec.entropy, 4)} bit per byte su 8 e un indice di coincidenza di ${IT.num(s.ciphers.ec.ic, 5)}, contro 1/256 ≈ ${IT.num(1 / 256, 5)} per byte uniformi: le frequenze del chiaro sono sparite, e i test non trovano né uno scarto dall’uniforme né una dipendenza dal byte cifrato. Non è un caso fortunato: sotto l’ipotesi decisionale di Diffie-Hellman (DDH) su secp256k1, (rG, M + rK) è indistinguibile da una coppia di punti casuali qualunque sia M (Tsiounis e Yung, 1998). I test non possono dimostrarlo; possono solo non smentirlo.`,
      'Due avvertenze. Il cifrato su curva non è uniforme in ogni suo byte: il primo byte di un punto compresso è 02 o 03, la parità di y, e per questo i test usano le ascisse e verificano la parità a parte. E l’indistinguibilità vale contro chi non conosce k: con k di 32 bit, chiunque lo calcoli (sezione 4) rende il cifrato trasparente. Le statistiche del cifrato sono perfette e la sicurezza è nulla: la sicurezza di uno schema a chiave pubblica non si vede nei suoi cifrati.',
    ],
  },
  cryptanalysis: {
    intro: [
      'La seconda parte: ritrovare la chiave del cifrario di Cesare dal solo cifrato, con la statistica di un corpus in una lingua nota.',
    ],
  },
  corpus: {
    intro: [
      'Il corpus è Alice’s Adventures in Wonderland di Lewis Carroll (1865), di pubblico dominio, nella trascrizione di Project Gutenberg (eBook #11): 12 capitoli in inglese. Per misurare l’attacco su testo che non ha mai visto, i capitoli hanno tre ruoli, come in un esperimento di apprendimento statistico: i capitoli I-VII stimano i modelli, VIII-IX scelgono il grado di smoothing (validazione), e l’attacco si misura su X-XII (test), mai usati prima. I modelli finali usano tutti i capitoli I-IX.',
    ],
    chaptersTitle: 'I capitoli e il loro ruolo',
    cols: { number: 'Cap.', title: 'Titolo', letters: 'Lettere', role: 'Ruolo' },
    roles: { fit: 'stima', validation: 'validazione', test: 'test' },
    chart: (s) => `Frequenza delle lettere: capitoli di addestramento (${chapterRange(SPLIT.training)}, ${IT.int(s.corpus.training.letters)} lettere, barre) e di test (${chapterRange(SPLIT.test)}, ${IT.int(s.corpus.test.letters)} lettere, tratteggio)`,
    facts: (s) => [
      `Nei capitoli di addestramento la lettera più frequente è la "${'abcdefghijklmnopqrstuvwxyz'[s.models.top]}" (${IT.pct(s.models.q[s.models.top])}), l’entropia delle lettere è ${IT.num(s.corpus.training.entropy, 3)} bit su un massimo di log2 26 ≈ ${IT.num(Math.log2(26), 3)}, e l’indice di coincidenza è ${IT.num(s.corpus.training.ic, 4)}, contro 1/26 ≈ ${IT.num(1 / 26, 4)} per lettere uniformi: la distanza fra le due è la ridondanza che l’attacco sfrutta.`,
      `Il test del χ² rifiuta l’omogeneità fra addestramento e test: i capitoli ${chapterRange(SPLIT.test)}, con più dialoghi e personaggi nuovi (il Re, la Regina, il processo), hanno frequenze significativamente diverse (p = ${IT.pval(s.corpus.homogeneity.pValue)}). Ma la differenza è piccola: la distanza di variazione totale fra le due distribuzioni è ${IT.pct(s.corpus.tvd)}, e la V di Cramér ${IT.num(s.corpus.homogeneity.cramerV, 3)}. Con centomila lettere anche una differenza minima diventa significativa: significatività statistica e rilevanza pratica sono due cose diverse, e per l’attacco conta la seconda. Un corpus non è la lingua, è un campione con il suo stile; che i modelli reggano su capitoli diversi da quelli su cui sono stati stimati è proprio ciò che la sezione 3.3 misura.`,
    ],
    modelsIntro: [
      'Oltre alle frequenze delle singole lettere, l’attacco può usare le sequenze: un modello a n-grammi stima la probabilità di ogni lettera date le n - 1 precedenti, cioè una catena di Markov di ordine n - 1. I conteggi grezzi non bastano: con ottantamila lettere molti dei 456.976 quadrigrammi possibili non compaiono mai, e un modello che desse loro probabilità zero scarterebbe anche il testo giusto alla prima sequenza insolita.',
      'Le probabilità sono quindi lisciate verso il modello di ordine inferiore: un contesto visto spesso conta per i suoi conteggi, uno visto di rado prende in prestito dal contesto più corto, e uno mai visto ricade su di esso. È la media a posteriori con una distribuzione di Dirichlet a priori centrata sull’ordine inferiore e del peso di β osservazioni. Lo smoothing additivo, più comune, darebbe a un contesto mai visto la distribuzione uniforme: proprio i contesti insoliti che una decifratura sbagliata produce riceverebbero probabilità generose, e i quadrigrammi perderebbero buona parte del loro vantaggio. β si sceglie sui capitoli di validazione, minimizzando l’entropia incrociata.',
    ],
    formula: [
      'P_n(x | h) = ( c(h x) + β · P_(n-1)(x | h′) ) / ( c(h) + β )',
      'h = le n - 1 lettere precedenti; h′ = h senza la più vecchia; P_0(x) = 1/26',
      'entropia incrociata  H = -(1/N) Σ log2 P(x_t | contesto)   [bit per lettera]',
    ].join('\n'),
    modelsTitle: 'I modelli, misurati sui capitoli di test',
    modelCols: { order: 'Ordine', beta: 'β scelto', crossEntropy: 'Entropia incrociata (bit/lettera)', redundancy: 'Ridondanza D (bit/lettera)', unicity: 'Distanza di unicità (lettere)' },
    orderName: (n) => ['singole lettere', 'bigrammi', 'trigrammi', 'quadrigrammi'][n - 1],
    after: (s) => [
      `L’entropia incrociata scende da ${IT.num(s.models.crossEntropy[0], 2)} bit per lettera con le sole frequenze a ${IT.num(s.models.crossEntropy[3], 2)} con i quadrigrammi: più contesto, meno incertezza su ogni lettera. Shannon (1951) stimava per l’inglese, con contesti lunghi, fra 0,6 e 1,3 bit per lettera; la differenza è la parte della lingua che quattro lettere non vedono. Per le singole lettere la scelta di β è indifferente (le entropie di validazione differiscono alla sesta cifra), perché ogni lettera compare migliaia di volte.`,
      `La ridondanza D = log2 26 - H è ciò che rende possibile l’attacco. La distanza di unicità di Shannon (1949), U = H(K)/D = log2 26 / D, stima quante lettere di cifrato servono perché una sola chiave dia un testo plausibile: circa ${IT.num(s.models.unicity[0], 1)} con le sole frequenze, circa ${IT.num(s.models.unicity[3], 1)} con i quadrigrammi. La sezione 3.4 mostra che le lunghezze a cui l’attacco diventa affidabile hanno proprio questo ordine di grandezza.`,
    ],
  },
  algorithm: {
    intro: [
      'L’algoritmo: per ognuno dei 26 spostamenti s, decifrare e misurare quanto il risultato somiglia all’inglese; scegliere lo spostamento più plausibile. Il criterio naturale è la verosimiglianza. Se le lettere del chiaro fossero indipendenti con le frequenze q del corpus, la probabilità di osservare il cifrato con la chiave s sarebbe il prodotto delle q delle lettere decifrate; lo spostamento che la rende massima è lo stimatore di massima verosimiglianza della chiave, e con la chiave uniforme a priori anche lo stimatore bayesiano che, sotto quel modello, minimizza la probabilità di errore.',
      'In pratica bastano i 26 conteggi n_x del cifrato: decifrare con s trasforma la lettera cifrata x + s nella x, e la log-verosimiglianza è una somma di 26 termini, 26 × 26 operazioni qualunque sia la lunghezza del testo.',
    ],
    formula: [
      'ŝ = argmax_s  Σ_i log q(c_i - s)  =  argmax_s  Σ_x n_(x+s) · log q(x)',
      'P(s | cifrato) = exp(ℓ(s)) / Σ_t exp(ℓ(t))     (chiave uniforme a priori)',
    ].join('\n'),
    liveTitle: 'L’attacco sul cifrato di Cesare del messaggio',
    live: (crack, shift) =>
      crack.key === null
        ? 'Il cifrato non contiene lettere, o più spostamenti sono a pari merito: la verosimiglianza non sceglie.'
        : `Su ${crack.letters} lettere, lo spostamento più verosimile è s = ${crack.key}, con probabilità a posteriori ${IT.prob(crack.posterior[crack.key])}${crack.key === shift ? ': è quello usato in 2.1. ✓' : `, ma in 2.1 è stato usato s = ${shift}: con così poche lettere l’attacco sbaglia. ✗`}`,
    posteriorChart: 'Probabilità a posteriori dei 26 spostamenti, con il più probabile evidenziato',
    candidatesTitle: 'I cinque spostamenti più probabili',
    candidateCols: { shift: 's', perLetter: 'Log-verosimiglianza per lettera', posterior: 'Probabilità a posteriori', text: 'Decifrato' },
    fit: (checks) =>
      checks === null
        ? []
        : [
          `Verifica: le lettere decifrate con s = ${checks.best.shift} seguono le frequenze dell’inglese? Il χ² di adattamento dà p = ${IT.pval(checks.best.test.pValue)}: ${checks.best.test.verdict === 'reject' ? 'rifiutato, il testo è insolito per l’inglese' : 'non rifiutato, il testo è compatibile con l’inglese'}.${checks.second ? ` Con il secondo spostamento più probabile, s = ${checks.second.shift}, p = ${IT.pval(checks.second.test.pValue)}: ${checks.second.test.verdict === 'reject' ? 'rifiutato' : 'non rifiutato'}.` : ''}`,
        ],
    pending: 'L’attacco usa i modelli della sezione 3.1, ancora in calcolo.',
    after: [
      'Il χ² di Pearson, spesso usato allo stesso scopo, minimizza Σ (n_x(s) - L q_x)² / (L q_x): misura la stessa distanza fra frequenze osservate e attese, ma pesa molto le lettere rare (una "z" inattesa fa salire molto il χ²), e su testi corti sbaglia più spesso della verosimiglianza (sezione 3.4).',
      'Il punto debole del cifrario di Cesare non è solo il numero di chiavi: è che la sostituzione conserva la statistica del testo. Ogni lettera del cifrato porta un po’ di informazione sulla chiave, e la verosimiglianza la somma.',
    ],
  },
  lengths: {
    intro: (s) => [
      `Per misurare l’efficacia, l’algoritmo è stato provato sui capitoli di test, che non ha mai visto: per ogni lunghezza L da ${LENGTHS[0]} a ${LENGTHS[LENGTHS.length - 1]} lettere, fino a ${IT.int(SAMPLES.maxTrials)} brani disgiunti di L lettere consecutive, ognuno cifrato con uno spostamento casuale (seme ${EXPLORE_SEED}). Un tentativo vale 1 se la chiave trovata è giusta, 1/t se è fra t chiavi a pari merito (la probabilità di indovinarla tirando a sorte fra quelle), 0 altrimenti. Con brani lunghi i brani disgiunti sono meno (${s.caesar.trials[s.caesar.trials.length - 1]} da ${LENGTHS[LENGTHS.length - 1]} lettere), e gli intervalli di confidenza, di Wilson al 95%, più larghi.`,
    ],
    chart: 'Massima verosimiglianza sulle frequenze delle lettere: tasso di successo per lunghezza del cifrato (asse logaritmico)',
    legend: ['Tasso di successo, con l’intervallo di confidenza al 95%', 'Limite inferiore di Chernoff per lettere indipendenti'],
    tableTitle: 'Tasso di successo per lunghezza',
    cols: { length: 'Lettere', trials: 'Brani', rate: 'Successo', interval: 'Intervallo al 95%', bound: 'Limite di Chernoff' },
    explain: (s) => {
      const r = (L) => IT.pct(rateAt(s, 'unigram', L));
      const q = s.models.q[s.models.top];
      return [
        `Con una lettera sola l’algoritmo indovina nel ${r(1)} dei casi: sceglie lo spostamento che trasforma quella lettera in "${'abcdefghijklmnopqrstuvwxyz'[s.models.top]}", ed è giusto quando la lettera era proprio quella (nel corpus il ${IT.pct(q)} delle lettere). Con 10 lettere indovina nel ${r(10)} dei casi, con 20 nel ${r(20)}, con 50 nel ${r(50)}.`,
        `La forma della curva ha una spiegazione teorica. Se le lettere fossero indipendenti con frequenze q, lo spostamento giusto perderebbe contro uno sbagliato d con probabilità al più ρ_d^L, dove ρ_d = min_λ Σ_x q(x)^(1-λ) q(x-d)^λ (limite di Chernoff), e l’errore totale sarebbe al più Σ_d ρ_d^L. Lo spostamento più facile da confondere con quello giusto è d = ${s.caesar.confusable.shift} (o ${26 - s.caesar.confusable.shift}, il suo opposto), con ρ = ${IT.num(s.caesar.confusable.rho, 3)}: ogni lettera in più moltiplica il termine dominante dell’errore per ${IT.num(s.caesar.confusable.rho, 3)}, cioè porta ${IT.num(-Math.log2(s.caesar.confusable.rho), 2)} bit di evidenza a favore della chiave giusta. Il limite è prudente, perché somma 25 eventi che si sovrappongono, e diventa informativo solo oltre una decina di lettere, ma dice la cosa importante: l’errore decresce esponenzialmente con la lunghezza.`,
        s.caesar.rates.unigram.every((r, i) => r >= s.caesar.bound[i])
          ? 'Il testo vero non è fatto di lettere indipendenti: le parole ripetono sequenze, e due brani dello stesso capitolo si somigliano. Eppure la curva misurata sta sopra il limite a ogni lunghezza: la dipendenza fra lettere vicine non danneggia un attacco che la ignora, e la sfruttano gli n-grammi della sezione 3.4.'
          : 'Il testo vero non è fatto di lettere indipendenti, e il limite vale per un modello: a qualche lunghezza la curva misurata scende sotto il limite, segno che la dipendenza fra lettere vicine, o la differenza fra i capitoli, pesa. Gli n-grammi della sezione 3.4 la sfruttano invece di subirla.',
      ];
    },
  },
  methods: {
    intro: [
      'La consegna suggerisce di confrontare la ricerca esaustiva, l’analisi delle frequenze e i punteggi a n-grammi. Con 26 chiavi, ogni metodo le prova tutte: cambia il criterio con cui riconosce quella giusta, e quindi quanta informazione sulla lingua usa.',
    ],
    list: [
      { method: 'top', text: 'assume che la lettera più frequente del cifrato sia la "e". Usa un solo numero del corpus.' },
      { method: 'chi2', text: 'la distanza fra le frequenze delle lettere decifrate e quelle del corpus.' },
      { method: 'unigram', text: 'le frequenze del corpus come modello: l’algoritmo della sezione 3.2.' },
      { method: 'bigram', text: 'la verosimiglianza con il modello a bigrammi della sezione 3.1, che vede anche l’ordine di due lettere.' },
      { method: 'quadgram', text: 'la verosimiglianza con il modello a quadrigrammi: ogni lettera date le tre precedenti.' },
      { method: 'dictionary', text: 'decifra con ogni chiave e conta le lettere delle parole che compaiono nei capitoli di addestramento. È la ricerca esaustiva come la farebbe una persona, che legge le 26 decifrature e sceglie quella con parole vere.' },
    ],
    chart: 'Tasso di successo dei sei metodi per lunghezza del cifrato (asse logaritmico)',
    tableTitle: 'Lettere necessarie per raggiungere il 50%, il 90% e il 99% di successo',
    cols: { method: 'Metodo', levels: ['50%', '90%', '99%'] },
    never: 'oltre 200',
    explain: (s) => {
      const t = Object.fromEntries(thresholds(s).map((row) => [row.method, row.levels]));
      const L = (m, i) => (t[m][i] === null ? 'oltre 200' : String(t[m][i]));
      const r = (m, n) => IT.pct(rateAt(s, m, n));
      return [
        `L’ordine dei metodi è quello dell’informazione che usano. Il χ² e la massima verosimiglianza usano la stessa informazione, le frequenze, ma la verosimiglianza la usa meglio: è il criterio ottimo sotto il modello, e a 10 lettere vince ${r('unigram', 10)} contro ${r('chi2', 10)}. I quadrigrammi, che usano anche l’ordine delle lettere, arrivano al 90% con ${L('quadgram', 1)} lettere e al 99% con ${L('quadgram', 2)}; le frequenze da sole ne vogliono ${L('unigram', 1)} e ${L('unigram', 2)}. La distanza di unicità della sezione 3.1 prevedeva questo ordine di grandezza: circa ${IT.num(s.models.unicity[0], 0)} lettere con le sole frequenze, circa ${IT.num(s.models.unicity[3], 1)} con i quadrigrammi.`,
        `La ricerca esaustiva con dizionario (${IT.int(s.corpus.vocabulary)} parole diverse) sta in mezzo: ha bisogno di parole intere, e un brano corto taglia le parole ai bordi (a 5 lettere vale ${r('dictionary', 5)}, contro ${r('quadgram', 5)} dei quadrigrammi). E la si mette fuori gioco togliendo gli spazi, come facevano i crittografi classici scrivendo il cifrato in gruppi di cinque lettere, mentre gli n-grammi non se ne accorgono, perché leggono solo le lettere.`,
        `La lettera più frequente è il metodo peggiore: anche a 200 lettere indovina solo nel ${r('top', 200)} dei casi, perché in un brano breve la "e" non è sempre la lettera più frequente. È il metodo che si insegna per primo, ma ignora 25 frequenze su 26.`,
        'Il costo non distingue i metodi: tutti provano 26 chiavi. Le frequenze richiedono 26 × 26 operazioni qualunque sia la lunghezza, gli n-grammi 26 per lettera, il dizionario 26 ricerche per parola. Contro un cifrario con 26 chiavi il costo non conta mai: conta solo saper riconoscere la chiave giusta.',
      ];
    },
  },
  limits: {
    paras: [
      'Testi corti. Sotto le 5 lettere nessun metodo è affidabile, e con una o due lettere il problema non ha una soluzione unica: molte chiavi danno decifrature plausibili. È l’idea della distanza di unicità: sotto quella lunghezza il cifrario è inattaccabile, non perché sia robusto ma perché il messaggio stesso è ambiguo.',
      'La lingua. Il modello deve essere quello del testo: un messaggio in italiano attaccato con le frequenze dell’inglese spesso cade lo stesso, perché le due lingue hanno molte lettere frequenti in comune, ma servono più lettere; un testo di cifre, sigle o parole d’ordine casuali non ha ridondanza da sfruttare, e nessun metodo statistico lo rompe. Lo stesso vale per un testo atipico: Gadsby (1939) di Ernest Vincent Wright, un romanzo scritto senza la lettera "e", inganna il metodo della lettera più frequente e indebolisce gli altri.',
      'Il modello. L’indipendenza delle lettere è falsa (il limite di Chernoff vale per un testo che non esiste) e un corpus di un solo autore non è la lingua (sezione 3.1). Gli n-grammi correggono la prima approssimazione, un corpus più grande e vario la seconda; entrambe le correzioni fanno risparmiare lettere, non cambiano la conclusione.',
      'Il limite vero è altrove: l’attacco funziona perché il cifrario di Cesare è una sostituzione fissa. Anche la sostituzione monoalfabetica generale, con 26! ≈ 4·10^26 ≈ 2^88 chiavi, più delle 2^56 di DES, cade allo stesso modo, con un po’ più di testo e una ricerca più furba: un grande spazio delle chiavi è necessario ma non sufficiente. Serve che il cifrato non conservi la statistica del chiaro, ed è ciò che lo schema su curva garantisce (sezione 2.3).',
    ],
  },
  attack: {
    intro: [
      `Lo schema giocattolo è sicuro quanto è difficile ritrovare k da K = kG. Con k ristretto a ${KEY_BITS} bit, il problema diventa il logaritmo discreto in un intervallo noto, [1, 2^${KEY_BITS}): l’attaccante non ha bisogno del messaggio né di statistiche, gli basta la chiave pubblica, che è pubblica per definizione. Le sottosezioni attaccano la chiave della sezione 1 con tre algoritmi, misurano come cresce il costo con la dimensione della chiave e discutono che cosa cambia contro una chiave vera.`,
      'Il costo si misura in operazioni di gruppo, somme o raddoppi di punti: un numero che non dipende dal computer. I tempi, invece, sono quelli di questo browser.',
    ],
  },
  exhaustive: {
    intro: [
      `L’attacco più semplice: calcolare G, 2G, 3G, ..., una somma di punti per volta, finché si ottiene K. Il primo k con kG = K è la chiave, e non ci sono falsi positivi, a differenza dell’attacco statistico, perché la verifica è esatta. Il costo è k somme, in media 2^${KEY_BITS - 1} per una chiave uniforme a ${KEY_BITS} bit. La pagina prova i primi 2^${Math.log2(EXHAUSTIVE_LIMIT)} = ${IT.int(EXHAUSTIVE_LIMIT)} candidati sulla chiave della sezione 1, ne misura la velocità e stima il resto.`,
      'L’implementazione avanza 256 candidati alla volta: ognuno riceve la stessa somma, e una sola inversione modulare serve per tutti (il trucco di Montgomery), ma i candidati si controllano in ordine, così il numero di somme resta esattamente k.',
    ],
    found: (r) => `La chiave è fra i primi ${IT.int(r.limit)} candidati: k = ${IT.int(r.key)}, trovata dopo ${IT.int(r.ops)} somme, in ${IT.ms(r.ms)}. ✓`,
    notFound: (r, key) => `I primi ${IT.int(r.limit)} candidati in ${IT.ms(r.ms)}: ${IT.int(r.rate)} somme al secondo. La chiave non è fra loro. Per arrivare a k = ${IT.big(key)} servirebbero ${IT.big(key)} somme, circa ${IT.duration(r.toKey)} a questa velocità, e ${IT.duration(r.toAll)} per coprire l’intero intervallo.`,
    after: [
      'Ore in JavaScript, in un browser, su un solo processore. Un’implementazione ottimizzata in C, o su una scheda grafica, è più veloce di ordini di grandezza, e copre 2^32 candidati in secondi: la ricerca esaustiva è già sufficiente a rompere lo schema giocattolo. È ciò che è successo davvero con Profanity e con Milk Sad (sezione 6), dove le chiavi private venivano da un seme di 32 bit.',
    ],
  },
  bsgs: {
    intro: [
      `Baby-step giant-step (Shanks, 1971) scambia tempo con memoria. Ogni k in [1, 2^${KEY_BITS}) si scrive k = i·m + j con m = 2^${KEY_BITS / 2} e 0 ≤ i, j ≤ m. I passi piccoli calcolano jG per j = 1, ..., m e li mettono in una tabella indicizzata da x; i passi grandi calcolano K, K - mG, K - 2mG, ... finché K - i·mG è nella tabella, cioè coincide con jG, oppure con -jG, che ha la stessa x: allora k = i·m + j, oppure k = i·m - j. Al più m + 2^32/m ≈ 2^17 operazioni invece di 2^32, ma servono m punti in memoria.`,
    ],
    formula: [
      'passi piccoli    tabella x(jG) → j,  per j = 1, ..., m        (m = 2^16)',
      'passi grandi     Q_i = K - i·mG,  per i = 0, 1, 2, ...',
      'incontro         x(Q_i) = x(jG)  ⇒  k = i·m + j  (oppure i·m - j)',
    ].join('\n'),
    result: (r) => (r.found
      ? `k = ${IT.int(r.key)} = ${IT.int(r.i)} · ${IT.int(r.m)} + ${IT.int(r.j)}: trovata con ${IT.int(r.ops)} operazioni (${IT.int(r.baby)} passi piccoli e ${IT.int(r.giant)} grandi), in ${IT.ms(r.ms)}. ✓`
      : 'La chiave non è nell’intervallo. ✗'),
    decryptedLabel: 'Il messaggio della sezione 1, decifrato con la chiave ritrovata',
    check: (ok) => (ok ? 'Coincide con il messaggio originale: l’attaccante legge tutto, senza aver mai visto k. ✓' : 'Non coincide con il messaggio. ✗'),
    after: [
      'La tabella dei passi piccoli non dipende dalla chiave attaccata: costruita una volta, serve per tutte le chiavi dello stesso intervallo, e ogni nuova chiave costa in media solo 2^15 passi grandi. Contro molti utenti con chiavi piccole l’attacco diventa più conveniente, non meno.',
    ],
  },
  kangaroo: {
    intro: [
      `Il metodo del canguro (Pollard, 1978) ottiene lo stesso costo, circa 2·2^${KEY_BITS / 2} = 2^${KEY_BITS / 2 + 1} operazioni, con una memoria trascurabile. Due branchi di canguri saltano lungo il gruppo: i salti valgono 2^j·G, e j dipende dal punto in cui il canguro si trova, così due canguri che passano per lo stesso punto da lì in poi fanno gli stessi salti. I canguri "domestici" partono da multipli noti di G a metà dell’intervallo, quelli "selvatici" da K più un multiplo noto. Quando un selvatico cade sulle orme di un domestico i due percorsi si fondono, e lo si scopre al successivo punto distinto (un punto la cui x finisce con d zeri binari), che entrambi visitano e memorizzano con la distanza percorsa. Da lì: esponente del domestico = k + esponente del selvatico, e k segue.`,
      'È la versione parallela di van Oorschot e Wiener (1999): N canguri, metà per branco, con salto medio N·√w/4 per un intervallo di ampiezza w, la scelta che minimizza il lavoro atteso, circa 2√w salti in tutto.',
    ],
    result: (r) => (r.found
      ? `k = ${IT.int(r.key)}: trovata con ${IT.int(r.ops)} salti di ${r.N} canguri (attesi circa ${IT.int(r.expected)}), salto medio ${IT.int(r.meanJump)}, memorizzando solo ${IT.int(r.distinguished)} punti distinti, in ${IT.ms(r.ms)}. ✓`
      : 'La chiave non è stata trovata. ✗'),
    after: [
      'Rispetto a baby-step giant-step la memoria scende da 65.536 punti a qualche centinaio, e il lavoro si divide fra tanti processori quanti sono i canguri, quasi senza comunicazione: è il metodo usato in pratica per i logaritmi discreti in un intervallo. Il numero di salti varia da una chiave all’altra: è piccolo quando k è vicino al centro dell’intervallo, dove partono i domestici, grande quando è vicino ai bordi.',
    ],
  },
  scaling: {
    intro: (sc) => [
      `Per vedere come cresce il costo, i tre attacchi sono stati provati su chiavi casuali di dimensione crescente (seme ${sc.seed}): la ricerca esaustiva da ${sc.rows.exhaustive[0].bits} a ${sc.rows.exhaustive[sc.rows.exhaustive.length - 1].bits} bit, baby-step giant-step da ${sc.rows.bsgs[0].bits} a ${sc.rows.bsgs[sc.rows.bsgs.length - 1].bits}, il canguro da ${sc.rows.kangaroo[0].bits} a ${sc.rows.kangaroo[sc.rows.kangaroo.length - 1].bits}. Le operazioni non dipendono dalla macchina; la velocità sì, e questa ne fa ${IT.int(sc.rate)} al secondo.`,
    ],
    chart: 'log2 delle operazioni medie per dimensione della chiave: misurate (punti) e retta con l’esponente teorico (tratteggio)',
    legend: ['Ricerca esaustiva', 'Baby-step giant-step', 'Canguro'],
    fitsTitle: 'Le pendenze stimate',
    fitCols: { method: 'Attacco', slope: 'Pendenza stimata', theory: 'Teoria', constant: 'Costante (log2)' },
    extrapolationTitle: 'Estrapolazione',
    extrapolationCols: { bits: 'Bit della chiave', exhaustive: 'Ricerca esaustiva', best: 'BSGS o canguro', here: 'Tempo qui', fast: 'Tempo a 10^12 operazioni/s', memory: 'Memoria di BSGS' },
    memory: (e) => `2^${e} punti`,
    explain: (sc) => {
      const f = sc.fits;
      return [
        `Le pendenze stimate sono ${IT.num(f.exhaustive.slope, 2)} ± ${IT.num(f.exhaustive.slopeError, 2)} per la ricerca esaustiva, ${IT.num(f.bsgs.slope, 3)} ± ${IT.num(f.bsgs.slopeError, 3)} per baby-step giant-step e ${IT.num(f.kangaroo.slope, 2)} ± ${IT.num(f.kangaroo.slopeError, 2)} per il canguro: compatibili con 1 e con 1/2. Ogni bit in più di chiave raddoppia il lavoro della ricerca esaustiva e lo moltiplica per √2 negli altri due. La ricerca esaustiva è la più rumorosa perché il suo costo è la chiave stessa, uniforme fra 1 e 2^b.`,
        'L’estrapolazione tiene fisso l’esponente della teoria e stima dai dati solo la costante: estrapolare la pendenza stimata sarebbe imprudente, perché un errore di 0,02 sulla pendenza diventerebbe un fattore 2^5 a 256 bit. È la differenza fra un modello giustificato dalla teoria e una retta adattata ai dati.',
        `A ${KEY_BITS} bit l’attacco migliore costa circa 2^17 operazioni: meno di un secondo. A 256 bit ne costerebbe circa 2^129, e anche a 10^12 operazioni al secondo servirebbero circa ${IT.duration(2 ** 129 / FAST_RATE)}, un miliardo di volte l’età dell’universo.`,
      ];
    },
  },
  differences: {
    intro: 'La consegna chiede di confrontare questo attacco con quello statistico al cifrario di Cesare. Sono diversi in quasi tutto.',
    cols: ['', 'Attacco statistico a Cesare', 'Attacco allo schema giocattolo'],
    rows: [
      ['Che cosa ricostruisce', 'Il messaggio, e la chiave come sottoprodotto.', 'La chiave privata; il messaggio segue.'],
      ['Da che cosa', 'Dal cifrato (poche lettere) e da un modello della lingua.', 'Dalla sola chiave pubblica: il cifrato serve solo dopo, per leggere.'],
      ['Che cosa sfrutta', 'La ridondanza della lingua, che la sostituzione conserva.', 'La struttura algebrica K = kG e il piccolo intervallo di k.'],
      ['Natura', 'Un problema di stima: quale chiave rende il testo più plausibile.', 'Un problema di ricerca: quale k soddisfa kG = K.'],
      ['Esito', 'Probabilistico: con testi corti può sbagliare.', 'Certo: la chiave esiste ed è unica nell’intervallo.'],
      ['Verifica della chiave', 'Statistica: la più verosimile, non necessariamente quella giusta.', 'Esatta: kG = K, senza falsi positivi.'],
      ['Costo', '26 tentativi, qualunque sia il testo.', 'Fino a 2^32 operazioni con la ricerca esaustiva, circa 2^17 con BSGS o il canguro.'],
      ['Dipende dal messaggio?', 'Sì: lingua e lunghezza decidono il successo.', 'No: funziona anche se il messaggio è casuale.'],
      ['Rimedio', 'Nessuno dentro il cifrario: la sostituzione conserva la statistica per costruzione.', 'Allargare lo spazio delle chiavi a n - 1 ≈ 2^256.'],
    ],
    after: [
      'In una frase: l’attacco a Cesare è un problema di stima, quello allo schema giocattolo un problema di ricerca. Il primo usa la statistica del messaggio, il secondo la ignora; il primo può sbagliare, il secondo no; il primo non si ferma allargando lo spazio delle chiavi (la sostituzione monoalfabetica, con 2^88 chiavi, cade allo stesso modo), il secondo sì.',
      'Hanno però un punto in comune: entrambi provano chiavi e riconoscono quella giusta. Contro Cesare provare è banale e riconoscere è il problema; contro lo schema su curva riconoscere è banale (kG = K) e provare è il problema. La sicurezza di un cifrario moderno chiede che entrambe le cose siano difficili: nessun riconoscimento statistico dal cifrato (sezione 2.3), e nessuna ricerca possibile nello spazio delle chiavi.',
    ],
  },
  real: {
    paras: [
      'Contro secp256k1 con una chiave scelta uniformemente fra 1 e n - 1, la ricerca esaustiva richiederebbe in media 2^255 operazioni, e baby-step giant-step e il canguro circa 2^128, il primo con 2^128 punti in memoria. Non è un limite di questi algoritmi: Shoup (1997) ha dimostrato che ogni algoritmo generico, che usa il gruppo solo attraverso le sue operazioni, ha bisogno di Ω(√n) operazioni. Il rho di Pollard raggiunge questo limite senza memoria, ma non fa meglio.',
      'Gli attacchi non generici sfruttano una struttura che secp256k1 non ha. Pohlig-Hellman richiede che l’ordine del gruppo abbia fattori piccoli, e n è primo; MOV e Frey-Rück richiedono un grado di immersione piccolo, e quello di secp256k1 è enorme; l’attacco di Smart richiede una curva anomala, con #E = p, e secp256k1 non lo è. L’unica struttura in più, l’endomorfismo (x, y) → (βx, y), riduce il rho di un fattore √6 (Duursma, Gaudry e Morain, 1999): da 2^128 a circa 2^127 operazioni, come visto nell’esercizio 1 dell’Homework #1.',
      `L’asimmetria è ciò che rende la crittografia possibile. Il proprietario della chiave calcola K = kG con circa 256 raddoppi e 128 somme, un costo che cresce come il logaritmo di n; l’attaccante ha bisogno di circa √n operazioni. Passare da ${KEY_BITS} a 256 bit moltiplica per 8 il lavoro di chi usa la chiave e per 2^112 quello di chi la cerca.`,
      'Per questo "ben configurato" vuol dire anzitutto chiave generata bene: uniforme in [1, n - 1], da un generatore crittografico. Le chiavi deboli trovate nella realtà non erano corte per scelta, ma per un generatore difettoso: 32 bit di seme in Profanity (2022) e nel comando bx seed di Libbitcoin Explorer (Milk Sad, 2023). La curva era sicura, lo spazio delle chiavi effettivo no. Resta un’eccezione: un computer quantistico abbastanza grande risolverebbe il logaritmo discreto in tempo polinomiale con l’algoritmo di Shor, e lì nessuna lunghezza di chiave su curva basterebbe.',
    ],
  },
  weaknesses: {
    intro: 'La consegna chiede di separare le debolezze dovute allo spazio ridotto delle chiavi da quelle del progetto dello schema. La tabella le elenca; due si possono provare qui, sul messaggio della sezione 1.',
    cols: { weakness: 'Debolezza', origin: 'Origine', attack: 'Attacco', fix: 'Rimedio' },
    rows: [
      ['k di 32 bit', 'Spazio delle chiavi', 'Ricerca esaustiva, baby-step giant-step, canguro (4.1-4.3): k dalla sola K, con circa 2^17 operazioni.', 'k uniforme in [1, n - 1].'],
      ['Precalcolo e molti bersagli', 'Spazio delle chiavi', 'Una tabella di passi piccoli, o di punti distinti, costruita una volta serve per ogni chiave dello stesso intervallo, e ogni chiave in più costa meno (Bernstein e Lange, 2012).', 'Come sopra.'],
      ['Nonce riusato', 'Progetto (uso)', 'Tutti i C1 uguali, e C2_i - C2_j = (b_i - b_j)G rivela le differenze fra i byte: un cifrario di Cesare sui byte, rotto con le frequenze (prova qui sotto).', 'Un nonce nuovo per ogni cifratura, dal generatore crittografico.'],
      ['Nonce prevedibile o piccolo', 'Progetto (uso)', 'Chi ricalcola r (da un seme noto, come i nonce riproducibili di questa pagina) o lo trova con baby-step giant-step se è piccolo, calcola S = rK e decifra senza k.', 'Come sopra.'],
      ['Malleabilità', 'Progetto', 'Aggiungere δG a C2 aggiunge δ al byte decifrato, senza conoscere k (prova qui sotto); i blocchi si possono anche scambiare, togliere o duplicare.', 'Un cifrario autenticato, che rifiuta i cifrati modificati (ECIES).'],
      ['Cifrati scelti', 'Progetto', 'Chi può far decifrare un cifrato a piacere manda (C1 + tG, C2 + tK), che cifra lo stesso messaggio con il nonce r + t, e lo legge: lo schema non è sicuro contro attacchi a cifrato scelto (IND-CCA2).', 'Come sopra.'],
      ['Punti non validati', 'Implementazione', 'Se la decifratura non controllasse che C1 sta sulla curva, punti di curve diverse con sottogruppi piccoli rivelerebbero k modulo piccoli primi (attacchi a curva non valida: Biehl, Meyer e Müller, 2000). Questa implementazione rifiuta i punti che non stanno sulla curva.', 'Validare ogni punto ricevuto.'],
      ['Un byte per blocco', 'Progetto', 'Rivela la lunghezza esatta, moltiplica il cifrato per 66, e i blocchi sono indipendenti, come nella modalità ECB.', 'Cifrare l’intero messaggio con una chiave derivata (cifratura ibrida).'],
      ['Messaggi piccoli', 'Progetto, ma innocua', 'Ogni blocco ha solo 256 messaggi possibili, ma cifrarli tutti e confrontare non serve, perché il nonce cambia il cifrato ogni volta. Lo servirebbe in uno schema deterministico, come RSA senza padding.', 'Nessuno: la cifratura probabilistica lo protegge già.'],
    ],
    reuseTitle: 'Prova: lo stesso nonce per ogni byte',
    reuse: (demo) => {
      const a = demo.attack;
      if (!a || !a.candidates.length) return ['Il messaggio non dà candidati validi.'];
      return [
        `Il messaggio della sezione 1 cifrato con un solo nonce: i ${demo.blocks.length} C1 sono ${a.sameC1 ? 'tutti uguali, e lo vede chiunque' : 'diversi'}. Le differenze C2_i - C2_1 = (b_i - b_1)G danno b_i - b_1 con la tabella dei punti, e del messaggio resta ignoto un solo byte, b_1: ${a.range} valori possibili, di cui ${a.valid} danno un testo UTF-8 valido. Le frequenze dei byte nei capitoli di addestramento scelgono il più plausibile:`,
      ];
    },
    reuseResult: 'Il messaggio letto senza k',
    reuseCheck: (ok) => (ok ? 'Coincide con il messaggio originale: nessuna chiave privata, nessun logaritmo discreto difficile. ✓' : 'Non coincide con il messaggio originale: il messaggio è troppo corto o atipico. ✗'),
    augustusTitle: 'Prova: la malleabilità',
    augustus: 'Ogni C2 del cifrato della sezione 1 più G, decifrato con k:',
    augustusFail: 'Il messaggio contiene il byte 255, che più 1 non è più un byte: il blocco non si decifra.',
    augustusAfter: 'Ogni byte è aumentato di 1: le lettere sono diventate le successive, gli spazi punti esclamativi. È il cifrario di Augusto, che secondo Svetonio spostava ogni lettera di un posto, applicato da chi non conosce la chiave a un messaggio che non può leggere.',
    after: [
      'Delle debolezze, solo le prime due vengono dallo spazio ridotto delle chiavi, e scompaiono con k di 256 bit. Le altre sono del progetto o dell’implementazione, e resterebbero con qualunque chiave: è per questo che gli schemi reali non cifrano con ElGamal "nudo", ma con schemi ibridi autenticati come ECIES (da DHIES, Abdalla, Bellare e Rogaway, 2001), sicuri anche contro chi può far decifrare cifrati scelti.',
    ],
  },
  stats: {
    verdict: { reject: 'H₀ rifiutata', notReject: 'H₀ non rifiutata' },
    expected: { reject: 'atteso: rifiuto', notReject: 'atteso: nessun rifiuto', either: 'misura una differenza reale' },
    testLine: testLineIt,
    groups: { corpus: 'Corpus', caesar: 'Cesare', ec: 'Schema su curva', keys: 'Chiavi pubbliche' },
    labels: {
      corpus: { homogeneity: 'Addestramento e test hanno le stesse frequenze delle lettere (χ², 2 × 26)' },
      caesar: {
        uniform: 'Le lettere del cifrato di Cesare sono uniformi sulle 26 (χ²)',
        dependence: 'Lettera del chiaro e lettera del cifrato sono indipendenti (χ², Cesare)',
      },
      ec: {
        uniform: 'I byte di x(C1) e x(C2) sono uniformi sui 256 valori (χ²)',
        parity: 'La y di C2 è dispari con probabilità 1/2 (binomiale)',
        independence: 'Il byte in chiaro e i primi 2 bit di x(C2) sono indipendenti (χ²)',
      },
      keys: {
        small: 'I bit di x(kG) sono monete eque per chiavi di 32 bit: Σz² ~ χ²(256)',
        full: 'I bit di x(kG) sono monete eque per chiavi di 256 bit: Σz² ~ χ²(256)',
      },
    },
  },
  tests: {
    intro: `I test d’ipotesi della pagina, con livello di significatività α = ${IT.num(SIGNIFICANCE, 2)}. A differenza degli homework precedenti, qui alcuni rifiuti sono attesi e voluti: il cifrato di Cesare non è uniforme e dipende dal chiaro, ed è proprio ciò che lo rende attaccabile.`,
    cols: { subject: 'Oggetto', hypothesis: 'Ipotesi nulla H₀', p: 'p-value', verdict: 'Esito', expected: 'Lettura' },
    keysIntro: (s) => `Le chiavi pubbliche: ${IT.int(s.keys.small.N)} chiavi K = kG con k uniforme fra 1 e 2^32 - 1, e altrettante con k uniforme fra 1 e n - 1. Se la restrizione lasciasse un’impronta nelle coordinate, il primo test la vedrebbe.`,
    after: (sum) => [
      `${sum.rejected} test su ${sum.count} rifiutano l’ipotesi nulla, ${sum.asExpected === sum.count ? 'tutti come atteso' : `${sum.asExpected} su ${sum.count} come atteso`}. I rifiuti del cifrario di Cesare sono la sua debolezza (sezione 2.3); quello del corpus misura una differenza reale ma piccola fra capitoli (sezione 3.1). I test sullo schema su curva e sulle chiavi pubbliche non rifiutano nulla, eppure lo schema si rompe in meno di un secondo: i test statistici misurano l’assenza di difetti grossolani nelle uscite, non la difficoltà di invertire la funzione.`,
    ],
  },
  history: {
    intro: 'Dal cifrario di Cesare a ElGamal su curva ellittica, le idee di questa pagina in ordine cronologico, con le due vulnerabilità reali che riproducono lo schema giocattolo.',
    legend: { task: 'usato in questa pagina', context: 'contesto' },
    events: [
      { year: 'I secolo a.C.', task: true, title: 'Il cifrario di Cesare', text: 'Svetonio (Vite dei Cesari, circa 121 d.C.) racconta che Cesare scriveva le lettere riservate sostituendo ogni lettera con quella tre posti più avanti, e che Augusto usava la successiva. Il messaggio di questa pagina è la sua descrizione.' },
      { year: 'IX secolo', task: true, title: 'al-Kindi e l’analisi delle frequenze', text: 'Nel trattato sulla decifrazione dei messaggi crittografici, al-Kindi descrive il metodo della sezione 3: contare le lettere del cifrato e confrontarle con quelle di un testo lungo nella stessa lingua. È la più antica descrizione nota della crittanalisi statistica; il manoscritto, conservato a Istanbul, è stato pubblicato nel 1987.' },
      { year: '1467', task: false, title: 'Alberti', text: 'Leon Battista Alberti descrive il disco cifrante e la sostituzione polialfabetica: cambiare alfabeto durante il messaggio, così che le frequenze non sopravvivano.' },
      { year: '1553-1586', task: false, title: 'Bellaso e Vigenère', text: 'Il cifrario che porta il nome di Vigenère, descritto prima da Giovan Battista Bellaso: un cifrario di Cesare con uno spostamento diverso per ogni lettera, dato da una parola chiave. Resiste per tre secoli.' },
      { year: '1863', task: false, title: 'Kasiski', text: 'Friedrich Kasiski pubblica come trovare la lunghezza della chiave di Vigenère: il cifrato si divide allora in tanti cifrari di Cesare, e ognuno cade con le frequenze.' },
      { year: '1900', task: false, title: 'Pearson', text: 'Karl Pearson introduce il test del χ², il criterio di uno dei metodi della sezione 3.4 e di molti test di questa pagina.' },
      { year: '1920-1922', task: false, title: 'Friedman', text: 'William Friedman definisce l’indice di coincidenza (scritto nel 1920, pubblicato nel 1922): la statistica entra nella crittanalisi come misura, non più come intuizione.' },
      { year: '1949-1951', task: true, title: 'Shannon', text: 'La teoria matematica della segretezza: cifrari perfetti, entropia e distanza di unicità (1949), poi la stima dell’entropia dell’inglese (1951). Sono le grandezze della sezione 3.1.' },
      { year: '1971', task: true, title: 'Baby-step giant-step', text: 'Daniel Shanks, studiando i numeri di classe dei campi quadratici, trova il primo algoritmo in √n per il logaritmo discreto.' },
      { year: '1976', task: false, title: 'Diffie e Hellman', text: 'Nasce la crittografia a chiave pubblica, con lo scambio di chiavi che porta il loro nome: S = rK = kC1 è uno scambio di Diffie-Hellman su curva.' },
      { year: '1978', task: true, title: 'Pollard', text: 'John Pollard pubblica i metodi rho e canguro (lambda) per il logaritmo discreto: √n operazioni, senza tabelle.' },
      { year: '1984-1985', task: true, title: 'Cifratura probabilistica ed ElGamal', text: 'Goldwasser e Micali definiscono la sicurezza semantica e la cifratura probabilistica (1984); Taher ElGamal pubblica lo schema di cifratura e di firma basato sul logaritmo discreto (1985).' },
      { year: '1985-1987', task: true, title: 'Curve ellittiche', text: 'Miller (1985) e Koblitz (1987) propongono le curve ellittiche per la crittografia; Koblitz descrive anche l’analogo di ElGamal su curva e come rappresentare un messaggio con un punto.' },
      { year: '1997-1999', task: false, title: 'I limiti degli attacchi generici', text: 'Shoup dimostra che un algoritmo generico ha bisogno di Ω(√n) operazioni (1997); van Oorschot e Wiener parallelizzano rho e canguro con i punti distinti (1999).' },
      { year: '2000-2001', task: false, title: 'secp256k1 ed ECIES', text: 'SEC 2 pubblica i parametri di secp256k1 (2000); Abdalla, Bellare e Rogaway analizzano DHIES (2001), lo schema ibrido autenticato da cui viene ECIES, il modo corretto di cifrare con una chiave su curva.' },
      { year: '2022', task: true, title: 'Profanity', text: 'Un generatore di indirizzi Ethereum "personalizzati" ricava le chiavi private da un seme di 32 bit. A metà settembre 1inch rende pubblica la debolezza; pochi giorni dopo Wintermute perde circa 160 milioni di dollari. Lo spazio delle chiavi dello schema giocattolo, nella realtà.' },
      { year: '2023', task: true, title: 'Milk Sad', text: 'Il comando bx seed di Libbitcoin Explorer 3.x genera le frasi dei wallet con un Mersenne Twister inizializzato da 32 bit dell’orologio di sistema: i fondi vengono rubati fra giugno e luglio (CVE-2023-39910).' },
    ],
    after: 'Letta in ordine, la storia ripete la stessa lezione due volte. I cifrari classici sono caduti per la statistica, e ogni tentativo di salvarli (più alfabeti, chiavi più lunghe) ha solo spostato più in là il numero di lettere necessarie, finché Shannon ha dato la misura esatta del problema. La crittografia moderna ha risolto quel problema, con cifrati indistinguibili dal caso, e ha spostato la sicurezza sulla difficoltà di un calcolo: ma un calcolo difficile su uno spazio di chiavi piccolo è facile, come hanno scoperto nel 2022 e nel 2023 i proprietari di chiavi generate da 32 bit.',
  },
  conclusion: (s) => [
    `Lo stesso messaggio, cifrato con i due schemi, mostra due modi opposti di fallire. Il cifrario di Cesare cade perché conserva la statistica del testo: con le frequenze dell’inglese e la massima verosimiglianza ${s ? `bastano 20 lettere per ritrovare la chiave nel ${IT.pct(rateAt(s, 'unigram', 20), 0)} dei casi, e con i quadrigrammi 10 lettere per il ${IT.pct(rateAt(s, 'quadgram', 10), 0)}` : 'bastano poche decine di lettere per ritrovare la chiave quasi sempre'}. Lo schema su curva ha un cifrato statisticamente impeccabile, e cade lo stesso, in meno di un secondo, perché la chiave privata ha 32 bit: l’attacco non guarda il messaggio, risolve un logaritmo discreto in un intervallo piccolo.`,
    'Le due lezioni si completano. Uno spazio delle chiavi grande è necessario ma non sufficiente: la sostituzione monoalfabetica ha 2^88 chiavi e si rompe con le frequenze. Un cifrato indistinguibile dal caso è necessario ma non sufficiente: lo schema giocattolo ce l’ha e si rompe con 2^17 operazioni. ElGamal su curva con una chiave di 256 bit ha entrambe le proprietà, e il miglior attacco noto richiede circa 2^128 operazioni.',
    'Resta ciò che nessuna lunghezza di chiave sistema: nonce riusati o prevedibili, cifrati malleabili, punti non validati. Sono errori di progetto e di implementazione, e nella realtà fanno più danni degli algoritmi: le chiavi rubate con Profanity e con Milk Sad stavano su una curva sicura, ma erano state generate male.',
  ],
  methodNames: methodNamesIt,
  attackNames: { exhaustive: 'Ricerca esaustiva', bsgs: 'Baby-step giant-step', kangaroo: 'Canguro' },
  // le legende dei grafici a barre: ogni voce si preme per nascondere la sua parte
  legends: {
    letters: ['conteggi delle lettere', 'attese dalle frequenze del corpus'],
    cipher: ['conteggi delle lettere del cifrato', 'attese dalle frequenze del corpus'],
    bytes: ['conteggi dei byte', 'attesa uniforme'],
    corpus: ['capitoli di addestramento', 'capitoli di test'],
    posterior: ['probabilità a posteriori', 'spostamento più probabile'],
  },
  tips: {
    // a value hidden from the legend (null) is left out of the label
    letter: (letter, count, expected) => `${letter}: ${count} ${count === 1 ? 'volta' : 'volte'}${expected === null ? '' : `, attese ${IT.num(expected, 1)}`}`,
    byte: (b, count, expected) => `Byte ${b}: ${IT.int(count)} volte${expected === null ? '' : `, attese ${IT.num(expected, 1)}`}`,
    bytes: (from, to, min, max, expected) => `Byte da ${from} a ${to}: da ${IT.int(min)} a ${IT.int(max)} volte${expected === null ? '' : `, attese ${IT.num(expected, 1)} ciascuno`}`,
    frequency: (letter, training, test) => `${letter}: ${IT.pct(training, 2)} in addestramento${test === null ? '' : `, ${IT.pct(test, 2)} nel test`}`,
    shift: (s, p, text) => `s = ${s}: probabilità ${IT.prob(p)}; "${text.slice(0, 32)}${text.length > 32 ? '...' : ''}"`,
    success: (L, n, rate, interval, bound) => {
      const parts = [rate !== null && `successo ${IT.pct(rate)} (95%: ${IT.pct(interval[0])}-${IT.pct(interval[1])})`, bound !== null && `limite di Chernoff ${IT.pct(bound)}`].filter(Boolean);
      return parts.length ? `${L} ${L === 1 ? 'lettera' : 'lettere'}, ${n} brani: ${parts.join('; ')}` : null;
    },
    methods: (L, rates) => {
      const parts = rates.map((r, i) => r !== null && `${Object.values(methodNamesIt)[i]} ${IT.pct(r)}`).filter(Boolean);
      return parts.length ? `${L} ${L === 1 ? 'lettera' : 'lettere'}: ${parts.join(', ')}` : null;
    },
    scaling: (bits, means) => (means.some((m) => m !== null) ? `${bits} bit: ${means.map((m, i) => (m === null ? null : `${['ricerca esaustiva', 'BSGS', 'canguro'][i]} ${IT.int(m)}`)).filter(Boolean).join(', ')} operazioni in media` : null),
  },
  download: {
    title: 'Scarica il codice',
    text: 'Il programma completo in HTML, CSS e JavaScript, senza dipendenze, in italiano e in inglese: dopo aver estratto l’archivio si apre con un doppio clic su index.html, anche offline. Con node homework2a.js stampa nel terminale lo schema, il cifrario di Cesare, gli attacchi e le statistiche; --key, --message, --shift e --random-nonces cambiano l’input.',
    contents: 'Contenuto: index.html, style.css, homework2a.js (schemi, attacchi, corpus e statistiche), app.js (interfaccia e testi), README.txt.',
    zip: 'Scarica homework2',
    online: 'Apri il programma online',
  },
  standalone: {
    subtitle: 'Uno schema giocattolo su curva ellittica e il cifrario di Cesare: cifratura, crittanalisi statistica e attacchi.',
    course: 'Statistics, laurea magistrale in Cybersecurity, Sapienza Università di Roma',
    online: 'Versione online',
    noscript: 'Questo programma ha bisogno di JavaScript.',
  },
};

// ---------------------------------------------------------------------------
// ENGLISH
// ---------------------------------------------------------------------------

const EN = formatters('.', ',', 'n/a', { years: 'years', days: 'days', hours: 'hours', minutes: 'minutes', seconds: 'seconds' }, '×');

/** The line of numbers under a hypothesis test, whatever its kind. */
function testLineEn(t) {
  const F = EN;
  switch (t.kind) {
    case 'chi2':
      return t.classes === undefined
        ? `Σz² = ${F.num(t.chi2, 1)}, χ² with ${t.df} degrees of freedom, p = ${F.pval(t.pValue)}`
        : `χ² = ${F.num(t.chi2, 1)} over ${t.classes} classes (${t.df} degrees of freedom), p = ${F.pval(t.pValue)}`;
    case 'binomial':
      return `${F.int(t.successes)} of ${F.int(t.trials)} = ${F.pct(t.rate, 2)} (expected ${F.pct(t.expectedRate, 2)}), z = ${F.num(t.z, 2)}, p = ${F.pval(t.pValue)}`;
    case 'independence':
      return `χ² = ${F.num(t.chi2, 1)} on a ${t.rows} × ${t.cols} table (${t.df} degrees of freedom, smallest expected count ${F.num(t.minExpected, 1)}), Cramér's V = ${F.num(t.cramerV, 3)}, p = ${F.pval(t.pValue)}`;
    default:
      return `p = ${F.pval(t.pValue)}`;
  }
}

const methodNamesEn = {
  top: 'Most frequent letter',
  chi2: 'Pearson’s χ²',
  unigram: 'Maximum likelihood',
  bigram: 'Bigrams',
  quadgram: 'Quadgrams',
  dictionary: 'Exhaustive search with a dictionary',
};

const en = {
  fmt: EN,
  ui: {
    index: 'Contents',
    indexTitle: 'Homework contents',
    close: 'Close',
    backToTop: 'Back to top',
    computing: 'Computing...',
    language: 'Language',
    error: (m) => `Error: ${m}`,
  },
  sections: {
    assignment: '0. The assignment',
    scheme: '1. TASK: the toy scheme on secp256k1, encrypting and decrypting',
    input: '1.1 Private key, message and nonces',
    keys: '1.2 Key generation',
    encrypt: '1.3 Encryption',
    decrypt: '1.4 Decryption',
    roles: '1.5 The role of the keys',
    verify: '1.6 Checks',
    caesar: '2. The Caesar cipher and the two schemes compared',
    caesarCipher: '2.1 Encrypting and decrypting the same message',
    compare: '2.2 Procedures and key spaces',
    properties: '2.3 The statistical properties of the two ciphertexts',
    cryptanalysis: '3. Statistical cryptanalysis of the Caesar cipher',
    corpus: '3.1 The corpus and the language models',
    algorithm: '3.2 The algorithm: maximum likelihood',
    lengths: '3.3 Ciphertexts of different lengths',
    methods: '3.4 Exhaustive search, frequencies and n-grams compared',
    limits: '3.5 Effectiveness and limitations',
    attack: '4. The attack on the toy scheme',
    exhaustive: '4.1 Exhaustive search',
    bsgs: '4.2 Baby-step giant-step',
    kangaroo: '4.3 Pollard’s kangaroo method',
    scaling: '4.4 The cost as the key grows',
    differences: '4.5 Two attacks compared',
    real: '4.6 Why it fails against properly configured ECC',
    weaknesses: '4.7 Other attacks: key space or design?',
    tests: '5. Summary of the statistical tests',
    history: '6. Historical context',
    conclusion: '7. Conclusions',
  },
  assignment: {
    intro: [
      'The assignment has three parts. The first asks to encrypt and decrypt a message with the toy scheme based on secp256k1 from the previous homework, describing the steps of the algorithm and the role of the keys; then to encrypt the same message with the Caesar cipher and to compare the two schemes: encryption and decryption procedures, key spaces, statistical properties. The second asks to break the Caesar cipher with statistics: given a large enough corpus in a known language, an algorithm that recovers the key from the distribution of letters, tested on texts of different lengths and, optionally, compared with exhaustive search, letter-frequency analysis and n-gram scoring. The third asks to break the toy scheme by exploiting the restricted space of private keys, to compare this attack with the statistical one, to explain why it would not work against properly configured elliptic-curve cryptography and, optionally, to tell the weaknesses due to the restricted key space from those of the scheme’s design.',
      `The scheme "of Part 1" needs to be made precise. Exercise 1 of Homework #1 computed K = kG on toy curves (y² = x³ + 7 over F_17, as the parameters of that assignment required, and over somewhat larger prime fields); Exercise 2 used secp256k1 with 256-bit keys, without encrypting anything. The scheme this assignment assumes lies in between: the real curve, secp256k1, with the private key restricted to a small range, here the integers from 1 to 2^${KEY_BITS} - 1; and, to encrypt, the standard method for a key pair K = kG, elliptic-curve ElGamal. Section 1 defines it and uses it.`,
      'The page follows the order of the assignment: section 1 encrypts and decrypts with the toy scheme, section 2 with the Caesar cipher and compares the two ciphertexts, section 3 breaks the Caesar cipher with the statistics of an English corpus, section 4 breaks the toy scheme with three discrete-logarithm algorithms and discusses why the same attack is not enough against a real key. Section 5 sums up the statistical tests, section 6 places the ideas in time and section 7 draws the conclusions. Every number is computed in the browser, and the downloadable program prints the same ones. The charts move: they zoom (ctrl + wheel, or a rectangle dragged; double click for the whole chart again), the bars by groups too, and the curves that follow the length of the message or of the key are drawn point by point.',
    ],
    originalTitle: 'The original text of the assignment',
    originalNote: 'As it was assigned.',
  },
  scheme: {
    intro: [
      'The scheme is elliptic-curve ElGamal, proposed by Koblitz in 1987 from ElGamal’s scheme of 1985, on the secp256k1 curve of Bitcoin and Ethereum. The receiver picks a private key k and publishes K = kG. To encrypt, the sender turns every byte of the message into a point M = bG, draws a random number r (the nonce) and sends the pair C1 = rG, C2 = M + rK. The receiver computes kC1 = k·rG = r·kG = rK, subtracts it from C2 and gets M back, and from M the byte. Whoever knows neither r nor k sees two points that, as far as anyone knows, cannot be told from random points.',
      `Compared with a real scheme there are two simplifications, both on purpose. The private key has at most ${KEY_BITS} bits instead of 256: this is the restriction of the assignment, which section 4 exploits. And every byte is encrypted on its own, with its own nonce: it costs 66 bytes of ciphertext for every byte of message, but makes the comparison with the Caesar cipher, which works one letter at a time, direct.`,
    ],
    formulasTitle: 'The scheme in three steps',
    formulas: [
      `Key generation      k drawn at random in [1, 2^${KEY_BITS} - 1]; K = kG`,
      'Encrypting byte b   M = bG; a fresh r in [1, n - 1];',
      '                    C1 = rG, S = rK, C2 = M + S',
      'Decryption          S = kC1 (= rK); M = C2 - S; b such that bG = M',
    ].join('\n'),
    stale: 'Values of the last valid input: the fields in 1.1 contain an error.',
  },
  input: {
    intro: 'The starting private key was drawn once and for all with a cryptographic generator; the message is the sentence in which Suetonius describes the Caesar cipher (Life of Julius Caesar, 56, in J. C. Rolfe’s English translation of 1914). Whoever opens the page sees the same values, and node homework2a.js prints the same numbers. Key and message can be changed, and every section follows, attacks included.',
    keyLabel: `Private key k (from 1 to ${EN.big(KEY_MAX)})`,
    keyHint: `An integer of at most ${KEY_BITS} bits, in decimal digits. With a small key, for example 1000, even the exhaustive search of section 4.1 finds it.`,
    randomKey: 'Random key',
    keyError: {
      empty: 'Type a key.',
      notInteger: (t) => `"${t}" is not an integer written in decimal digits.`,
      range: `The key goes from 1 to ${EN.big(KEY_MAX)} = 2^${KEY_BITS} - 1.`,
    },
    messageLabel: `Message (at most ${MESSAGE_MAX_BYTES} bytes of UTF-8)`,
    messageHint: (bytes) => `${bytes} of ${MESSAGE_MAX_BYTES} bytes: every byte becomes a block of the ciphertext. Accented letters take two bytes.`,
    messageError: {
      empty: 'Type a message.',
      tooLong: (bytes) => `The message takes ${bytes} bytes in UTF-8: at most ${MESSAGE_MAX_BYTES}.`,
    },
    noncesLabel: 'Nonces',
    nonces: { seeded: 'Reproducible', random: 'Random' },
    reroll: 'New random nonces',
    noncesHint: 'The reproducible nonces come from SHA-256 of a fixed seed, so that the page and the terminal show the same ciphertext; for the same reason anyone can recompute them, which is one of the weaknesses of section 4.7. The random nonces come from the browser’s cryptographic generator: the ciphertext changes with every draw, the decrypted message does not.',
    cipherNow: ({ mode, draw, total, digest, ok }) =>
      mode === 'random'
        ? `Draw ${EN.int(draw)}: the ciphertext of section 1.3, ${EN.int(total)} bytes, has SHA-256 ${digest} and changes with every draw; decrypted with k, it ${ok ? 'still gives the message' : 'does not give the message'}.`
        : `The ciphertext of section 1.3, ${EN.int(total)} bytes, has SHA-256 ${digest}: with the reproducible nonces it is always the same, here and in the terminal.`,
    defaultBadge: (pk) => `Starting values: the key drawn for this homework, the sentence of Suetonius and the reproducible nonces. Expected public key, also computed with the ethers 6.13.5 library: ${pk}.`,
    customBadge: 'Values different from the starting ones.',
    restore: 'Restore the starting values',
    stale: 'While a field contains an error, the sections that depend on it keep its last valid value.',
  },
  keys: {
    intro: [
      'The private key k is an integer; the public key is the point K = kG, computed with the scalar multiplication of Exercise 1 of Homework #1, here on the 256-bit numbers of secp256k1. Computing K from k costs at most 64 point additions with a precomputed table of multiples of G; going back from K to k is the discrete logarithm problem.',
      `On secp256k1, with k chosen between 1 and n - 1, the best known attack takes about 2^128 operations. With a ${KEY_BITS}-bit k, as here, about 2^17 are enough (section 4): the curve is the same, only the set in which k must be searched changes.`,
    ],
    kLabel: 'Private key k (decimal)',
    hexLabel: 'k in hexadecimal',
    binaryLabel: (bits) => `k in binary: ${bits} significant bits of ${KEY_BITS}`,
    xLabel: 'Abscissa x of K',
    yLabel: 'Ordinate y of K',
    compressedLabel: (even) => `K in compressed form (SEC 1): ${even ? '02, y even' : '03, y odd'}, then x`,
    onCurve: (ok) => (ok ? 'K satisfies y² = x³ + 7 (mod p): it is a point of the curve. ✓' : 'K is not a point of the curve. ✗'),
    reference: (ok) => (ok ? 'It matches the public key computed with ethers 6.13.5. ✓' : 'It does not match the public key computed with ethers 6.13.5. ✗'),
    after: [
      `The public key does not betray its origin: the x and y of K look like random 256-bit numbers even when k has only ${KEY_BITS} bits, and the test of section 2.3 cannot tell the public keys of small private keys from those of 256-bit private keys. The flaw of the toy scheme is not statistical but algebraic: K = kG with a small k.`,
    ],
  },
  encrypt: {
    intro: [
      'The message becomes a sequence of bytes (UTF-8), and every byte b becomes the point M = bG: byte 0 is the point at infinity, byte 255 is 255G. For every byte a nonce r is drawn, an integer between 1 and n - 1, and C1 = rG and the shared point S = rK are computed; the ciphertext of the byte is the pair (C1, C2 = M + S), 66 bytes in compressed form.',
      'The nonce is used once and forgotten: whoever knew it would compute S = rK from K, which is public, and decrypt the block. C1 = rG carries it without revealing it, because recovering r from C1 is again a discrete logarithm, and with a 256-bit r a hard one.',
    ],
    tableTitle: 'The blocks of the ciphertext',
    cols: { position: '#', byte: 'Byte', r: 'Nonce r', C1: 'C1 = rG', C2: 'C2 = bG + rK' },
    size: ({ bytes, total }) => `${EN.int(bytes)} bytes of message, ${EN.int(bytes)} blocks, ${EN.int(total)} bytes of ciphertext.`,
    after: [
      'The same byte encrypted twice gives two different blocks, because the nonce changes: all the "e"s of the message have a different ciphertext. This is probabilistic encryption (Goldwasser and Micali, 1984), the property the Caesar cipher lacks and section 2.3 measures.',
    ],
  },
  decrypt: {
    intro: [
      'The receiver knows k and nothing else. For every block it computes S = kC1, which equals rK because kC1 = k(rG) = r(kG) = rK; it subtracts S from C2 and gets M = bG. What is left is to find b, again a discrete logarithm, but an easy one: b has only 256 values, and a table of the points 0G, ..., 255G, built once, gives it with a lookup.',
      `With a ${KEY_BITS}-bit k, kC1 costs about thirty doublings and fifteen additions: the small key makes decryption fast too. It is its only advantage, and security pays for it.`,
    ],
    firstTitle: 'The first block, step by step',
    labels: {
      C1: 'C1, received',
      C2: 'C2, received',
      S: 'S = kC1',
      M: 'M = C2 - S',
    },
    decoded: (b, c) => (b < 0 ? 'M is not bG for any byte: the block does not decrypt. ✗' : `M = ${b}G: byte ${b}, "${c}". ✓`),
    sameS: (ok) => (ok ? 'kC1 equals the point rK computed by the sender. ✓' : 'kC1 does not equal rK. ✗'),
    resultLabel: 'The decrypted message',
    check: (ok) => (ok ? 'The decrypted message matches the original. ✓' : 'The decrypted message does not match the original. ✗'),
  },
  roles: {
    intro: 'Every value of the scheme has an owner and a purpose, and each, if it leaks, does a different kind of damage.',
    cols: { value: 'Value', who: 'Who knows it', purpose: 'What it is for', leak: 'If it leaks' },
    rows: [
      {
        value: 'k, private key',
        who: 'The receiver only.',
        purpose: 'Decrypting: S = kC1.',
        leak: 'Anyone decrypts every message, past and future, encrypted with K.',
      },
      {
        value: 'K = kG, public key',
        who: 'Everyone.',
        purpose: 'Encrypting: S = rK. Anyone can write to the receiver.',
        leak: 'It is public by design: it protects k as long as the discrete logarithm is hard, and with a small k it is not.',
      },
      {
        value: 'r, nonce',
        who: 'The sender only, for the time of one block.',
        purpose: 'Making encryption probabilistic; C1 = rG carries it without revealing it.',
        leak: 'Whoever knows r computes S = rK and decrypts that block. A reused or predictable nonce breaks the scheme even with a safe k (section 4.7).',
      },
      {
        value: 'S = rK = kC1, shared secret',
        who: 'Sender and receiver.',
        purpose: 'The mask that hides M: C2 = M + S. It is an elliptic-curve Diffie-Hellman exchange.',
        leak: 'It decrypts that block, and only that one.',
      },
      {
        value: 'M = bG, encoding',
        who: 'It is not a secret.',
        purpose: 'Bringing the byte into the group of points, where S can be added.',
        leak: 'Nothing: the table of the 256 points is public.',
      },
      {
        value: 'p, n, G, curve parameters',
        who: 'Everyone.',
        purpose: 'Fixing the group in which everything is computed.',
        leak: 'Nothing: they are public by design.',
      },
    ],
    after: 'The difference from the Caesar cipher is already here. Caesar has a single key, which encrypts and decrypts and must stay secret for both; the curve scheme has two, and the one that encrypts can be published. The price of the asymmetry is a hard problem to rest on: the discrete logarithm, which the 32-bit restriction makes easy.',
  },
  verify: {
    intro: 'Everything is written from scratch, with no libraries. Before trusting the numbers, the page compares them with known values: the test vectors of SHA-256 (FIPS 180-4), some multiples of G computed with ethers 6.13.5 (each computed both with the precomputed table and by doublings and additions), nG = O, which says that G has order n, and the round trip of both ciphers on the starting message.',
    summary: (ok, n) => `${ok} of ${n} checks passed.`,
    details: (n) => `The ${n} checks`,
    groups: { sha256: 'SHA-256 (FIPS 180-4)', curve: 'secp256k1', scheme: 'Toy scheme', caesar: 'Caesar cipher' },
    cols: { check: 'Check', expected: 'Expected value', result: 'Result' },
    ok: 'passed',
    failed: 'failed',
  },
  caesar: {
    intro: [
      'The second part of the assignment: the same message with the Caesar cipher, and the comparison between the two schemes.',
    ],
  },
  caesarCipher: {
    intro: [
      `The Caesar cipher moves every letter s places forward in the alphabet, starting again from A after Z: with s = ${DEFAULT_SHIFT}, the shift Suetonius attributes to Caesar, A becomes D, B becomes E, ..., Z becomes C. Decrypting means moving back by the same s places. In formulas, with the letters numbered from 0 (A) to 25 (Z): c = (p + s) mod 26 and p = (c - s) mod 26.`,
      'Here upper and lower case are kept, and anything that is not a letter from A to Z (spaces, punctuation, digits, accented letters) stays as it is, as in most textbook implementations.',
    ],
    shiftLabel: 'Shift s (from 0 to 25)',
    shiftHint: 'With s = 0 the text stays in the clear; s and 26 - s undo each other.',
    shiftError: {
      empty: 'Type a shift.',
      notInteger: (t) => `"${t}" is not an integer written in digits.`,
      range: 'The shift goes from 0 to 25.',
    },
    tableTitle: 'The substitution table',
    plainRow: 'Plain',
    cipherRow: 'Cipher',
    cipherLabel: 'The encrypted message',
    decryptedLabel: 'The decrypted message',
    check: (ok) => (ok ? 'The decrypted message matches the original. ✓' : 'The decrypted message does not match the original. ✗'),
    top: (f) =>
      f.top
        ? `The ciphertext has the same length, the same spaces and the same punctuation as the message, and every letter is always replaced by the same one: "${f.top.letter}", the most frequent letter of the message (${f.top.count} times out of ${f.letters}), always becomes "${f.top.image}".`
        : 'The message contains no letters from A to Z: the Caesar cipher leaves it as it is.',
    stale: 'Values of the last valid shift: the field contains an error.',
  },
  compare: {
    intro: 'The table compares the two schemes and, for reference, what is really used to encrypt with an elliptic-curve key.',
    cols: ['', 'Caesar cipher', 'Toy scheme (EC-ElGamal, 32-bit k)', 'Properly configured ECC (ECIES)'],
    rows: (size) => [
      ['Kind', 'Symmetric: the same key encrypts and decrypts.', 'Asymmetric: K encrypts, k decrypts.', 'Asymmetric for the key, symmetric for the message (hybrid encryption).'],
      ['Group', 'The integers modulo 26, with addition.', 'The points of secp256k1, with point addition; order n ≈ 2^256.', 'The same.'],
      ['Encryption', 'c = p + s (mod 26), letter by letter, deterministic.', 'C1 = rG, C2 = bG + rK, byte by byte, with a fresh nonce for every byte.', 'An ephemeral point rG, the secret rK passed through a key derivation function, and an authenticated cipher (AES-GCM, ChaCha20-Poly1305) over the whole message.'],
      ['Decryption', 'p = c - s (mod 26).', 'S = kC1, M = C2 - S, then the table of the 256 points.', 'S = k·rG, the same derivation, and the check of the tag before decrypting.'],
      ['Key space', '26 shifts, one of which (0) does not encrypt: log2 26 ≈ 4.7 bits.', `2^${KEY_BITS} - 1 private keys: ${KEY_BITS} bits, but about 16 bits of security against baby-step giant-step and the kangaroo.`, 'n - 1 ≈ 2^256 keys: about 128 bits of security.'],
      ['Ciphertext length', 'The same as the message.', `66 bytes per byte of message: here ${EN.int(size.bytes)} bytes become ${EN.int(size.total)}.`, 'The message plus 33 bytes (the ephemeral point) and 16 of tag.'],
      ['The same letter twice', 'Always gives the same letter.', 'Gives two different blocks.', 'Gives different ciphertexts.'],
      ['What leaks', 'Letter frequencies, word lengths, spaces, punctuation, repeated letters.', 'The exact length in bytes.', 'The length of the message.'],
      ['Integrity', 'None.', 'None: the ciphertext is malleable (section 4.7).', 'The tag rejects every modified ciphertext.'],
      ['Best attack', 'Statistical, from the ciphertext alone: a few letters are enough (section 3).', 'Algebraic, from the public key alone: about 2^17 operations (section 4).', 'Algebraic: about 2^128 operations, out of reach.'],
    ],
    after: [
      'The similarities are structural. Both encrypt by adding an element of a group to the plaintext and decrypt by subtracting it: Caesar adds s in the group of the integers modulo 26, the curve scheme adds S = rK in the group of points. Both work one symbol at a time, and in both the key lies in a set that can be listed: 26 elements in one case, about 4.3 billion in the other. In both, decrypting with the wrong key gives nonsense, and the attacker needs a way to recognize the right one.',
      'The differences lie in three places. The key: Caesar has a single secret key that encrypts and decrypts; the curve scheme separates who can encrypt (anyone, with K) from who can decrypt (only the holder of k), and it is this asymmetry that requires a hard problem such as the discrete logarithm. The translation: Caesar always uses the same one, s, while the curve scheme uses a new one for every byte, S = rK with a random r; it is the difference between a substitution cipher and a one-time pad in the group of points, and section 4.7 shows that reusing r is enough to fall back to a Caesar cipher on bytes. And the key space: 26 against 2^32, and above all against 2^256 in a real scheme.',
    ],
  },
  properties: {
    intro: [
      'The assignment asks to compare the statistical properties too. The Caesar cipher is a fixed permutation of the alphabet: the letter frequencies of the ciphertext are those of the plaintext, rotated by s places. The curve scheme is probabilistic: the ciphertext of every byte is a pair of points that, statistically, does not depend on the byte.',
    ],
    lettersChart: 'The letters of the message: counts (bars) and expected counts from the frequencies of the corpus of section 3 (dashed)',
    cipherChart: (shift) => `The letters of the Caesar ciphertext (bars), with the same expected counts (dashed): the same profile, shifted by ${shift} ${shift === 1 ? 'place' : 'places'}`,
    sampleIntro: (s) => `A short message is too little for tests. For those, the first ${EN.int(s.ciphers.bytes)} bytes of the test chapters of the corpus (section 3.1), ${EN.int(s.ciphers.plain.letters)} letters, are encrypted with both schemes: with Caesar (s = ${s.ciphers.shift}) and with the toy scheme, with the starting key and reproducible nonces from a seed other than that of section 1.`,
    bytesChart: (s) => `The bytes of the abscissas x(C1) and x(C2) of the curve ciphertext: ${EN.int(s.ciphers.ec.counts.reduce((a, b) => a + b, 0))} bytes, counts (bars) and uniform expectation (dashed)`,
    tableTitle: 'Entropy and index of coincidence',
    cols: { text: 'Text', symbols: 'Symbols', entropy: 'Entropy (bits per symbol)', ic: 'Index of coincidence' },
    rowNames: { plain: 'Plaintext (letters)', caesar: 'Caesar ciphertext (letters)', ec: 'Curve ciphertext (bytes of x(C1) and x(C2))' },
    entropyCell: (v, max) => `${EN.num(v, 3)} of ${EN.num(max, 3)}`,
    icCell: (v, uniform) => `${EN.num(v, 5)} (uniform: ${EN.num(uniform, 5)})`,
    repeated: (s) => {
      const r = s.ciphers.repeated;
      const letter = 'abcdefghijklmnopqrstuvwxyz'[r.letter];
      return `The letter "${letter}" occurs ${r.occurrences} times in the text: the Caesar cipher turns it ${r.occurrences} times into the same letter (${r.caesarDistinct} distinct ${r.caesarDistinct === 1 ? 'ciphertext' : 'ciphertexts'}), the curve scheme into ${r.ecDistinct} blocks, all different.`;
    },
    explain: (s) => [
      `The entropies and the indices of coincidence of the plaintext and of the Caesar ciphertext are identical, not about equal: a permutation of the symbols does not change the distribution, it renames its values. This is why the index of coincidence (Friedman, 1922) tells that a text is encrypted with a single substitution, but not which one: the key is found by comparing the frequencies with those of the language (section 3). The tests confirm it: the letters of the ciphertext are anything but uniform, and the ciphertext letter depends entirely on the plaintext letter (Cramér's V = ${EN.num(s.ciphers.caesar.dependence.cramerV, 3)}).`,
      `The curve ciphertext has an entropy of ${EN.num(s.ciphers.ec.entropy, 4)} bits per byte out of 8 and an index of coincidence of ${EN.num(s.ciphers.ec.ic, 5)}, against 1/256 ≈ ${EN.num(1 / 256, 5)} for uniform bytes: the frequencies of the plaintext are gone, and the tests find neither a departure from uniformity nor a dependence on the encrypted byte. It is not luck: under the decisional Diffie-Hellman assumption (DDH) on secp256k1, (rG, M + rK) cannot be told from a pair of random points whatever M is (Tsiounis and Yung, 1998). The tests cannot prove it; they can only fail to refute it.`,
      'Two caveats. The curve ciphertext is not uniform in every byte: the first byte of a compressed point is 02 or 03, the parity of y, which is why the tests use the abscissas and check the parity separately. And the indistinguishability holds against whoever does not know k: with a 32-bit k, anyone who computes it (section 4) makes the ciphertext transparent. The statistics of the ciphertext are perfect and the security is nil: the security of a public-key scheme cannot be seen in its ciphertexts.',
    ],
  },
  cryptanalysis: {
    intro: [
      'The second part: recovering the key of the Caesar cipher from the ciphertext alone, with the statistics of a corpus in a known language.',
    ],
  },
  corpus: {
    intro: [
      'The corpus is Lewis Carroll’s Alice’s Adventures in Wonderland (1865), in the public domain, in the Project Gutenberg transcription (eBook #11): 12 chapters in English. To measure the attack on text it has never seen, the chapters have three roles, as in a statistical learning experiment: chapters I-VII estimate the models, VIII-IX choose the amount of smoothing (validation), and the attack is measured on X-XII (test), never used before. The final models use all of chapters I-IX.',
    ],
    chaptersTitle: 'The chapters and their role',
    cols: { number: 'Ch.', title: 'Title', letters: 'Letters', role: 'Role' },
    roles: { fit: 'estimation', validation: 'validation', test: 'test' },
    chart: (s) => `Letter frequencies: training chapters (${chapterRange(SPLIT.training)}, ${EN.int(s.corpus.training.letters)} letters, bars) and test chapters (${chapterRange(SPLIT.test)}, ${EN.int(s.corpus.test.letters)} letters, dashed)`,
    facts: (s) => [
      `In the training chapters the most frequent letter is "${'abcdefghijklmnopqrstuvwxyz'[s.models.top]}" (${EN.pct(s.models.q[s.models.top])}), the entropy of the letters is ${EN.num(s.corpus.training.entropy, 3)} bits out of a maximum of log2 26 ≈ ${EN.num(Math.log2(26), 3)}, and the index of coincidence is ${EN.num(s.corpus.training.ic, 4)}, against 1/26 ≈ ${EN.num(1 / 26, 4)} for uniform letters: the distance between the two is the redundancy the attack exploits.`,
      `The χ² test rejects homogeneity between training and test: chapters ${chapterRange(SPLIT.test)}, with more dialogue and new characters (the King, the Queen, the trial), have significantly different frequencies (p = ${EN.pval(s.corpus.homogeneity.pValue)}). But the difference is small: the total variation distance between the two distributions is ${EN.pct(s.corpus.tvd)}, and Cramér's V ${EN.num(s.corpus.homogeneity.cramerV, 3)}. With a hundred thousand letters even a tiny difference becomes significant: statistical significance and practical relevance are two different things, and what matters to the attack is the second. A corpus is not the language, it is a sample with its own style; whether the models hold on chapters other than those they were estimated on is exactly what section 3.3 measures.`,
    ],
    modelsIntro: [
      'Besides the frequencies of single letters, the attack can use sequences: an n-gram model estimates the probability of every letter given the n - 1 before it, that is, a Markov chain of order n - 1. Raw counts are not enough: with eighty thousand letters many of the 456,976 possible quadgrams never occur, and a model giving them probability zero would discard even the right text at its first unusual sequence.',
      'The probabilities are therefore smoothed toward the model of lower order: a context seen often counts for its own counts, one seen rarely borrows from the shorter context, and one never seen falls back on it. It is the posterior mean under a Dirichlet prior centred on the lower order and worth β observations. Additive smoothing, more common, would give an unseen context the uniform distribution: the very unusual contexts that a wrong decryption produces would receive generous probabilities, and the quadgrams would lose much of their advantage. β is chosen on the validation chapters, by minimizing the cross-entropy.',
    ],
    formula: [
      'P_n(x | h) = ( c(h x) + β · P_(n-1)(x | h′) ) / ( c(h) + β )',
      'h = the n - 1 letters before; h′ = h without the oldest; P_0(x) = 1/26',
      'cross-entropy  H = -(1/N) Σ log2 P(x_t | context)   [bits per letter]',
    ].join('\n'),
    modelsTitle: 'The models, measured on the test chapters',
    modelCols: { order: 'Order', beta: 'Chosen β', crossEntropy: 'Cross-entropy (bits/letter)', redundancy: 'Redundancy D (bits/letter)', unicity: 'Unicity distance (letters)' },
    orderName: (n) => ['single letters', 'bigrams', 'trigrams', 'quadgrams'][n - 1],
    after: (s) => [
      `The cross-entropy falls from ${EN.num(s.models.crossEntropy[0], 2)} bits per letter with the frequencies alone to ${EN.num(s.models.crossEntropy[3], 2)} with quadgrams: more context, less uncertainty about each letter. Shannon (1951) estimated for English, with long contexts, between 0.6 and 1.3 bits per letter; the difference is the part of the language that four letters cannot see. For single letters the choice of β makes no difference (the validation entropies differ in the sixth digit), because every letter occurs thousands of times.`,
      `The redundancy D = log2 26 - H is what makes the attack possible. Shannon’s unicity distance (1949), U = H(K)/D = log2 26 / D, estimates how many ciphertext letters are needed for a single key to give a plausible text: about ${EN.num(s.models.unicity[0], 1)} with the frequencies alone, about ${EN.num(s.models.unicity[3], 1)} with quadgrams. Section 3.4 shows that the lengths at which the attack becomes reliable have just this order of magnitude.`,
    ],
  },
  algorithm: {
    intro: [
      'The algorithm: for each of the 26 shifts s, decrypt and measure how much the result looks like English; pick the most plausible shift. The natural criterion is the likelihood. If the letters of the plaintext were independent with the frequencies q of the corpus, the probability of observing the ciphertext under the key s would be the product of the q of the decrypted letters; the shift that maximizes it is the maximum-likelihood estimator of the key, and with a uniform prior on the key also the Bayes estimator that, under that model, minimizes the probability of error.',
      'In practice the 26 counts n_x of the ciphertext are enough: decrypting with s turns the cipher letter x + s into x, and the log-likelihood is a sum of 26 terms, 26 × 26 operations whatever the length of the text.',
    ],
    formula: [
      'ŝ = argmax_s  Σ_i log q(c_i - s)  =  argmax_s  Σ_x n_(x+s) · log q(x)',
      'P(s | ciphertext) = exp(ℓ(s)) / Σ_t exp(ℓ(t))     (uniform prior on the key)',
    ].join('\n'),
    liveTitle: 'The attack on the Caesar ciphertext of the message',
    live: (crack, shift) =>
      crack.key === null
        ? 'The ciphertext contains no letters, or several shifts tie: the likelihood does not choose.'
        : `Over ${crack.letters} letters, the most likely shift is s = ${crack.key}, with posterior probability ${EN.prob(crack.posterior[crack.key])}${crack.key === shift ? ': it is the one used in 2.1. ✓' : `, but s = ${shift} was used in 2.1: with so few letters the attack fails. ✗`}`,
    posteriorChart: 'Posterior probability of the 26 shifts, with the most probable one highlighted',
    candidatesTitle: 'The five most probable shifts',
    candidateCols: { shift: 's', perLetter: 'Log-likelihood per letter', posterior: 'Posterior probability', text: 'Decryption' },
    fit: (checks) =>
      checks === null
        ? []
        : [
          `Check: do the letters decrypted with s = ${checks.best.shift} follow the frequencies of English? The χ² goodness of fit gives p = ${EN.pval(checks.best.test.pValue)}: ${checks.best.test.verdict === 'reject' ? 'rejected, the text is unusual for English' : 'not rejected, the text is compatible with English'}.${checks.second ? ` With the second most probable shift, s = ${checks.second.shift}, p = ${EN.pval(checks.second.test.pValue)}: ${checks.second.test.verdict === 'reject' ? 'rejected' : 'not rejected'}.` : ''}`,
        ],
    pending: 'The attack uses the models of section 3.1, still being computed.',
    after: [
      'Pearson’s χ², often used for the same purpose, minimizes Σ (n_x(s) - L q_x)² / (L q_x): it measures the same distance between observed and expected frequencies, but weighs rare letters heavily (an unexpected "z" sends the χ² up), and on short texts it fails more often than the likelihood (section 3.4).',
      'The weakness of the Caesar cipher is not just the number of keys: it is that the substitution preserves the statistics of the text. Every letter of the ciphertext carries a little information about the key, and the likelihood adds it up.',
    ],
  },
  lengths: {
    intro: (s) => [
      `To measure its effectiveness, the algorithm was tried on the test chapters, which it has never seen: for every length L from ${LENGTHS[0]} to ${LENGTHS[LENGTHS.length - 1]} letters, up to ${EN.int(SAMPLES.maxTrials)} disjoint passages of L consecutive letters, each encrypted with a random shift (seed ${EXPLORE_SEED}). A trial counts 1 if the key found is right, 1/t if it is among t keys tied for best (the probability of guessing it by drawing among them), 0 otherwise. With long passages there are fewer disjoint ones (${s.caesar.trials[s.caesar.trials.length - 1]} of ${LENGTHS[LENGTHS.length - 1]} letters), and the 95% confidence intervals, Wilson’s, are wider.`,
    ],
    chart: 'Maximum likelihood on the letter frequencies: success rate by ciphertext length (logarithmic axis)',
    legend: ['Success rate, with the 95% confidence interval', 'Chernoff’s lower bound for independent letters'],
    tableTitle: 'Success rate by length',
    cols: { length: 'Letters', trials: 'Passages', rate: 'Success', interval: '95% interval', bound: 'Chernoff bound' },
    explain: (s) => {
      const r = (L) => EN.pct(rateAt(s, 'unigram', L));
      const q = s.models.q[s.models.top];
      return [
        `With a single letter the algorithm is right in ${r(1)} of the cases: it picks the shift that turns that letter into "${'abcdefghijklmnopqrstuvwxyz'[s.models.top]}", and it is right when the letter was just that one (${EN.pct(q)} of the letters of the corpus). With 10 letters it is right in ${r(10)} of the cases, with 20 in ${r(20)}, with 50 in ${r(50)}.`,
        `The shape of the curve has a theoretical explanation. If the letters were independent with frequencies q, the right shift would lose against a wrong shift d with probability at most ρ_d^L, where ρ_d = min_λ Σ_x q(x)^(1-λ) q(x-d)^λ (Chernoff bound), and the total error would be at most Σ_d ρ_d^L. The shift most easily confused with the right one is d = ${s.caesar.confusable.shift} (or ${26 - s.caesar.confusable.shift}, its opposite), with ρ = ${EN.num(s.caesar.confusable.rho, 3)}: every extra letter multiplies the dominant term of the error by ${EN.num(s.caesar.confusable.rho, 3)}, that is, it brings ${EN.num(-Math.log2(s.caesar.confusable.rho), 2)} bits of evidence in favour of the right key. The bound is cautious, because it adds up 25 overlapping events, and it becomes informative only beyond about ten letters, but it says the important thing: the error decreases exponentially with the length.`,
        s.caesar.rates.unigram.every((r, i) => r >= s.caesar.bound[i])
          ? 'Real text is not made of independent letters: words repeat sequences, and two passages of the same chapter resemble each other. Yet the measured curve lies above the bound at every length: the dependence between neighbouring letters does not harm an attack that ignores it, and the n-grams of section 3.4 exploit it.'
          : 'Real text is not made of independent letters, and the bound holds for a model: at some lengths the measured curve falls below the bound, a sign that the dependence between neighbouring letters, or the difference between chapters, weighs in. The n-grams of section 3.4 exploit it instead of suffering it.',
      ];
    },
  },
  methods: {
    intro: [
      'The assignment suggests comparing exhaustive key search, letter-frequency analysis and n-gram scoring. With 26 keys, every method tries them all: what changes is the criterion by which it recognizes the right one, and so how much information about the language it uses.',
    ],
    list: [
      { method: 'top', text: 'assumes that the most frequent letter of the ciphertext is "e". It uses a single number from the corpus.' },
      { method: 'chi2', text: 'the distance between the frequencies of the decrypted letters and those of the corpus.' },
      { method: 'unigram', text: 'the frequencies of the corpus as a model: the algorithm of section 3.2.' },
      { method: 'bigram', text: 'the likelihood under the bigram model of section 3.1, which also sees the order of two letters.' },
      { method: 'quadgram', text: 'the likelihood under the quadgram model: every letter given the three before it.' },
      { method: 'dictionary', text: 'decrypts with every key and counts the letters of the words that occur in the training chapters. It is exhaustive search as a person would do it, reading the 26 decryptions and picking the one with real words.' },
    ],
    chart: 'Success rate of the six methods by ciphertext length (logarithmic axis)',
    tableTitle: 'Letters needed to reach 50%, 90% and 99% success',
    cols: { method: 'Method', levels: ['50%', '90%', '99%'] },
    never: 'over 200',
    explain: (s) => {
      const t = Object.fromEntries(thresholds(s).map((row) => [row.method, row.levels]));
      const L = (m, i) => (t[m][i] === null ? 'over 200' : String(t[m][i]));
      const r = (m, n) => EN.pct(rateAt(s, m, n));
      return [
        `The order of the methods is that of the information they use. The χ² and maximum likelihood use the same information, the frequencies, but the likelihood uses it better: it is the optimal criterion under the model, and at 10 letters it wins ${r('unigram', 10)} against ${r('chi2', 10)}. The quadgrams, which also use the order of the letters, reach 90% with ${L('quadgram', 1)} letters and 99% with ${L('quadgram', 2)}; the frequencies alone need ${L('unigram', 1)} and ${L('unigram', 2)}. The unicity distance of section 3.1 predicted this order of magnitude: about ${EN.num(s.models.unicity[0], 0)} letters with the frequencies alone, about ${EN.num(s.models.unicity[3], 1)} with quadgrams.`,
        `Exhaustive search with a dictionary (${EN.int(s.corpus.vocabulary)} distinct words) lies in between: it needs whole words, and a short passage cuts the words at its edges (at 5 letters it scores ${r('dictionary', 5)}, against ${r('quadgram', 5)} for the quadgrams). And it is put out of action by removing the spaces, as classical cryptographers did by writing ciphertext in groups of five letters, while the n-grams do not notice, because they read only the letters.`,
        `The most frequent letter is the worst method: even at 200 letters it is right in only ${r('top', 200)} of the cases, because in a short passage "e" is not always the most frequent letter. It is the method taught first, but it ignores 25 of the 26 frequencies.`,
        'Cost does not separate the methods: they all try 26 keys. The frequencies take 26 × 26 operations whatever the length, the n-grams 26 per letter, the dictionary 26 lookups per word. Against a cipher with 26 keys cost never matters: only recognizing the right key does.',
      ];
    },
  },
  limits: {
    paras: [
      'Short texts. Below 5 letters no method is reliable, and with one or two letters the problem has no unique solution: many keys give plausible decryptions. This is the idea of the unicity distance: below that length the cipher cannot be broken, not because it is strong but because the message itself is ambiguous.',
      'The language. The model must be the text’s: a message in Italian attacked with English frequencies often falls anyway, because the two languages share many frequent letters, but more letters are needed; a text of digits, acronyms or random passwords has no redundancy to exploit, and no statistical method breaks it. The same holds for an atypical text: Ernest Vincent Wright’s Gadsby (1939), a novel written without the letter "e", fools the most-frequent-letter method and weakens the others.',
      'The model. The independence of letters is false (the Chernoff bound holds for a text that does not exist) and a corpus by a single author is not the language (section 3.1). The n-grams correct the first approximation, a larger and more varied corpus the second; both corrections save letters, neither changes the conclusion.',
      'The real limit lies elsewhere: the attack works because the Caesar cipher is a fixed substitution. Even the general monoalphabetic substitution, with 26! ≈ 4·10^26 ≈ 2^88 keys, more than DES’s 2^56, falls the same way, with a little more text and a smarter search: a large key space is necessary but not sufficient. The ciphertext must not preserve the statistics of the plaintext, and that is what the curve scheme guarantees (section 2.3).',
    ],
  },
  attack: {
    intro: [
      `The toy scheme is as safe as recovering k from K = kG is hard. With k restricted to ${KEY_BITS} bits, the problem becomes the discrete logarithm in a known interval, [1, 2^${KEY_BITS}): the attacker needs neither the message nor statistics, only the public key, which is public by definition. The subsections attack the key of section 1 with three algorithms, measure how the cost grows with the size of the key and discuss what changes against a real key.`,
      'The cost is measured in group operations, additions or doublings of points: a number that does not depend on the computer. The times, instead, are those of this browser.',
    ],
  },
  exhaustive: {
    intro: [
      `The simplest attack: compute G, 2G, 3G, ..., one point addition at a time, until K comes out. The first k with kG = K is the key, and there are no false positives, unlike the statistical attack, because the check is exact. The cost is k additions, 2^${KEY_BITS - 1} on average for a uniform ${KEY_BITS}-bit key. The page tries the first 2^${Math.log2(EXHAUSTIVE_LIMIT)} = ${EN.int(EXHAUSTIVE_LIMIT)} candidates on the key of section 1, measures the speed and estimates the rest.`,
      'The implementation advances 256 candidates at a time: each receives the same addition, and a single modular inversion serves them all (Montgomery’s trick), but the candidates are checked in order, so the number of additions stays exactly k.',
    ],
    found: (r) => `The key is among the first ${EN.int(r.limit)} candidates: k = ${EN.int(r.key)}, found after ${EN.int(r.ops)} additions, in ${EN.ms(r.ms)}. ✓`,
    notFound: (r, key) => `The first ${EN.int(r.limit)} candidates in ${EN.ms(r.ms)}: ${EN.int(r.rate)} additions per second. The key is not among them. Reaching k = ${EN.big(key)} would take ${EN.big(key)} additions, about ${EN.duration(r.toKey)} at this speed, and ${EN.duration(r.toAll)} to cover the whole range.`,
    after: [
      'Hours in JavaScript, in a browser, on a single core. An optimized implementation in C, or on a graphics card, is faster by orders of magnitude, and covers 2^32 candidates in seconds: exhaustive search alone is enough to break the toy scheme. This is what really happened with Profanity and with Milk Sad (section 6), where the private keys came from a 32-bit seed.',
    ],
  },
  bsgs: {
    intro: [
      `Baby-step giant-step (Shanks, 1971) trades time for memory. Every k in [1, 2^${KEY_BITS}) can be written k = i·m + j with m = 2^${KEY_BITS / 2} and 0 ≤ i, j ≤ m. The baby steps compute jG for j = 1, ..., m and put them in a table indexed by x; the giant steps compute K, K - mG, K - 2mG, ... until K - i·mG is in the table, that is, it equals jG, or -jG, which has the same x: then k = i·m + j, or k = i·m - j. At most m + 2^32/m ≈ 2^17 operations instead of 2^32, but m points must be kept in memory.`,
    ],
    formula: [
      'baby steps    table x(jG) → j,  for j = 1, ..., m        (m = 2^16)',
      'giant steps   Q_i = K - i·mG,  for i = 0, 1, 2, ...',
      'meeting       x(Q_i) = x(jG)  ⇒  k = i·m + j  (or i·m - j)',
    ].join('\n'),
    result: (r) => (r.found
      ? `k = ${EN.int(r.key)} = ${EN.int(r.i)} · ${EN.int(r.m)} + ${EN.int(r.j)}: found with ${EN.int(r.ops)} operations (${EN.int(r.baby)} baby steps and ${EN.int(r.giant)} giant ones), in ${EN.ms(r.ms)}. ✓`
      : 'The key is not in the range. ✗'),
    decryptedLabel: 'The message of section 1, decrypted with the recovered key',
    check: (ok) => (ok ? 'It matches the original message: the attacker reads everything without ever having seen k. ✓' : 'It does not match the message. ✗'),
    after: [
      'The table of baby steps does not depend on the key under attack: built once, it serves every key of the same range, and every new key costs on average only 2^15 giant steps. Against many users with small keys the attack becomes cheaper, not more expensive.',
    ],
  },
  kangaroo: {
    intro: [
      `The kangaroo method (Pollard, 1978) achieves the same cost, about 2·2^${KEY_BITS / 2} = 2^${KEY_BITS / 2 + 1} operations, with negligible memory. Two herds of kangaroos jump along the group: the jumps are worth 2^j·G, and j depends on the point where the kangaroo stands, so two kangaroos that pass through the same point make the same jumps from there on. The "tame" kangaroos start from known multiples of G in the middle of the interval, the "wild" ones from K plus a known multiple. When a wild kangaroo lands on the tracks of a tame one the two paths merge, and this shows at the next distinguished point (a point whose x ends with d zero bits), which both visit and store with the distance travelled. From there: exponent of the tame one = k + exponent of the wild one, and k follows.`,
      'This is the parallel version of van Oorschot and Wiener (1999): N kangaroos, half per herd, with mean jump N·√w/4 for an interval of width w, the choice that minimizes the expected work, about 2√w jumps in all.',
    ],
    result: (r) => (r.found
      ? `k = ${EN.int(r.key)}: found with ${EN.int(r.ops)} jumps of ${r.N} kangaroos (about ${EN.int(r.expected)} expected), mean jump ${EN.int(r.meanJump)}, storing only ${EN.int(r.distinguished)} distinguished points, in ${EN.ms(r.ms)}. ✓`
      : 'The key was not found. ✗'),
    after: [
      'Compared with baby-step giant-step, the memory falls from 65,536 points to a few hundred, and the work splits among as many processors as there are kangaroos, with almost no communication: it is the method used in practice for discrete logarithms in an interval. The number of jumps varies from key to key: it is small when k is near the middle of the interval, where the tame kangaroos start, large when it is near the edges.',
    ],
  },
  scaling: {
    intro: (sc) => [
      `To see how the cost grows, the three attacks were tried on random keys of increasing size (seed ${sc.seed}): exhaustive search from ${sc.rows.exhaustive[0].bits} to ${sc.rows.exhaustive[sc.rows.exhaustive.length - 1].bits} bits, baby-step giant-step from ${sc.rows.bsgs[0].bits} to ${sc.rows.bsgs[sc.rows.bsgs.length - 1].bits}, the kangaroo from ${sc.rows.kangaroo[0].bits} to ${sc.rows.kangaroo[sc.rows.kangaroo.length - 1].bits}. The operations do not depend on the machine; the speed does, and this one does ${EN.int(sc.rate)} per second.`,
    ],
    chart: 'log2 of the mean operations by key size: measured (points) and the line with the theoretical exponent (dashed)',
    legend: ['Exhaustive search', 'Baby-step giant-step', 'Kangaroo'],
    fitsTitle: 'The estimated slopes',
    fitCols: { method: 'Attack', slope: 'Estimated slope', theory: 'Theory', constant: 'Constant (log2)' },
    extrapolationTitle: 'Extrapolation',
    extrapolationCols: { bits: 'Key bits', exhaustive: 'Exhaustive search', best: 'BSGS or kangaroo', here: 'Time here', fast: 'Time at 10^12 operations/s', memory: 'BSGS memory' },
    memory: (e) => `2^${e} points`,
    explain: (sc) => {
      const f = sc.fits;
      return [
        `The estimated slopes are ${EN.num(f.exhaustive.slope, 2)} ± ${EN.num(f.exhaustive.slopeError, 2)} for exhaustive search, ${EN.num(f.bsgs.slope, 3)} ± ${EN.num(f.bsgs.slopeError, 3)} for baby-step giant-step and ${EN.num(f.kangaroo.slope, 2)} ± ${EN.num(f.kangaroo.slopeError, 2)} for the kangaroo: compatible with 1 and with 1/2. Every extra bit of key doubles the work of exhaustive search and multiplies it by √2 in the other two. Exhaustive search is the noisiest because its cost is the key itself, uniform between 1 and 2^b.`,
        'The extrapolation keeps the exponent of the theory fixed and estimates only the constant from the data: extrapolating the estimated slope would be unwise, because an error of 0.02 in the slope would become a factor 2^5 at 256 bits. It is the difference between a model justified by theory and a line fitted to the data.',
        `At ${KEY_BITS} bits the best attack costs about 2^17 operations: less than a second. At 256 bits it would cost about 2^129, and even at 10^12 operations per second it would take about ${EN.duration(2 ** 129 / FAST_RATE)}, a billion times the age of the universe.`,
      ];
    },
  },
  differences: {
    intro: 'The assignment asks to compare this attack with the statistical one against the Caesar cipher. They differ in almost everything.',
    cols: ['', 'Statistical attack on Caesar', 'Attack on the toy scheme'],
    rows: [
      ['What it rebuilds', 'The message, and the key as a by-product.', 'The private key; the message follows.'],
      ['From what', 'From the ciphertext (a few letters) and a model of the language.', 'From the public key alone: the ciphertext is needed only afterwards, to read.'],
      ['What it exploits', 'The redundancy of the language, which the substitution preserves.', 'The algebraic structure K = kG and the small range of k.'],
      ['Nature', 'An estimation problem: which key makes the text most plausible.', 'A search problem: which k satisfies kG = K.'],
      ['Outcome', 'Probabilistic: with short texts it can fail.', 'Certain: the key exists and is unique in the range.'],
      ['Check of the key', 'Statistical: the most likely key, not necessarily the right one.', 'Exact: kG = K, with no false positives.'],
      ['Cost', '26 trials, whatever the text.', 'Up to 2^32 operations with exhaustive search, about 2^17 with BSGS or the kangaroo.'],
      ['Depends on the message?', 'Yes: language and length decide success.', 'No: it works even if the message is random.'],
      ['Remedy', 'None within the cipher: the substitution preserves the statistics by construction.', 'Widening the key space to n - 1 ≈ 2^256.'],
    ],
    after: [
      'In one sentence: the attack on Caesar is an estimation problem, the one on the toy scheme a search problem. The first uses the statistics of the message, the second ignores them; the first can fail, the second cannot; the first is not stopped by widening the key space (the monoalphabetic substitution, with 2^88 keys, falls the same way), the second is.',
      'They do share one point: both try keys and recognize the right one. Against Caesar trying is trivial and recognizing is the problem; against the curve scheme recognizing is trivial (kG = K) and trying is the problem. The security of a modern cipher requires both to be hard: no statistical recognition from the ciphertext (section 2.3), and no feasible search of the key space.',
    ],
  },
  real: {
    paras: [
      'Against secp256k1 with a key chosen uniformly between 1 and n - 1, exhaustive search would take 2^255 operations on average, and baby-step giant-step and the kangaroo about 2^128, the former with 2^128 points in memory. This is not a limit of these algorithms: Shoup (1997) proved that every generic algorithm, one that uses the group only through its operations, needs Ω(√n) operations. Pollard’s rho reaches this bound without memory, but does no better.',
      'Non-generic attacks exploit a structure that secp256k1 lacks. Pohlig-Hellman requires the order of the group to have small factors, and n is prime; MOV and Frey-Rück require a small embedding degree, and that of secp256k1 is huge; Smart’s attack requires an anomalous curve, with #E = p, and secp256k1 is not one. Its only extra structure, the endomorphism (x, y) → (βx, y), reduces the rho by a factor √6 (Duursma, Gaudry and Morain, 1999): from 2^128 to about 2^127 operations, as seen in Exercise 1 of Homework #1.',
      `The asymmetry is what makes cryptography possible. The key owner computes K = kG with about 256 doublings and 128 additions, a cost that grows like the logarithm of n; the attacker needs about √n operations. Going from ${KEY_BITS} to 256 bits multiplies the work of the key’s user by 8 and that of whoever searches for it by 2^112.`,
      'This is why "properly configured" means above all a well-generated key: uniform in [1, n - 1], from a cryptographic generator. The weak keys found in the real world were not short by choice, but because of a faulty generator: 32 bits of seed in Profanity (2022) and in the bx seed command of Libbitcoin Explorer (Milk Sad, 2023). The curve was secure, the effective key space was not. One exception remains: a large enough quantum computer would solve the discrete logarithm in polynomial time with Shor’s algorithm, and then no elliptic-curve key length would be enough.',
    ],
  },
  weaknesses: {
    intro: 'The assignment asks to separate the weaknesses due to the restricted key space from those of the scheme’s design. The table lists them; two can be tried here, on the message of section 1.',
    cols: { weakness: 'Weakness', origin: 'Origin', attack: 'Attack', fix: 'Remedy' },
    rows: [
      ['32-bit k', 'Key space', 'Exhaustive search, baby-step giant-step, kangaroo (4.1-4.3): k from K alone, with about 2^17 operations.', 'k uniform in [1, n - 1].'],
      ['Precomputation and many targets', 'Key space', 'A table of baby steps, or of distinguished points, built once serves every key of the same range, and every further key costs less (Bernstein and Lange, 2012).', 'As above.'],
      ['Reused nonce', 'Design (usage)', 'All C1 equal, and C2_i - C2_j = (b_i - b_j)G reveals the differences between the bytes: a Caesar cipher on bytes, broken with frequencies (try it below).', 'A fresh nonce for every encryption, from the cryptographic generator.'],
      ['Predictable or small nonce', 'Design (usage)', 'Whoever recomputes r (from a known seed, like the reproducible nonces of this page) or finds it with baby-step giant-step when it is small computes S = rK and decrypts without k.', 'As above.'],
      ['Malleability', 'Design', 'Adding δG to C2 adds δ to the decrypted byte, without knowing k (try it below); blocks can also be swapped, removed or duplicated.', 'An authenticated cipher, which rejects modified ciphertexts (ECIES).'],
      ['Chosen ciphertexts', 'Design', 'Whoever can have any ciphertext decrypted sends (C1 + tG, C2 + tK), which encrypts the same message with nonce r + t, and reads it: the scheme is not secure against chosen-ciphertext attacks (IND-CCA2).', 'As above.'],
      ['Unvalidated points', 'Implementation', 'If decryption did not check that C1 lies on the curve, points of other curves with small subgroups would reveal k modulo small primes (invalid-curve attacks: Biehl, Meyer and Müller, 2000). This implementation rejects points that are not on the curve.', 'Validating every point received.'],
      ['One byte per block', 'Design', 'It reveals the exact length, multiplies the ciphertext by 66, and the blocks are independent, as in ECB mode.', 'Encrypting the whole message with a derived key (hybrid encryption).'],
      ['Small messages', 'Design, but harmless', 'Every block has only 256 possible messages, but encrypting them all and comparing does not help, because the nonce changes the ciphertext every time. It would in a deterministic scheme, such as RSA without padding.', 'None: probabilistic encryption already protects it.'],
    ],
    reuseTitle: 'Try it: the same nonce for every byte',
    reuse: (demo) => {
      const a = demo.attack;
      if (!a || !a.candidates.length) return ['The message gives no valid candidates.'];
      return [
        `The message of section 1 encrypted with a single nonce: its ${demo.blocks.length} C1 are ${a.sameC1 ? 'all equal, for anyone to see' : 'different'}. The differences C2_i - C2_1 = (b_i - b_1)G give b_i - b_1 through the table of points, and only one byte of the message stays unknown, b_1: ${a.range} possible values, of which ${a.valid} give valid UTF-8 text. The byte frequencies of the training chapters pick the most plausible:`,
      ];
    },
    reuseResult: 'The message read without k',
    reuseCheck: (ok) => (ok ? 'It matches the original message: no private key, no hard discrete logarithm. ✓' : 'It does not match the original message: the message is too short or too unusual. ✗'),
    augustusTitle: 'Try it: malleability',
    augustus: 'Every C2 of the ciphertext of section 1 plus G, decrypted with k:',
    augustusFail: 'The message contains byte 255, which plus 1 is no longer a byte: that block does not decrypt.',
    augustusAfter: 'Every byte went up by 1: the letters became the next ones, the spaces exclamation marks. It is the cipher of Augustus, who according to Suetonius moved every letter by one place, applied by someone who does not know the key to a message they cannot read.',
    after: [
      'Of these weaknesses, only the first two come from the restricted key space, and they vanish with a 256-bit k. The others belong to the design or the implementation and would remain with any key: this is why real systems do not encrypt with "bare" ElGamal, but with authenticated hybrid schemes such as ECIES (from DHIES, Abdalla, Bellare and Rogaway, 2001), secure even against whoever can have chosen ciphertexts decrypted.',
    ],
  },
  stats: {
    verdict: { reject: 'H₀ rejected', notReject: 'H₀ not rejected' },
    expected: { reject: 'expected: rejection', notReject: 'expected: no rejection', either: 'measures a real difference' },
    testLine: testLineEn,
    groups: { corpus: 'Corpus', caesar: 'Caesar', ec: 'Curve scheme', keys: 'Public keys' },
    labels: {
      corpus: { homogeneity: 'Training and test have the same letter frequencies (χ², 2 × 26)' },
      caesar: {
        uniform: 'The letters of the Caesar ciphertext are uniform over the 26 (χ²)',
        dependence: 'Plaintext letter and ciphertext letter are independent (χ², Caesar)',
      },
      ec: {
        uniform: 'The bytes of x(C1) and x(C2) are uniform over the 256 values (χ²)',
        parity: 'The y of C2 is odd with probability 1/2 (binomial)',
        independence: 'The plaintext byte and the first 2 bits of x(C2) are independent (χ²)',
      },
      keys: {
        small: 'The bits of x(kG) are fair coins for 32-bit keys: Σz² ~ χ²(256)',
        full: 'The bits of x(kG) are fair coins for 256-bit keys: Σz² ~ χ²(256)',
      },
    },
  },
  tests: {
    intro: `The hypothesis tests of the page, at significance level α = ${EN.num(SIGNIFICANCE, 2)}. Unlike the previous homework, here some rejections are expected and wanted: the Caesar ciphertext is not uniform and depends on the plaintext, which is exactly what makes it breakable.`,
    cols: { subject: 'Subject', hypothesis: 'Null hypothesis H₀', p: 'p-value', verdict: 'Outcome', expected: 'Reading' },
    keysIntro: (s) => `The public keys: ${EN.int(s.keys.small.N)} keys K = kG with k uniform between 1 and 2^32 - 1, and as many with k uniform between 1 and n - 1. If the restriction left a trace in the coordinates, the first test would see it.`,
    after: (sum) => [
      `${sum.rejected} of ${sum.count} tests reject the null hypothesis, ${sum.asExpected === sum.count ? 'all as expected' : `${sum.asExpected} of ${sum.count} as expected`}. The rejections of the Caesar cipher are its weakness (section 2.3); that of the corpus measures a real but small difference between chapters (section 3.1). The tests on the curve scheme and on the public keys reject nothing, and yet the scheme breaks in less than a second: statistical tests measure the absence of gross defects in the outputs, not how hard it is to invert the function.`,
    ],
  },
  history: {
    intro: 'From the Caesar cipher to elliptic-curve ElGamal, the ideas of this page in chronological order, with the two real vulnerabilities that reproduce the toy scheme.',
    legend: { task: 'used in this page', context: 'context' },
    events: [
      { year: '1st century BC', task: true, title: 'The Caesar cipher', text: 'Suetonius (Lives of the Caesars, about AD 121) tells that Caesar wrote his confidential letters by replacing every letter with the one three places further on, and that Augustus used the next one. The message of this page is his description.' },
      { year: '9th century', task: true, title: 'al-Kindi and frequency analysis', text: 'In his treatise on deciphering cryptographic messages, al-Kindi describes the method of section 3: count the letters of the ciphertext and compare them with those of a long text in the same language. It is the oldest known description of statistical cryptanalysis; the manuscript, kept in Istanbul, was published in 1987.' },
      { year: '1467', task: false, title: 'Alberti', text: 'Leon Battista Alberti describes the cipher disk and polyalphabetic substitution: changing alphabet during the message, so that the frequencies do not survive.' },
      { year: '1553-1586', task: false, title: 'Bellaso and Vigenère', text: 'The cipher named after Vigenère, first described by Giovan Battista Bellaso: a Caesar cipher with a different shift for every letter, given by a keyword. It held out for three centuries.' },
      { year: '1863', task: false, title: 'Kasiski', text: 'Friedrich Kasiski publishes how to find the key length of Vigenère: the ciphertext then splits into many Caesar ciphers, and each falls to frequencies.' },
      { year: '1900', task: false, title: 'Pearson', text: 'Karl Pearson introduces the χ² test, the criterion of one of the methods of section 3.4 and of many tests of this page.' },
      { year: '1920-1922', task: false, title: 'Friedman', text: 'William Friedman defines the index of coincidence (written in 1920, published in 1922): statistics enters cryptanalysis as a measurement, no longer as intuition.' },
      { year: '1949-1951', task: true, title: 'Shannon', text: 'The mathematical theory of secrecy: perfect ciphers, entropy and unicity distance (1949), then the estimate of the entropy of English (1951). They are the quantities of section 3.1.' },
      { year: '1971', task: true, title: 'Baby-step giant-step', text: 'Daniel Shanks, studying class numbers of quadratic fields, finds the first √n algorithm for the discrete logarithm.' },
      { year: '1976', task: false, title: 'Diffie and Hellman', text: 'Public-key cryptography is born, with the key exchange that bears their name: S = rK = kC1 is a Diffie-Hellman exchange on a curve.' },
      { year: '1978', task: true, title: 'Pollard', text: 'John Pollard publishes the rho and kangaroo (lambda) methods for the discrete logarithm: √n operations, with no tables.' },
      { year: '1984-1985', task: true, title: 'Probabilistic encryption and ElGamal', text: 'Goldwasser and Micali define semantic security and probabilistic encryption (1984); Taher ElGamal publishes the encryption and signature scheme based on the discrete logarithm (1985).' },
      { year: '1985-1987', task: true, title: 'Elliptic curves', text: 'Miller (1985) and Koblitz (1987) propose elliptic curves for cryptography; Koblitz also describes the elliptic-curve analogue of ElGamal and how to represent a message with a point.' },
      { year: '1997-1999', task: false, title: 'The limits of generic attacks', text: 'Shoup proves that a generic algorithm needs Ω(√n) operations (1997); van Oorschot and Wiener parallelize rho and the kangaroo with distinguished points (1999).' },
      { year: '2000-2001', task: false, title: 'secp256k1 and ECIES', text: 'SEC 2 publishes the parameters of secp256k1 (2000); Abdalla, Bellare and Rogaway analyse DHIES (2001), the authenticated hybrid scheme ECIES comes from, the right way to encrypt with a curve key.' },
      { year: '2022', task: true, title: 'Profanity', text: 'A generator of "vanity" Ethereum addresses derives the private keys from a 32-bit seed. In mid-September 1inch discloses the weakness; a few days later Wintermute loses about 160 million dollars. The key space of the toy scheme, in the real world.' },
      { year: '2023', task: true, title: 'Milk Sad', text: 'The bx seed command of Libbitcoin Explorer 3.x generates wallet sentences with a Mersenne Twister seeded with 32 bits of the system clock: funds are stolen in June and July (CVE-2023-39910).' },
    ],
    after: 'Read in order, history repeats the same lesson twice. Classical ciphers fell to statistics, and every attempt to save them (more alphabets, longer keys) only pushed the number of letters needed further away, until Shannon gave the exact measure of the problem. Modern cryptography solved that problem, with ciphertexts that cannot be told from random, and moved security onto the hardness of a computation: but a hard computation over a small key space is easy, as the owners of keys generated from 32 bits found out in 2022 and 2023.',
  },
  conclusion: (s) => [
    `The same message, encrypted with the two schemes, shows two opposite ways of failing. The Caesar cipher falls because it preserves the statistics of the text: with the frequencies of English and maximum likelihood ${s ? `20 letters are enough to recover the key in ${EN.pct(rateAt(s, 'unigram', 20), 0)} of the cases, and with quadgrams 10 letters for ${EN.pct(rateAt(s, 'quadgram', 10), 0)}` : 'a few dozen letters are enough to recover the key almost always'}. The curve scheme has a statistically flawless ciphertext, and falls all the same, in less than a second, because the private key has 32 bits: the attack does not look at the message, it solves a discrete logarithm in a small interval.`,
    'The two lessons complete each other. A large key space is necessary but not sufficient: the monoalphabetic substitution has 2^88 keys and breaks with frequencies. A ciphertext indistinguishable from random is necessary but not sufficient: the toy scheme has one and breaks with 2^17 operations. Elliptic-curve ElGamal with a 256-bit key has both properties, and the best known attack takes about 2^128 operations.',
    'What remains is what no key length fixes: reused or predictable nonces, malleable ciphertexts, unvalidated points. They are design and implementation errors, and in the real world they do more damage than the algorithms: the keys stolen through Profanity and Milk Sad lived on a secure curve, but had been badly generated.',
  ],
  methodNames: methodNamesEn,
  attackNames: { exhaustive: 'Exhaustive search', bsgs: 'Baby-step giant-step', kangaroo: 'Kangaroo' },
  // the legends of the bar charts: every item can be pressed to hide its part
  legends: {
    letters: ['letter counts', 'expected from the frequencies of the corpus'],
    cipher: ['letter counts of the ciphertext', 'expected from the frequencies of the corpus'],
    bytes: ['byte counts', 'uniform expectation'],
    corpus: ['training chapters', 'test chapters'],
    posterior: ['posterior probability', 'most probable shift'],
  },
  tips: {
    // a value hidden from the legend (null) is left out of the label
    letter: (letter, count, expected) => `${letter}: ${count} ${count === 1 ? 'time' : 'times'}${expected === null ? '' : `, ${EN.num(expected, 1)} expected`}`,
    byte: (b, count, expected) => `Byte ${b}: ${EN.int(count)} times${expected === null ? '' : `, ${EN.num(expected, 1)} expected`}`,
    bytes: (from, to, min, max, expected) => `Bytes ${from} to ${to}: ${EN.int(min)} to ${EN.int(max)} times${expected === null ? '' : `, ${EN.num(expected, 1)} expected each`}`,
    frequency: (letter, training, test) => `${letter}: ${EN.pct(training, 2)} in training${test === null ? '' : `, ${EN.pct(test, 2)} in test`}`,
    shift: (s, p, text) => `s = ${s}: probability ${EN.prob(p)}; "${text.slice(0, 32)}${text.length > 32 ? '...' : ''}"`,
    success: (L, n, rate, interval, bound) => {
      const parts = [rate !== null && `success ${EN.pct(rate)} (95%: ${EN.pct(interval[0])}-${EN.pct(interval[1])})`, bound !== null && `Chernoff bound ${EN.pct(bound)}`].filter(Boolean);
      return parts.length ? `${L} ${L === 1 ? 'letter' : 'letters'}, ${n} passages: ${parts.join('; ')}` : null;
    },
    methods: (L, rates) => {
      const parts = rates.map((r, i) => r !== null && `${Object.values(methodNamesEn)[i]} ${EN.pct(r)}`).filter(Boolean);
      return parts.length ? `${L} ${L === 1 ? 'letter' : 'letters'}: ${parts.join(', ')}` : null;
    },
    scaling: (bits, means) => (means.some((m) => m !== null) ? `${bits} bits: ${means.map((m, i) => (m === null ? null : `${['exhaustive search', 'BSGS', 'kangaroo'][i]} ${EN.int(m)}`)).filter(Boolean).join(', ')} operations on average` : null),
  },
  download: {
    title: 'Download the code',
    text: 'The complete program in HTML, CSS and JavaScript, with no dependencies, in Italian and English: once the archive is extracted, it opens with a double click on index.html, even offline. With node homework2a.js it prints the scheme, the Caesar cipher, the attacks and the statistics in a terminal; --key, --message, --shift and --random-nonces change the input.',
    contents: 'Contents: index.html, style.css, homework2a.js (schemes, attacks, corpus and statistics), app.js (interface and texts), README.txt.',
    zip: 'Download homework2',
    online: 'Open the program online',
  },
  standalone: {
    subtitle: 'A toy elliptic-curve scheme and the Caesar cipher: encryption, statistical cryptanalysis and attacks.',
    course: 'Statistics, MSc in Cybersecurity, Sapienza University of Rome',
    online: 'Online version',
    noscript: 'This program needs JavaScript.',
  },
};

const HW2A_TEXTS = { it, en };

return { originalAssignment, HW2A_TEXTS };
})();

(function () {
'use strict';

// src/pages/statistics/hw2a/standalone/app.js
// L'interfaccia del programma scaricabile, in JavaScript puro: niente React,
// niente dipendenze. Disegna le stesse sezioni della pagina del sito con gli
// stessi testi (texts.js), la stessa logica di presentazione (view.js) e gli
// stessi calcoli (homework2a.js). La build (build/homework-standalone.js) lo
// unisce a view.js e texts.js in un unico app.js, uno script classico che si
// apre anche da file:// con un doppio clic su index.html.
//
// Da file:// i worker non partono: i calcoli lunghi (esplorazione, costo
// degli attacchi, attacchi sulla chiave) girano qui, a fette di pochi
// millisecondi, e la pagina resta reattiva mentre i numeri arrivano.
//
// Ogni testo entra nella pagina con textContent, mai come HTML: nemmeno
// quello che si scrive nei campi puo' diventare markup.
const hw = Homework2a;
const view = view$;
const { HW2A_TEXTS, originalAssignment } = texts$;
const kit = kitDom$;

const HEADINGS = ['h2', 'h3', 'h4'];
const LANGUAGES = ['it', 'en'];

const PALETTES = {
  light: hw.DEFAULT_PALETTE,
  dark: {
    background: '#161616',
    text: '#d6d6d6',
    grid: '#262626',
    bars: '#7986cb',
    reference: '#ff6b81',
    highlight: '#ff6b81',
    series: ['#7986cb', '#ff6b81', '#4fb39c', '#ffca28', '#ba68c8', '#4dd0e1', '#9e9e9e'],
  },
};
const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');
const palette = () => (darkQuery.matches ? PALETTES.dark : PALETTES.light);

// I campi non devono passare per correttori o completamenti.
const PRIVATE_FIELD = {
  autocomplete: 'off',
  autocorrect: 'off',
  autocapitalize: 'none',
  spellcheck: 'false',
  'data-gramm': 'false',
  'data-lpignore': 'true',
};

// ---------------------------------------------------------------------------
// Stato e preferenze
// ---------------------------------------------------------------------------

// Si apre sempre in inglese, come la pagina sul sito; IT / EN cambia lingua
// finche' la pagina resta aperta, senza salvare la scelta. Il sito, aprendo
// la versione online, passa nell'indirizzo la lingua che si stava leggendo.
function initialLanguage() {
  const fromUrl = new URLSearchParams(window.location.search).get('lang');
  return LANGUAGES.includes(fromUrl) ? fromUrl : 'en';
}

const state = {
  lang: initialLanguage(),
  fields: { ...view.DEFAULT_INPUTS },
  applied: { key: hw.DEFAULT_KEY, message: hw.DEFAULT_MESSAGE, shift: hw.DEFAULT_SHIFT },
  nonces: 'seeded',
  // round cambia a ogni scelta sui nonce e ricrea lo schema; draw conta le
  // estrazioni casuali, compresa quella che fa da sola una chiave nuova
  round: 0,
  draw: 0,
};
let text = HW2A_TEXTS[state.lang];
const regions = {};
const controls = {};
// null while computing, then { value } or { error }
const computed = { verify: null, stats: null, scaling: null };
const attacks = { key: null, token: null, exhaustive: null, bsgs: null, kangaroo: null };

// Lo schema si ricrea solo se cambiano chiave o nonce; il cifrato solo se
// cambia anche il messaggio; il modello della lingua una volta sola.
const cache = { schemeId: null, scheme: null, message: null, encryption: null, decryption: null, augustus: null, reuseId: null, reuse: null, models: null };

function current() {
  const a = state.applied;
  const schemeId = `${a.key}|${state.nonces}|${state.round}`;
  if (cache.schemeId !== schemeId) {
    cache.schemeId = schemeId;
    cache.scheme = hw.toyScheme(a.key, { nonces: state.nonces });
    cache.message = null;
  }
  if (cache.message !== a.message) {
    cache.message = a.message;
    cache.encryption = cache.scheme.encrypt(a.message);
    cache.decryption = cache.scheme.decrypt(cache.encryption.blocks);
    cache.augustus = view.augustusDemo(cache.scheme, cache.encryption.blocks);
  }
  const reuseId = `${a.key}|${a.message}`;
  if (cache.reuseId !== reuseId) {
    cache.reuseId = reuseId;
    cache.reuse = view.reuseDemo(a.key, a.message);
  }
  return {
    scheme: cache.scheme,
    encryption: cache.encryption,
    decryption: cache.decryption,
    augustus: cache.augustus,
    reuse: cache.reuse,
    publicKey: hw.pointHex(cache.scheme.K),
    caesar: view.caesarFacts(a.message, a.shift),
  };
}

function languageModels() {
  const s = computed.stats && computed.stats.value;
  if (!s) return null;
  if (!cache.models) cache.models = hw.languageModels(s.models.betas);
  return cache.models;
}

// ---------------------------------------------------------------------------
// DOM: un aiutante minimo, i grafici e il loro ridisegno
// ---------------------------------------------------------------------------

/** h('p', { class: 'note', text: '...' }, child, ...): text always via textContent. */
function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') el.className = value;
    else if (key === 'text') el.textContent = value;
    else if (key === 'style') Object.assign(el.style, value);
    else if (key.startsWith('on')) el.addEventListener(key.slice(2), value);
    else el.setAttribute(key, value === true ? '' : String(value));
  }
  for (const child of children.flat(Infinity)) {
    if (child === null || child === undefined || child === false) continue;
    el.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return el;
}

const paras = (list) => list.filter(Boolean).map((t) => h('p', { text: t }));
const title = (id, level, label) => h(HEADINGS[level], { id, tabindex: -1, class: 'anchor', text: label });
const subtitle = (label) => h('p', { class: 'table-title' }, h('strong', { text: label }));
const pending = (result = null) => (result && result.error ? h('p', { class: 'note', text: text.ui.error(result.error) }) : h('p', { class: 'note pending', role: 'status', text: text.ui.computing }));
// La nota "valori dell'ultimo input valido" c'e' sempre, nascosta: la mostra
// il CSS quando la sezione ha la classe is-stale.
const staleNote = (label) => h('p', { class: 'stale stale-note', text: label });
const check = (ok, label) => h('p', { class: ok ? 'check is-ok' : 'check is-bad', text: label });
const formulas = (content, label = null) => [label && subtitle(label), h('pre', { text: content })];

/** A labelled value: the label above, the (long) value below. */
const value = (label, content, extra = '') => h('div', { class: `value ${extra}`.trim() }, h('span', { class: 'value-label', text: label }), h('code', null, content));

// what the reader hid in the legends, by chart: a region filled anew (a step, a result) keeps it
const kept = {};
const keep = (name) => {
  if (!kept[name]) kept[name] = new Set();
  return kept[name];
};

/** The parts of the drawing covered by the hidden items of a legend. */
const partsOf = (items, hidden) => items.flatMap((item, i) => (hidden.has(i) ? item.parts || [] : []));

/** Hides the cells and rows of a table that belong to hidden parts (data-part), and shows the others. */
function hideParts(tableEl, parts) {
  for (const el of tableEl.querySelectorAll('[data-part]')) el.hidden = parts.includes(el.dataset.part);
}

/**
 * A chart (chartkit/kitDom.js): drawn by homework2a.js, with its legend
 * (`items`), its label under the pointer, the table tied to it (`link`)
 * and zoom (bars by whole groups). onHide(parts) runs when the reader hides
 * or shows a part, for the table tied to the chart, and `keep` (a set,
 * keep(name)) remembers the hidden items when the chart is built again.
 * `reveal` (milliseconds a point) draws a line chart point by point, as
 * the length or the key grows.
 */
function figure(caption, draw, data, { wide = false, tip = null, items = null, note = null, link = null, onHide = null, keep: kept = null, reveal = 0 } = {}) {
  return kit.createFigure({ label: caption, draw, data, palette: palette(), lib: hw, schedule: view.scheduleFrameJob, lang: state.lang, tip, items, note, link, onHide, keep: kept, wide, animation: reveal ? view.reveal(data, reveal) : null });
}

/** Replaces the content of a region, releasing the charts it contained and their labels. */
function fill(region, ...nodes) {
  kit.releaseFigures(region);
  region.replaceChildren(...nodes.flat(Infinity).filter((n) => n !== null && n !== undefined && n !== false));
}

/** A table: column headers, then rows of cells, each { text | node, class?, head? } (head: a row header, th); `id` for a table tied to a chart (view.LINKED_TABLES); `columns` gives the part of a chart each column belongs to, and a row can have its own `part`: hideParts() hides them with their curve. */
function table(className, headers, rows, id = null, columns = []) {
  return h(
    'table',
    { id, class: `table ${className}` },
    h('thead', null, h('tr', null, headers.map((x, i) => h('th', { text: x, 'data-part': columns[i] || null })))),
    h(
      'tbody',
      null,
      rows.map((row) => h(
        'tr',
        { class: row.class || null, 'data-part': row.part || null },
        row.cells.map((cell, i) => h(cell.head ? 'th' : 'td', { 'data-label': cell.head ? null : headers[i], class: cell.class || null, 'data-part': columns[i] || null }, cell.node || cell.text)),
      )),
    ),
  );
}

/** The hypothesis tests of one subject, with what each should say. */
function tests(group, s, only = null) {
  return h(
    'div',
    { class: 'tests' },
    view.statTests(s)[group].filter(([key]) => !only || only.includes(key)).map(([key, t]) => {
      const rejected = t.verdict === 'reject';
      const expected = view.EXPECTED_VERDICTS[group][key];
      return h(
        'div',
        { class: `test ${rejected ? 'is-invalid' : 'is-valid'}` },
        h(
          'p',
          { class: 'test-head' },
          h('strong', { text: text.stats.labels[group][key] }),
          ' ',
          h('span', { class: `badge ${rejected ? 'is-invalid' : 'is-valid'}`, text: text.stats.verdict[rejected ? 'reject' : 'notReject'] }),
          h('span', { class: 'note', text: ` (${text.stats.expected[expected]})` }),
        ),
        h('p', { text: text.stats.testLine(t) }),
      );
    }),
  );
}

// ---------------------------------------------------------------------------
// 0. La consegna
// ---------------------------------------------------------------------------

function assignmentSection() {
  const blocks = originalAssignment().map((block) => (block.type === 'title' ? h('p', null, h('strong', { text: block.text })) : h('p', { text: block.text })));
  return h(
    'section',
    { class: 'section' },
    title('hw2a-assignment', 0, text.sections.assignment),
    paras(text.assignment.intro),
    h(
      'details',
      { class: 'original', open: true },
      h('summary', { text: text.assignment.originalTitle }),
      h('p', { class: 'note', text: text.assignment.originalNote }),
      h('blockquote', { lang: 'en' }, blocks),
    ),
  );
}

// ---------------------------------------------------------------------------
// 1. Lo schema giocattolo
// ---------------------------------------------------------------------------

function schemeSection() {
  const S = text.sections;
  for (const name of ['keyHelp', 'messageHelp', 'nonces', 'cipherNow', 'stale', 'badge', 'keys', 'encrypt', 'decrypt', 'verify']) regions[name] = h('div');
  regions.scheme = h(
    'section',
    { class: 'section' },
    title('hw2a-scheme', 0, S.scheme),
    paras(text.scheme.intro),
    formulas(text.scheme.formulas, text.scheme.formulasTitle),

    title('hw2a-input', 1, S.input),
    inputBlock(),

    title('hw2a-keys', 1, S.keys),
    paras(text.keys.intro),
    regions.keys,
    paras(text.keys.after),

    title('hw2a-encrypt', 1, S.encrypt),
    paras(text.encrypt.intro),
    regions.encrypt,
    paras(text.encrypt.after),

    title('hw2a-decrypt', 1, S.decrypt),
    paras(text.decrypt.intro),
    regions.decrypt,

    title('hw2a-roles', 1, S.roles),
    h('p', { text: text.roles.intro }),
    table(
      'discussion key-roles',
      [text.roles.cols.value, text.roles.cols.who, text.roles.cols.purpose, text.roles.cols.leak],
      text.roles.rows.map((r) => ({ cells: [{ head: true, text: r.value }, { text: r.who }, { text: r.purpose }, { text: r.leak }] })),
    ),
    h('p', { text: text.roles.after }),

    title('hw2a-verify', 1, S.verify),
    h('p', { text: text.verify.intro }),
    regions.verify,
  );
  return regions.scheme;
}

// --- 1.1 I campi ----------------------------------------------------------------

function inputBlock() {
  const I = text.input;
  const f = state.fields;
  controls.key = h('input', {
    type: 'text',
    inputmode: 'numeric',
    class: 'key',
    ...PRIVATE_FIELD,
    maxlength: view.KEY_MAX_LENGTH,
    'aria-describedby': 'key-help',
    oninput: (e) => changeFields({ keyText: e.target.value.slice(0, view.KEY_MAX_LENGTH) }),
  });
  controls.key.value = f.keyText;
  controls.message = h('textarea', {
    rows: 3,
    ...PRIVATE_FIELD,
    maxlength: view.MESSAGE_MAX_LENGTH,
    'aria-describedby': 'message-help',
    oninput: (e) => changeFields({ message: e.target.value.slice(0, view.MESSAGE_MAX_LENGTH) }),
  });
  controls.message.value = f.message;
  return [
    h('p', { text: I.intro }),
    h(
      'div',
      { class: 'fields' },
      h(
        'div',
        { class: 'controls' },
        h('label', null, h('span', { text: I.keyLabel }), controls.key),
        h('span', { class: 'buttons' }, h('button', { type: 'button', class: 'btn alt', text: I.randomKey, onclick: () => changeFields({ keyText: hw.randomPrivateKey().toString() }, true) })),
      ),
      regions.keyHelp,
      h('label', { class: 'mnemonic' }, h('span', { text: I.messageLabel }), controls.message),
      regions.messageHelp,
      regions.nonces,
      regions.cipherNow,
      h('p', { class: 'note', text: I.noncesHint }),
    ),
    regions.stale,
    regions.badge,
  ];
}

/** Puts the values of the state into the fields, after a button changed them. */
function syncFields() {
  const f = state.fields;
  if (controls.key.value !== f.keyText) controls.key.value = f.keyText;
  if (controls.message.value !== f.message) controls.message.value = f.message;
  if (controls.shift && controls.shift.value !== f.shiftText) controls.shift.value = f.shiftText;
}

function changeFields(patch, fromButton = false) {
  state.fields = { ...state.fields, ...patch };
  if (fromButton) syncFields();
  const read = view.readInputs(state.fields);
  const prev = state.applied;
  const next = {
    key: read.key.ok ? read.key.value : prev.key,
    message: read.message.ok ? read.message.value : prev.message,
    shift: read.shift.ok ? read.shift.value : prev.shift,
  };
  state.applied = next;
  if (next.key !== prev.key && state.nonces === 'random') state.draw++;
  updateInputs(read);
  if (next.key !== prev.key || next.message !== prev.message) updateScheme();
  else if (next.shift !== prev.shift) updateCaesar();
}

function chooseNonces(mode, reroll = false) {
  if (mode === state.nonces && !reroll) return;
  state.nonces = mode;
  state.round++;
  if (mode === 'random') state.draw++;
  updateInputs(view.readInputs(state.fields));
  updateScheme();
}

function restore() {
  state.fields = { ...view.DEFAULT_INPUTS };
  syncFields();
  state.applied = { key: hw.DEFAULT_KEY, message: hw.DEFAULT_MESSAGE, shift: hw.DEFAULT_SHIFT };
  if (state.nonces !== 'seeded') {
    state.nonces = 'seeded';
    state.round++;
  }
  updateInputs(view.readInputs(state.fields));
  updateScheme();
}

function updateInputs(read) {
  const I = text.input;
  const C = text.caesarCipher;
  let keyError = null;
  if (!read.key.ok) keyError = read.key.error === 'notInteger' ? I.keyError.notInteger(read.key.text) : I.keyError[read.key.error];
  let messageError = null;
  if (!read.message.ok) messageError = read.message.error === 'tooLong' ? I.messageError.tooLong(read.message.bytes) : I.messageError.empty;
  let shiftError = null;
  if (!read.shift.ok) shiftError = read.shift.error === 'notInteger' ? C.shiftError.notInteger(read.shift.text) : C.shiftError[read.shift.error];
  fill(regions.keyHelp, h('p', { id: 'key-help', class: keyError ? 'field-error' : 'note', role: keyError ? 'alert' : null, text: keyError || I.keyHint }));
  fill(regions.messageHelp, h('p', { id: 'message-help', class: messageError ? 'field-error' : 'note', role: messageError ? 'alert' : null, text: messageError || I.messageHint(read.message.bytes) }));
  if (regions.shiftHelp) fill(regions.shiftHelp, h('p', { id: 'shift-help', class: shiftError ? 'field-error' : 'note', role: shiftError ? 'alert' : null, text: shiftError || C.shiftHint }));
  controls.key.setAttribute('aria-invalid', String(!read.key.ok));
  controls.message.setAttribute('aria-invalid', String(!read.message.ok));
  if (controls.shift) controls.shift.setAttribute('aria-invalid', String(!read.shift.ok));
  fill(
    regions.nonces,
    h(
      'div',
      { class: 'nonces', role: 'group', 'aria-label': I.noncesLabel },
      h('span', { class: 'nonces-label', text: I.noncesLabel }),
      ['seeded', 'random'].map((mode) => h('button', { type: 'button', class: 'btn alt', 'aria-pressed': String(state.nonces === mode), text: I.nonces[mode], onclick: () => chooseNonces(mode) })),
      state.nonces === 'random' && h('button', { type: 'button', class: 'btn alt', text: I.reroll, onclick: () => chooseNonces('random', true) }),
    ),
  );
  const schemeStale = !read.key.ok || !read.message.ok;
  const caesarStale = !read.shift.ok || !read.message.ok;
  regions.scheme.classList.toggle('is-stale', schemeStale);
  regions.attack.classList.toggle('is-stale', schemeStale);
  regions.caesar.classList.toggle('is-stale', caesarStale);
  regions.cryptanalysis.classList.toggle('is-stale', caesarStale);
  fill(regions.stale, (schemeStale || caesarStale) && h('p', { class: 'stale', role: 'status', text: I.stale }));
  const badge = view.inputBadge(state.fields, state.nonces, I);
  fill(
    regions.badge,
    h(
      'p',
      { class: badge.known ? 'badge-line is-task' : 'badge-line is-custom' },
      h('span', { text: badge.text }),
      badge.restore && h('button', { type: 'button', class: 'btn alt restore', text: I.restore, onclick: restore }),
    ),
  );
}

// --- 1.2 - 1.4 Chiavi, cifratura e decifratura ------------------------------------

function updateKeys(c) {
  const K = text.keys;
  const f = view.keyFacts(c.scheme);
  fill(
    regions.keys,
    staleNote(text.scheme.stale),
    value(K.kLabel, f.k),
    value(K.hexLabel, f.hex),
    value(K.binaryLabel(f.bits), f.binary),
    value(K.xLabel, f.x),
    value(K.yLabel, f.y),
    value(K.compressedLabel(f.even), f.compressed),
    check(f.onCurve, K.onCurve(f.onCurve)),
    f.isDefault && check(f.matchesReference, K.reference(f.matchesReference)),
  );
}

function updateEncryption(c) {
  const E = text.encrypt;
  fill(
    regions.encrypt,
    subtitle(E.tableTitle),
    staleNote(text.scheme.stale),
    h('div', { class: 'scroll' }, table('compact blocks', [E.cols.position, E.cols.byte, E.cols.r, E.cols.C1, E.cols.C2], view.blockRows(c.encryption.blocks).map((r) => ({ cells: [{ text: r.position }, { text: `${r.byte} ${r.char}` }, { text: r.r }, { text: r.C1 }, { text: r.C2 }] })))),
    h('p', { class: 'note', text: E.size(view.ciphertextSize(c.encryption.blocks)) }),
  );
}

// Il cifrato di adesso sotto i pulsanti dei nonce: la tabella e' in 1.3, piu'
// in basso. La riga si illumina solo a una scelta sui nonce (o a una chiave
// nuova con i nonce casuali), non a ogni lettera del messaggio.
let cipherNowId = '0:0';

function updateCipherNow(c) {
  const id = `${state.round}:${state.draw}`;
  const flash = id !== cipherNowId;
  cipherNowId = id;
  const summary = view.cipherSummary(c.encryption, c.decryption, state.nonces, state.draw);
  fill(regions.cipherNow, h('p', { class: 'cipher-now' }, h('span', { class: flash ? 'flash' : null, text: text.input.cipherNow(summary) })));
}

function updateDecryption(c) {
  const D = text.decrypt;
  const first = view.firstBlock(c.encryption.blocks, c.decryption);
  const ok = c.decryption.ok && c.decryption.text === c.encryption.text;
  fill(
    regions.decrypt,
    first && [
      subtitle(D.firstTitle),
      staleNote(text.scheme.stale),
      value(D.labels.C1, first.C1),
      value(D.labels.C2, first.C2),
      value(D.labels.S, first.S),
      check(first.sameS, D.sameS(first.sameS)),
      value(D.labels.M, first.M),
      check(first.decoded >= 0, D.decoded(first.decoded, first.char)),
    ],
    value(D.resultLabel, c.decryption.text ?? ''),
    check(ok, D.check(ok)),
  );
}

function updateVerify() {
  const V = text.verify;
  const result = computed.verify;
  if (!result || !result.value) {
    fill(regions.verify, pending(result));
    return;
  }
  const rows = result.value;
  const ok = rows.filter((r) => r.ok).length;
  fill(
    regions.verify,
    h('p', { class: ok === rows.length ? 'check is-ok' : 'check is-bad' }, h('strong', { text: V.summary(ok, rows.length) })),
    h(
      'details',
      { class: 'details' },
      h('summary', { text: V.details(rows.length) }),
      view.checkGroups(rows).map((g) => [
        subtitle(V.groups[g.group]),
        table('discussion vectors', [V.cols.check, V.cols.expected, V.cols.result], g.rows.map((r) => ({
          cells: [{ head: true, text: r.name }, { node: h('code', { text: r.expected }) }, { class: r.ok ? 'is-ok' : 'is-bad', node: h('span', { 'aria-label': r.ok ? V.ok : V.failed, text: r.ok ? '✓' : '✗' }) }],
        }))),
      ]),
    ),
  );
}

// ---------------------------------------------------------------------------
// 2. Il cifrario di Cesare
// ---------------------------------------------------------------------------

function caesarSection() {
  const S = text.sections;
  const C = text.caesarCipher;
  for (const name of ['shiftHelp', 'caesarLive', 'compare', 'propertiesLive', 'propertiesStats']) regions[name] = h('div');
  controls.shift = h('input', {
    type: 'text',
    inputmode: 'numeric',
    class: 'shift',
    ...PRIVATE_FIELD,
    maxlength: view.SHIFT_MAX_LENGTH,
    'aria-describedby': 'shift-help',
    oninput: (e) => changeFields({ shiftText: e.target.value.slice(0, view.SHIFT_MAX_LENGTH) }),
  });
  controls.shift.value = state.fields.shiftText;
  regions.caesar = h(
    'section',
    { class: 'section' },
    title('hw2a-caesar', 0, S.caesar),
    paras(text.caesar.intro),
    title('hw2a-caesar-cipher', 1, S.caesarCipher),
    paras(C.intro),
    h('div', { class: 'controls' }, h('label', null, h('span', { text: C.shiftLabel }), controls.shift)),
    regions.shiftHelp,
    regions.caesarLive,
    title('hw2a-compare', 1, S.compare),
    regions.compare,
    title('hw2a-properties', 1, S.properties),
    paras(text.properties.intro),
    regions.propertiesLive,
    regions.propertiesStats,
  );
  return regions.caesar;
}

function updateCaesar() {
  const c = current();
  const C = text.caesarCipher;
  const P = text.properties;
  const shift = state.applied.shift;
  const table26 = view.substitution(shift);
  fill(
    regions.caesarLive,
    subtitle(C.tableTitle),
    h(
      'div',
      { class: 'subst', role: 'table', 'aria-label': C.tableTitle },
      h('div', { class: 'subst-row', role: 'row' }, h('span', { class: 'subst-head', role: 'rowheader', text: C.plainRow }), table26.plain.map((l) => h('span', { role: 'cell', text: l }))),
      h('div', { class: 'subst-row is-cipher', role: 'row' }, h('span', { class: 'subst-head', role: 'rowheader', text: C.cipherRow }), table26.cipher.map((l) => h('span', { role: 'cell', text: l }))),
    ),
    staleNote(C.stale),
    value(C.cipherLabel, c.caesar.cipher),
    value(C.decryptedLabel, c.caesar.decrypted),
    check(c.caesar.ok, C.check(c.caesar.ok)),
    h('p', { text: C.top(c.caesar) }),
  );
  const F = text.fmt;
  const letters = view.letterChart(state.applied.message, F.decimal);
  const cipherLetters = view.letterChart(c.caesar.cipher, F.decimal);
  fill(
    regions.propertiesLive,
    h(
      'div',
      { class: 'charts' },
      figure(P.lettersChart, hw.drawBarChart, letters, { tip: view.tips.letters(letters, text.tips), items: view.legends.letters(text), keep: keep('letters') }),
      figure(P.cipherChart(shift), hw.drawBarChart, cipherLetters, { tip: view.tips.letters(cipherLetters, text.tips), items: view.legends.cipher(text), keep: keep('cipher') }),
    ),
  );
  updateAlgorithm();
}

function updateCompare() {
  const C = text.compare;
  const c = current();
  const rows = C.rows(view.ciphertextSize(c.encryption.blocks));
  fill(
    regions.compare,
    h('p', { text: C.intro }),
    table('discussion compare', C.cols, rows.map((row) => ({ cells: [{ head: true, text: row[0] }, ...row.slice(1).map((cell) => ({ text: cell }))] }))),
    paras(C.after),
  );
}

function updateProperties() {
  const P = text.properties;
  const F = text.fmt;
  const s = computed.stats && computed.stats.value;
  if (!s) {
    fill(regions.propertiesStats, pending(computed.stats));
    return;
  }
  const bytes = view.ecBytesChart(s, F.decimal);
  fill(
    regions.propertiesStats,
    h('p', { text: P.sampleIntro(s) }),
    figure(P.bytesChart(s), hw.drawBarChart, bytes, { wide: true, tip: view.tips.ecBytes(bytes, text.tips), items: view.legends.bytes(text), keep: keep('bytes') }),
    subtitle(P.tableTitle),
    table('discussion ciphers', [P.cols.text, P.cols.symbols, P.cols.entropy, P.cols.ic], view.cipherRows(s).map((r) => ({
      cells: [{ head: true, text: P.rowNames[r.key] }, { text: F.int(r.symbols) }, { text: P.entropyCell(r.entropy, r.max) }, { text: P.icCell(r.ic, r.uniformIc) }],
    }))),
    h('p', { text: P.repeated(s) }),
    tests('caesar', s),
    tests('ec', s),
    paras(P.explain(s)),
  );
}

// ---------------------------------------------------------------------------
// 3. Crittanalisi statistica
// ---------------------------------------------------------------------------

function cryptanalysisSection() {
  const S = text.sections;
  for (const name of ['corpus', 'algorithmLive', 'lengths', 'methods']) regions[name] = h('div');
  regions.cryptanalysis = h(
    'section',
    { class: 'section' },
    title('hw2a-cryptanalysis', 0, S.cryptanalysis),
    paras(text.cryptanalysis.intro),
    title('hw2a-corpus', 1, S.corpus),
    paras(text.corpus.intro),
    regions.corpus,
    title('hw2a-algorithm', 1, S.algorithm),
    paras(text.algorithm.intro),
    formulas(text.algorithm.formula),
    subtitle(text.algorithm.liveTitle),
    regions.algorithmLive,
    paras(text.algorithm.after),
    title('hw2a-lengths', 1, S.lengths),
    regions.lengths,
    title('hw2a-methods', 1, S.methods),
    paras(text.methods.intro),
    h('ul', { class: 'roles' }, text.methods.list.map((item) => h('li', null, h('strong', { text: text.methodNames[item.method] }), `: ${item.text}`))),
    regions.methods,
    title('hw2a-limits', 1, S.limits),
    paras(text.limits.paras),
  );
  return regions.cryptanalysis;
}

function updateCorpus() {
  const C = text.corpus;
  const F = text.fmt;
  const s = computed.stats && computed.stats.value;
  if (!s) {
    fill(regions.corpus, pending(computed.stats));
    return;
  }
  const chart = view.corpusChart(s, F.decimal);
  fill(
    regions.corpus,
    subtitle(C.chaptersTitle),
    table('discussion chapters', [C.cols.number, C.cols.title, C.cols.letters, C.cols.role], view.chapterRows(s).map((c) => ({
      class: `is-${c.role}`,
      cells: [{ head: true, text: c.number }, { text: c.title }, { text: F.int(c.letters) }, { text: C.roles[c.role] }],
    }))),
    figure(C.chart(s), hw.drawBarChart, chart, { wide: true, tip: view.tips.corpus(chart, text.tips), items: view.legends.corpus(text), keep: keep('corpus') }),
    paras(C.facts(s)),
    tests('corpus', s),
    paras(C.modelsIntro),
    formulas(C.formula),
    subtitle(C.modelsTitle),
    table('discussion models', ['order', 'beta', 'crossEntropy', 'redundancy', 'unicity'].map((k) => C.modelCols[k]), view.modelRows(s).map((r) => ({
      cells: [{ head: true, text: `${r.order} (${C.orderName(r.order)})` }, { text: F.num(r.beta, r.beta < 1 ? 1 : 0) }, { text: F.num(r.crossEntropy, 3) }, { text: F.num(r.redundancy, 3) }, { text: F.num(r.unicity, 1) }],
    }))),
    paras(C.after(s)),
  );
}

function updateAlgorithm() {
  const A = text.algorithm;
  const F = text.fmt;
  const models = languageModels();
  if (!models) {
    fill(regions.algorithmLive, computed.stats && computed.stats.error ? pending(computed.stats) : h('p', { class: 'note pending', role: 'status', text: A.pending }));
    return;
  }
  const c = current();
  const shift = state.applied.shift;
  const crack = hw.crackCaesar(c.caesar.cipher, models);
  const chart = view.posteriorChart(crack, F.decimal);
  const candidates = view.candidateRows(crack);
  fill(
    regions.algorithmLive,
    check(crack.key === shift, A.live(crack, shift)),
    figure(A.posteriorChart, hw.drawBarChart, chart, { wide: true, tip: view.tips.posterior(crack, text.tips), link: view.links.candidates(candidates), items: view.legends.posterior(text), keep: keep('posterior') }),
    subtitle(A.candidatesTitle),
    table('discussion candidates', [A.candidateCols.shift, A.candidateCols.perLetter, A.candidateCols.posterior, A.candidateCols.text], candidates.map((r) => ({
      class: r.shift === crack.key ? 'is-current' : null,
      cells: [{ head: true, text: r.shift }, { text: F.num(r.perLetter, 3) }, { text: F.prob(r.posterior) }, { node: h('code', { text: r.text.length > 60 ? `${r.text.slice(0, 60)}...` : r.text }) }],
    })), view.LINKED_TABLES.candidates),
    paras(A.fit(view.fitChecks(crack, models))),
  );
}

function updateLengths() {
  const L = text.lengths;
  const F = text.fmt;
  const s = computed.stats && computed.stats.value;
  if (!s) {
    fill(regions.lengths, pending(computed.stats));
    return;
  }
  const chart = view.successChart(s, F.decimal);
  // il tasso di successo (con il suo intervallo) e il limite di Chernoff sono anche colonne della tabella
  const lengths = table('compact lengths', [L.cols.length, L.cols.trials, L.cols.rate, L.cols.interval, L.cols.bound], view.lengthRows(s).map((r) => ({
    cells: [{ text: r.length }, { text: F.int(r.trials) }, { text: F.pct(r.rates.unigram) }, { text: `${F.pct(r.interval[0])} - ${F.pct(r.interval[1])}` }, { text: F.pct(r.bound) }],
  })), view.LINKED_TABLES.lengths, [null, null, 'series:0', 'series:0', 'series:1']);
  hideParts(lengths, partsOf(view.legends.success(text), keep('success')));
  fill(
    regions.lengths,
    paras(L.intro(s)),
    figure(L.chart, hw.drawLineChart, chart, { wide: true, reveal: 200, tip: view.tips.success(s, text.tips), link: view.links.lengths, items: view.legends.success(text), keep: keep('success'), onHide: (parts) => hideParts(lengths, parts) }),
    subtitle(L.tableTitle),
    h('div', { class: 'scroll' }, lengths),
    paras(L.explain(s)),
  );
}

function updateMethods() {
  const M = text.methods;
  const F = text.fmt;
  const s = computed.stats && computed.stats.value;
  if (!s) {
    fill(regions.methods, pending(computed.stats));
    return;
  }
  const chart = view.methodsChart(s, F.decimal);
  // ogni metodo e' una curva del grafico e una riga della tabella delle soglie
  const thresholds = table('discussion thresholds', [M.cols.method, ...M.cols.levels], view.thresholds(s).map((row) => ({
    part: `series:${hw.METHODS.indexOf(row.method)}`,
    cells: [{ head: true, text: text.methodNames[row.method] }, ...row.levels.map((v) => ({ text: v === null ? M.never : String(v) }))],
  })));
  hideParts(thresholds, partsOf(view.legends.methods(text), keep('methods')));
  fill(
    regions.methods,
    figure(M.chart, hw.drawLineChart, chart, { wide: true, reveal: 200, tip: view.tips.methods(s, text.tips), items: view.legends.methods(text), keep: keep('methods'), onHide: (parts) => hideParts(thresholds, parts) }),
    subtitle(M.tableTitle),
    thresholds,
    paras(M.explain(s)),
  );
}

// ---------------------------------------------------------------------------
// 4. L'attacco allo schema giocattolo
// ---------------------------------------------------------------------------

function attackSection() {
  const S = text.sections;
  for (const name of ['exhaustive', 'bsgs', 'kangaroo', 'scaling', 'weaknessesLive']) regions[name] = h('div');
  const D = text.differences;
  const W = text.weaknesses;
  regions.attack = h(
    'section',
    { class: 'section' },
    title('hw2a-attack', 0, S.attack),
    paras(text.attack.intro),
    title('hw2a-exhaustive', 1, S.exhaustive),
    paras(text.exhaustive.intro),
    regions.exhaustive,
    paras(text.exhaustive.after),
    title('hw2a-bsgs', 1, S.bsgs),
    paras(text.bsgs.intro),
    formulas(text.bsgs.formula),
    regions.bsgs,
    paras(text.bsgs.after),
    title('hw2a-kangaroo', 1, S.kangaroo),
    paras(text.kangaroo.intro),
    regions.kangaroo,
    paras(text.kangaroo.after),
    title('hw2a-scaling', 1, S.scaling),
    regions.scaling,
    title('hw2a-differences', 1, S.differences),
    h('p', { text: D.intro }),
    table('discussion differences', D.cols, D.rows.map((row) => ({ cells: [{ head: true, text: row[0] }, { text: row[1] }, { text: row[2] }] }))),
    paras(D.after),
    title('hw2a-real', 1, S.real),
    paras(text.real.paras),
    title('hw2a-weaknesses', 1, S.weaknesses),
    h('p', { text: W.intro }),
    table('discussion weaknesses', [W.cols.weakness, W.cols.origin, W.cols.attack, W.cols.fix], W.rows.map((row) => ({ cells: [{ head: true, text: row[0] }, { text: row[1] }, { text: row[2] }, { text: row[3] }] }))),
    regions.weaknessesLive,
    paras(W.after),
  );
  return regions.attack;
}

function updateAttacks() {
  const c = current();
  const ready = attacks.key === c.publicKey;
  const X = text.exhaustive;
  const B = text.bsgs;
  const ex = ready && attacks.exhaustive;
  if (ex && ex.value) {
    const r = view.exhaustiveSummary(ex.value, state.applied.key);
    fill(regions.exhaustive, r.found ? check(true, X.found(r)) : h('p', { text: X.notFound(r, state.applied.key) }));
  } else fill(regions.exhaustive, pending(ex || null));
  const bs = ready && attacks.bsgs;
  if (bs && bs.value) {
    const r = view.bsgsSummary(bs.value);
    const recovered = r.found ? hw.toyScheme(BigInt(r.key)).decrypt(c.encryption.blocks) : null;
    fill(regions.bsgs, check(r.found, B.result(r)), recovered && [value(B.decryptedLabel, recovered.text ?? ''), check(recovered.ok, B.check(recovered.ok))]);
  } else fill(regions.bsgs, pending(bs || null));
  const ka = ready && attacks.kangaroo;
  if (ka && ka.value) fill(regions.kangaroo, check(ka.value.found, text.kangaroo.result(ka.value)));
  else fill(regions.kangaroo, pending(ka || null));
}

function updateScaling() {
  const C = text.scaling;
  const F = text.fmt;
  const sc = computed.scaling && computed.scaling.value;
  if (!sc) {
    fill(regions.scaling, pending(computed.scaling));
    return;
  }
  const chart = view.scalingChart(sc, F.decimal);
  // ogni attacco: i suoi punti, la sua retta e la sua riga della tabella delle pendenze
  const fits = table('discussion fits', [C.fitCols.method, C.fitCols.slope, C.fitCols.theory, C.fitCols.constant], view.ATTACKS.map((m, i) => ({
    part: `series:${i}`,
    cells: [{ head: true, text: text.attackNames[m] }, { text: `${F.num(sc.fits[m].slope, 3)} ± ${F.num(sc.fits[m].slopeError, 3)}` }, { text: F.num(sc.fits[m].exponent, 1) }, { text: F.num(sc.fits[m].constant, 2) }],
  })));
  hideParts(fits, partsOf(view.legends.scaling(text), keep('scaling')));
  fill(
    regions.scaling,
    paras(C.intro(sc)),
    figure(C.chart, hw.drawLineChart, chart, { wide: true, reveal: 220, tip: view.tips.scaling(sc, text.tips), items: view.legends.scaling(text), keep: keep('scaling'), onHide: (parts) => hideParts(fits, parts) }),
    subtitle(C.fitsTitle),
    fits,
    subtitle(C.extrapolationTitle),
    table('discussion extrapolation', ['bits', 'exhaustive', 'best', 'here', 'fast', 'memory'].map((k) => C.extrapolationCols[k]), view.extrapolationRows(sc).map((r) => ({
      cells: [{ head: true, text: r.bits }, { text: F.pow2(r.log2.exhaustive) }, { text: F.pow2(r.best) }, { text: F.duration(r.here) }, { text: F.duration(r.fast) }, { text: C.memory(r.memory) }],
    }))),
    paras(C.explain(sc)),
  );
}

function updateWeaknesses() {
  const W = text.weaknesses;
  const c = current();
  const best = c.reuse.attack && c.reuse.attack.candidates.length ? c.reuse.attack.candidates[0] : null;
  fill(
    regions.weaknessesLive,
    subtitle(W.reuseTitle),
    staleNote(text.scheme.stale),
    paras(W.reuse(c.reuse)),
    best && [value(W.reuseResult, best.text), check(best.text === state.applied.message, W.reuseCheck(best.text === state.applied.message))],
    subtitle(W.augustusTitle),
    h('p', { text: W.augustus }),
    c.augustus.ok ? value('', c.augustus.text ?? '') : h('p', { class: 'note', text: W.augustusFail }),
    h('p', { text: W.augustusAfter }),
  );
}

// ---------------------------------------------------------------------------
// 5, 6 e 7
// ---------------------------------------------------------------------------

function testsSection() {
  regions.tests = h('div');
  return h('section', { class: 'section' }, title('hw2a-tests', 0, text.sections.tests), h('p', { text: text.tests.intro }), regions.tests);
}

function updateTests() {
  const T = text.tests;
  const F = text.fmt;
  const s = computed.stats && computed.stats.value;
  if (!s) {
    fill(regions.tests, pending(computed.stats));
    return;
  }
  const summary = view.testSummary(s);
  fill(
    regions.tests,
    h('p', { text: T.keysIntro(s) }),
    tests('keys', s),
    table('discussion summary-tests', [T.cols.subject, T.cols.hypothesis, T.cols.p, T.cols.verdict, T.cols.expected], summary.all.map((t) => {
      const rejected = t.result.verdict === 'reject';
      return {
        class: rejected ? 'is-rejected' : null,
        cells: [{ head: true, text: text.stats.groups[t.group] }, { text: text.stats.labels[t.group][t.key] }, { text: F.pval(t.result.pValue) }, { text: text.stats.verdict[rejected ? 'reject' : 'notReject'] }, { text: text.stats.expected[t.expected] }],
      };
    })),
    paras(T.after(summary)),
  );
}

function historySection() {
  const H = text.history;
  return h(
    'section',
    { class: 'section' },
    title('hw2a-history', 0, text.sections.history),
    h('p', { text: H.intro }),
    h('p', { class: 'legend' }, h('span', { class: 'legend-task', text: H.legend.task }), h('span', { class: 'legend-context', text: H.legend.context })),
    h(
      'ol',
      { class: 'timeline' },
      H.events.map((e) => h('li', { class: e.task ? 'is-task' : 'is-context' }, h('span', { class: 'year', text: e.year }), h('div', null, h('strong', { text: e.title }), h('p', { text: e.text })))),
    ),
    h('p', { text: H.after }),
  );
}

function conclusionSection() {
  regions.conclusion = h('div');
  return h('section', { class: 'section' }, title('hw2a-conclusion', 0, text.sections.conclusion), regions.conclusion);
}

function updateConclusion() {
  fill(regions.conclusion, paras(text.conclusion((computed.stats && computed.stats.value) || null)));
}

// ---------------------------------------------------------------------------
// Aggiornamenti e calcoli lunghi
// ---------------------------------------------------------------------------

function updateStats() {
  updateProperties();
  updateCorpus();
  updateAlgorithm();
  updateLengths();
  updateMethods();
  updateTests();
  updateConclusion();
}

function updateScheme() {
  const c = current();
  updateKeys(c);
  updateEncryption(c);
  updateDecryption(c);
  updateCipherNow(c);
  updateCaesar();
  updateCompare();
  updateWeaknesses();
  updateAttacks();
  scheduleAttacks();
}

const message = (error) => (error instanceof Error ? error.message : String(error));

/** A generator that stops early, returning null, once its token is cancelled. */
function* cancellable(steps, token) {
  let step = steps.next();
  while (!step.done) {
    if (token.cancelled) return null;
    yield;
    step = steps.next();
  }
  return step.value;
}

let attackTimer = null;

// Gli attacchi ripartono quando la chiave smette di cambiare; quelli sulla
// chiave vecchia vengono fermati alla fetta successiva.
function scheduleAttacks() {
  const publicKey = current().publicKey;
  if (attacks.key === publicKey) return;
  clearTimeout(attackTimer);
  attackTimer = setTimeout(() => startAttacks(publicKey), 400);
}

function startAttacks(publicKey) {
  if (attacks.token) attacks.token.cancelled = true;
  const token = { cancelled: false };
  Object.assign(attacks, { key: publicKey, token, exhaustive: null, bsgs: null, kangaroo: null });
  updateAttacks();
  const run = (name) => hw.runStepsAsync(() => cancellable(hw.attackSteps(name, publicKey), token)).then(
    (value) => {
      if (token.cancelled || value === null) return;
      attacks[name] = { value };
      updateAttacks();
    },
    (error) => {
      if (token.cancelled) return;
      attacks[name] = { error: message(error) };
      updateAttacks();
    },
  );
  // the quick ones first: the exhaustive search takes seconds
  run('bsgs').then(() => run('kangaroo')).then(() => run('exhaustive'));
}

function startComputations() {
  setTimeout(() => {
    try {
      computed.verify = { value: hw.verifyAll() };
    } catch (error) {
      computed.verify = { error: message(error) };
    }
    updateVerify();
  }, 50);
  hw.exploreAsync().then(
    (value) => {
      computed.stats = { value };
      updateStats();
    },
    (error) => {
      computed.stats = { error: message(error) };
      updateStats();
    },
  );
  hw.scalingAsync().then(
    (value) => {
      computed.scaling = { value };
      updateScaling();
    },
    (error) => {
      computed.scaling = { error: message(error) };
      updateScaling();
    },
  );
  startAttacks(current().publicKey);
}

// ---------------------------------------------------------------------------
// Indice, lingua e avvio
// ---------------------------------------------------------------------------

const dialog = document.getElementById('index-dialog');
const FOLLOW_MS = 2500;

// Porta il titolo in cima e lo segue per un paio di secondi: se nel
// frattempo qualcosa sopra cambia altezza (una statistica che finisce di
// calcolarsi), lo scorrimento riparte verso la nuova posizione. Se l'utente
// scorre da se', si smette subito di inseguire.
function scrollToSection(target) {
  const behavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth';
  const userEvents = ['wheel', 'touchstart', 'keydown', 'mousedown'];
  const started = performance.now();
  let stopped = false;
  let lastTop = target.getBoundingClientRect().top + window.scrollY;
  const stop = () => {
    stopped = true;
    userEvents.forEach((type) => window.removeEventListener(type, stop));
  };
  userEvents.forEach((type) => window.addEventListener(type, stop, { passive: true }));
  target.scrollIntoView({ behavior, block: 'start' });
  const follow = () => {
    if (stopped) return;
    if (performance.now() - started > FOLLOW_MS) {
      stop();
      return;
    }
    const top = target.getBoundingClientRect().top + window.scrollY;
    if (Math.abs(top - lastTop) > 1) {
      lastTop = top;
      target.scrollIntoView({ behavior, block: 'start' });
    }
    requestAnimationFrame(follow);
  };
  requestAnimationFrame(follow);
}

function closeIndex() {
  document.documentElement.classList.remove('index-open');
  if (dialog.open) dialog.close();
}

function goTo(id) {
  closeIndex();
  const target = document.getElementById(id);
  if (!target) return;
  target.focus({ preventScroll: true });
  scrollToSection(target);
  target.classList.remove('flash');
  void target.offsetWidth;
  target.classList.add('flash');
  target.addEventListener('animationend', () => target.classList.remove('flash'), { once: true });
}

// In cima alla pagina, con il focus sul titolo: chi usa la tastiera riparte
// da li', non dal pulsante in fondo
function backToTop() {
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  window.scrollTo({ top: 0, behavior: reduced ? 'auto' : 'smooth' });
  document.getElementById('page-title').focus({ preventScroll: true });
}

const toTopButton = () => h('p', { class: 'to-top' }, h('button', { type: 'button', class: 'btn alt', text: text.ui.backToTop, onclick: backToTop }));

function renderChrome() {
  const t = text;
  document.documentElement.lang = state.lang;
  document.title = 'Homework #2 - Statistics';
  document.getElementById('subtitle').textContent = t.standalone.subtitle;
  document.getElementById('course').textContent = t.standalone.course;
  document.getElementById('open-index').textContent = t.ui.index;
  document.getElementById('index-title').textContent = t.ui.indexTitle;
  document.querySelector('.index-close').setAttribute('aria-label', t.ui.close);
  document.getElementById('language').setAttribute('aria-label', t.ui.language);
  document.getElementById('online-label').textContent = t.standalone.online;
  for (const button of document.querySelectorAll('[data-lang]')) {
    button.setAttribute('aria-pressed', String(button.dataset.lang === state.lang));
  }
  document.getElementById('index-list').replaceChildren(
    ...view.tocEntries(t.sections).map((entry) => h('li', { class: `level-${entry.level}` }, h('button', { type: 'button', text: entry.title, onclick: () => goTo(entry.id) }))),
  );
}

function render() {
  text = HW2A_TEXTS[state.lang];
  renderChrome();
  const app = document.getElementById('app');
  fill(app, assignmentSection(), schemeSection(), caesarSection(), cryptanalysisSection(), attackSection(), testsSection(), historySection(), conclusionSection(), toTopButton());
  updateInputs(view.readInputs(state.fields));
  const c = current();
  updateKeys(c);
  updateEncryption(c);
  updateDecryption(c);
  updateCipherNow(c);
  updateVerify();
  updateCaesar();
  updateCompare();
  updateWeaknesses();
  updateAttacks();
  updateScaling();
  updateStats();
}

function boot() {
  for (const button of document.querySelectorAll('[data-lang]')) {
    button.addEventListener('click', () => {
      if (button.dataset.lang === state.lang) return;
      state.lang = LANGUAGES.includes(button.dataset.lang) ? button.dataset.lang : 'en';
      render();
    });
  }
  document.getElementById('open-index').addEventListener('click', () => {
    document.documentElement.classList.add('index-open');
    dialog.showModal();
  });
  document.querySelector('.index-close').addEventListener('click', closeIndex);
  dialog.addEventListener('close', () => document.documentElement.classList.remove('index-open'));
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) closeIndex();
  });
  darkQuery.addEventListener('change', render);
  render();
  startComputations();
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
})();
})();
