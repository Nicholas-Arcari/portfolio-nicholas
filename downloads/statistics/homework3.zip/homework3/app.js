/*
 * Homework #3 - Statistics - Nicholas Arcari
 * Sapienza University of Rome, MSc in Cybersecurity
 *
 * Interface and texts (Italian and English). Needs homework3.js, loaded first.
 *
 * Generated from the sources of the online page,
 * https://nicholas-arcari.github.io/portfolio-nicholas/#/statistics/homework-3
 */

(function () {
'use strict';

var kitView$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitView.js
// La matematica delle viste di un grafico interattivo: quale parte degli
// assi si vede, come cambia con lo zoom e con lo spostamento, e la
// conversione fra i pixel del riquadro e i valori. Niente DOM: sono funzioni
// pure, che servono identiche alla pagina e al programma scaricabile.
//
// Una vista e' { x: [lo, hi] o null, y: [lo, hi] o null } nelle unita' degli
// assi; null su un asse vuol dire "tutto". Il riquadro (frame) e' quello che
// la libreria di ogni homework descrive con chartFrame(): { plot: { x, y, w,
// h }, x: { min, max, log } o null, y: { min, max, log }, zoom: 'xy' o 'y' }.
// Sugli assi logaritmici i conti si fanno sui logaritmi, cosi' lo zoom e lo
// spostamento hanno lo stesso effetto in ogni punto dell'asse.

/** How far the view can be enlarged: a thousandth of the whole axis. */
const MIN_SPAN = 1e-3;

const fwd = (axis, v) => (axis.log ? Math.log10(v) : v);
const back = (axis, t) => (axis.log ? 10 ** t : t);

/** The pixel of the value v on an axis drawn from p0 (its min) to p1 (its max). */
function toPixel(axis, v, p0, p1) {
  const lo = fwd(axis, axis.min);
  const hi = fwd(axis, axis.max);
  return p0 + ((fwd(axis, v) - lo) / (hi - lo)) * (p1 - p0);
}

/** The value of the pixel p on an axis drawn from p0 (its min) to p1 (its max). */
function toValue(axis, p, p0, p1) {
  const lo = fwd(axis, axis.min);
  const hi = fwd(axis, axis.max);
  return back(axis, lo + ((p - p0) / (p1 - p0)) * (hi - lo));
}

/** Whether the point (x, y), in CSS pixels of the canvas, lies in the plot. */
const inPlot = (frame, x, y, slack = 0) => !!frame && x >= frame.plot.x - slack && x <= frame.plot.x + frame.plot.w + slack && y >= frame.plot.y - slack && y <= frame.plot.y + frame.plot.h + slack;

/** The values under the point (x, y): { x, y }, with null on an axis without values (categories). */
function valueAt(frame, x, y) {
  const { plot } = frame;
  return {
    x: frame.x ? toValue(frame.x, x, plot.x, plot.x + plot.w) : null,
    y: toValue(frame.y, y, plot.y + plot.h, plot.y),
  };
}

/** The pixels of the values { x, y } (either may be null). */
function pixelAt(frame, x, y) {
  const { plot } = frame;
  return {
    x: x === null || !frame.x ? null : toPixel(frame.x, x, plot.x, plot.x + plot.w),
    y: y === null ? null : toPixel(frame.y, y, plot.y + plot.h, plot.y),
  };
}

/** The whole extent of the data of a frame drawn without a view: the limits zoom and panning stay within. */
const fullView = (frame) => ({ x: frame.x ? [frame.x.min, frame.x.max] : null, y: [frame.y.min, frame.y.max] });

const axesOf = (zoom) => ({ x: zoom === 'xy' || zoom === 'x', y: zoom === 'xy' || zoom === 'y' });

/** One axis of a view, kept inside the whole axis and no narrower than MIN_SPAN of it; the full axis becomes null. */
function clampAxis(range, full, axis) {
  if (!range || !full) return null;
  const f0 = fwd(axis, full[0]);
  const f1 = fwd(axis, full[1]);
  const whole = f1 - f0;
  let a = fwd(axis, range[0]);
  let b = fwd(axis, range[1]);
  if (b - a >= whole * (1 - 1e-9)) return null;
  const span = Math.max(b - a, whole * MIN_SPAN);
  const mid = (a + b) / 2;
  a = mid - span / 2;
  b = mid + span / 2;
  if (a < f0) [a, b] = [f0, f0 + span];
  if (b > f1) [a, b] = [f1 - span, f1];
  return [back(axis, a), back(axis, b)];
}

/** A view kept inside the whole data; null when it shows everything. */
function clampView(view, frameAxes, full) {
  if (!view) return null;
  const x = frameAxes.x ? clampAxis(view.x, full.x, frameAxes.x) : null;
  const y = clampAxis(view.y, full.y, frameAxes.y);
  return x || y ? { x, y } : null;
}

/** The range an axis shows now: the view's, or the whole one. */
const current = (view, full, key) => (view && view[key]) || full[key];

/** Zooms one axis by k (k > 1 enlarges) about the value c. */
function zoomAxis(range, axis, c, k) {
  const a = fwd(axis, range[0]);
  const b = fwd(axis, range[1]);
  const t = fwd(axis, c);
  return [back(axis, t - (t - a) / k), back(axis, t + (b - t) / k)];
}

/**
 * The view zoomed by k (k > 1 enlarges, k < 1 shrinks) about the pixel (px,
 * py) of the plot, on the axes the chart allows (frame.zoom); `frame` is
 * the frame of the chart as drawn now, `full` its whole extent.
 */
function zoomView(view, frame, full, px, py, k) {
  const allowed = axesOf(frame.zoom);
  const at = valueAt(frame, px, py);
  const next = { x: null, y: null };
  if (allowed.x && frame.x) next.x = zoomAxis(current(view, full, 'x'), frame.x, at.x, k);
  else if (view && view.x) next.x = view.x;
  if (allowed.y) next.y = zoomAxis(current(view, full, 'y'), frame.y, at.y, k);
  else if (view && view.y) next.y = view.y;
  return clampView(next, frame, full);
}

/** The view moved by (dx, dy) pixels of the plot: the data follow the pointer. */
function panView(view, frame, full, dx, dy) {
  if (!view) return null;
  const allowed = axesOf(frame.zoom);
  const shift = (range, axis, pixels, size) => {
    const a = fwd(axis, range[0]);
    const b = fwd(axis, range[1]);
    const d = (pixels / size) * (b - a);
    return [back(axis, a - d), back(axis, b - d)];
  };
  const next = { x: view.x, y: view.y };
  if (allowed.x && frame.x && view.x) next.x = shift(view.x, frame.x, dx, frame.plot.w);
  if (allowed.y && view.y) next.y = shift(view.y, frame.y, -dy, frame.plot.h);
  // keep the span while moving: clampAxis would shrink a view pushed against the edge
  const keep = (range, full, axis) => {
    if (!range) return null;
    const f0 = fwd(axis, full[0]);
    const f1 = fwd(axis, full[1]);
    let a = fwd(axis, range[0]);
    let b = fwd(axis, range[1]);
    if (a < f0) [a, b] = [f0, f0 + (b - a)];
    if (b > f1) [a, b] = [f1 - (b - a), f1];
    return [back(axis, a), back(axis, b)];
  };
  return { x: frame.x ? keep(next.x, full.x, frame.x) : null, y: keep(next.y, full.y, frame.y) };
}

/** The view of the rectangle selected from (x0, y0) to (x1, y1), in pixels, on the axes the chart allows. */
function boxView(view, frame, full, x0, y0, x1, y1) {
  const allowed = axesOf(frame.zoom);
  const a = valueAt(frame, Math.min(x0, x1), Math.max(y0, y1));
  const b = valueAt(frame, Math.max(x0, x1), Math.min(y0, y1));
  return clampView(
    {
      x: allowed.x && frame.x ? [a.x, b.x] : (view && view.x) || null,
      y: allowed.y ? [a.y, b.y] : (view && view.y) || null,
    },
    frame,
    full,
  );
}

/** Whether a view shows less than the whole data. */
const isZoomed = (view) => !!view && (!!view.x || !!view.y);

return { toPixel, toValue, inPlot, valueAt, pixelAt, fullView, clampView, zoomView, panView, boxView, isZoomed };
})();

var kitGestures$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitGestures.js
// I gesti su un elemento: il puntatore (mouse, penna, dito), la rotella e i
// tasti, tradotti in quello che vogliono dire: passare sopra, premere e
// trascinare, il doppio clic, la rotella con Ctrl, il pizzico a due dita.
// Non sa niente di grafici: chi lo usa decide, con il valore che restituisce,
// se un gesto lo riguarda (press, wheel, pinch e key restituiscono true per
// tenerlo). Le coordinate sono in pixel CSS dall'angolo in alto a sinistra
// dell'elemento.

/**
 * Listens to `el` and calls `handlers`:
 *   hover(p)                     the pointer moves over it (not while a drag is on)
 *   leave()                      it leaves
 *   press(p) -> boolean          a button or a finger goes down; true starts a drag
 *   drag(p, start)               the pointer moves during that drag
 *   release(p, start)            the drag ends (or is cancelled)
 *   dblclick(p) -> boolean       double click
 *   wheel(p, { deltaY, ctrl }) -> boolean   true stops the page from scrolling
 *   pinch({ x, y, scale, dx, dy }) -> boolean   two fingers: the centre, the change of their distance and of the centre
 *   key(event) -> boolean        a key while the element has the focus; true stops its default action
 * p is { x, y, pointerType, button, shift, ctrl }. Returns the function that stops listening.
 */
function attachGestures(el, handlers) {
  const at = (e) => {
    const r = el.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top, pointerType: e.pointerType || 'mouse', button: e.button ?? 0, shift: !!e.shiftKey, ctrl: !!(e.ctrlKey || e.metaKey) };
  };
  const touches = new Map(); // pointerId -> { x, y } of the fingers down
  let drag = null; // { id, start } while a press holds the pointer
  let pinch = null; // { distance, x, y } while two fingers are down

  const twoFingers = () => {
    const [a, b] = [...touches.values()];
    return { distance: Math.hypot(a.x - b.x, a.y - b.y), x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
  };

  const onDown = (e) => {
    const p = at(e);
    if (e.pointerType === 'touch') {
      touches.set(e.pointerId, p);
      if (touches.size === 2) {
        // two fingers: the drag of one finger, if any, ends and the pinch begins
        if (drag && handlers.release) handlers.release(p, drag.start);
        drag = null;
        pinch = twoFingers();
        return;
      }
      if (touches.size > 2) return;
    }
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    if (handlers.press && handlers.press(p)) {
      drag = { id: e.pointerId, start: p };
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        // a pointer that is already gone cannot be captured: the drag still works while it stays on the element
      }
      // the mouse: no text selected while dragging. A finger is kept by touchstart (below), and in Firefox a
      // pointerdown cancelled for a finger keeps a second finger (the pinch) away from the element
      if (e.pointerType !== 'touch') e.preventDefault();
    }
  };

  const onMove = (e) => {
    const p = at(e);
    if (e.pointerType === 'touch' && touches.has(e.pointerId)) {
      touches.set(e.pointerId, p);
      if (pinch && touches.size === 2) {
        const now = twoFingers();
        const used = handlers.pinch && handlers.pinch({ x: now.x, y: now.y, scale: now.distance / Math.max(1, pinch.distance), dx: now.x - pinch.x, dy: now.y - pinch.y });
        pinch = now;
        if (used) e.preventDefault();
        return;
      }
    }
    if (drag && e.pointerId === drag.id) {
      if (handlers.drag) handlers.drag(p, drag.start);
      return;
    }
    if (!drag && handlers.hover && e.pointerType !== 'touch') handlers.hover(p);
  };

  const onUp = (e) => {
    const p = at(e);
    if (e.pointerType === 'touch') {
      touches.delete(e.pointerId);
      if (touches.size < 2) pinch = null;
    }
    if (drag && e.pointerId === drag.id) {
      const { start } = drag;
      drag = null;
      if (handlers.release) handlers.release(p, start);
    }
  };

  const onLeave = (e) => {
    if (!drag && e.pointerType !== 'touch' && handlers.leave) handlers.leave();
  };

  const onDouble = (e) => {
    if (handlers.dblclick && handlers.dblclick(at(e))) e.preventDefault();
  };

  const onWheel = (e) => {
    if (handlers.wheel && handlers.wheel(at(e), { deltaY: e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY, ctrl: !!(e.ctrlKey || e.metaKey) })) e.preventDefault();
  };

  const onKey = (e) => {
    if (handlers.key && handlers.key(e)) e.preventDefault();
  };

  // With touch-action: pan-y a finger moving up or down scrolls the page, and the browser takes the
  // gesture away from the chart (pointercancel). A finger that grabbed something (press returned
  // true: a line to drag) and a second finger (the pinch) keep the gesture for the chart: the
  // pointerdown comes before its touchstart, so the decision is taken when the browser asks.
  const onTouchStart = (e) => {
    if (drag || e.touches.length > 1) e.preventDefault();
  };
  const onTouchMove = (e) => {
    if ((drag || pinch) && e.cancelable) e.preventDefault();
  };

  el.addEventListener('pointerdown', onDown);
  el.addEventListener('pointermove', onMove);
  el.addEventListener('pointerup', onUp);
  el.addEventListener('pointercancel', onUp);
  el.addEventListener('pointerleave', onLeave);
  el.addEventListener('dblclick', onDouble);
  el.addEventListener('wheel', onWheel, { passive: false });
  el.addEventListener('keydown', onKey);
  el.addEventListener('touchstart', onTouchStart, { passive: false });
  el.addEventListener('touchmove', onTouchMove, { passive: false });
  return () => {
    el.removeEventListener('pointerdown', onDown);
    el.removeEventListener('pointermove', onMove);
    el.removeEventListener('pointerup', onUp);
    el.removeEventListener('pointercancel', onUp);
    el.removeEventListener('pointerleave', onLeave);
    el.removeEventListener('dblclick', onDouble);
    el.removeEventListener('wheel', onWheel);
    el.removeEventListener('keydown', onKey);
    el.removeEventListener('touchstart', onTouchStart);
    el.removeEventListener('touchmove', onTouchMove);
  };
}

return { attachGestures };
})();

var kitChart$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitChart.js
// Un grafico interattivo: il canvas disegnato dalla libreria dell'homework,
// una tela trasparente sopra per i segni delle interazioni (il rettangolo
// dello zoom, le maniglie da trascinare), la vista (quale parte degli assi
// si vede), le parti nascoste dalla legenda e l'etichetta sotto il
// puntatore.
//
// Il controllore non sa che grafico sia: lo sanno le funzioni che riceve
// (draw, frame, withView, height, hitTest, hitAt, pointerLabel), che ogni
// libreria fornisce (Dependency Inversion). Le interazioni sono plugin
// (kitPlugins.js): un'interazione nuova e' un plugin nuovo, il controllore
// non cambia (Open/Closed). I gesti passano ai plugin in ordine, e il primo
// che ne tiene uno lo segue fino alla fine.
const { attachGestures } = kitGestures$;
const { clampView, fullView, isZoomed, zoomView } = kitView$;

const requestFrame = (fn) => (typeof requestAnimationFrame === 'function' ? requestAnimationFrame(fn) : setTimeout(fn, 16));
const cancelFrame = (id) => (typeof cancelAnimationFrame === 'function' ? cancelAnimationFrame(id) : clearTimeout(id));

/**
 * Makes `canvas` an interactive chart. `deps`:
 *   draw, data, palette        the chart and what it draws
 *   frame(draw, data, width)   where the plot lies and what it shows (null: no zoom)
 *   withView(draw, data, view) the same data in another view
 *   height(draw, data, width)  the height of the canvas at this width
 *   hitTest, hitAt, pointerLabel   the label under the pointer (as attachChartTooltip)
 *   describe(hit, hidden)      its text, or null for none; link: the linked table, or null
 *   hidden                     the parts hidden by the legend
 *   plugins                    the interactions, in order of priority
 *   schedule(job)              where the first drawing goes (a queue of frames), optional
 * Returns the controller: setData, setPalette, setHidden, setDescribe,
 * resize, getFrame, getView, setView, zoomBy, resetView, isZoomed, on,
 * requestOverlay, setCursor, destroy.
 */
function createChart(canvas, deps) {
  const { draw, frame: frameOf, withView, height: heightOf, hitTest, hitAt, pointerLabel, schedule = null } = deps;
  let data = deps.data;
  let palette = deps.palette;
  let hidden = deps.hidden || [];
  let describe = deps.describe || null;
  let link = deps.link || null;
  let width = -1;
  let view = null;
  let viewed = data; // the data as drawn now: hidden parts and view applied
  let frame = null; // where the plot lies now
  let full = null; // the whole extent of the data, without a view
  let frameRequest = 0;
  let firstDrawn = false;
  let destroyed = false;
  const listeners = {};
  const plugins = deps.plugins || [];

  // the transparent canvas over the chart, for the marks of the interactions
  const overlay = document.createElement('canvas');
  overlay.setAttribute('aria-hidden', 'true');
  Object.assign(overlay.style, { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px' });
  canvas.after(overlay);

  const emit = (name, payload) => (listeners[name] || []).forEach((fn) => fn(payload));
  const shown = () => (hidden.length ? { ...data, hidden } : data);

  const drawOverlay = () => {
    const dpr = (typeof window !== 'undefined' && window.devicePixelRatio) || 1;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    Object.assign(overlay.style, { left: `${canvas.offsetLeft}px`, top: `${canvas.offsetTop}px`, width: `${w}px`, height: `${h}px` });
    if (overlay.width !== Math.round(w * dpr) || overlay.height !== Math.round(h * dpr)) {
      overlay.width = Math.round(w * dpr);
      overlay.height = Math.round(h * dpr);
    }
    const ctx = overlay.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    if (!frame) return;
    for (const plugin of plugins) if (plugin.overlay) plugin.overlay(ctx, frame, palette);
  };

  const render = () => {
    frameRequest = 0;
    if (destroyed || width <= 0) return;
    const base = shown();
    const fullFrame = frameOf(draw, base, width);
    full = fullFrame ? fullView(fullFrame) : null;
    // a view that the new data no longer allows (other limits) is brought back inside them
    if (view && fullFrame) view = clampView(view, fullFrame, full);
    if (!fullFrame) view = null;
    viewed = view ? withView(draw, base, view) : base;
    canvas.style.height = `${heightOf(draw, viewed, width)}px`;
    draw(canvas, { ...viewed, width }, palette);
    frame = frameOf(draw, viewed, width);
    canvas.tabIndex = frame ? 0 : -1;
    drawOverlay();
    // the label under a still pointer follows the chart that changed under it
    if (detachLabel && detachLabel.refresh) detachLabel.refresh();
    emit('render', { frame, view });
  };

  /** Draws again at the next frame (several changes in the same frame draw once). */
  const redraw = () => {
    if (!frameRequest && !destroyed) frameRequest = requestFrame(render);
  };

  // the label under the pointer, attached once: it always reads the data as drawn now
  let detachLabel = null;
  const attachLabel = () => {
    if (detachLabel || !describe) return;
    detachLabel = pointerLabel(
      canvas,
      (x, y, w) => {
        if (!describe) return null;
        const hit = hitTest(draw, viewed, w, x, y);
        const text = hit && describe(hit, hidden);
        return text ? { rect: hit.rect, text, row: link ? link.row(hit) : -1 } : null;
      },
      link && {
        table: () => (link ? link.table() : null),
        locate: (row, w) => {
          const hit = link && hitAt(draw, viewed, w, link.point(row));
          return hit && hit.rect;
        },
      },
    );
  };
  attachLabel();

  const api = {
    canvas,
    overlay,
    get palette() {
      return palette;
    },
    setData(next) {
      data = next;
      redraw();
    },
    setPalette(next) {
      palette = next;
      redraw();
    },
    setHidden(parts) {
      hidden = parts || [];
      redraw();
    },
    setDescribe(fn) {
      describe = fn;
      attachLabel();
    },
    setLink(next) {
      link = next;
    },
    /** The width the canvas gets in the page (from a ResizeObserver): the first drawing goes through the queue, if any. */
    resize(next) {
      if (next <= 0 || next === width) return;
      width = next;
      if (!firstDrawn && schedule) {
        firstDrawn = true;
        canvas.style.height = `${heightOf(draw, shown(), width)}px`;
        schedule(() => {
          if (!destroyed && canvas.isConnected) render();
        });
        return;
      }
      firstDrawn = true;
      render();
    },
    redraw,
    requestOverlay: () => drawOverlay(),
    getFrame: () => frame,
    getFullView: () => full,
    getView: () => view,
    setView(next) {
      const before = JSON.stringify(view);
      view = next && frame ? clampView(next, frame, full) : null;
      if (JSON.stringify(view) !== before) {
        emit('view', view);
        redraw();
      }
    },
    /** Zooms about the centre of the plot (k > 1 enlarges). */
    zoomBy(k) {
      if (!frame || !full) return;
      api.setView(zoomView(view, frame, full, frame.plot.x + frame.plot.w / 2, frame.plot.y + frame.plot.h / 2, k));
    },
    resetView() {
      api.setView(null);
    },
    isZoomed: () => isZoomed(view),
    canZoom: () => !!frame,
    setCursor(cursor) {
      canvas.style.cursor = cursor || '';
    },
    on(name, fn) {
      (listeners[name] = listeners[name] || []).push(fn);
      return () => {
        listeners[name] = (listeners[name] || []).filter((f) => f !== fn);
      };
    },
    emit,
    destroy() {
      destroyed = true;
      cancelFrame(frameRequest);
      detachGestures();
      if (detachLabel) detachLabel();
      for (const plugin of plugins) if (plugin.uninstall) plugin.uninstall();
      overlay.remove();
    },
  };

  // the gestures go to the plugins in order: the first that takes a press follows it to the end
  let active = null;
  // the cursor is the kit's only when a plugin asked for one: a canvas that sets its own (a point to grab) keeps it
  let cursorSet = false;
  const detachGestures = attachGestures(canvas, {
    hover(p) {
      let cursor = '';
      for (const plugin of plugins) {
        const c = plugin.hover && plugin.hover(p);
        if (c) {
          cursor = c;
          break;
        }
      }
      if (cursor || cursorSet) api.setCursor(cursor);
      cursorSet = !!cursor;
    },
    leave() {
      for (const plugin of plugins) if (plugin.leave) plugin.leave();
      if (cursorSet) api.setCursor('');
      cursorSet = false;
    },
    press(p) {
      active = plugins.find((plugin) => plugin.pointerDown && plugin.pointerDown(p)) || null;
      // the label waits while a plugin follows the drag
      if (active && detachLabel && detachLabel.suspend) detachLabel.suspend(true);
      return !!active;
    },
    drag(p, start) {
      if (active && active.pointerMove) active.pointerMove(p, start);
    },
    release(p, start) {
      if (active && active.pointerUp) active.pointerUp(p, start);
      if (active && detachLabel && detachLabel.suspend) detachLabel.suspend(false);
      active = null;
    },
    dblclick: (p) => plugins.some((plugin) => plugin.doubleClick && plugin.doubleClick(p)),
    wheel: (p, w) => plugins.some((plugin) => plugin.wheel && plugin.wheel(p, w)),
    pinch: (g) => plugins.some((plugin) => plugin.pinch && plugin.pinch(g)),
    key: (e) => plugins.some((plugin) => plugin.key && plugin.key(e)),
  });
  for (const plugin of plugins) if (plugin.install) plugin.install(api);
  return api;
}

return { createChart };
})();

var kitPlugins$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitPlugins.js
// Le interazioni di un grafico (kitChart.js), una per plugin. Un plugin e'
// un oggetto con i soli metodi che gli servono (Interface Segregation):
//   install(chart), uninstall()
//   hover(p) -> cursore o '', leave()
//   pointerDown(p) -> true per tenere il gesto, pointerMove(p, start), pointerUp(p, start)
//   doubleClick(p), wheel(p, { deltaY, ctrl }), pinch({ x, y, scale, dx, dy }), key(event) -> true se usati
//   overlay(ctx, frame, palette): i suoi segni sulla tela trasparente sopra il grafico
// Un'interazione nuova e' un plugin nuovo: il controllore non cambia.
const { boxView, inPlot, panView, pixelAt, valueAt, zoomView } = kitView$;

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/**
 * Zoom and panning: ctrl (or cmd) + wheel and two fingers zoom about the
 * pointer; a drag selects the rectangle to enlarge, or moves the view once
 * it is enlarged (with shift it always selects); a double click and the
 * keys 0 or Escape go back to the whole chart; + and - zoom, the arrows
 * move. A plain wheel scrolls the page, and the chart says (event 'hint')
 * how to zoom instead. On a canvas where dragging already means something
 * (a point to move, a curve to draw) `drag: false` leaves the drag to it,
 * and `panKeys: 'shift'` moves the view only with shift + arrows, when the
 * arrows are taken too.
 */
function zoomPan({ drag = true, panKeys = 'arrows' } = {}) {
  let chart = null;
  let mode = null; // 'pan' or 'box' during a drag
  let box = null;
  let last = null;
  return {
    name: 'zoomPan',
    install(c) {
      chart = c;
    },
    hover(p) {
      const f = chart.getFrame();
      if (!drag || !inPlot(f, p.x, p.y)) return '';
      return chart.isZoomed() && !p.shift ? 'grab' : 'zoom-in';
    },
    pointerDown(p) {
      const f = chart.getFrame();
      if (!drag || !f || p.pointerType === 'touch' || !inPlot(f, p.x, p.y)) return false;
      if (chart.isZoomed() && !p.shift) {
        mode = 'pan';
        last = p;
        chart.setCursor('grabbing');
        return true;
      }
      mode = 'box';
      box = { x0: p.x, y0: p.y, x1: p.x, y1: p.y };
      return true;
    },
    pointerMove(p) {
      const f = chart.getFrame();
      if (!f) return;
      if (mode === 'pan') {
        chart.setView(panView(chart.getView(), f, chart.getFullView(), p.x - last.x, p.y - last.y));
        last = p;
      } else if (mode === 'box') {
        box.x1 = clamp(p.x, f.plot.x, f.plot.x + f.plot.w);
        box.y1 = clamp(p.y, f.plot.y, f.plot.y + f.plot.h);
        chart.requestOverlay();
      }
    },
    pointerUp() {
      const f = chart.getFrame();
      if (mode === 'box' && box && f) {
        const wide = Math.abs(box.x1 - box.x0) > 6 && f.zoom !== 'y';
        const tall = Math.abs(box.y1 - box.y0) > 6 && f.zoom !== 'x';
        if (wide || tall) {
          const { plot } = f;
          // a thin selection enlarges one axis only, the other one stays as it is
          const x0 = wide ? box.x0 : plot.x;
          const x1 = wide ? box.x1 : plot.x + plot.w;
          const y0 = tall ? box.y0 : plot.y;
          const y1 = tall ? box.y1 : plot.y + plot.h;
          const next = boxView(chart.getView(), f, chart.getFullView(), x0, y0, x1, y1);
          const view = chart.getView();
          chart.setView({ x: wide ? next && next.x : view && view.x, y: tall ? next && next.y : view && view.y });
        }
      }
      mode = null;
      box = null;
      chart.requestOverlay();
      chart.setCursor('');
    },
    doubleClick() {
      if (!chart.isZoomed()) return false;
      chart.resetView();
      return true;
    },
    wheel(p, w) {
      const f = chart.getFrame();
      if (!f || !inPlot(f, p.x, p.y)) return false;
      if (!w.ctrl) {
        chart.emit('hint');
        return false;
      }
      chart.setView(zoomView(chart.getView(), f, chart.getFullView(), p.x, p.y, Math.exp(-w.deltaY * 0.0025)));
      return true;
    },
    pinch(g) {
      const f = chart.getFrame();
      if (!f) return false;
      const zoomed = zoomView(chart.getView(), f, chart.getFullView(), g.x, g.y, g.scale);
      chart.setView(zoomed ? panView(zoomed, f, chart.getFullView(), g.dx, g.dy) : null);
      return true;
    },
    key(e) {
      const f = chart.getFrame();
      if (!f) return false;
      if (e.key === '+' || e.key === '=') {
        chart.zoomBy(1.5);
        return true;
      }
      if (e.key === '-' || e.key === '_') {
        if (!chart.isZoomed()) return false;
        chart.zoomBy(1 / 1.5);
        return true;
      }
      if (e.key === '0' || e.key === 'Escape') {
        if (!chart.isZoomed()) return false;
        chart.resetView();
        return true;
      }
      const step = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
      if (!step || !chart.isZoomed() || (panKeys === 'shift' && !e.shiftKey)) return false;
      chart.setView(panView(chart.getView(), f, chart.getFullView(), -step[0] * f.plot.w * 0.1, -step[1] * f.plot.h * 0.1));
      return true;
    },
    overlay(ctx, f, pal) {
      if (mode !== 'box' || !box) return;
      const yOnly = f.zoom === 'y';
      const xOnly = f.zoom === 'x';
      const x = yOnly ? f.plot.x : Math.min(box.x0, box.x1);
      const w = yOnly ? f.plot.w : Math.abs(box.x1 - box.x0);
      const y = xOnly ? f.plot.y : Math.min(box.y0, box.y1);
      const h = xOnly ? f.plot.h : Math.abs(box.y1 - box.y0);
      ctx.fillStyle = pal.highlight;
      ctx.globalAlpha = 0.1;
      ctx.fillRect(x, y, w, h);
      ctx.globalAlpha = 1;
      ctx.strokeStyle = pal.highlight;
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 3]);
      ctx.strokeRect(x + 0.5, y + 0.5, w, h);
      ctx.setLineDash([]);
    },
  };
}

/**
 * Lines to drag on the chart, bound to the parameters of its spec: specs
 * [{ id, axis: 'x' (a vertical line) or 'y' (a horizontal one), value,
 * min, max, step?, values? (the allowed ones), label? }], in the units of
 * the axes. onChange(id, value) receives the new value while dragging; the
 * line itself moves when the spec gives the new value back (setSpecs).
 */
function handles({ onChange, onEnd = null }) {
  let chart = null;
  let specs = [];
  let grabbed = null;
  const where = (f, spec) => {
    const at = spec.axis === 'x' ? pixelAt(f, spec.value, null).x : pixelAt(f, null, spec.value).y;
    if (at === null || !Number.isFinite(at)) return null;
    const inside = spec.axis === 'x' ? at >= f.plot.x - 1 && at <= f.plot.x + f.plot.w + 1 : at >= f.plot.y - 1 && at <= f.plot.y + f.plot.h + 1;
    return inside ? at : null;
  };
  const near = (p) => {
    const f = chart && chart.getFrame();
    if (!f || !inPlot(f, p.x, p.y, 8)) return null;
    const reach = p.pointerType === 'touch' ? 14 : 7;
    let best = null;
    let distance = reach;
    for (const spec of specs) {
      const at = where(f, spec);
      if (at === null) continue;
      const d = Math.abs((spec.axis === 'x' ? p.x : p.y) - at);
      if (d <= distance) {
        best = spec;
        distance = d;
      }
    }
    return best;
  };
  const snap = (spec, v) => {
    if (spec.values && spec.values.length) {
      // on a logarithmic axis the nearest value is the nearest in the logarithms, as the eye sees it
      const f = chart && chart.getFrame();
      const axis = f && f[spec.axis];
      const t = axis && axis.log ? (u) => Math.log10(u) : (u) => u;
      return spec.values.reduce((a, b) => (Math.abs(t(b) - t(v)) < Math.abs(t(a) - t(v)) ? b : a));
    }
    let out = clamp(v, spec.min ?? -Infinity, spec.max ?? Infinity);
    if (spec.step) out = Math.round(out / spec.step) * spec.step;
    return Number(out.toPrecision(12));
  };
  return {
    name: 'handles',
    install(c) {
      chart = c;
    },
    setSpecs(next) {
      specs = next || [];
      if (chart) chart.requestOverlay();
    },
    hover(p) {
      const spec = near(p);
      if (!spec) return '';
      return spec.axis === 'x' ? 'ew-resize' : 'ns-resize';
    },
    pointerDown(p) {
      grabbed = near(p);
      if (!grabbed) return false;
      chart.setCursor(grabbed.axis === 'x' ? 'ew-resize' : 'ns-resize');
      return true;
    },
    pointerMove(p) {
      const f = chart.getFrame();
      if (!grabbed || !f) return;
      const v = valueAt(f, p.x, p.y)[grabbed.axis];
      if (v === null || !Number.isFinite(v)) return;
      const next = snap(grabbed, v);
      if (next !== grabbed.value) {
        grabbed = { ...grabbed, value: next };
        onChange(grabbed.id, next);
      }
    },
    pointerUp() {
      if (grabbed && onEnd) onEnd(grabbed.id);
      grabbed = null;
      chart.setCursor('');
    },
    overlay(ctx, f, pal) {
      for (const spec of specs) {
        const at = where(f, spec);
        if (at === null) continue;
        const active = grabbed && grabbed.id === spec.id;
        ctx.strokeStyle = pal.highlight;
        ctx.fillStyle = pal.highlight;
        ctx.lineWidth = active ? 2.5 : 1.8;
        ctx.beginPath();
        if (spec.axis === 'x') {
          ctx.moveTo(at, f.plot.y);
          ctx.lineTo(at, f.plot.y + f.plot.h);
        } else {
          ctx.moveTo(f.plot.x, at);
          ctx.lineTo(f.plot.x + f.plot.w, at);
        }
        ctx.stroke();
        // the knob to grab, with the label beside it: at the left of a horizontal line, away from
        // the zoom buttons in the top right corner, and at the top of a vertical one, above the bars
        // (at its bottom when the line runs under the zoom buttons)
        const low = spec.axis === 'x' && at > f.plot.x + f.plot.w - 96;
        const kx = spec.axis === 'x' ? at : f.plot.x + 9;
        let ky = at;
        if (spec.axis === 'x') ky = low ? f.plot.y + f.plot.h - 9 : f.plot.y + 9;
        ctx.beginPath();
        ctx.arc(kx, ky, active ? 7 : 6, 0, 2 * Math.PI);
        ctx.fill();
        ctx.strokeStyle = pal.background;
        ctx.lineWidth = 1.5;
        ctx.stroke();
        if (spec.label) {
          ctx.font = '11px sans-serif';
          ctx.fillStyle = pal.text;
          const right = spec.axis === 'x' && at > f.plot.x + f.plot.w * 0.7;
          ctx.textAlign = right ? 'right' : 'left';
          const tx = spec.axis === 'x' ? at + (right ? -10 : 10) : kx + 11;
          // above the line, or below it when the line is at the top of the plot
          let ty = spec.axis === 'x' ? ky + 4 : at - 7;
          if (spec.axis === 'y' && at - f.plot.y < 16) ty = at + 15;
          ctx.fillText(spec.label, tx, ty);
        }
      }
    },
  };
}

return { zoomPan, handles };
})();

var kitPlayer$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitPlayer.js
// Il lettore delle animazioni: un tempo t da 0 a frames - 1 che avanza a
// una certa velocita', con avvio, pausa, un passo avanti o indietro e un
// punto qualsiasi. Non sa niente di grafici: a ogni passo chiama
// onFrame(t), e chi lo usa ridisegna. All'inizio sta sull'ultimo passo, cosi'
// chi non preme Avvia vede il grafico completo, e non parte mai da solo:
// rispetta anche chi ha chiesto meno movimento.

const requestFrame = (fn) => (typeof requestAnimationFrame === 'function' ? requestAnimationFrame(fn) : setTimeout(() => fn(Date.now()), 16));
const cancelFrame = (id) => (typeof cancelAnimationFrame === 'function' ? cancelAnimationFrame(id) : clearTimeout(id));

/**
 * A player of `frames` steps, one every `ms` milliseconds at speed 1.
 * onFrame(t) draws step t; onChange(state) tells the interface { t,
 * frames, playing, speed }. Returns { play, pause, toggle, step, seek,
 * setSpeed, setFrames, setMs, state, destroy }.
 */
function createPlayer({ frames = 1, ms: stepMs = 60, loop = false, onFrame, onChange = null }) {
  let ms = stepMs;
  let count = Math.max(1, frames);
  let t = count - 1;
  let playing = false;
  let speed = 1;
  let request = 0;
  let last = 0;
  let elapsed = 0;
  const state = () => ({ t, frames: count, playing, speed });
  const notify = () => {
    if (onChange) onChange(state());
  };
  const tick = (now) => {
    if (!playing) return;
    if (!last) last = now;
    elapsed += (now - last) * speed;
    last = now;
    let moved = false;
    while (elapsed >= ms && playing) {
      elapsed -= ms;
      if (t < count - 1) {
        t += 1;
        moved = true;
      } else if (loop) {
        t = 0;
        moved = true;
      } else {
        playing = false;
      }
    }
    if (moved) onFrame(t);
    notify();
    if (playing) request = requestFrame(tick);
  };
  const api = {
    play() {
      if (playing || count < 2) return;
      // at the end, play starts again from the beginning
      if (t >= count - 1) {
        t = 0;
        onFrame(t);
      }
      playing = true;
      last = 0;
      elapsed = 0;
      request = requestFrame(tick);
      notify();
    },
    pause() {
      if (!playing) return;
      playing = false;
      cancelFrame(request);
      notify();
    },
    toggle() {
      if (playing) api.pause();
      else api.play();
    },
    step(by = 1) {
      api.pause();
      const next = Math.min(count - 1, Math.max(0, t + by));
      if (next !== t) {
        t = next;
        onFrame(t);
      }
      notify();
    },
    seek(at) {
      const next = Math.min(count - 1, Math.max(0, Math.round(at)));
      if (next !== t) {
        t = next;
        onFrame(t);
      }
      notify();
    },
    setSpeed(next) {
      speed = next;
      notify();
    },
    /** A new number of steps (the parameters changed): when stopped, the player goes to the end, where the chart is complete. */
    setFrames(next) {
      count = Math.max(1, next);
      if (!playing || t > count - 1) t = count - 1;
      notify();
    },
    /** Another length of a step, in milliseconds at speed 1 (a new animation). */
    setMs(next) {
      ms = Math.max(1, next);
    },
    state,
    destroy() {
      playing = false;
      cancelFrame(request);
    },
  };
  return api;
}

return { createPlayer };
})();

var kitSpec$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitSpec.js
// I comandi di una sezione e il suo modello: i parametri che i comandi
// cambiano e, quando una simulazione dipende da loro, il suo risultato. Il
// modello e' della sezione, non del grafico: grafici e tabelle della stessa
// sezione leggono gli stessi parametri e la stessa simulazione, e non
// possono raccontare cose diverse. Non sa niente di React ne' del DOM: la
// pagina lo usa con useModel.js, il programma scaricabile direttamente.
//
//   control = { key, kind: 'slider', values: [...], label(value) }
//           | { key, kind: 'choice', options: [[value, name], ...], label }
//           | { key, kind: 'toggle', label }
//           | { kind: 'action', label, run(params) -> params }
// Le etichette sono gia' nella lingua della pagina; il modello tiene solo i
// parametri, che non dipendono dalla lingua.

/** The position of a slider: the index of the value closest to the parameter. */
function sliderIndex(control, params) {
  const v = params[control.key];
  let best = 0;
  control.values.forEach((x, i) => {
    if (Math.abs(x - v) < Math.abs(control.values[best] - v)) best = i;
  });
  return best;
}

/** The parameters after a control is used: a slider gives the index of its value, a choice its value, a toggle true or false, an action nothing. */
function applyControl(control, params, input) {
  if (control.kind === 'slider') return { ...params, [control.key]: control.values[input] };
  if (control.kind === 'choice') return { ...params, [control.key]: input };
  if (control.kind === 'toggle') return { ...params, [control.key]: !!input };
  if (control.kind === 'action') return control.run(params);
  return params;
}

const keyOf = (params) => JSON.stringify(params);
const KEPT = 6;

/**
 * The state of a section with controls: { params, sim, pending, error }.
 *   params            the parameters at the start
 *   simulate(params)  optional: the steps (a generator) of a simulation, whose return value is its result
 *   simKey(params)    which parameters the simulation depends on (default: all of them)
 *   runner            the library's runStepsAsync: the simulation runs in slices of a few milliseconds
 * While a simulation runs, `sim` stays the last result (so nothing goes
 * blank) and `pending` is true; the results of the last parameters seen
 * are kept, and a simulation nobody wants any more stops between two slices.
 * Returns { get, setParams, provide, subscribe, destroy }.
 */
function createModel({ params, simulate = null, simKey = keyOf, runner = null }) {
  let state = { params: { ...params }, sim: null, pending: false, error: null };
  const cache = new Map();
  const listeners = new Set();
  let job = null;
  const set = (patch) => {
    state = { ...state, ...patch };
    listeners.forEach((fn) => fn());
  };
  const remember = (key, value) => {
    cache.delete(key);
    cache.set(key, value);
    while (cache.size > KEPT) cache.delete(cache.keys().next().value);
  };
  const run = (p) => {
    if (!simulate) return;
    const key = simKey(p);
    if (cache.has(key)) {
      if (job) job.cancel();
      job = null;
      set({ sim: cache.get(key), pending: false, error: null });
      return;
    }
    if (job && job.key === key) return;
    if (job) job.cancel();
    if (!runner) return;
    let cancelled = false;
    function* guarded() {
      const steps = simulate(p);
      let step = steps.next();
      while (!step.done) {
        if (cancelled) throw new Error('cancelled');
        yield;
        step = steps.next();
      }
      return step.value;
    }
    job = {
      key,
      cancel: () => {
        cancelled = true;
      },
    };
    set({ pending: true });
    runner(guarded).then(
      (value) => {
        if (cancelled) return;
        remember(key, value);
        job = null;
        set({ sim: value, pending: false, error: null });
      },
      (error) => {
        if (cancelled) return;
        job = null;
        set({ pending: false, error: error instanceof Error ? error.message : String(error) });
      },
    );
  };
  return {
    get: () => state,
    setParams(next) {
      set({ params: next });
      run(next);
    },
    /** A result computed elsewhere (the worker of the page) for the parameters `forParams`: used now if they are the current ones. */
    provide(value, forParams = params) {
      if (!simulate || !value) return;
      const key = simKey(forParams);
      if (!cache.has(key)) remember(key, value);
      if (simKey(state.params) === key && state.sim !== value) {
        if (job && job.key === key) {
          job.cancel();
          job = null;
        }
        set({ sim: value, pending: false, error: null });
      }
    },
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    destroy() {
      if (job) job.cancel();
      job = null;
      listeners.clear();
    },
  };
}

return { sliderIndex, applyControl, createModel };
})();

var kitLabels$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitLabels.js
// I testi dei comandi dei grafici interattivi, uguali in ogni homework: lo
// zoom, il suggerimento, il lettore delle animazioni.

const KIT_LABELS = Object.freeze({
  it: Object.freeze({
    tools: 'Zoom del grafico',
    zoomIn: 'Ingrandisci',
    zoomOut: 'Riduci',
    reset: 'Vista intera',
    hint: 'Ctrl + rotella per ingrandire; oppure trascinate per scegliere una zona, doppio clic per tornare alla vista intera',
    touchHint: 'Due dita per ingrandire',
    player: 'Animazione',
    play: 'Avvia',
    pause: 'Pausa',
    back: 'Un passo indietro',
    forward: 'Un passo avanti',
    speed: 'Velocità',
    position: (t, n) => `Passo ${t} di ${n}`,
    pending: 'Simulazione in corso...',
  }),
  en: Object.freeze({
    tools: 'Chart zoom',
    zoomIn: 'Zoom in',
    zoomOut: 'Zoom out',
    reset: 'Whole chart',
    hint: 'Ctrl + wheel to zoom; or drag to pick an area, double click to go back to the whole chart',
    touchHint: 'Two fingers to zoom',
    player: 'Animation',
    play: 'Play',
    pause: 'Pause',
    back: 'One step back',
    forward: 'One step forward',
    speed: 'Speed',
    position: (t, n) => `Step ${t} of ${n}`,
    pending: 'Simulating...',
  }),
});

/** The labels in a language, English when it is not known. */
const kitLabels = (lang) => KIT_LABELS[lang] || KIT_LABELS.en;

return { KIT_LABELS, kitLabels };
})();

var kitReveal$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitReveal.js
// L'animazione piu' comune dei grafici degli homework: una curva disegnata
// punto per punto, al crescere della sua x (n che cresce, i giorni, i
// tentativi). Vale per i dati dei grafici a linee di ogni libreria, { x,
// series: [{ values, band?, fixed? }] }: le serie `fixed` (riferimenti,
// bande, soglie) restano intere.

/** An animation that draws a line chart point by point, as its x grows: { frames, at(t), ms }. */
function reveal(chart, ms = 110) {
  return {
    frames: chart.x.length,
    ms,
    at: (t) => ({
      ...chart,
      series: chart.series.map((s) => (s.fixed ? s : { ...s, values: s.values.map((v, i) => (i <= t ? v : null)), band: s.band ? s.band.map((b, i) => (i <= t ? b : null)) : s.band })),
    }),
  };
}

return { reveal };
})();

var kitSource$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitSource.js
// Una tela che si disegna da sola (un'animazione, un editor da trascinare)
// come grafico del kit: lo stato e i suoi comandi restano suoi, il kit le
// da' la vista (zoom e spostamento), la tela trasparente, i gesti, i
// plugin e l'etichetta sotto il puntatore. Il controllore e' lo stesso
// degli altri grafici (kitChart.js): la tela gli passa solo le sue funzioni.

const { createChart } = kitChart$;

/**
 * Makes `canvas` a chart of the kit, drawn by `source`:
 *   draw(canvas, view, width, palette)   its state as it is now, in this view (null: the whole of it)
 *   frame(view, width)                   where the plot lies and what it shows, as chartFrame of the libraries
 *   height(width)                        the height of the canvas at this width
 *   locate(x, y, view, width)            optional: what is under the pointer, { rect, text } or null
 * `options`: palette, pointerLabel (the attachPointerLabel of the library),
 * plugins (zoomPan, ...), schedule. The source asks for a new drawing with
 * chart.redraw() when its state changes. Returns the chart (kitChart.js).
 */
function createSourceChart(canvas, source, { palette, pointerLabel, plugins = [], schedule = null }) {
  const viewOf = (data) => data.view || null;
  return createChart(canvas, {
    draw: (target, data, pal) => source.draw(target, viewOf(data), data.width, pal),
    data: { view: null },
    palette,
    frame: (draw, data, width) => source.frame(viewOf(data), width),
    withView: (draw, data, view) => ({ ...data, view }),
    height: (draw, data, width) => source.height(width),
    hitTest: (draw, data, width, x, y) => (source.locate ? source.locate(x, y, viewOf(data), width) : null),
    hitAt: () => null,
    pointerLabel,
    describe: source.locate ? (hit) => hit.text : null,
    plugins,
    schedule,
  });
}

return { createSourceChart };
})();

var kitDom$ = (function () {
'use strict';

// src/pages/statistics/chartkit/kitDom.js
// L'adattatore del kit dei grafici interattivi per i programmi scaricabili:
// lo stesso grafico della pagina (ChartFigure.jsx), costruito con il DOM, senza
// React. Un grafico e' una <figure> con, dall'alto: il riquadro del canvas
// con i pulsanti dello zoom, il lettore dell'animazione, la legenda a
// pulsanti, la nota e la didascalia. I comandi di una sezione (controlsOf,
// modelControls) stanno sopra i suoi grafici e seguono il suo modello
// (kitSpec.createModel). Le classi sono quelle di style.css dei programmi.
//
// Ogni testo entra con textContent, mai come HTML.
const { createChart } = kitChart$;
const { createSourceChart } = kitSource$;
const { kitLabels } = kitLabels$;
const { createPlayer } = kitPlayer$;
const { handles: handlesPlugin, zoomPan } = kitPlugins$;
const { applyControl, createModel: makeModel, sliderIndex } = kitSpec$;

const HINT_MS = 2200;

/** The model of a section with controls (kitSpec.createModel), for the programs. */
const createModel = makeModel;
let uid = 0;

/** el('p', { class: 'note', text: '...' }, child, ...): the text always through textContent. */
function el(tag, attrs, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key === 'style') Object.assign(node.style, value);
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? '' : String(value));
  }
  for (const child of children.flat(Infinity)) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}

/** The parts of the drawing covered by the hidden items of a legend. */
const partsOf = (items, hidden) => items.flatMap((item, i) => (hidden.has(i) ? item.parts || [] : []));

/** Hides the cells, columns and rows of a table that belong to hidden parts (data-part), and shows the others. */
function hideParts(table, parts) {
  if (!table) return;
  for (const node of table.querySelectorAll('[data-part]')) node.hidden = parts.includes(node.dataset.part);
}

/**
 * The legend of a chart: { label, color? | paletteKey?, dashed?, box?,
 * parts }. Every item is a button: pressed its parts are on screen,
 * released they are hidden; onChange(parts) receives the hidden parts.
 * `hidden`, the set of the hidden items, outlives the legend.
 */
function legend(items, onChange, hidden, palette) {
  return el(
    'ul',
    { class: 'series-legend' },
    items.map((item, i) => {
      const color = item.paletteKey ? palette[item.paletteKey] : palette.series[(item.color ?? i) % palette.series.length];
      let swatch = null;
      if (item.box) swatch = 'is-box';
      else if (item.dashed) swatch = 'is-dashed';
      const button = el(
        'button',
        {
          type: 'button',
          'aria-pressed': String(!hidden.has(i)),
          class: hidden.has(i) ? 'is-off' : null,
          onclick: () => {
            if (hidden.has(i)) hidden.delete(i);
            else hidden.add(i);
            button.setAttribute('aria-pressed', String(!hidden.has(i)));
            button.classList.toggle('is-off', hidden.has(i));
            onChange(partsOf(items, hidden));
          },
        },
        el('span', { class: swatch, 'aria-hidden': 'true', style: { borderColor: color, backgroundColor: item.box ? color : 'transparent' } }),
        item.label,
      );
      return el('li', null, button);
    }),
  );
}

/**
 * The controls of a section (kitSpec), with the classes of the programs:
 * getParams() gives the parameters, onChange(params) receives them after
 * every use. box.update() moves the controls to the current parameters
 * without rebuilding them (a slider keeps the focus while it moves).
 */
function controlsOf(controls, getParams, onChange, pendingLabel = '') {
  const id = `kitc${(uid += 1)}`;
  const actions = controls.filter((c) => c.kind === 'action');
  const pending = el('p', { class: 'kit-pending note', role: 'status', text: pendingLabel, hidden: true });
  const params = getParams();
  const blocks = controls
    .map((c, i) => {
      if (c.kind === 'slider') {
        const index = sliderIndex(c, params);
        const text = c.label(c.values[index]);
        return el(
          'div',
          { class: 'slider' },
          el('label', { for: `${id}-${c.key}`, text }),
          el('input', { id: `${id}-${c.key}`, type: 'range', min: 0, max: c.values.length - 1, step: 1, value: index, 'aria-valuetext': text, oninput: (e) => onChange(applyControl(c, getParams(), Number(e.target.value))) }),
        );
      }
      if (c.kind === 'choice') {
        return el(
          'div',
          { class: 'choices', role: 'group', 'aria-label': c.label },
          el('span', { class: 'choices-label', text: c.label }),
          c.options.map(([value, name]) => el('button', { type: 'button', class: 'btn alt', 'aria-pressed': String(params[c.key] === value), text: name, onclick: () => onChange(applyControl(c, getParams(), value)) })),
        );
      }
      if (c.kind === 'toggle') {
        return el('label', { class: 'kit-toggle' }, el('input', { type: 'checkbox', checked: !!params[c.key], onchange: (e) => onChange(applyControl(c, getParams(), e.target.checked)) }), ` ${c.label}`);
      }
      if (i !== controls.indexOf(actions[0])) return null;
      return el('p', { class: 'kit-actions' }, actions.map((a) => el('button', { type: 'button', class: 'btn alt small', text: a.label, onclick: () => onChange(applyControl(a, getParams())) })));
    })
    .filter(Boolean);
  const box = el('div', { class: 'kit-controls' }, blocks, pending);
  box.update = (busy = false) => {
    const now = getParams();
    let k = 0;
    for (const c of controls) {
      if (c.kind === 'action' && c !== actions[0]) continue;
      const block = blocks[k];
      k += 1;
      if (c.kind === 'slider') {
        const index = sliderIndex(c, now);
        const text = c.label(c.values[index]);
        block.querySelector('label').textContent = text;
        const input = block.querySelector('input');
        if (Number(input.value) !== index) input.value = String(index);
        input.setAttribute('aria-valuetext', text);
      } else if (c.kind === 'choice') {
        block.querySelectorAll('button').forEach((b, j) => b.setAttribute('aria-pressed', String(now[c.key] === c.options[j][0])));
      } else if (c.kind === 'toggle') {
        block.querySelector('input').checked = !!now[c.key];
      }
    }
    pending.hidden = !busy;
  };
  return box;
}

/** The controls bound to the model of a section (kitSpec.createModel): they follow it, and are released with their region (releaseFigures). */
function modelControls(model, controls, lang = 'en') {
  const box = controlsOf(controls, () => model.get().params, (next) => model.setParams(next), kitLabels(lang).pending);
  box.kitRelease = model.subscribe(() => box.update(model.get().pending));
  box.update(model.get().pending);
  return box;
}

/** The player of an animation: back, play or pause, forward, the position and the speed. */
function playerBar(id, player, labels) {
  const back = el('button', { type: 'button', class: 'btn alt small', 'aria-label': labels.back, title: labels.back, text: '‹', onclick: () => player.step(-1) });
  const play = el('button', { type: 'button', class: 'btn small kit-play', onclick: () => player.toggle() });
  const forward = el('button', { type: 'button', class: 'btn alt small', 'aria-label': labels.forward, title: labels.forward, text: '›', onclick: () => player.step(1) });
  const position = el('input', { id: `${id}-t`, class: 'kit-position', type: 'range', min: 0, step: 1, oninput: (e) => player.seek(Number(e.target.value)) });
  const where = el('span', { class: 'kit-step', 'aria-hidden': 'true' });
  const speeds = [1, 2, 4].map((s) => el('button', { type: 'button', class: 'btn alt small', text: `×${s}`, onclick: () => player.setSpeed(s) }));
  const bar = el('div', { class: 'kit-player', role: 'group', 'aria-label': labels.player }, back, play, forward, position, where, el('span', { class: 'kit-speed', role: 'group', 'aria-label': labels.speed }, speeds));
  bar.update = (state) => {
    play.textContent = state.playing ? labels.pause : labels.play;
    play.setAttribute('aria-pressed', String(state.playing));
    back.disabled = state.t <= 0;
    forward.disabled = state.t >= state.frames - 1;
    position.max = String(state.frames - 1);
    position.value = String(state.t);
    const text = labels.position(state.t + 1, state.frames);
    position.setAttribute('aria-label', text);
    position.setAttribute('aria-valuetext', text);
    where.textContent = text;
    speeds.forEach((b, i) => b.setAttribute('aria-pressed', String(state.speed === [1, 2, 4][i])));
  };
  return bar;
}

// one observer for every chart of the page: the width of each canvas, measured after layout
const sizes = typeof ResizeObserver === 'function'
  ? new ResizeObserver((entries) => {
    for (const entry of entries) {
      const width = Math.round(entry.contentRect.width);
      const figure = entry.target.closest('figure');
      if (figure && figure.kit && width > 0) figure.kit.chart.resize(width);
    }
  })
  : null;

/**
 * An interactive chart for the programs. `options`:
 *   label, draw, data, palette, lang
 *   lib (the library of the homework), schedule (the queue of the first drawings)
 *   tip (describe(hit, hidden)), link, items (the legend), keep (the set of hidden items that outlives the chart),
 *   table (the id of the linked table: the legend hides its parts too), onHide(parts) (anything else the legend hides), note, wide
 *   animation ({ frames, at(t) -> data, ms }: the chart step by step, with the player)
 *   handles ({ items, onChange(id, value) }: the lines to drag), pending (a simulation is running)
 * Returns the <figure>, with figure.kit = { chart, setData, setTip, setLabel,
 * setNote, relabel, setHidden, setAnimation, setHandles, setPending, destroy }.
 */
function createFigure(options) {
  const { label, draw, palette, lib, schedule = null, lang = 'en', items = null, note = null, link = null, table = null, wide = true } = options;
  const labels = kitLabels(lang);
  const id = `kit${(uid += 1)}`;
  const hidden = options.keep || new Set();
  let given = options.data;
  let animation = options.animation || null;
  let onHandle = options.handles ? options.handles.onChange : null;
  let t = animation ? Math.max(1, animation.frames) - 1 : 0;
  const frames = () => (animation ? Math.max(1, animation.frames) : 1);
  const dataNow = () => (animation && t < frames() - 1 ? animation.at(t) : given);

  const canvas = el('canvas', { class: 'chart', role: 'img', 'aria-label': label });
  const plot = el('div', { class: 'kit-plot' }, canvas);
  const zoomIn = el('button', { type: 'button', 'aria-label': labels.zoomIn, title: labels.zoomIn, text: '+' });
  const zoomOut = el('button', { type: 'button', 'aria-label': labels.zoomOut, title: labels.zoomOut, text: '-', disabled: true });
  const reset = el('button', { type: 'button', 'aria-label': labels.reset, title: labels.reset, text: '⤢', disabled: true });
  const tools = el('div', { class: 'kit-tools', role: 'group', 'aria-label': labels.tools, hidden: true }, zoomIn, zoomOut, reset);
  const hint = el('p', { class: 'kit-hint', 'aria-live': 'polite', text: labels.hint, hidden: true });
  const busy = el('p', { class: 'kit-busy', role: 'status', text: labels.pending, hidden: !options.pending });
  const caption = el('figcaption', { text: label });
  const noteEl = el('p', { class: 'figure-note', text: note || '', hidden: !note });

  const handles = options.handles ? handlesPlugin({ onChange: (key, value) => onHandle && onHandle(key, value) }) : null;
  const chart = createChart(canvas, {
    draw,
    data: dataNow(),
    palette,
    frame: lib.chartFrame,
    withView: lib.withView,
    height: lib.chartHeight,
    hitTest: lib.chartHitTest,
    hitAt: lib.chartHitAt,
    pointerLabel: lib.attachPointerLabel,
    describe: options.tip || null,
    link,
    hidden: items ? partsOf(items, hidden) : [],
    plugins: handles ? [handles, zoomPan()] : [zoomPan()],
    schedule,
  });
  if (handles) handles.setSpecs(options.handles.items);
  zoomIn.addEventListener('click', () => chart.zoomBy(1.5));
  zoomOut.addEventListener('click', () => chart.zoomBy(1 / 1.5));
  reset.addEventListener('click', () => chart.resetView());
  chart.on('render', ({ frame }) => {
    tools.hidden = !frame;
  });
  chart.on('view', () => {
    const zoomed = chart.isZoomed();
    tools.classList.toggle('is-zoomed', zoomed);
    zoomOut.disabled = !zoomed;
    reset.disabled = !zoomed;
  });
  let hintTimer = 0;
  chart.on('hint', () => {
    hint.hidden = false;
    clearTimeout(hintTimer);
    hintTimer = setTimeout(() => {
      hint.hidden = true;
    }, HINT_MS);
  });

  // the animation: the player starts on the last step, where the chart is complete
  let bar = null;
  const player = createPlayer({
    frames: frames(),
    ms: (animation && animation.ms) || 60,
    onFrame: (step) => {
      t = step;
      chart.setData(dataNow());
    },
    onChange: (state) => bar && bar.update(state),
  });
  bar = playerBar(id, player, labels);
  bar.hidden = !animation;
  bar.update(player.state());

  const legendEl = items
    ? legend(
      items,
      (parts) => {
        chart.setHidden(parts);
        if (table) hideParts(document.getElementById(table), parts);
        if (options.onHide) options.onHide(parts);
      },
      hidden,
      palette,
    )
    : null;
  const figure = el(
    'figure',
    { class: `${wide ? 'figure wide' : 'figure'} kit-figure${options.pending ? ' is-pending' : ''}` },
    el('div', { class: 'kit-stage' }, plot, tools, hint, busy),
    bar,
    legendEl,
    noteEl,
    caption,
  );
  figure.kit = {
    chart,
    setData(next) {
      given = next;
      chart.setData(dataNow());
    },
    setTip: (next) => chart.setDescribe(next),
    setLabel(next) {
      canvas.setAttribute('aria-label', next);
      caption.textContent = next;
    },
    setNote(next) {
      noteEl.textContent = next || '';
      noteEl.hidden = !next;
    },
    /** New labels for the buttons of the legend (the same items, in the same order). */
    relabel(next) {
      if (!legendEl) return;
      legendEl.querySelectorAll('button').forEach((button, i) => {
        if (next[i]) button.lastChild.textContent = next[i].label;
      });
    },
    setHidden: (parts) => chart.setHidden(parts),
    /** A new animation (the parameters changed): when stopped, the player goes to the end, where the chart is complete. */
    setAnimation(next) {
      animation = next || null;
      bar.hidden = !animation;
      if (animation && animation.ms) player.setMs(animation.ms);
      player.setFrames(frames());
      t = player.state().t;
      chart.setData(dataNow());
    },
    setHandles(next) {
      if (!handles || !next) return;
      onHandle = next.onChange;
      handles.setSpecs(next.items);
    },
    setPending(on) {
      busy.hidden = !on;
      figure.classList.toggle('is-pending', !!on);
      canvas.setAttribute('aria-busy', on ? 'true' : 'false');
    },
    destroy() {
      clearTimeout(hintTimer);
      if (sizes) sizes.unobserve(canvas);
      player.destroy();
      chart.destroy();
    },
  };
  if (sizes) sizes.observe(canvas);
  // the table may come after the chart: its parts are hidden once both are on the page
  if (table && hidden.size && typeof requestAnimationFrame === 'function') requestAnimationFrame(() => hideParts(document.getElementById(table), partsOf(items, hidden)));
  return figure;
}

/** Releases the charts and the controls inside a region that is about to be replaced. */
function releaseFigures(region) {
  for (const figure of region.querySelectorAll('figure.kit-figure')) if (figure.kit) figure.kit.destroy();
  for (const box of region.querySelectorAll('.kit-controls, .kit-stage')) if (box.kitRelease) box.kitRelease();
}

/**
 * A canvas that draws itself (an animation, an editor: kitSource.js) as a
 * chart of the kit, in the program: the canvas goes into a box of its own
 * (kit-plot) with the buttons of the zoom and the hint, and the controller
 * follows its width. `options`: palette, lib (the library of the homework),
 * lang, plugins (zoomPan(zoom) by default), zoom (the options of that
 * zoomPan: { drag: false } leaves the mouse and one finger to the canvas,
 * panKeys: 'shift' moves the view with shift + arrows), schedule. Returns { stage, chart }:
 * the stage takes the place of the canvas in the page, and carries
 * kitRelease (releaseFigures calls it).
 */
function createSourceStage(canvas, source, { palette, lib, lang = 'en', plugins = null, zoom = {}, schedule = null }) {
  const labels = kitLabels(lang);
  const plot = el('div', { class: 'kit-plot' }, canvas);
  const zoomIn = el('button', { type: 'button', 'aria-label': labels.zoomIn, title: labels.zoomIn, text: '+' });
  const zoomOut = el('button', { type: 'button', 'aria-label': labels.zoomOut, title: labels.zoomOut, text: '-', disabled: true });
  const reset = el('button', { type: 'button', 'aria-label': labels.reset, title: labels.reset, text: '⤢', disabled: true });
  const tools = el('div', { class: 'kit-tools', role: 'group', 'aria-label': labels.tools, hidden: true }, zoomIn, zoomOut, reset);
  const hint = el('p', { class: 'kit-hint', 'aria-live': 'polite', text: labels.hint, hidden: true });
  const stage = el('div', { class: 'kit-stage kit-source' }, plot, tools, hint);
  const chart = createSourceChart(canvas, source, { palette, pointerLabel: lib.attachPointerLabel, plugins: plugins || [zoomPan(zoom)], schedule });
  zoomIn.addEventListener('click', () => chart.zoomBy(1.5));
  zoomOut.addEventListener('click', () => chart.zoomBy(1 / 1.5));
  reset.addEventListener('click', () => chart.resetView());
  chart.on('render', ({ frame }) => {
    tools.hidden = !frame;
  });
  chart.on('view', () => {
    const zoomed = chart.isZoomed();
    tools.classList.toggle('is-zoomed', zoomed);
    zoomOut.disabled = !zoomed;
    reset.disabled = !zoomed;
  });
  let hintTimer = 0;
  chart.on('hint', () => {
    hint.hidden = false;
    clearTimeout(hintTimer);
    hintTimer = setTimeout(() => {
      hint.hidden = true;
    }, HINT_MS);
  });
  const observer = typeof ResizeObserver === 'function'
    ? new ResizeObserver((entries) => {
      const width = Math.round(entries[entries.length - 1].contentRect.width);
      if (width > 0) chart.resize(width);
    })
    : null;
  if (observer) observer.observe(canvas);
  stage.kitRelease = () => {
    clearTimeout(hintTimer);
    if (observer) observer.disconnect();
    chart.destroy();
    stage.kitRelease = null;
  };
  return { stage, chart };
}

return { createModel, partsOf, hideParts, legend, controlsOf, modelControls, createFigure, releaseFigures, createSourceStage };
})();

var view$ = (function () {
'use strict';

// src/pages/statistics/hw3/view.js
// Logica di presentazione dell'Homework #3, condivisa fra la pagina del sito
// (React) e il programma scaricabile (DOM puro): le sezioni, la lettura dei
// campi, le righe delle tabelle e i dati dei grafici. Tenerla qui impedisce
// che le due versioni dicano cose diverse sugli stessi numeri.
const hw = Homework3;
const { reveal: revealChart } = kitReveal$;

/** The sections of the homework, in page order: ids for the anchors, keys for the titles. */
const SECTIONS = [
  { id: 'hw3-assignment', key: 'assignment', level: 0 },
  { id: 'hw3-model', key: 'model', level: 0 },
  { id: 'hw3-models', key: 'models', level: 1 },
  { id: 'hw3-quantities', key: 'quantities', level: 1 },
  { id: 'hw3-input', key: 'input', level: 1 },
  { id: 'hw3-trajectories', key: 'trajectories', level: 1 },
  { id: 'hw3-verify', key: 'verify', level: 1 },
  { id: 'hw3-distributions', key: 'distributions', level: 0 },
  { id: 'hw3-sweep', key: 'sweep', level: 1 },
  { id: 'hw3-moments', key: 'moments', level: 1 },
  { id: 'hw3-choice', key: 'choice', level: 1 },
  { id: 'hw3-lln', key: 'lln', level: 0 },
  { id: 'hw3-convergence', key: 'convergence', level: 1 },
  { id: 'hw3-bounds', key: 'bounds', level: 1 },
  { id: 'hw3-strong', key: 'strong', level: 1 },
  { id: 'hw3-variance', key: 'variance', level: 0 },
  { id: 'hw3-clt', key: 'clt', level: 0 },
  { id: 'hw3-normal', key: 'normal', level: 1 },
  { id: 'hw3-speed', key: 'speed', level: 1 },
  { id: 'hw3-bernoulli', key: 'bernoulli', level: 1 },
  { id: 'hw3-interpretation', key: 'interpretation', level: 0 },
  { id: 'hw3-size', key: 'size', level: 1 },
  { id: 'hw3-attackers', key: 'attackers', level: 1 },
  { id: 'hw3-aggregate', key: 'aggregate', level: 1 },
  { id: 'hw3-limits', key: 'limits', level: 1 },
  { id: 'hw3-tests', key: 'tests', level: 0 },
  { id: 'hw3-history', key: 'history', level: 0 },
  { id: 'hw3-conclusion', key: 'conclusion', level: 0 },
];

/** The entries of the index: the sections with their titles in the current language. */
const tocEntries = (titles) => SECTIONS.map((s) => ({ ...s, title: titles[s.key] }));

// ---------------------------------------------------------------------------
// I campi
// ---------------------------------------------------------------------------

/** How many characters each field accepts. */
const FIELD_LENGTH = Object.freeze({ p: 8, n: 6, m: 6, seed: 10 });

const DEFAULT_PARAMS = Object.freeze({ p: hw.DEFAULT_P, n: hw.DEFAULT_N, m: hw.DEFAULT_M, seed: hw.DEFAULT_SEED });

/** The text of the fields for some parameters. */
const fieldsOf = (params) => ({ pText: String(params.p), nText: String(params.n), mText: String(params.m), seedText: String(params.seed) });

const DEFAULT_INPUTS = Object.freeze(fieldsOf(DEFAULT_PARAMS));

/** The four fields, read and checked. */
const readInputs = ({ pText, nText, mText, seedText }) => ({
  p: hw.parseProbability(pText),
  n: hw.parseInteger(nText, hw.LIMITS.n),
  m: hw.parseInteger(mText, hw.LIMITS.m),
  seed: hw.parseInteger(seedText, hw.LIMITS.seed),
});

const sameParams = (a, b) => a.p === b.p && a.n === b.n && a.m === b.m && a.seed === b.seed;

/** The parameters to use: the value of every valid field, the last valid value of the others (the same object if nothing changes). */
function applyInputs(read, previous) {
  const next = {};
  for (const key of ['p', 'n', 'm', 'seed']) next[key] = read[key].ok ? read[key].value : previous[key];
  return sameParams(next, previous) ? previous : next;
}

const allValid = (read) => read.p.ok && read.n.ok && read.m.ok && read.seed.ok;

/** The key of a computation in the cache and in the worker: one per set of parameters. */
const paramsKey = (params) => `${params.p}|${params.n}|${params.m}|${params.seed}`;
function parseParamsKey(key) {
  const [p, n, m, seed] = key.split('|').map(Number);
  return { p, n, m, seed };
}

/** The line under the fields: the initial values, or different ones with the button that restores them. */
function inputBadge(params, I) {
  return sameParams(params, DEFAULT_PARAMS) ? { known: true, text: I.defaultBadge, restore: false } : { known: false, text: I.customBadge, restore: true };
}

// ---------------------------------------------------------------------------
// L'animazione
// ---------------------------------------------------------------------------

/** The animation: attackers drawn, attackers in the histogram, the speeds (1 = a run in about 15 seconds). */
const ANIMATION = Object.freeze({ shown: 50, sample: 500, speeds: Object.freeze([0.25, 1, 4]) });

/** The options of the animation for some parameters and a model: it draws and counts at most m attackers. */
const animationOptions = (params, model) => ({
  model,
  p: params.p,
  n: params.n,
  m: params.m,
  seed: params.seed,
  shown: Math.min(ANIMATION.shown, params.m),
  sample: Math.min(ANIMATION.sample, params.m),
});

// ---------------------------------------------------------------------------
// Istogrammi
// ---------------------------------------------------------------------------

/**
 * How a checkpoint is displayed: the value of atom k and the distance
 * between atoms, for S_n, S_n/n, S_n/sqrt(n) or the standardized
 * (S_n - n mu)/(sigma sqrt(n)), with the mean and standard deviation of the
 * quantity.
 */
function displayOf(point, mom, kind) {
  const n = point.n;
  if (kind === 'standardized') {
    const scale = mom.sigma * Math.sqrt(n);
    return { valueOf: (k) => (point.low + point.step * k - n * mom.mu) / scale, spacing: point.step / scale, mean: 0, sd: 1 };
  }
  const c = hw.quantityScale(kind, n);
  const q = hw.quantityMoments(mom, n, kind);
  return { valueOf: (k) => (point.low + point.step * k) * c, spacing: point.step * c, mean: q.mean, sd: q.sd };
}

/**
 * A histogram whose bins follow the lattice of the values: every bin holds
 * a whole number of atoms, so that no bin gets one atom more than its
 * neighbour (with bins of any width a lattice gives a comb of tall and short
 * bars). Heights are densities, share divided by width, so that they can be
 * compared with a density curve; `expected` is the same for the exact law.
 */
function latticeHistogram({ counts, pmf = null, valueOf, spacing, range, target = 44 }) {
  const [x0, x1] = range;
  const per = Math.max(1, Math.round((x1 - x0) / target / spacing));
  let total = 0;
  for (const c of counts) total += c;
  const bars = [];
  const expected = [];
  let k0 = 0;
  while (k0 < counts.length) {
    let k1 = Math.min(counts.length, k0 + per);
    // the atoms left at the end, fewer than half a bar, join the last bar: a
    // bar of a single atom would be very narrow and, as a density, very tall
    if (counts.length - k1 > 0 && counts.length - k1 < per / 2) k1 = counts.length;
    const from = valueOf(k0) - spacing / 2;
    const to = valueOf(k1 - 1) + spacing / 2;
    if (to > x0 && from < x1) {
      let count = 0;
      let prob = 0;
      for (let k = k0; k < k1; k++) {
        count += counts[k];
        if (pmf) prob += pmf[k];
      }
      const width = to - from;
      bars.push({ from, to, value: count / total / width, share: count / total, prob });
      expected.push(prob / width);
    }
    k0 = k1;
  }
  return { x0, x1, bars, expected: pmf ? expected : null, width: per * spacing, total };
}

/**
 * The normal density N(mean, sd^2) averaged over windows as wide as the
 * bins: the height a bar centred at x would have under the normal law. With
 * narrow bins it is the density itself; with wide ones it stays comparable
 * with the bars instead of rising above them.
 */
function normalCurve(mean, sd, width, [x0, x1]) {
  const points = Math.min(1200, Math.max(160, Math.ceil((x1 - x0) / (Math.min(width, sd) / 2))));
  const out = [];
  for (let i = 0; i <= points; i++) {
    const x = x0 + (i * (x1 - x0)) / points;
    out.push([x, (hw.normalCdf((x + width / 2 - mean) / sd) - hw.normalCdf((x - width / 2 - mean) / sd)) / width]);
  }
  return out;
}

/**
 * The axis of the histograms of section 2. S_n/n and S_n/sqrt(n) keep the
 * same axis for every n, wide enough for all of them, so that the
 * concentration of the first and the stability (or the drift) of the second
 * can be seen; S_n, whose centre and width grow with n, gets the axis of its
 * own n, otherwise for small n it would be a single bar at the edge.
 */
function sweepRange(M, quantity, g) {
  const { mom } = M;
  if (quantity === 'mean') return [mom.low - 0.04 * (1 - mom.low), 1 + 0.04 * (1 - mom.low)];
  let lo = Infinity;
  let hi = -Infinity;
  for (const pt of quantity === 'sum' ? [M.points[g]] : M.points) {
    const q = hw.quantityMoments(mom, pt.n, quantity);
    lo = Math.min(lo, q.mean - 4.2 * q.sd);
    hi = Math.max(hi, q.mean + 4.2 * q.sd);
  }
  // a Bernoulli score is never negative
  if (mom.low === 0) lo = Math.max(lo, -0.6);
  return [lo, hi];
}

/** The histogram of a quantity at checkpoint g, on the axis of section 2. */
function sweepChart(M, g, quantity, decimal = '.') {
  const point = M.points[g];
  const d = displayOf(point, M.mom, quantity);
  const range = sweepRange(M, quantity, g);
  const h = latticeHistogram({ counts: point.counts, pmf: point.pmf, valueOf: d.valueOf, spacing: d.spacing, range });
  return { ...h, curve: normalCurve(d.mean, d.sd, h.width, range), normal: { mean: d.mean, sd: d.sd }, xTicks: hw.niceTicks(range[0], range[1], 5), decimal };
}

/** Mean and standard deviation of a quantity at checkpoint g, simulated and exact. */
function quantityStats(M, g, quantity) {
  const pt = M.points[g];
  const c = hw.quantityScale(quantity, pt.n);
  const q = hw.quantityMoments(M.mom, pt.n, quantity);
  return { n: pt.n, mean: pt.sample.mean * c, sd: Math.sqrt(pt.sample.variance) * c, theoryMean: q.mean, theorySd: q.sd };
}

/** The index of the checkpoint n in the grid, or the last. */
const pointIndex = (M, n) => {
  const g = M.points.findIndex((pt) => pt.n === n);
  return g < 0 ? M.points.length - 1 : g;
};

/** The rows of the table of section 2.2: the mean of S_n/n and the variance of S_n/sqrt(n) of both models. */
function momentRows(s) {
  const B = s.models.bernoulli.points;
  const R = s.models.rademacher.points;
  return B.map((pt, g) => ({ n: pt.n, bMean: pt.sample.mean / pt.n, bVar: pt.sample.variance / pt.n, rMean: R[g].sample.mean / R[g].n, rVar: R[g].sample.variance / R[g].n }));
}

/** How far the sample moments of section 2.2 go from the exact ones: the largest |mean - mu| in standard errors, the largest relative error of the variance, and √(2/m). */
function momentFacts(s) {
  let meanZ = 0;
  let varRel = 0;
  for (const model of hw.MODELS) {
    const M = s.models[model];
    for (const pt of M.points) {
      const se = M.mom.sigma / Math.sqrt(pt.n * pt.sample.m);
      meanZ = Math.max(meanZ, Math.abs(pt.sample.mean / pt.n - M.mom.mu) / se);
      varRel = Math.max(varRel, Math.abs(pt.sample.variance / (pt.n * M.mom.variance) - 1));
    }
  }
  return { meanZ, varRel, expectedRel: Math.sqrt(2 / s.params.m) };
}

// ---------------------------------------------------------------------------
// La legge dei grandi numeri
// ---------------------------------------------------------------------------

/** The ticks of a logarithmic n axis: the powers of 10 up to n. */
const powerTicks = (nMax) => [1, 10, 100, 1000, 10000, 100000].filter((v) => v <= nMax);

/** P(|S_n/n - mu| > epsilon) at checkpoint g: simulated with its Wilson interval, exact, and the bounds. */
function exceedance(M, g, epsilon) {
  const pt = M.points[g];
  let beyond = 0;
  for (let k = 0; k < pt.counts.length; k++) {
    if (pt.counts[k] && hw.beyondEpsilon(pt.low + pt.step * k, pt.n, M.mom.mu, epsilon)) beyond += pt.counts[k];
  }
  const rate = beyond / pt.sample.m;
  return {
    n: pt.n,
    beyond,
    rate,
    interval: hw.wilsonInterval(rate, pt.sample.m),
    exact: hw.exactExceedance({ n: pt.n, low: pt.low, step: pt.step, pmf: pt.pmf }, M.mom.mu, epsilon),
    chebyshev: hw.chebyshevBound(M.mom, pt.n, epsilon),
    hoeffding: hw.hoeffdingBound(M.mom, pt.n, epsilon),
    normal: hw.normalExceedance(M.mom, pt.n, epsilon),
  };
}

/** An animation that draws the simulated values of a line chart point by point, as n (or the attackers) grows (chartkit/kitReveal.js); the exact values and the bounds stay whole. */
const reveal = revealChart;

const llnRows = (s, epsilon) => ({
  bernoulli: s.models.bernoulli.points.map((_, g) => exceedance(s.models.bernoulli, g, epsilon)),
  rademacher: s.models.rademacher.points.map((_, g) => exceedance(s.models.rademacher, g, epsilon)),
});

function llnChart(rows, decimal = '.') {
  return {
    x: rows.map((r) => r.n),
    logX: true,
    yMin: 0,
    yMax: 1,
    yTicks: [0, 0.25, 0.5, 0.75, 1],
    xTicks: powerTicks(rows[rows.length - 1].n),
    decimal,
    series: [
      { values: rows.map((r) => r.rate), band: rows.map((r) => r.interval), colorIndex: 0 },
      { values: rows.map((r) => r.exact), colorIndex: 2, dots: false, fixed: true },
      { values: rows.map((r) => r.chebyshev), colorIndex: 3, dashed: true, fixed: true },
      { values: rows.map((r) => r.hoeffding), colorIndex: 4, dotted: true, fixed: true },
    ],
  };
}

/** What the text of section 3 says about the rows of one model: from which n the exact probability stays below 1%, whether it ever grows with n, the last row. */
function llnFacts(rows) {
  let below = null;
  for (let i = rows.length - 1; i >= 0 && rows[i].exact < 0.01; i--) below = rows[i].n;
  let rises = null;
  for (let i = 1; i < rows.length; i++) {
    if (rows[i].exact > rows[i - 1].exact + 1e-9 && rows[i - 1].exact < 1) {
      rises = { from: rows[i - 1], to: rows[i] };
      break;
    }
  }
  return { below, rises, last: rows[rows.length - 1], chebyshevUseful: rows.find((r) => r.chebyshev < 1) || null };
}

// ---------------------------------------------------------------------------
// La varianza
// ---------------------------------------------------------------------------

const decade = (v, up) => 10 ** (up ? Math.ceil(Math.log10(v)) : Math.floor(Math.log10(v)));

/** The variances of S_n, S_n/n and S_n/sqrt(n) on logarithmic axes: simulated (dots) and exact (dashed). */
function varianceChart(M, decimal = '.') {
  const x = M.points.map((pt) => pt.n);
  const series = [];
  let lo = Infinity;
  let hi = -Infinity;
  hw.QUANTITIES.forEach((q, i) => {
    const sample = M.points.map((pt) => pt.sample.variance * hw.quantityScale(q, pt.n) ** 2);
    const exact = M.points.map((pt) => hw.quantityMoments(M.mom, pt.n, q).variance);
    for (const v of [...sample, ...exact]) {
      if (v > 0) {
        lo = Math.min(lo, v);
        hi = Math.max(hi, v);
      }
    }
    series.push({ values: sample, colorIndex: i, dotsOnly: true }, { values: exact, colorIndex: i, dashed: true, fixed: true });
  });
  const yMin = decade(lo, false);
  const yMax = decade(hi, true);
  const yTicks = [];
  for (let v = yMin; v <= yMax * 1.0001; v *= 100) yTicks.push(v);
  return { x, logX: true, logY: true, yMin, yMax, yTicks, xTicks: powerTicks(x[x.length - 1]), decimal, series };
}

/** The slopes of log Var against log n, for the three quantities of each model: the same fit, moved by -2 and -1. */
function varianceFits(s) {
  const out = {};
  for (const model of hw.MODELS) {
    const M = s.models[model];
    const fit = hw.fitLine(M.points.map((pt) => Math.log10(pt.n)), M.points.map((pt) => Math.log10(pt.sample.variance)));
    out[model] = { sum: fit.slope, mean: fit.slope - 2, normalized: fit.slope - 1, error: fit.slopeError };
  }
  return out;
}

const VARIANCE_SLOPES = Object.freeze({ sum: 1, mean: -1, normalized: 0 });

// ---------------------------------------------------------------------------
// Il teorema del limite centrale
// ---------------------------------------------------------------------------

/** The histogram of the standardized S_n at checkpoint g, against N(0, 1). */
function cltHistogram(M, g, decimal = '.') {
  const pt = M.points[g];
  const d = displayOf(pt, M.mom, 'standardized');
  const range = [-4.2, 4.2];
  const h = latticeHistogram({ counts: pt.counts, pmf: pt.pmf, valueOf: d.valueOf, spacing: d.spacing, range, target: 40 });
  return { ...h, curve: normalCurve(0, 1, h.width, range), normal: { mean: 0, sd: 1 }, xTicks: [-4, -2, 0, 2, 4], decimal };
}

/** The normal quantile plot at checkpoint g: 199 quantiles of the standardized S_n against those of N(0, 1). */
function qqData(M, g, decimal = '.') {
  const pt = M.points[g];
  const d = displayOf(pt, M.mom, 'standardized');
  const m = pt.sample.m;
  const Q = Math.min(199, m);
  const points = [];
  let k = 0;
  let cumulative = pt.counts[0];
  for (let i = 1; i <= Q; i++) {
    const prob = (i - 0.5) / Q;
    while (cumulative < prob * m && k < pt.counts.length - 1) {
      k++;
      cumulative += pt.counts[k];
    }
    points.push([hw.normalQuantile(prob), d.valueOf(k)]);
  }
  return { points, lo: -3.6, hi: 3.6, ticks: [-3, -2, -1, 0, 1, 2, 3], decimal };
}

/** Skewness and excess kurtosis of S_n: exact (cumulants: kappa3 / sigma^3 sqrt(n), kappa4 / sigma^4 n) and simulated. */
function shapeAt(M, g) {
  const pt = M.points[g];
  return {
    n: pt.n,
    skewness: pt.sample.skewness,
    excess: pt.sample.kurtosis - 3,
    theorySkewness: M.mom.skewness / Math.sqrt(pt.n),
    theoryExcess: M.mom.kappa4 / (M.mom.variance ** 2 * pt.n),
    ks: pt.ks,
    ksCorrected: pt.ksCorrected,
    distance: pt.distance,
    distanceCorrected: pt.distanceCorrected,
  };
}

/** The exact Kolmogorov distance from the normal along n, the Berry-Esseen bound, the simulated distances and the noise of the simulation. */
function distanceChart(M, m, decimal = '.') {
  const { ns, distance, corrected, bound } = M.curve;
  const at = new Map(M.points.map((pt) => [pt.n, pt]));
  const noise = hw.KS_MEAN / Math.sqrt(m);
  return {
    x: ns,
    logX: true,
    logY: true,
    yMin: 1e-6,
    yMax: 1,
    yTicks: [1e-6, 1e-4, 1e-2, 1],
    xTicks: powerTicks(ns[ns.length - 1]),
    decimal,
    series: [
      { values: distance, colorIndex: 1, dots: false, fixed: true },
      { values: corrected, colorIndex: 2, dots: false, fixed: true },
      { values: bound, colorIndex: 3, dashed: true, fixed: true },
      { values: ns.map((n) => (at.has(n) ? at.get(n).ks : null)), colorIndex: 0, dotsOnly: true },
      { values: ns.map(() => noise), colorIndex: 6, dotted: true, fixed: true },
    ],
  };
}

/** The distances at n along the exact curve. */
function curveAt(M, n) {
  const i = M.curve.ns.indexOf(n);
  return i < 0 ? null : { distance: M.curve.distance[i], corrected: M.curve.corrected[i], bound: M.curve.bound[i] };
}

/** The table of section 5.3: the drift of S_n/sqrt(n) in the Bernoulli model and the skewness that fades. */
const driftRows = (M) =>
  M.points.map((pt) => ({
    n: pt.n,
    mean: M.mom.mu * Math.sqrt(pt.n),
    sampleMean: pt.sample.mean / Math.sqrt(pt.n),
    skewness: M.mom.skewness / Math.sqrt(pt.n),
    sampleSkewness: pt.sample.skewness,
    distance: pt.distance,
  }));

/** The smallest n with n p (1 - p) >= 10, the usual rule for the normal approximation of the binomial. */
const normalRule = (mom) => Math.ceil(10 / mom.variance - 1e-9);

/** How many observations a Kolmogorov-Smirnov test needs to see a distance d: about (1/d)^2. */
const neededFor = (d) => Math.ceil(1 / (d * d));

/** The targets of section 2.3: a probability within 10% and a variance within 5%, both at 95%. */
const M_TARGET = Object.freeze({ z: 1.959963984540054, relative: 0.1, varianceRelative: 0.05 });

/** How many attackers estimate a probability P within the relative error of M_TARGET: m >= z^2 (1 - P)/(r^2 P); one for P = 1, none is enough for P = 0. */
const neededForProbability = (P) => (P >= 1 ? 1 : P > 0 ? Math.ceil((M_TARGET.z ** 2 * (1 - P)) / (M_TARGET.relative ** 2 * P)) : Infinity);

/** How many attackers estimate the variance of S_n within 5%, for S_n about normal: m >= 2 (z/r)^2, the same at every n. */
const neededForVariance = () => Math.ceil(2 * (M_TARGET.z / M_TARGET.varianceRelative) ** 2);

/** The table of section 2.3: at every n the exact probability of section 3 and the exact distance from the normal of section 5, with the attackers each one needs. */
function choiceRows(s, epsilon) {
  const rows = llnRows(s, epsilon);
  const R = s.models.rademacher;
  return rows.bernoulli.map((b, i) => {
    const r = rows.rademacher[i];
    const d = R.points[i].distance;
    return { n: b.n, pB: b.exact, mB: neededForProbability(b.exact), pR: r.exact, mR: neededForProbability(r.exact), d, mD: neededFor(d) };
  });
}

/** The largest n of the grid up to which a column of the table needs at most m attackers (null if not even the first). */
function enoughUpTo(rows, key, m) {
  let last = null;
  for (const r of rows) {
    if (r[key] > m) break;
    last = r.n;
  }
  return last;
}

// ---------------------------------------------------------------------------
// Sistemi e attaccanti
// ---------------------------------------------------------------------------

/** The share of the first `even` systems spent ahead, over the attackers, against Feller's law and the arcsine density. */
function arcsineChart(W, decimal = '.') {
  const N = W.even / 2;
  const h = latticeHistogram({ counts: W.arcsine, pmf: W.arcsineLaw, valueOf: (k) => k / N, spacing: 1 / N, range: [0, 1], target: 40 });
  // the density is infinite at 0 and 1: averaged over windows as wide as the bars, inside [0, 1]
  const curve = [];
  const w = h.width;
  for (let i = 0; i <= 400; i++) {
    const x = w / 2 + (i * (1 - w)) / 400;
    curve.push([x, (hw.arcsineCdf(x + w / 2) - hw.arcsineCdf(x - w / 2)) / w]);
  }
  return { ...h, curve, xTicks: [0, 0.25, 0.5, 0.75, 1], decimal };
}

/** The best of b attackers, standardized: simulated with its 95% interval, exact, the normal maximum and sqrt(2 ln b). */
function bestChart(G, decimal = '.') {
  const rows = G.rows;
  const values = rows.flatMap((r) => [r.mean - 1.96 * r.error, r.mean + 1.96 * r.error, r.exact, r.asymptote]);
  const lo = Math.min(-0.3, ...values);
  const hi = Math.max(...values) + 0.3;
  return {
    x: rows.map((r) => r.b),
    logX: true,
    yMin: Math.floor(lo * 2) / 2,
    yMax: Math.ceil(hi * 2) / 2,
    yTicks: hw.niceTicks(Math.floor(lo * 2) / 2, Math.ceil(hi * 2) / 2, 6),
    xTicks: powerTicks(rows[rows.length - 1].b),
    decimal,
    series: [
      { values: rows.map((r) => r.mean), band: rows.map((r) => [r.mean - 1.96 * r.error, r.mean + 1.96 * r.error]), colorIndex: 0 },
      { values: rows.map((r) => r.exact), colorIndex: 1, dots: false, fixed: true },
      { values: rows.map((r) => r.normal), colorIndex: 2, dashed: true, fixed: true },
      { values: rows.map((r) => r.asymptote), colorIndex: 3, dotted: true, fixed: true },
    ],
  };
}

/** At least one of b attackers beyond mean + 3 sd, and the systems hit by at least one of the first b: simulated and exact. */
function probabilityChart(G, decimal = '.') {
  const rows = G.rows;
  return {
    x: rows.map((r) => r.b),
    logX: true,
    yMin: 0,
    yMax: 1,
    yTicks: [0, 0.25, 0.5, 0.75, 1],
    xTicks: powerTicks(rows[rows.length - 1].b),
    decimal,
    series: [
      { values: rows.map((r) => r.beyond), colorIndex: 0, dotsOnly: true },
      { values: rows.map((r) => r.beyondExact), colorIndex: 0, dashed: true, fixed: true },
      { values: rows.map((r) => r.coverage), colorIndex: 2, dotsOnly: true },
      { values: rows.map((r) => r.coverageExact), colorIndex: 2, dashed: true, fixed: true },
    ],
  };
}

/** The row of a group size b, if the run has it. */
const groupRow = (G, b) => G.rows.find((r) => r.b === b) || null;

/** How many attackers have hit each system (Bernoulli), against Bin(m, p). */
function systemsChart(M, decimal = '.') {
  const A = M.aggregate;
  const m = M.params.m;
  const mean = m * M.mom.hit;
  const sd = Math.sqrt(m * M.mom.hit * (1 - M.mom.hit));
  const range = [Math.max(-0.5, mean - 4.5 * sd), Math.min(m + 0.5, mean + 4.5 * sd)];
  const h = latticeHistogram({ counts: A.perSystem, pmf: A.systemLaw, valueOf: (k) => k, spacing: 1, range, target: 40 });
  return { ...h, curve: normalCurve(mean, sd, h.width, range), normal: { mean, sd }, xTicks: hw.niceTicks(range[0], range[1], 5), decimal };
}

/** The aggregate score of all attackers on all systems, with its z-score. */
function aggregateFacts(M) {
  const A = M.aggregate;
  return { total: A.total, expected: A.expected, sd: A.sd, z: (A.total - A.expected) / A.sd, perSystemMean: A.systemSample.mean, perSystemVariance: A.systemSample.variance, systemMean: M.params.m * M.mom.hit, systemVariance: M.params.m * M.mom.hit * (1 - M.mom.hit) };
}

// ---------------------------------------------------------------------------
// Test
// ---------------------------------------------------------------------------

const TEST_GROUPS = ['sim', 'lln', 'clt', 'walk'];

const statTests = hw.statisticalTests;

/**
 * The verdict each test should give. Most null hypotheses are true by
 * construction, and must not be rejected; the tests at n = 10 and some
 * normality tests have a false null hypothesis, and reject when the test
 * sees the difference: for Kolmogorov-Smirnov when sqrt(m) times the exact
 * distance is well above the critical value, for Jarque-Bera when
 * m (g1^2/6 + g2^2/24), the expected excess of the statistic, is large. In
 * between the outcome depends on the sample: "either".
 */
function expectedVerdicts(s) {
  const B = s.models.bernoulli;
  const R = s.models.rademacher;
  const m = s.params.m;
  const n = s.params.n;
  const last = (M) => M.points[M.points.length - 1];
  const small = (M) => M.points[pointIndex(M, hw.SMALL_N)];
  const ks = (d) => {
    const lambda = Math.sqrt(m) * d;
    if (lambda > 2.2) return 'reject';
    return lambda < 0.6 ? 'notReject' : 'either';
  };
  const jb = (mom, size) => {
    const g1 = mom.skewness / Math.sqrt(size);
    const g2 = mom.kappa4 / (mom.variance ** 2 * size);
    const excess = m * ((g1 * g1) / 6 + (g2 * g2) / 24);
    if (excess > 25) return 'reject';
    return excess < 1 ? 'notReject' : 'either';
  };
  return {
    sim: { bernoulliPairs: 'notReject', rademacherPairs: 'notReject', bernoulliSystems: 'notReject' },
    lln: { bernoulliMean: 'notReject', rademacherMean: 'notReject', bernoulliVariance: 'notReject', rademacherVariance: 'notReject' },
    clt: {
      bernoulliExact: 'notReject',
      rademacherExact: 'notReject',
      rademacherNormal: ks(last(R).distanceCorrected),
      rademacherSmall: ks(small(R).distance),
      rademacherJb: jb(R.mom, n),
      bernoulliJb: jb(B.mom, n),
      bernoulliSmall: jb(B.mom, hw.SMALL_N),
    },
    walk: { arcsine: 'notReject' },
  };
}

/**
 * Every test with its expected verdict, and the counts of the summary:
 * rejections, outcomes as expected, and Holm's correction on the tests whose
 * null hypothesis holds (the p-values in increasing order against alpha/K,
 * alpha/(K - 1), ...: rejections that survive it are unlikely to be chance).
 */
function testSummary(s) {
  const expected = expectedVerdicts(s);
  const tests = hw.statisticalTests(s);
  const all = TEST_GROUPS.flatMap((group) => tests[group].map(([key, result]) => ({ group, key, result, expected: expected[group][key] })));
  const rejected = all.filter((t) => t.result.verdict === 'reject').length;
  const asExpected = all.filter((t) => t.expected === 'either' || t.expected === t.result.verdict).length;
  const nulls = all.filter((t) => t.expected === 'notReject');
  const sorted = nulls.map((t) => t.result.pValue).sort((a, b) => a - b);
  let holm = 0;
  while (holm < sorted.length && sorted[holm] <= hw.SIGNIFICANCE / (sorted.length - holm)) holm++;
  const falseRejections = nulls.filter((t) => t.result.verdict === 'reject');
  return { all, count: all.length, rejected, asExpected, nulls: nulls.length, falseRejections, holm, holmThreshold: hw.SIGNIFICANCE / Math.max(1, sorted.length) };
}

// ---------------------------------------------------------------------------
// Etichette dei grafici
// ---------------------------------------------------------------------------

const normalShare = (normal, from, to) => (normal ? hw.normalCdf((to - normal.mean) / normal.sd) - hw.normalCdf((from - normal.mean) / normal.sd) : null);

/** The texts under the pointer: functions of the hit, built from the data of a chart and the words of a language (T = text.tips). */
// ---------------------------------------------------------------------------
// Le legende dei grafici, per la pagina e per il programma scaricabile: ogni
// voce { label, color, dashed?, parts } e' un pulsante che nasconde le sue
// parti del disegno (`hidden` dei dati di ogni grafico, o setHidden()
// dell'animazione); i grafici dei due modelli affiancati hanno una legenda sola
// ---------------------------------------------------------------------------

const seriesItem = (label, color, i, extra = {}) => ({ label, color, parts: [`series:${i}`], ...extra });
const partItem = (label, color, part, extra = {}) => ({ label, color, parts: [part], ...extra });

// a histogram against a law: the simulation, the exact law (dashed) and the continuous curve
const histogramItems = (labels) => [partItem(labels[0], 0, 'bars'), partItem(labels[1], 1, 'expected', { dashed: true }), partItem(labels[2], 2, 'curve')];

const legends = {
  trajectories: (text) => [
    partItem(text.trajectories.legend[0], 0, 'others'),
    partItem(text.trajectories.legend[1], 1, 'first'),
    partItem(text.trajectories.legend[2], 2, 'band', { dashed: true }),
    partItem(text.trajectories.legend[3], 3, 'envelope', { dashed: true }),
  ],
  sweep: (text) => histogramItems(text.sweep.legend),
  lln: (text) => [
    seriesItem(text.convergence.legend[0], 0, 0),
    seriesItem(text.convergence.legend[1], 2, 1),
    seriesItem(text.convergence.legend[2], 3, 2, { dashed: true }),
    seriesItem(text.convergence.legend[3], 4, 3, { dashed: true }),
  ],
  // the three quantities, each with its simulated points and its exact line; the last item is all the exact lines
  variance: (text) => [
    { label: text.variance.legend[0], color: 0, parts: ['series:0', 'series:1'] },
    { label: text.variance.legend[1], color: 1, parts: ['series:2', 'series:3'] },
    { label: text.variance.legend[2], color: 2, parts: ['series:4', 'series:5'] },
    // 'theory': the column of the exact slopes in the table, which only this item hides
    { label: text.variance.legend[3], color: 6, dashed: true, parts: ['series:1', 'series:3', 'series:5', 'theory'] },
  ],
  clt: (text) => histogramItems(text.normal.legend),
  qq: (text) => [partItem(text.normal.qqLegend[0], 0, 'points'), partItem(text.normal.qqLegend[1], 1, 'line', { dashed: true })],
  speed: (text) => [
    seriesItem(text.speed.legend[0], 1, 0),
    seriesItem(text.speed.legend[1], 2, 1),
    seriesItem(text.speed.legend[2], 3, 2, { dashed: true }),
    seriesItem(text.speed.legend[3], 0, 3),
    seriesItem(text.speed.legend[4], 6, 4, { dashed: true }),
  ],
  arcsine: (text) => histogramItems(text.size.arcsineLegend),
  best: (text) => [
    seriesItem(text.attackers.bestLegend[0], 0, 0),
    seriesItem(text.attackers.bestLegend[1], 1, 1),
    seriesItem(text.attackers.bestLegend[2], 2, 2, { dashed: true }),
    seriesItem(text.attackers.bestLegend[3], 3, 3, { dashed: true }),
  ],
  probability: (text) => [
    seriesItem(text.attackers.probabilityLegend[0], 0, 0),
    seriesItem(text.attackers.probabilityLegend[1], 0, 1, { dashed: true }),
    seriesItem(text.attackers.probabilityLegend[2], 2, 2),
    seriesItem(text.attackers.probabilityLegend[3], 2, 3, { dashed: true }),
  ],
  systems: (text) => histogramItems(text.aggregate.systemsLegend),
};

/** Whether series i of a chart is on screen: the reader can hide it from the legend. */
const seriesOn = (hidden, i) => !hidden.includes(`series:${i}`);

/**
 * The labels under the pointer, one factory per chart: each returns
 * (hit, hidden) => text, where `hidden` lists the parts of the chart that
 * the reader turned off in the legend, and the label leaves them out.
 */
const tips = {
  // the animation: the words for a bar of its histogram or a system of its trajectories (hit.show: what is on screen)
  trajectory: (text) => (hit) => text.tips.trajectory(hit, text.trajectoryNames[hit.quantity]),
  histogram: (h, T) => (hit, hidden = []) => {
    const b = h.bars[hit.index];
    return b ? T.bin(b.from, b.to, b.share, h.expected && !hidden.includes('expected') ? b.prob : null, hidden.includes('curve') ? null : normalShare(h.normal, b.from, b.to)) : null;
  },
  arcsine: (h, T) => (hit, hidden = []) => {
    const b = h.bars[hit.index];
    return b ? T.share(Math.max(0, b.from), Math.min(1, b.to), b.share, hidden.includes('expected') ? null : b.prob, hidden.includes('curve') ? null : hw.arcsineCdf(b.to) - hw.arcsineCdf(b.from)) : null;
  },
  lln: (rows, T) => (hit, hidden = []) => T.lln(rows[hit.index], { rate: seriesOn(hidden, 0), exact: seriesOn(hidden, 1), chebyshev: seriesOn(hidden, 2), hoeffding: seriesOn(hidden, 3) }),
  variance: (M, T) => (hit, hidden = []) => {
    const pt = M.points[hit.index];
    return T.variance(
      pt.n,
      hw.QUANTITIES.map((q, i) => {
        const sample = seriesOn(hidden, 2 * i) ? pt.sample.variance * hw.quantityScale(q, pt.n) ** 2 : null;
        const exact = seriesOn(hidden, 2 * i + 1) ? hw.quantityMoments(M.mom, pt.n, q).variance : null;
        return sample === null && exact === null ? null : [sample, exact];
      }),
    );
  },
  distance: (M, T) => (hit, hidden = []) => {
    const n = M.curve.ns[hit.index];
    const pt = M.points.find((x) => x.n === n);
    const pick = (i, v) => (seriesOn(hidden, i) ? v : null);
    return T.distance(n, pick(0, M.curve.distance[hit.index]), pick(1, M.curve.corrected[hit.index]), pick(2, M.curve.bound[hit.index]), pt ? pick(3, pt.ks) : null);
  },
  qq: (q, T) => (hit) => {
    const [a, b] = q.points[hit.index];
    return T.qq(a, b);
  },
  best: (G, T) => (hit, hidden = []) => T.best(G.rows[hit.index], { mean: seriesOn(hidden, 0), exact: seriesOn(hidden, 1), normal: seriesOn(hidden, 2), asymptote: seriesOn(hidden, 3) }),
  probability: (G, T) => (hit, hidden = []) => T.probability(G.rows[hit.index], { beyond: seriesOn(hidden, 0), beyondExact: seriesOn(hidden, 1), coverage: seriesOn(hidden, 2), coverageExact: seriesOn(hidden, 3) }),
};

// ---------------------------------------------------------------------------
// Tabelle legate ai grafici
// ---------------------------------------------------------------------------

/** The id of every table tied to a chart: the page and the program find it by id. */
const LINKED_TABLES = Object.freeze({ lln: 'hw3-lln-table' });

/**
 * The links of hw.attachChartTooltip, { table, row, point }: the point
 * under the pointer marks its row of the table, and a row under the
 * pointer outlines its point. The table of section 3 has one row per
 * point of both charts, in the same order.
 */
const links = {
  lln: Object.freeze({ table: () => document.getElementById(LINKED_TABLES.lln), row: (hit) => hit.index, point: (row) => row }),
};

// ---------------------------------------------------------------------------
// Disegno a fette
// ---------------------------------------------------------------------------

// Quando arrivano i risultati molti grafici vanno disegnati insieme: si
// disegnano qualcuno per fotogramma, entro pochi millisecondi, cosi' la
// pagina continua a rispondere.
const frameJobs = [];
let frameRequested = false;

function runFrameJobs() {
  const start = Date.now();
  while (frameJobs.length && Date.now() - start < 8) frameJobs.shift()();
  frameRequested = frameJobs.length > 0;
  if (frameRequested) requestAnimationFrame(runFrameJobs);
}

/** Draws a chart at the next free moment: a few per frame, within 8 milliseconds. */
function scheduleFrameJob(job) {
  frameJobs.push(job);
  if (!frameRequested) {
    frameRequested = true;
    requestAnimationFrame(runFrameJobs);
  }
}

return { SECTIONS, tocEntries, FIELD_LENGTH, DEFAULT_PARAMS, fieldsOf, DEFAULT_INPUTS, readInputs, sameParams, applyInputs, allValid, paramsKey, parseParamsKey, inputBadge, ANIMATION, animationOptions, displayOf, latticeHistogram, normalCurve, sweepRange, sweepChart, quantityStats, pointIndex, momentRows, momentFacts, powerTicks, exceedance, reveal, llnRows, llnChart, llnFacts, varianceChart, varianceFits, VARIANCE_SLOPES, cltHistogram, qqData, shapeAt, distanceChart, curveAt, driftRows, normalRule, neededFor, M_TARGET, neededForProbability, neededForVariance, choiceRows, enoughUpTo, arcsineChart, bestChart, probabilityChart, groupRow, systemsChart, aggregateFacts, TEST_GROUPS, statTests, expectedVerdicts, testSummary, legends, tips, LINKED_TABLES, links, scheduleFrameJob };
})();

var texts$ = (function () {
'use strict';

// src/pages/statistics/hw3/texts.js
// I testi dell'Homework #3 in italiano e in inglese. Li usano sia la pagina
// del sito sia il programma scaricabile, cosi' le due versioni dicono le
// stesse cose con le stesse parole. Ogni numero arriva dagli argomenti (i
// risultati della simulazione, la tolleranza scelta) o dalle costanti della
// libreria: nessuna frase contiene un risultato scritto a mano.
const { BERRY_ESSEEN_C, DEFAULT_M, DEFAULT_N, DEFAULT_P, DEFAULT_SEED, KS_MEAN, LIMITS, SIGNIFICANCE, SMALL_N, expectedMaxDiscrete } = Homework3;
const { M_TARGET, aggregateFacts, choiceRows, curveAt, enoughUpTo, groupRow, llnFacts, llnRows, momentFacts, neededFor, neededForVariance, normalRule, varianceFits } = view$;

/** Number formatting of one language: decimal and thousands separators, the "not available" marker, the multiplication sign. */
function formatters(decimal, thousands, na, times) {
  const local = (s) => (decimal === '.' ? s : s.replace('.', decimal));
  const missing = (v) => v === null || v === undefined || Number.isNaN(v);
  const group = (digits) => digits.replace(/\B(?=(\d{3})+(?!\d))/g, thousands);
  const sci = (v, digits = 1) => {
    if (missing(v)) return na;
    if (v === 0) return '0';
    const e = Math.floor(Math.log10(Math.abs(v)));
    let mant = v / 10 ** e;
    let exp = e;
    if (Number(Math.abs(mant).toFixed(digits)) >= 10) {
      mant /= 10;
      exp += 1;
    }
    return `${local(mant.toFixed(digits))} ${times} 10^${exp}`;
  };
  // fixed decimals, with the thousands grouped: 2828.4 -> 2.828,4 in Italian
  const num = (v, digits = 3) => {
    if (missing(v)) return na;
    const [whole, part] = Math.abs(v).toFixed(digits).split('.');
    const negative = v < 0 && Math.abs(v) >= 0.5 * 10 ** -digits;
    return `${negative ? '-' : ''}${group(whole)}${part ? `${decimal}${part}` : ''}`;
  };
  return {
    na,
    decimal,
    int: (v) => (missing(v) ? na : `${v < 0 ? '-' : ''}${group(String(Math.round(Math.abs(Number(v)))))}`),
    num,
    // a number with as many decimals as typed (a parameter): 0.2 -> 0,2
    plain: (v) => (missing(v) ? na : local(String(v))),
    pval: (v) => (missing(v) ? na : v === 0 ? `< ${local('1e-300')}` : v < 0.001 ? sci(v) : local(v.toFixed(3))),
    pct: (v, digits = 1) => (missing(v) ? na : `${local((100 * v).toFixed(digits))}%`),
    // a probability with four decimals, or "< 0.0001"
    prob: (v) => (missing(v) ? na : v < 1e-4 && v > 0 ? `< ${local('0.0001')}` : local(v.toFixed(4))),
    // a small positive number: four decimals, or powers of ten below 10^-4
    small: (v, digits = 4) => (missing(v) ? na : v === 0 ? '0' : Math.abs(v) < 10 ** -digits ? sci(v) : local(v.toFixed(digits))),
    sci,
    ms: (v) => (missing(v) ? na : v >= 1000 ? `${local((v / 1000).toFixed(2))} s` : `${Math.max(1, Math.round(v))} ms`),
  };
}

/**
 * The assignment as the professor wrote it, block by block. The only
 * change is the minus sign, written "-" as everywhere on this site.
 */
const originalAssignment = () => [
  { type: 'p', text: 'HMWK ==> Consider n systems and m attackers. Model the penetration process using a stochastic process with independent and identically distributed increments X₁, X₂, …, representing the penetration score at each step. Consider two possible models for the score:' },
  { type: 'p', text: 'Bernoulli model: Xᵢ ∈ {0,1}, with P(Xᵢ = 1) = p.' },
  { type: 'p', text: 'Rademacher model: Xᵢ ∈ {-1,+1}, with P(Xᵢ = +1) = P(Xᵢ = -1) = 1/2. This second model is introduced to study the symmetric, zero-mean case.' },
  { type: 'p', text: 'For increasing values of n and suitable choices of m, simulate multiple sample trajectories and study the distributions of the following three quantities:' },
  { type: 'p', text: 'Total score: Sₙ = ∑ᵢ₌₁ⁿ Xᵢ' },
  { type: 'p', text: 'Average score: Sₙ/n = (1/n)∑ᵢ₌₁ⁿ Xᵢ' },
  { type: 'p', text: 'Normalized total score: Sₙ/√n = (1/√n)∑ᵢ₌₁ⁿ Xᵢ' },
  {
    type: 'p',
    text: 'Compare the behavior of these quantities as n increases. In particular, investigate the convergence in probability of Sₙ/n according to the Law of Large Numbers, the behavior of the variance under the different normalizations, and the convergence in distribution of Sₙ/√n to a standard normal distribution in the Rademacher case, according to the Central Limit Theorem. Interpret the simulated trajectories in the context of the n systems and m attackers, discussing how the system size and number of attackers affect the aggregate penetration score.',
  },
];

// ---------------------------------------------------------------------------
// I numeri che i testi citano, calcolati una volta dai risultati
// ---------------------------------------------------------------------------

const lastOf = (M) => M.points[M.points.length - 1];
const lawOf = (pt) => ({ n: pt.n, low: pt.low, step: pt.step, pmf: pt.pmf });

/** Section 5.2: the exact distances at n = 100 and at the last n, and how close Berry-Esseen is. */
function speedFacts(s) {
  const B = s.models.bernoulli;
  const R = s.models.rademacher;
  const N = s.params.n;
  const n100 = N >= 100 ? 100 : N;
  const r100 = curveAt(R, n100);
  const rN = curveAt(R, N);
  const b100 = curveAt(B, n100);
  const bN = curveAt(B, N);
  const noise = KS_MEAN / Math.sqrt(s.params.m);
  return { N, n100, r100, rN, b100, bN, noise, ratio: rN.bound / rN.distance - 1, need: neededFor(rN.distance), symmetric: Math.abs(1 - 2 * s.params.p) < 1e-9 };
}

/** Section 6: the Bernoulli score at n, the walk, the best of b attackers and the coverage. */
function interpretationFacts(s) {
  const B = s.models.bernoulli;
  const R = s.models.rademacher;
  const N = s.params.n;
  const mom = B.mom;
  const law = lawOf(lastOf(B));
  const scale = mom.sigma * Math.sqrt(N);
  const best = (b) => (expectedMaxDiscrete(law, b) - N * mom.mu) / scale;
  const tail = B.groups.tail;
  const atLeast = (b) => 1 - (1 - tail) ** b;
  const sd100 = Math.sqrt(Math.min(100, N) * mom.variance);
  return {
    N,
    m: s.params.m,
    p: s.params.p,
    np: N * mom.mu,
    sd: scale,
    n100: Math.min(100, N),
    sd100,
    rel100: sd100 / (Math.min(100, N) * mom.mu),
    relN: scale / (N * mom.mu),
    walk: R.walk,
    typical: Math.sqrt((2 * N) / Math.PI),
    best10: best(10),
    best100: best(100),
    best1000: best(1000),
    tail,
    atLeast100: atLeast(100),
    atLeast1000: atLeast(1000),
    cover5: 1 - (1 - mom.hit) ** 5,
    cover20: 1 - (1 - mom.hit) ** 20,
    row5: groupRow(B.groups, 5),
    row20: groupRow(B.groups, 20),
    b95: Math.ceil(Math.log(0.05) / Math.log(1 - mom.hit) - 1e-9),
    aggregate: aggregateFacts(B),
    systems: B.tests.systems,
  };
}

/** The digits of a value of each quantity: S_n with one decimal, S_n/n with four, S_n/sqrt(n) with three. */
const DIGITS = { sum: 1, mean: 4, normalized: 3 };

// ---------------------------------------------------------------------------
// ITALIANO
// ---------------------------------------------------------------------------

/**
 * The labels under the pointer list only what is on screen: `show` says
 * which parts of the chart the reader has not hidden from the legend (a
 * missing key counts as shown), and a label with nothing left is null.
 */
const on = (show, key) => !show || show[key] !== false;
const said = (head, items, sep = ', ') => {
  const kept = items.filter(Boolean);
  return kept.length ? `${head}: ${kept.join(sep)}` : null;
};

const IT = formatters(',', '.', 'n/d', '×');

/** A number of attackers: digits, powers of ten when huge, ∞ when no number is enough. */
const countIt = (v) => (!Number.isFinite(v) ? '∞' : v >= 1e7 ? IT.sci(v) : IT.int(v));

/** The line of numbers under a hypothesis test, whatever its kind. */
function testLineIt(t) {
  const F = IT;
  switch (t.kind) {
    case 'chi2':
      return `χ² = ${F.num(t.chi2, 1)} su ${F.int(t.classes)} classi (${F.int(t.df)} gradi di libertà), p = ${F.pval(t.pValue)}`;
    case 'independence':
      return `χ² = ${F.num(t.chi2, 2)} su una tabella 2 × 2 di ${F.int(t.N)} coppie (1 grado di libertà), V di Cramér = ${F.num(t.cramerV, 5)}, p = ${F.pval(t.pValue)}`;
    case 'mean':
      return `media ${F.num(t.mean, 5)} contro ${F.num(t.expected, 5)}, z = ${F.num(t.z, 2)}, p = ${F.pval(t.pValue)}`;
    case 'variance':
      return `varianza ${F.num(t.variance, 1)} contro ${F.num(t.expected, 1)} (rapporto ${F.num(t.ratio, 4)}), z = ${F.num(t.z, 2)}, p = ${F.pval(t.pValue)}`;
    case 'ks':
      return `D = ${F.num(t.D, 4)} su ${F.int(t.m)} attaccanti, √m D = ${F.num(t.lambda, 2)}, p = ${F.pval(t.pValue)}${t.corrected ? ' (con la correzione di continuità; contro una legge discreta il test è conservativo)' : ''}`;
    case 'jb':
      return `asimmetria ${F.num(t.skewness, 3)}, curtosi in eccesso ${F.num(t.excessKurtosis, 3)}, JB = ${F.num(t.statistic, 2)} (χ² con 2 gradi di libertà), p = ${F.pval(t.pValue)}`;
    default:
      return `p = ${F.pval(t.pValue)}`;
  }
}

/** A value of a quantity, with the digits of that quantity. */
const valueIt = (v, quantity) => IT.num(v, DIGITS[quantity]);

/** A width in the units of an axis, with the decimals it needs. */
const edgeDigits = (from, to) => {
  const w = Math.abs(to - from);
  if (w >= 10) return 0;
  if (w >= 1) return 1;
  if (w >= 0.1) return 2;
  return w >= 0.01 ? 3 : 4;
};

const it = {
  fmt: IT,
  ui: {
    index: 'Indice',
    indexTitle: 'Indice dell’homework',
    close: 'Chiudi',
    backToTop: 'Torna su',
    computing: 'Simulazione in corso...',
    language: 'Lingua',
    error: (m) => `Errore: ${m}`,
  },
  sections: {
    assignment: '0. La consegna',
    model: '1. TASK: sistemi, attaccanti e il processo di penetrazione',
    models: '1.1 I due modelli del punteggio',
    quantities: '1.2 Le tre grandezze',
    input: '1.3 Sistemi, attaccanti e seme',
    trajectories: '1.4 Le traiettorie, sistema dopo sistema',
    verify: '1.5 Verifiche',
    distributions: '2. Le distribuzioni con sempre più sistemi',
    sweep: '2.1 Gli istogrammi, punto per punto',
    moments: '2.2 Medie e varianze',
    choice: '2.3 Quanti attaccanti servono',
    lln: '3. La legge dei grandi numeri',
    convergence: '3.1 La convergenza in probabilità del punteggio medio',
    bounds: '3.2 Chebyshev, Hoeffding e la normale',
    strong: '3.3 Legge debole e legge forte',
    variance: '4. La varianza sotto le tre normalizzazioni',
    clt: '5. Il teorema del limite centrale',
    normal: '5.1 Rademacher: la somma normalizzata verso la normale',
    speed: '5.2 Quanto è veloce la convergenza',
    bernoulli: '5.3 Bernoulli: cosa converge e cosa no',
    interpretation: '6. Sistemi e attaccanti: l’interpretazione',
    size: '6.1 Più sistemi',
    attackers: '6.2 Più attaccanti',
    aggregate: '6.3 Il punteggio aggregato',
    limits: '6.4 I limiti del modello',
    tests: '7. Riepilogo dei test statistici',
    history: '8. Contesto storico',
    conclusion: '9. Conclusioni',
  },
  assignment: {
    intro: [
      'La consegna chiede di modellare con un processo stocastico la penetrazione di m attaccanti su n sistemi: a ogni passo un attaccante ottiene un punteggio X_i, e i punteggi X_1, X_2, ... sono indipendenti e identicamente distribuiti. I modelli sono due: Bernoulli, in cui X_i vale 1 con probabilità p e 0 altrimenti, e Rademacher, in cui vale +1 o -1 con probabilità 1/2, il caso simmetrico a media nulla. Per n crescenti e m scelti in modo adatto si simulano molte traiettorie e si studiano le distribuzioni del punteggio totale S_n, del punteggio medio S_n/n e del punteggio totale normalizzato S_n/√n: la convergenza in probabilità di S_n/n (legge dei grandi numeri), la varianza sotto le tre normalizzazioni e la convergenza in distribuzione di S_n/√n alla normale standard nel caso di Rademacher (teorema del limite centrale). Infine si interpretano le traiettorie nel contesto dei sistemi e degli attaccanti, discutendo come la dimensione del sistema e il numero di attaccanti influenzano il punteggio aggregato.',
      'La sezione 1 precisa il modello, ne anima le traiettorie e verifica il simulatore; la 2 mostra le distribuzioni delle tre grandezze al crescere di n e quanti attaccanti servono per ogni n; la 3 è dedicata alla legge dei grandi numeri, la 4 alla varianza, la 5 al teorema del limite centrale e alla velocità della convergenza; la 6 interpreta i risultati per sistemi e attaccanti. La 7 riassume i test statistici, la 8 colloca le idee nel tempo e la 9 trae le conclusioni. Tutti i numeri sono calcolati nel browser, e il programma scaricabile stampa gli stessi. I grafici si muovono: si ingrandiscono (Ctrl + rotella, oppure un rettangolo trascinato; doppio clic per tornare alla vista intera), e quelli che seguono n o il numero di attaccanti disegnano la simulazione punto per punto, con i valori esatti e i limiti fermi come riferimento.',
    ],
    originalTitle: 'Il testo originale della consegna',
    originalNote: 'Com’è stato assegnato, in inglese. L’unica modifica è il segno meno, scritto "-" come in tutto il sito.',
  },
  model: {
    intro: [
      'Ogni attaccante affronta i sistemi uno dopo l’altro: sul sistema i ottiene il punteggio X_i, e dopo k sistemi il suo punteggio è S_k = X_1 + ... + X_k. La traiettoria k ↦ S_k è un cammino aleatorio, e gli m attaccanti sono m copie indipendenti dello stesso cammino. In questa lettura n è la lunghezza delle traiettorie, cioè quanti sistemi affronta ogni attaccante, e m è la dimensione del campione, cioè quante traiettorie si osservano per stimare le distribuzioni.',
      'La consegna non dice in che modo n e m entrino nel processo, e la pagina li fissa così per una ragione precisa: la somma S_n = X_1 + ... + X_n corre sui passi del processo, quindi n conta i passi di un attaccante, cioè i sistemi che affronta; gli attaccanti non compaiono nella somma, e sono le sue ripetizioni indipendenti, cioè il campione. L’altra lettura possibile, in cui per ogni sistema si sommano i punteggi degli m attaccanti, è la stessa tabella m × n di esiti letta per colonne: la sezione 6.3 mostra che per i colpi di ciascun sistema valgono gli stessi teoremi, con m al posto di n. Le conclusioni quindi non dipendono dalla lettura scelta; cambia solo quale indice si chiama n.',
      'L’ipotesi i.i.d. dice due cose: i sistemi sono ugualmente difficili, perché ogni X_i ha la stessa legge, e l’esito su un sistema non dice nulla sugli altri, perché gli X_i sono indipendenti. In altre parole l’attaccante non impara e i sistemi non condividono vulnerabilità: la sezione 6.4 discute quanto sia realistico e cosa cambia senza.',
    ],
    formulasTitle: 'Il modello in formule',
    formulas: [
      'Incrementi    X_1, X_2, ... i.i.d.,  E[X] = μ,  Var(X) = σ²',
      'Bernoulli     X ∈ {0, 1},    P(X = 1) = p          μ = p,  σ² = p(1 - p)',
      'Rademacher    X ∈ {-1, +1},  P(X = +1) = 1/2       μ = 0,  σ² = 1',
      'Traiettoria   S_0 = 0,  S_k = S_(k-1) + X_k,  k = 1, ..., n',
      'Grandezze     S_n,  S_n/n,  S_n/√n',
    ].join('\n'),
  },
  models: {
    intro: [
      'Nel modello di Bernoulli X_i vale 1 se l’attaccante penetra il sistema i e 0 se fallisce: S_n conta i sistemi penetrati e segue la legge binomiale Bin(n, p), e S_n/n è la frazione di sistemi penetrati. Nel modello di Rademacher X_i vale +1 o -1: l’attaccante guadagna o perde terreno con la stessa probabilità, come in una partita alla pari con chi difende (un accesso ottenuto o revocato, un privilegio guadagnato o perso). Se K è il numero di passi in avanti, S_n = K - (n - K) = 2K - n con K ~ Bin(n, 1/2): è il cammino aleatorio semplice simmetrico.',
      'I due modelli sono parenti stretti: se B vale 1 con probabilità 1/2, allora 2B - 1 è Rademacher. Più in generale la standardizzazione (X - μ)/σ porta qualunque incremento a media 0 e varianza 1. Il modello di Rademacher è il caso in cui l’incremento è già standardizzato, ed è per questo che la consegna lo usa per il teorema del limite centrale.',
    ],
    tableTitle: (p) => `I momenti di un incremento, con p = ${IT.plain(p)}`,
    cols: { model: 'Modello', values: 'Valori', mu: 'Media μ', variance: 'Varianza σ²', rho: 'E|X - μ|³', skewness: 'Asimmetria' },
    after: [
      'La media e la varianza bastano alla legge dei grandi numeri e al teorema del limite centrale; il momento E|X - μ|³ entra nel limite di Berry-Esseen sulla velocità della convergenza (sezione 5.2); l’asimmetria, (1 - 2p)/√(p(1 - p)) per Bernoulli, spiega perché con p lontano da 1/2 la convergenza alla normale è più lenta.',
    ],
  },
  quantities: {
    intro: [
      'Per somme di variabili indipendenti le medie e le varianze si sommano: E[S_n] = nμ e Var(S_n) = nσ². Dividere per una costante c divide la media e la deviazione standard per c, e la varianza per c². La tabella dà i valori esatti delle tre grandezze: la variabile è sempre la stessa, cambia l’unità di misura con cui la si guarda.',
    ],
    tableTitle: 'Media, varianza e deviazione standard esatte',
    cols: { quantity: 'Grandezza', mean: 'Media', variance: 'Varianza', sd: 'Deviazione standard', trend: 'Al crescere di n' },
    rows: [
      ['S_n', 'nμ', 'nσ²', 'σ√n', 'cresce: per Bernoulli la media come n e la deviazione standard come √n, per Rademacher solo la deviazione standard'],
      ['S_n/n', 'μ', 'σ²/n', 'σ/√n', 'si concentra su μ: la varianza tende a 0'],
      ['S_n/√n', 'μ√n', 'σ²', 'σ', 'la varianza resta σ²: per Rademacher la legge si stabilizza, per Bernoulli la media μ√n cresce senza limite'],
    ],
    after: [
      'La seconda riga è la legge dei grandi numeri, la terza il teorema del limite centrale. Dividere per n schiaccia la variabilità, non dividere la lascia crescere, e √n è l’unica scala intermedia che la mantiene finita e diversa da zero: è il motivo per cui la consegna chiede proprio queste tre normalizzazioni.',
    ],
  },
  input: {
    intro: `I valori iniziali sono p = ${IT.plain(DEFAULT_P)} (in media un attaccante penetra un sistema su ${Math.round(1 / DEFAULT_P)}), n = ${IT.int(DEFAULT_N)} sistemi, m = ${IT.int(DEFAULT_M)} attaccanti e il seme ${DEFAULT_SEED}. Ogni attaccante ha un generatore suo, xoshiro128**, con lo stato ricavato da SplitMix64 a partire dal seme, dal modello e dal numero dell’attaccante: con lo stesso seme la pagina, l’animazione e node homework3.js vedono gli stessi attaccanti e stampano gli stessi numeri. Più sistemi allungano le traiettorie già simulate, più attaccanti si aggiungono ai primi senza cambiarli. Ogni modifica ripete la simulazione, che con i valori iniziali conta ${IT.int(2 * DEFAULT_N * DEFAULT_M)} incrementi; il tempo impiegato compare sotto i campi.`,
    pLabel: `Probabilità di penetrazione p, modello di Bernoulli (da ${IT.plain(LIMITS.p[0])} a ${IT.plain(LIMITS.p[1])})`,
    pHint: 'Con la virgola o con il punto: 0,2 e 0.2 sono lo stesso valore. Il modello di Rademacher non dipende da p.',
    nLabel: `Sistemi n (da ${IT.int(LIMITS.n[0])} a ${IT.int(LIMITS.n[1])})`,
    nHint: 'La lunghezza delle traiettorie. Le grandezze si osservano a n = 1, 2, 5, 10, 20, 50, ... e all’ultimo sistema.',
    mLabel: `Attaccanti m (da ${IT.int(LIMITS.m[0])} a ${IT.int(LIMITS.m[1])})`,
    mHint: 'Le traiettorie simulate per ogni modello. Una probabilità si stima con un errore di circa 1/√m, e una distanza fra leggi sotto 0,87/√m non si distingue dal rumore.',
    seedLabel: `Seme (da 0 a ${IT.int(LIMITS.seed[1])})`,
    seedHint: 'Lo stesso seme dà gli stessi attaccanti, qui e nel terminale (node homework3.js --seed ...).',
    randomSeed: 'Seme casuale',
    errors: {
      empty: () => 'Scrivi un valore.',
      notInteger: (t) => `"${t}" non è un intero scritto in cifre decimali.`,
      notNumber: (t) => `"${t}" non è un numero.`,
      range: (lo, hi) => `Il valore va da ${lo} a ${hi}.`,
    },
    limits: {
      p: [IT.plain(LIMITS.p[0]), IT.plain(LIMITS.p[1])],
      n: [IT.int(LIMITS.n[0]), IT.int(LIMITS.n[1])],
      m: [IT.int(LIMITS.m[0]), IT.int(LIMITS.m[1])],
      seed: [IT.int(LIMITS.seed[0]), IT.int(LIMITS.seed[1])],
    },
    defaultBadge: `Valori iniziali: p = ${IT.plain(DEFAULT_P)}, n = ${IT.int(DEFAULT_N)} sistemi, m = ${IT.int(DEFAULT_M)} attaccanti, seme ${DEFAULT_SEED}.`,
    customBadge: 'Valori diversi da quelli iniziali.',
    restore: 'Ripristina i valori iniziali',
    stale: 'Finché un campo contiene un errore, la pagina usa il suo ultimo valore valido.',
    pending: 'Simulazione in corso con i nuovi valori: le sezioni seguenti si aggiornano appena finisce.',
    run: (s) => `Simulati ${IT.int(2 * s.params.m * s.params.n)} incrementi (${IT.int(s.params.m)} attaccanti, ${IT.int(s.params.n)} sistemi, 2 modelli) e calcolate le leggi esatte in ${IT.ms(s.ms)}.`,
  },
  trajectories: {
    intro: (shown, sample) => [
      `L’animazione mostra il processo mentre accade. A sinistra le traiettorie dei primi ${IT.int(shown)} attaccanti, sistema dopo sistema, con il primo in rosso; a destra l’istogramma dei valori di ${IT.int(sample)} attaccanti al sistema corrente, con la curva della legge normale che ha la stessa media e la stessa deviazione standard. La fascia verde è media ± 2 deviazioni standard, la linea tratteggiata verde la media e quella punteggiata gialla l’inviluppo della legge del logaritmo iterato, kμ ± σ√(2k ln ln k), nelle unità della grandezza scelta.`,
      'Si possono scegliere il modello e la grandezza. Con S_k la fascia si allarga come √k; con S_k/k si stringe attorno a μ, ed è la legge dei grandi numeri; con S_k/√k ha larghezza costante, ed è la scala del teorema del limite centrale. L’animazione si apre sull’ultimo sistema: Avvia la fa ripartire dal primo, Un sistema avanza di un passo.',
    ],
    modelLabel: 'Modello',
    quantityLabel: 'Grandezza',
    speedLabel: 'Velocità',
    speeds: ['lenta', 'normale', 'veloce'],
    play: 'Avvia',
    pause: 'Pausa',
    resume: 'Riprendi',
    step: 'Un sistema',
    reset: 'Dall’inizio',
    end: 'Alla fine',
    legend: ['traiettorie e istogramma dei valori', 'attaccante 1', 'media (tratteggio), media ± 2σ (fascia), legge normale (curva)', 'inviluppo del logaritmo iterato'],
    caption: (st, quantityName) =>
      st.k === 0
        ? `Sistema 0 di ${IT.int(st.n)}: nessun sistema ancora attaccato.`
        : `Sistema ${IT.int(st.k)} di ${IT.int(st.n)}. ${quantityName}: media sui ${IT.int(st.sample)} attaccanti ${valueIt(st.mean, st.quantity)} (esatta ${valueIt(st.theoryMean, st.quantity)}), deviazione standard ${valueIt(st.sd, st.quantity)} (esatta ${valueIt(st.theorySd, st.quantity)}); fuori dalla fascia il ${IT.pct(st.outside)}, contro circa il 4,6% di una normale. Attaccante 1: ${valueIt(st.first, st.quantity)}.`,
    after: [
      'Guardata con S_k, la nuvola delle traiettorie è un ventaglio che si apre come √k: per Rademacher attorno allo zero, per Bernoulli attorno alla retta kp, che alla scala di n fa sembrare il ventaglio una sola linea. Con S_k/k lo stesso ventaglio, diviso per k, si chiude su μ: ogni attaccante finisce per penetrare una frazione dei sistemi vicina a p. Con S_k/√k le traiettorie restano in una fascia di larghezza costante e l’istogramma a destra smette di cambiare forma: è la campana del teorema del limite centrale.',
      'Le singole traiettorie però non si calmano mai. Escono e rientrano dalla fascia, e continuano a farlo: la legge del logaritmo iterato (Khinchin, 1924) dice che i loro massimi crescono un po’ più di √k, come √(2k ln ln k), e che quasi ogni traiettoria si avvicina al suo inviluppo infinite volte. La fascia descrive gli attaccanti a un sistema fissato, l’inviluppo il percorso di ciascuno.',
    ],
  },
  verify: {
    intro: 'Prima di fidarsi della simulazione, le sue parti vengono confrontate con valori calcolati altrove. Le uscite di xoshiro128** e SplitMix64 e i punteggi di due attaccanti dopo 10.000 sistemi vengono dal codice C di riferimento dei due generatori, compilato con gcc; le leggi e le funzioni speciali (normale, binomiale, χ², Kolmogorov, arcoseno, massimo di normali, Jarque-Bera) da SciPy 1.17.1.',
    summary: (ok, total) => `${ok} verifiche su ${total} superate.`,
    details: (n) => `Mostra le ${n} verifiche`,
    groups: { generator: 'Generatore (codice C di riferimento)', functions: 'Leggi e funzioni speciali (SciPy 1.17.1)' },
    cols: { check: 'Verifica', expected: 'Atteso', result: 'Esito' },
    ok: 'superata',
    failed: 'fallita',
  },
  distributions: {
    intro: [
      'A n fissato le tre grandezze hanno la stessa forma: un istogramma di S_n/n è un istogramma di S_n con un altro asse. Le distingue il modo in cui cambiano al crescere di n. Per vederlo l’asse di S_n/n e quello di S_n/√n restano gli stessi per ogni n; quello di S_n segue la distribuzione, che altrimenti per n piccoli sarebbe una sola barra al margine.',
    ],
  },
  sweep: {
    intro: [
      'Il cursore sceglie n fra i punti in cui le traiettorie vengono osservate; Avvia li scorre in ordine. Le barre sono le frazioni degli m attaccanti divise per la larghezza della barra, cioè densità; il tratteggio rosso è la legge esatta di S_n sulle stesse barre e la curva verde la normale con la stessa media e la stessa varianza. Ogni barra contiene un numero intero di valori possibili di S_n: per n piccoli i valori sono pochi e si vedono uno per uno.',
    ],
    quantityLabel: 'Grandezza',
    nLabel: (n) => `n = ${IT.int(n)}`,
    play: 'Avvia',
    pause: 'Pausa',
    chart: (model, quantity, n, m) => `${model}: istogramma di ${quantity} con n = ${IT.int(n)}, sui ${IT.int(m)} attaccanti`,
    legend: ['simulazione', 'legge esatta di S_n', 'normale con la stessa media e la stessa varianza'],
    stats: (model, st, quantity) => `${model}, n = ${IT.int(st.n)}: media ${valueIt(st.mean, quantity)} (esatta ${valueIt(st.theoryMean, quantity)}), deviazione standard ${valueIt(st.sd, quantity)} (esatta ${valueIt(st.theorySd, quantity)}).`,
    after: [
      'Con S_n le campane si spostano e si allargano: per Bernoulli la media np cresce come n e la deviazione standard solo come √n, per Rademacher la media resta 0 e la larghezza cresce come √n. Con S_n/n le stesse campane si stringono fino a una sola barra sopra μ: è la convergenza in probabilità della sezione 3. Con S_n/√n la larghezza resta la stessa: per Rademacher la campana smette di muoversi e coincide con N(0, 1), per Bernoulli trasla verso destra, perché la media p√n cresce senza limite.',
      'Per n piccoli nessuna delle tre somiglia a una normale: con n = 1 la legge ha due soli valori, e per Bernoulli con p lontano da 1/2 è anche asimmetrica. La legge esatta e la simulazione invece coincidono sempre, entro le fluttuazioni di un campione di m attaccanti: è la prima verifica che il simulatore realizza il modello.',
    ],
  },
  moments: {
    intro: 'Le medie e le varianze campionarie sugli m attaccanti, accanto ai valori esatti. Bastano la media di S_n/n e la varianza di S_n/√n: le altre si ottengono moltiplicando o dividendo per n.',
    tableTitle: 'Media campionaria di S_n/n e varianza campionaria di S_n/√n, valori esatti fra parentesi',
    cols: { n: 'n', bMean: 'Bernoulli: media di S_n/n', bVar: 'Bernoulli: varianza di S_n/√n', rMean: 'Rademacher: media di S_n/n', rVar: 'Rademacher: varianza di S_n/√n' },
    after: (s) => {
      const f = momentFacts(s);
      return [
        `Le medie campionarie di S_n/n distano da μ al più ${IT.num(f.meanZ, 1)} errori standard, dove l’errore standard è σ/√(nm); le varianze campionarie di S_n/√n distano da σ² al più il ${IT.pct(f.varRel)}, contro un errore relativo tipico di √(2/m) = ${IT.pct(f.expectedRel)}. Sono le differenze che ci si aspetta da ${IT.int(s.params.m)} attaccanti, e i test della sezione 3 lo verificano a n = ${IT.int(s.params.n)}.`,
        'Le colonne mostrano già i due teoremi: la media di S_n/n resta su μ per ogni n mentre la sua varianza, σ²/n, scende verso zero; la varianza di S_n/√n resta σ² per ogni n.',
      ];
    },
  },
  choice: {
    intro: [
      'La consegna chiede di simulare per n crescenti con scelte adatte di m. Che cosa sia adatto dipende da che cosa si vuole vedere, e si calcola prima di simulare: una frazione stimata su m attaccanti ha un errore che scende come 1/√m, quindi a ogni domanda corrisponde un numero minimo di attaccanti, e quel numero dipende da n.',
    ],
    formulasTitle: 'Gli attaccanti necessari, al 95%',
    formulas: [
      `${`Probabilità P, errore relativo del ${IT.pct(M_TARGET.relative, 0)}`.padEnd(40)} m ≥ z² (1 - P)/(r² P) ≈ ${IT.num(M_TARGET.z ** 2 / M_TARGET.relative ** 2, 0)} (1 - P)/P`,
      `${'Distanza D dalla normale'.padEnd(40)} m ≥ (1/D)²;  per Rademacher D ≈ 1/√(2πn), quindi m ≈ 2πn ≈ ${IT.num(2 * Math.PI, 1)} n`,
      `${`Varianza, errore relativo del ${IT.pct(M_TARGET.varianceRelative, 0)}`.padEnd(40)} m ≥ 2 (z/r)² = ${IT.int(neededForVariance())}, a ogni n`,
    ].join('\n'),
    tableTitle: (eps, m) => `Gli attaccanti necessari a ogni n, con ε = ${IT.num(eps, 2)}; in rosso quando servono più dei ${IT.int(m)} attaccanti simulati`,
    cols: { n: 'n', pB: 'Bernoulli: P(|S_n/n - μ| > ε)', mB: 'm necessario', pR: 'Rademacher: P(|S_n/n - μ| > ε)', mR: 'm necessario', d: 'Rademacher: distanza D dalla normale', mD: 'm necessario' },
    count: (v) => countIt(v),
    after: (s, eps) => {
      const rows = choiceRows(s, eps);
      const m = s.params.m;
      const last = rows[rows.length - 1];
      const reach = (key) => {
        const n = enoughUpTo(rows, key, m);
        if (n === null) return 'per nessun n della griglia';
        return n === last.n ? `a ogni n, fino a ${IT.int(n)}` : `fino a n = ${IT.int(n)}`;
      };
      const mVar = neededForVariance();
      return [
        `Con i ${IT.int(m)} attaccanti simulati la probabilità della legge dei grandi numeri si stima con un errore del ${IT.pct(M_TARGET.relative, 0)} ${reach('mB')} per Bernoulli e ${reach('mR')} per Rademacher. Oltre, l’evento diventa troppo raro per un campione: a n = ${IT.int(last.n)} servirebbero ${countIt(last.mB)} e ${countIt(last.mR)} attaccanti. Il numero necessario cresce come 1/P, e P scende in modo esponenziale con n (Hoeffding, sezione 3.2): per n grandi nessuna m è adatta, e la probabilità si calcola esattamente dalla legge binomiale.`,
        `La differenza fra S_n/√n e la normale si vede ${reach('mD')}: la distanza vale circa 1/√(2πn), quindi servono circa 2πn attaccanti, ${countIt(last.mD)} a n = ${IT.int(last.n)}. Qui la m adatta cresce in proporzione a n, e con meno attaccanti la simulazione non distingue S_n/√n dalla normale anche quando la differenza c’è. Per la varianza invece bastano ${IT.int(mVar)} attaccanti a ogni n${m >= mVar ? `, e i ${IT.int(m)} simulati bastano` : `, più dei ${IT.int(m)} simulati`}.`,
        'Una sola m non è adatta a tutte le domande e a tutti gli n. La pagina usa gli stessi attaccanti a ogni n, così le traiettorie sono traiettorie vere e le distribuzioni ai diversi n sono quelle degli stessi attaccanti più avanti; la tabella dice per ogni domanda fin dove arriva la simulazione e da dove servono i calcoli esatti. Con il campo m della sezione 1.3 si vede il confine spostarsi: quadruplicare gli attaccanti dimezza gli errori.',
      ];
    },
  },
  lln: {
    intro: [
      'La legge (debole) dei grandi numeri dice che per ogni ε > 0 la probabilità P(|S_n/n - μ| > ε) tende a 0 quando n cresce: il punteggio medio converge in probabilità a μ. Qui quella probabilità si stima con la frazione di attaccanti che dopo n sistemi distano da μ più di ε, la si confronta con il valore esatto, calcolato dalla legge binomiale, e con due disuguaglianze che la limitano dall’alto senza conoscere la legge.',
    ],
  },
  convergence: {
    intro: 'Il cursore cambia ε, e grafici e tabella lo seguono. Le bande attorno ai punti sono intervalli di Wilson al 95%, che restano dentro [0, 1] anche quando la frazione osservata è 0.',
    epsilonLabel: (eps) => `Tolleranza ε = ${IT.num(eps, 2)}`,
    chart: (model, eps) => `${model}: P(|S_n/n - μ| > ${IT.num(eps, 2)}) al crescere di n (asse di n logaritmico)`,
    legend: ['simulazione, con intervallo di Wilson al 95%', 'valore esatto', 'limite di Chebyshev', 'limite di Hoeffding'],
    tableTitle: (eps) => `P(|S_n/n - μ| > ${IT.num(eps, 2)}): frazione di attaccanti (intervallo al 95%) e valore esatto`,
    cols: { n: 'n', simulated: 'simulata (95%)', exact: 'esatta' },
    after: (s, eps) => {
      const rows = llnRows(s, eps);
      const fB = llnFacts(rows.bernoulli);
      const fR = llnFacts(rows.rademacher);
      const N = IT.int(s.params.n);
      const from = (f, model) => `da n = ${IT.int(f.below)} per ${model}`;
      let below;
      if (fB.below !== null && fR.below !== null) below = `scende sotto l’1% ${from(fB, 'Bernoulli')} e ${from(fR, 'Rademacher')}`;
      else if (fB.below !== null) below = `scende sotto l’1% ${from(fB, 'Bernoulli')}, mentre per Rademacher non ci scende entro n = ${N}`;
      else if (fR.below !== null) below = `scende sotto l’1% ${from(fR, 'Rademacher')}, mentre per Bernoulli non ci scende entro n = ${N}`;
      else below = `non scende sotto l’1% entro n = ${N} in nessuno dei due modelli`;
      const rise = fB.rises ? ['Bernoulli', fB.rises] : fR.rises ? ['Rademacher', fR.rises] : null;
      const sB = s.models.bernoulli.mom.sigma;
      const out = [
        `Con ε = ${IT.num(eps, 2)} la probabilità esatta ${below}. Conta il rapporto fra ε e la deviazione standard di un incremento: la probabilità dipende da n attraverso ε√n/σ, e σ vale ${IT.num(sB, 3)} per Bernoulli e 1 per Rademacher.`,
      ];
      if (rise) {
        out.push(`Per n piccoli la discesa non è regolare: per ${rise[0]} la probabilità passa da ${IT.num(rise[1].from.exact, 4)} a n = ${IT.int(rise[1].from.n)} a ${IT.num(rise[1].to.exact, 4)} a n = ${IT.int(rise[1].to.n)}. S_n/n assume solo valori distanti ${rise[0] === 'Bernoulli' ? '1/n' : '2/n'} l’uno dall’altro, e finché questo passo è più largo di ε conta quanti valori cadono vicino a μ, non quanto è grande n.`);
      }
      out.push(`La simulazione segue il valore esatto finché la probabilità è più grande di 1/m = ${IT.small(1 / s.params.m)}; sotto, quasi sempre nessun attaccante supera ε, la frazione osservata è 0 e resta solo il limite superiore dell’intervallo di Wilson, ${IT.num(fB.last.interval[1], 4)}. È il primo senso in cui m va scelto in modo adatto: per stimare una probabilità P servono molti più di 1/P attaccanti, e per n grandi restano il calcolo esatto e i limiti della sezione 3.2.`);
      return out;
    },
  },
  bounds: {
    paras: (s, eps) => {
      const rows = llnRows(s, eps);
      const lb = rows.bernoulli[rows.bernoulli.length - 1];
      const lr = rows.rademacher[rows.rademacher.length - 1];
      const n0 = (M) => IT.int(Math.ceil(M.mom.variance / (eps * eps) - 1e-9));
      return [
        `Disuguaglianza di Chebyshev: P(|S_n/n - μ| > ε) ≤ σ²/(nε²). È la legge debole dimostrata in una riga, perché Var(S_n/n) = σ²/n; vale per qualunque legge con varianza finita, ma decresce solo come 1/n, e finché n < σ²/ε² supera 1 e non dice nulla: con ε = ${IT.num(eps, 2)} fino a n = ${n0(s.models.bernoulli)} per Bernoulli e ${n0(s.models.rademacher)} per Rademacher.`,
        `Disuguaglianza di Hoeffding (1963): se gli incrementi stanno in un intervallo di ampiezza b - a, P(|S_n/n - μ| > ε) ≤ 2 exp(-2nε²/(b - a)²), con b - a = 1 per Bernoulli e 2 per Rademacher. Decresce in modo esponenziale, come la probabilità vera: a n = ${IT.int(lb.n)} Chebyshev dà ${IT.small(lb.chebyshev)} e Hoeffding ${IT.small(lb.hoeffding)} per Bernoulli, contro un valore esatto di ${IT.small(lb.exact)}; per Rademacher ${IT.small(lr.chebyshev)}, ${IT.small(lr.hoeffding)} e ${IT.small(lr.exact)}.`,
        'La normale approssima la stessa probabilità con 2(1 - Φ(ε√n/σ)): è il teorema del limite centrale usato per la legge dei grandi numeri. Al centro della distribuzione è precisa, ma nelle code il suo errore relativo cresce, e lì servono le stime di grandi deviazioni (Cramér, Chernoff), che danno il tasso esponenziale esatto. I due limiti valgono sempre e la normale no: è il prezzo della generalità.',
      ];
    },
  },
  strong: {
    paras: [
      'La legge forte dei grandi numeri, di Borel (1909) per le prove di Bernoulli e di Kolmogorov (1933) in generale, dice di più: con probabilità 1 la traiettoria S_k/k di ogni attaccante converge a μ. La legge debole è un’affermazione sulla distribuzione di S_n/n a n fissato, quella degli istogrammi della sezione 2; la forte è un’affermazione su ogni traiettoria, quella dell’animazione della sezione 1.4 con S_k/k: ogni attaccante, prima o poi, entra nella fascia μ ± ε e non ne esce più.',
      'La differenza non è solo formale. La convergenza in probabilità permetterebbe a ogni traiettoria di uscire dalla fascia infinite volte, purché sempre più di rado; quella quasi certa lo esclude. Per un difensore la prima dice che a un istante fissato quasi tutti gli attaccanti hanno una frazione di successi vicina a p, la seconda che ognuno di loro, da un certo sistema in poi, resterà vicino a p per sempre.',
    ],
  },
  variance: {
    intro: 'La varianza delle tre grandezze, campionaria (punti) ed esatta (tratteggio), su scale logaritmiche in entrambi gli assi: una legge di potenza n^a diventa una retta di pendenza a.',
    chart: (model) => `${model}: varianza di S_n, S_n/n e S_n/√n al crescere di n (scale logaritmiche)`,
    legend: ['S_n', 'S_n/n', 'S_n/√n', 'valori esatti (tratteggio)'],
    fitTitle: 'Pendenza di log Var contro log n, stimata con i minimi quadrati',
    fitCols: { quantity: 'Grandezza', bernoulli: 'Bernoulli', rademacher: 'Rademacher', theory: 'Teoria' },
    after: (s) => {
      const fits = varianceFits(s);
      const slopes = (f) => `${IT.num(f.sum, 3)}, ${IT.num(f.mean, 3)} e ${IT.num(f.normalized, 3)} (± ${IT.num(f.error, 3)})`;
      return [
        `Var(S_n) = nσ² cresce, Var(S_n/n) = σ²/n tende a zero, Var(S_n/√n) = σ² resta costante: è la regola Var(cX) = c² Var(X) con c = 1, 1/n e 1/√n. Le rette hanno pendenze 1, -1 e 0; le pendenze stimate sono ${slopes(fits.bernoulli)} per Bernoulli e ${slopes(fits.rademacher)} per Rademacher.`,
        'Le tre stime però non sono tre prove indipendenti: la varianza campionaria di S_n/n è esattamente quella di S_n divisa per n², quindi le tre pendenze differiscono esattamente di 2 e di 1, e l’informazione è una sola, Var(S_n) proporzionale a n. L’errore della pendenza è quello dei minimi quadrati, che tratta i punti come indipendenti; qui non lo sono, perché a ogni n gli attaccanti sono gli stessi, e l’incertezza vera è un po’ più grande.',
        'Con una normalizzazione qualsiasi n^α, Var(S_n/n^α) = σ² n^(1 - 2α): tende a infinito per α < 1/2, a zero per α > 1/2, e resta finita e positiva solo per α = 1/2. √n è l’unica scala a cui la variabilità di S_n resta visibile, ed è la scala del teorema del limite centrale.',
      ];
    },
  },
  clt: {
    intro: [
      'Il teorema del limite centrale (Lindeberg e Lévy, per incrementi i.i.d. con varianza finita) dice che (S_n - nμ)/(σ√n) converge in distribuzione a N(0, 1): per ogni x, P((S_n - nμ)/(σ√n) ≤ x) → Φ(x). Nel modello di Rademacher μ = 0 e σ = 1, quindi la grandezza standardizzata è proprio S_n/√n, il caso che la consegna chiede di studiare. Nel modello di Bernoulli S_n/√n non converge (sezione 5.3): converge la versione centrata e scalata, (S_n - np)/√(np(1 - p)).',
    ],
  },
  normal: {
    intro: 'Istogramma e grafico quantile-quantile della grandezza standardizzata, per ogni n. Nel grafico quantile-quantile ogni punto confronta un quantile della simulazione con lo stesso quantile di N(0, 1): se le due leggi coincidono, i punti stanno sulla diagonale. Per n piccoli i punti formano gradini, perché S_n ha pochi valori.',
    modelLabel: 'Grandezza',
    models: { rademacher: 'Rademacher: S_n/√n', bernoulli: 'Bernoulli: (S_n - np)/√(np(1 - p))' },
    nLabel: (n) => `n = ${IT.int(n)}`,
    histChart: (label, n) => `${label} con n = ${IT.int(n)}: istogramma e densità di N(0, 1)`,
    qqChart: (label, n) => `${label} con n = ${IT.int(n)}: quantili simulati contro quantili di N(0, 1)`,
    legend: ['simulazione', 'legge esatta', 'N(0, 1)'],
    qqLegend: ['quantili simulati', 'diagonale: le due leggi coincidono'],
    stats: (sh) => `n = ${IT.int(sh.n)}: asimmetria ${IT.num(sh.skewness, 3)} (esatta ${IT.num(sh.theorySkewness, 3)}), curtosi in eccesso ${IT.num(sh.excess, 3)} (esatta ${IT.num(sh.theoryExcess, 3)}); distanza di Kolmogorov dalla normale: simulata ${IT.num(sh.ks, 4)}, esatta ${IT.num(sh.distance, 4)}, esatta con la correzione di continuità ${IT.small(sh.distanceCorrected)}.`,
    after: [
      'Si vedono due cose. La prima: anche per Rademacher, che è simmetrico, la legge di S_n/√n per n piccoli è a gradini, perché S_n ha solo n + 1 valori, distanti 2/√n dopo la standardizzazione. Per n pari la funzione di ripartizione salta di P(S_n = 0) ≈ √(2/(πn)) nello zero, e nessuna funzione continua può starle più vicina di metà del salto, circa 1/√(2πn).',
      'La seconda: la convergenza non dipende dalla forma della legge degli incrementi. Due valori soli, discreti, in un caso asimmetrici: basta che la varianza sia finita, e la somma standardizzata diventa normale. È ciò che rende la normale la legge di riferimento per ogni punteggio aggregato.',
    ],
  },
  speed: {
    intro: `Quanto è vicina alla normale la somma standardizzata, per ogni n? La distanza di Kolmogorov sup_x |F_n(x) - Φ(x)| si calcola esattamente dalla legge binomiale (linee) e si stima dalla simulazione (punti). Il teorema di Berry-Esseen la limita con C E|X - μ|³/(σ³√n), dove C ≤ ${IT.num(BERRY_ESSEEN_C, 4)} (Shevtsova, 2011).`,
    chart: (model) => `${model}: distanza di Kolmogorov dalla normale al crescere di n (scale logaritmiche)`,
    legend: ['esatta', 'esatta, con la correzione di continuità', 'limite di Berry-Esseen', 'simulata (Kolmogorov-Smirnov)', 'rumore della simulazione, 0,87/√m'],
    after: (s) => {
      const f = speedFacts(s);
      const p = IT.plain(s.params.p);
      return [
        `Per Rademacher la distanza esatta vale ${IT.num(f.r100.distance, 4)} a n = ${IT.int(f.n100)} e ${IT.small(f.rN.distance)} a n = ${IT.int(f.N)}: decresce come 1/√n, e quasi esattamente come 1/√(2πn) ≈ 0,399/√n, metà del salto nello zero. Il limite di Berry-Esseen, ${IT.num(BERRY_ESSEEN_C, 4)}/√n, le sta sopra di appena il ${IT.pct(f.ratio, 0)}: per una legge a due valori il teorema è quasi ottimale. Con la correzione di continuità, cioè confrontando la normale a metà strada fra due valori possibili, la distanza scende a ${IT.small(f.rN.corrected)}, un ordine 1/n: per somme di Rademacher l’errore della normale è quasi tutto dovuto al reticolo.`,
        f.symmetric
          ? `Con p = ${p} anche la binomiale di Bernoulli è simmetrica: la distanza vale ${IT.num(f.b100.distance, 4)} a n = ${IT.int(f.n100)}, e con la correzione di continuità scende a ${IT.small(f.b100.corrected)}, come per Rademacher.`
          : `Per Bernoulli con p = ${p} la distanza è più grande (${IT.num(f.b100.distance, 4)} a n = ${IT.int(f.n100)}), perché al reticolo si aggiunge l’asimmetria della binomiale, (1 - 2p)/√(np(1 - p)), che la correzione di continuità non elimina: corretta, la distanza vale ${IT.num(f.b100.corrected, 4)}, ancora di ordine 1/√n.`,
        `La distanza simulata segue quella esatta finché questa supera il rumore della simulazione, circa 0,87/√m = ${IT.num(f.noise, 4)} con m = ${IT.int(s.params.m)}; sotto, i punti si appiattiscono sul rumore. È il secondo senso in cui m va scelto in modo adatto: per vedere una differenza d fra due leggi servono almeno (1/d)² attaccanti, circa ${IT.int(f.need)} per la distanza esatta a n = ${IT.int(f.N)}.`,
      ];
    },
  },
  bernoulli: {
    intro: 'Per Bernoulli S_n/√n ha media p√n e varianza p(1 - p): la varianza resta finita, come per Rademacher, ma la media cresce senza limite, e la legge scivola verso destra senza fermarsi (sezione 2.1). Il teorema del limite centrale si applica alla grandezza centrata: (S_n - np)/√n converge a N(0, p(1 - p)), e (S_n - np)/√(np(1 - p)) a N(0, 1), il teorema di de Moivre e Laplace.',
    tableTitle: 'Bernoulli: la deriva di S_n/√n e l’asimmetria che si attenua',
    cols: { n: 'n', mean: 'E[S_n/√n] = p√n', sampleMean: 'Media simulata', skewness: 'Asimmetria esatta', sampleSkewness: 'Asimmetria simulata', distance: 'Distanza esatta dalla normale' },
    after: (s) => {
      const M = s.models.bernoulli;
      const N = s.params.n;
      return [
        `L’asimmetria della binomiale, (1 - 2p)/√(np(1 - p)), tende a zero come 1/√n: con p = ${IT.plain(s.params.p)} vale ${IT.num(M.mom.skewness / Math.sqrt(SMALL_N), 3)} a n = ${SMALL_N} e ${IT.num(M.mom.skewness / Math.sqrt(N), 4)} a n = ${IT.int(N)}. Quando p è piccolo e np resta moderato la normale approssima male, e la binomiale somiglia piuttosto alla legge di Poisson di media np (Poisson, 1837): con sistemi molto difficili da penetrare il numero di successi di un attaccante resta piccolo e asimmetrico anche per n grandi. La regola pratica np(1 - p) ≥ 10, per usare la normale, qui chiede n ≥ ${IT.int(normalRule(M.mom))}.`,
        'Per l’interpretazione la differenza fra i due modelli è importante: nel modello di Bernoulli lo spostamento p√n di S_n/√n è il punteggio che l’attaccante accumula in media, ed è quello che conta; le fluttuazioni attorno, di ordine 1, sono il rumore. Nel modello di Rademacher non c’è spostamento, e le fluttuazioni sono tutto.',
      ];
    },
  },
  interpretation: {
    intro: ['Tornando agli attaccanti e ai sistemi: cosa cambia con più sistemi, cosa con più attaccanti, e come si comporta il punteggio aggregato di tutti.'],
  },
  size: {
    paras: (s) => {
      const f = interpretationFacts(s);
      const W = f.walk;
      return [
        `Più sistemi rendono prevedibile la frazione, non il totale. Nel modello di Bernoulli un attaccante penetra in media np sistemi, con una deviazione standard di √(np(1 - p)): con n = ${IT.int(f.N)} sono ${IT.num(f.np, 0)} ± ${IT.num(f.sd, 1)}. In valore assoluto l’incertezza cresce (da ${IT.num(f.sd100, 1)} sistemi a n = ${IT.int(f.n100)} a ${IT.num(f.sd, 1)} a n = ${IT.int(f.N)}), in proporzione cala (dal ${IT.pct(f.rel100)} al ${IT.pct(f.relN)} della media). Per chi difende un’infrastruttura grande è una buona notizia a metà: la quota di sistemi compromessi è quasi certa, il loro numero no.`,
        `Nel modello di Rademacher la media è zero, ma le traiettorie non restano vicine allo zero. Il valore tipico di |S_n| è √(2n/π) ≈ ${IT.num(f.typical, 1)}, e il massimo raggiunto lungo la strada ha in media lo stesso ordine: ${IT.num(W.maximumExact, 1)} esatto, dal principio di riflessione, e ${IT.num(W.maximum, 1)} nella simulazione. Il cammino torna in zero in media solo ${IT.num(W.zerosExact, 1)} volte in ${IT.int(f.N)} passi (${IT.num(W.zeros, 1)} nella simulazione): i pareggi sono rari, e in proporzione lo diventano sempre di più, come √n su n.`,
        `La legge dell’arcoseno (Lévy, 1939) dice quanto tempo un attaccante passa in vantaggio. L’intuizione direbbe circa la metà; invece la quota di tempo in vantaggio ha densità 1/(π√(x(1 - x))), alta vicino a 0 e a 1 e bassa nel mezzo: chi passa in vantaggio tende a restarci a lungo. Fra gli attaccanti simulati, il ${IT.pct(W.extreme)} è stato dalla stessa parte per più del 90% dei primi ${IT.int(W.even)} sistemi (esatto ${IT.pct(W.extremeExact)}, legge limite ${IT.pct(W.extremeLimit)}), contro il 20% che darebbe una quota uniforme.`,
      ];
    },
    arcsineChart: (even, m) => `Rademacher: quota dei primi ${IT.int(even)} sistemi in cui l’attaccante è in vantaggio, sui ${IT.int(m)} attaccanti`,
    arcsineLegend: ['simulazione', 'legge esatta (Feller)', 'densità dell’arcoseno'],
    after: ['È la lezione più controintuitiva di questa sezione: in un confronto alla pari, un attaccante in vantaggio per migliaia di sistemi di fila non è un indizio di bravura, è il comportamento normale del caso. Lo stesso vale per un difensore che "vince" a lungo.'],
  },
  attackers: {
    intro: 'Il numero di attaccanti non cambia la legge del punteggio di ognuno: cambia quanto bene la si stima (sezioni 3 e 5) e, soprattutto, cosa fa il migliore. Per vederlo gli m attaccanti del modello di Bernoulli vengono divisi in gruppi di b, e in ogni gruppo si guarda il massimo dei punteggi finali standardizzati, (S_n - np)/√(np(1 - p)).',
    bestChart: (n) => `Bernoulli, n = ${IT.int(n)}: il miglior punteggio standardizzato in un gruppo di b attaccanti (asse di b logaritmico)`,
    bestLegend: ['simulazione: media sui gruppi, intervallo al 95%', 'valore esatto (binomiale)', 'massimo di b normali standard', '√(2 ln b)'],
    probabilityChart: (n) => `Bernoulli, n = ${IT.int(n)}: almeno uno di b attaccanti oltre la media di 3 deviazioni standard, e sistemi penetrati da almeno uno dei primi b`,
    probabilityLegend: ['almeno uno oltre +3σ: simulazione', 'almeno uno oltre +3σ: esatta', 'sistemi penetrati: simulazione', 'sistemi penetrati: esatta'],
    after: (s) => {
      const f = interpretationFacts(s);
      const simulated = f.row5 && f.row20 ? ` (simulati: ${IT.pct(f.row5.coverage)} e ${IT.pct(f.row20.coverage)})` : '';
      return [
        `Il migliore di b attaccanti si allontana dalla media lentamente, come √(2 ln b): ${IT.num(f.best10, 2)} deviazioni standard con 10 attaccanti, ${IT.num(f.best100, 2)} con 100 e ${IT.num(f.best1000, 2)} con 1.000, secondo la legge esatta. Per ogni fattore 10 di attaccanti in più il primo guadagna circa ${IT.num((f.best1000 - f.best10) / 2, 2)} deviazioni standard: raddoppiare gli attaccanti non raddoppia nulla.`,
        `Gli eventi rari per un attaccante diventano probabili per molti. Superare la media di 3 deviazioni standard succede a un singolo attaccante con probabilità ${IT.num(f.tail, 4)}, ma ad almeno uno su 100 con probabilità ${IT.num(f.atLeast100, 3)} e ad almeno uno su 1.000 con ${IT.num(f.atLeast1000, 3)}. Per chi difende conta il caso peggiore, e il caso peggiore cresce con m anche se nessun attaccante è più bravo degli altri.`,
        `La stessa formula vale per la copertura dei sistemi: un sistema resiste a un attaccante con probabilità 1 - p e a b attaccanti indipendenti con probabilità (1 - p)^b, quindi la quota di sistemi penetrati da almeno uno dei primi b è 1 - (1 - p)^b: ${IT.pct(f.cover5)} con 5 attaccanti e ${IT.pct(f.cover20)} con 20${simulated}. Con p = ${IT.plain(f.p)} bastano ${IT.int(f.b95)} attaccanti indipendenti per raggiungere il 95% dei sistemi.`,
      ];
    },
  },
  aggregate: {
    paras: (s) => {
      const f = interpretationFacts(s);
      const A = f.aggregate;
      return [
        `Il punteggio aggregato di tutti gli attaccanti su tutti i sistemi, T, la somma di tutti gli X, è una somma di mn incrementi i.i.d., e valgono gli stessi teoremi con mn al posto di n. Per Bernoulli T ha media mnp = ${IT.int(A.expected)} e deviazione standard √(mnp(1 - p)) = ${IT.num(A.sd, 1)}; la simulazione dà ${IT.int(A.total)} (z = ${IT.num(A.z, 2)}). Media e varianza dipendono da n e m solo attraverso il prodotto: 10 attaccanti su 1.000 sistemi e 1.000 attaccanti su 10 sistemi producono in media lo stesso punteggio aggregato.`,
        `Il prodotto però non dice tutto: la stessa tabella m × n di esiti si legge per righe o per colonne. Per riga, cioè per attaccante, la somma è S_n; per colonna, cioè per sistema, è il numero di attaccanti che lo hanno penetrato, K_i ~ Bin(m, p). I teoremi valgono anche lungo le colonne, con m al posto di n: per sistema la media è mp = ${IT.num(A.systemMean, 1)} e la varianza mp(1 - p) = ${IT.num(A.systemVariance, 1)}; sui ${IT.int(f.N)} sistemi simulati sono ${IT.num(A.perSystemMean, 1)} e ${IT.num(A.perSystemVariance, 1)}, e il test χ² ${f.systems.verdict === 'reject' ? 'rifiuta' : 'non rifiuta'} la legge binomiale (p = ${IT.pval(f.systems.pValue)}).`,
      ];
    },
    systemsChart: (n, m) => `Bernoulli: numero di attaccanti, sui ${IT.int(m)}, che hanno penetrato ciascuno degli ${IT.int(n)} sistemi`,
    systemsLegend: ['simulazione', 'legge esatta Bin(m, p)', 'normale con la stessa media e la stessa varianza'],
    after: ['In sintesi, n e m hanno ruoli simmetrici nel punteggio totale e ruoli diversi nelle domande che contano: n decide quanto è prevedibile la quota di successi di ciascun attaccante, m quanto è estremo il migliore e quanti sistemi vengono raggiunti da qualcuno.'],
  },
  limits: {
    paras: [
      'Il modello i.i.d. è una prima approssimazione, utile proprio perché permette di calcolare tutto. Nella realtà le sue ipotesi cadono in almeno quattro modi, e ognuno cambia una conclusione diversa.',
      'Sistemi diversi. Se la probabilità di penetrazione dipende dal sistema, p_i, gli incrementi restano indipendenti ma non sono più identicamente distribuiti. La legge dei grandi numeri vale ancora, per la media delle p_i, e il teorema del limite centrale nelle versioni di Lyapunov (1901) e di Lindeberg (1922), purché nessun sistema domini la varianza: le conclusioni delle sezioni 3, 4 e 5 restano, con μ e σ² medie sui sistemi.',
      'Vulnerabilità comuni. Se molti sistemi condividono una vulnerabilità (lo stesso software, la stessa configurazione), gli esiti sono correlati. Con una correlazione ρ fra gli incrementi, Var(S_n) = nσ²(1 + (n - 1)ρ), che cresce come n², e S_n/n non si concentra più su μ: la legge dei grandi numeri cade. È il caso peggiore per chi difende, perché la diversificazione smette di ridurre il rischio.',
      'Attaccanti che imparano. Se ogni successo rende più facile il successivo, per esempio perché un accesso ottenuto apre la strada al movimento laterale, gli incrementi sono dipendenti e il processo somiglia a un’urna di Pólya: S_n/n converge ancora, ma a un limite casuale che dipende dai primi passi, e due attaccanti identici possono finire con frazioni di successo molto diverse.',
      'Punteggi a coda pesante. Se un singolo sistema può valere un punteggio enorme (un controller di dominio rispetto a una stampante) e la varianza è infinita, il teorema del limite centrale classico non vale: la somma è dominata dai valori più grandi e tende a una legge stabile, non normale. In tutti questi casi la simulazione resta lo strumento giusto: cambia il modello, non il metodo.',
    ],
  },
  stats: {
    verdict: { reject: 'H₀ rifiutata', notReject: 'H₀ non rifiutata' },
    expected: { reject: 'atteso: rifiuto', notReject: 'atteso: nessun rifiuto', either: 'dipende dalla potenza del test' },
    testLine: testLineIt,
    groups: { sim: 'Generatore', lln: 'Grandi numeri', clt: 'Limite centrale', walk: 'Cammino aleatorio' },
    labels: {
      sim: {
        bernoulliPairs: 'Bernoulli: incrementi consecutivi indipendenti (χ², 2 × 2)',
        rademacherPairs: 'Rademacher: incrementi consecutivi indipendenti (χ², 2 × 2)',
        bernoulliSystems: 'Bernoulli: i colpi per sistema seguono Bin(m, p) (χ²)',
      },
      lln: {
        bernoulliMean: 'Bernoulli: la media di S_n/n è p (z)',
        rademacherMean: 'Rademacher: la media di S_n/n è 0 (z)',
        bernoulliVariance: 'Bernoulli: la varianza di S_n è np(1 - p) (z, grandi campioni)',
        rademacherVariance: 'Rademacher: la varianza di S_n è n (z, grandi campioni)',
      },
      clt: {
        bernoulliExact: 'Bernoulli: S_n segue la sua legge esatta Bin(n, p) (χ²)',
        rademacherExact: 'Rademacher: S_n segue la sua legge esatta 2 Bin(n, 1/2) - n (χ²)',
        rademacherNormal: 'Rademacher: S_n/√n è N(0, 1), con la correzione di continuità (Kolmogorov-Smirnov)',
        rademacherSmall: `Rademacher: S_${SMALL_N}/√${SMALL_N} è N(0, 1), senza correzione (Kolmogorov-Smirnov)`,
        rademacherJb: 'Rademacher: S_n/√n ha asimmetria e curtosi di una normale (Jarque-Bera)',
        bernoulliJb: 'Bernoulli: S_n standardizzata ha asimmetria e curtosi di una normale (Jarque-Bera)',
        bernoulliSmall: `Bernoulli: S_${SMALL_N} standardizzata ha asimmetria e curtosi di una normale (Jarque-Bera)`,
      },
      walk: { arcsine: 'Rademacher: il tempo in vantaggio segue la legge dell’arcoseno di Feller (χ²)' },
    },
  },
  tests: {
    intro: (s) => `I test d’ipotesi della pagina, con livello di significatività α = ${IT.num(SIGNIFICANCE, 2)}. Il generatore si controlla con gli incrementi consecutivi e con i colpi per sistema; la legge dei grandi numeri con la media e la varianza a n = ${IT.int(s.params.n)}; il teorema del limite centrale con la legge esatta, la normale e i momenti; il cammino con la legge dell’arcoseno. Due test, a n = ${SMALL_N}, hanno un’ipotesi nulla falsa di proposito: la normale non è ancora una buona approssimazione, e il loro rifiuto è atteso.`,
    cols: { subject: 'Oggetto', hypothesis: 'Ipotesi nulla H₀', p: 'p-value', verdict: 'Esito', expected: 'Lettura' },
    after: (sum, s) => {
      const out = [`${sum.rejected} test su ${sum.count} rifiutano l’ipotesi nulla, ${sum.asExpected === sum.count ? 'tutti come atteso' : `${sum.asExpected} su ${sum.count} come atteso`}.`];
      const expectedFalse = IT.num(sum.nulls * SIGNIFICANCE, 2);
      const which = sum.falseRejections.map((t) => IT.pval(t.result.pValue)).join(', ');
      out.push(
        `Fra i ${sum.nulls} test con un’ipotesi nulla vera (o falsa per differenze troppo piccole perché m attaccanti le vedano), al livello ${IT.num(SIGNIFICANCE, 2)} ci si aspettano in media ${expectedFalse} rifiuti per puro caso: ${sum.falseRejections.length === 0 ? 'qui non ce ne sono' : `qui ${sum.falseRejections.length === 1 ? 'ce n’è uno' : `ce ne sono ${sum.falseRejections.length}`} (p = ${which})`}. La correzione di Holm per i test multipli, che tiene sotto il 5% la probabilità anche di un solo rifiuto sbagliato, confronta il p-value più piccolo con ${IT.num(SIGNIFICANCE, 2)}/${sum.nulls} = ${IT.num(sum.holmThreshold, 4)}, il successivo con ${IT.num(SIGNIFICANCE, 2)}/${sum.nulls - 1} e così via: ${sum.holm === 0 ? 'nessun rifiuto sopravvive' : `${sum.holm === 1 ? 'sopravvive un rifiuto' : `sopravvivono ${sum.holm} rifiuti`}, da guardare come un possibile difetto`}.`,
      );
      const small = s.models.rademacher.tests.smallKs;
      out.push(`Un’osservazione vale per tutti: a parità di differenza, il p-value dipende da m. Con ${IT.int(s.params.m)} attaccanti il test di Kolmogorov-Smirnov vede distanze dalla normale di qualche centesimo e rifiuta la normalità di S_${SMALL_N}/√${SMALL_N} con p = ${IT.pval(small.pValue)}; con cinquanta attaccanti la stessa distanza, ${IT.num(small.D, 3)}, passerebbe inosservata. Significatività ed entità di una differenza sono due domande diverse.`);
      return out;
    },
  },
  history: {
    intro: 'Dalle prove di Bernoulli al generatore di questa pagina, le idee usate nell’homework in ordine cronologico.',
    legend: { task: 'usato in questa pagina', context: 'contesto' },
    events: [
      { year: '1654', task: false, title: 'Pascal e Fermat', text: 'Il problema delle parti, come dividere la posta di una partita interrotta: la corrispondenza fra Pascal e Fermat fonda il calcolo delle probabilità.' },
      { year: '1713', task: true, title: 'Jakob Bernoulli', text: 'Nell’Ars Conjectandi, pubblicata postuma, il "teorema d’oro": la frequenza dei successi in prove indipendenti si avvicina alla loro probabilità. È la prima legge dei grandi numeri, e le prove con due esiti portano il suo nome.' },
      { year: '1733', task: true, title: 'de Moivre', text: 'Approssima la binomiale con p = 1/2 con la curva che oggi si chiama normale, poi la ripubblica in The Doctrine of Chances (1738): il primo teorema del limite centrale, proprio per somme di incrementi ±1.' },
      { year: '1812', task: true, title: 'Laplace', text: 'Nella Théorie analytique des probabilités estende il risultato a p qualunque, il teorema di de Moivre e Laplace della sezione 5.3, e a somme più generali.' },
      { year: '1837', task: true, title: 'Poisson', text: 'Nelle Recherches sur la probabilité des jugements dà il nome alla legge dei grandi numeri e ricava la legge degli eventi rari, l’approssimazione della binomiale quando p è piccolo.' },
      { year: '1853-1867', task: true, title: 'Bienaymé e Chebyshev', text: 'La disuguaglianza P(|X - μ| ≥ kσ) ≤ 1/k² e la dimostrazione della legge debole per variabili indipendenti con varianze limitate: il limite della sezione 3.2.' },
      { year: '1889', task: true, title: 'Galton', text: 'In Natural Inheritance descrive il quincunx, la tavola di chiodi che aveva costruito anni prima: a ogni fila una pallina rimbalza a destra o a sinistra, quindi ogni pallina compie un cammino di Rademacher, e il mucchio in fondo è la campana.' },
      { year: '1900-1901', task: true, title: 'Lyapunov', text: 'Dimostra il teorema del limite centrale per variabili indipendenti non identiche, con una condizione sui momenti, usando le funzioni caratteristiche.' },
      { year: '1905', task: false, title: 'Pearson', text: 'In una lettera a Nature chiede la legge della distanza percorsa da chi fa n passi in direzioni casuali: nasce il nome random walk.' },
      { year: '1909', task: true, title: 'Borel', text: 'La legge forte dei grandi numeri per le prove di Bernoulli: quasi ogni numero reale ha cifre binarie con frequenza 1/2.' },
      { year: '1920-1921', task: true, title: 'Pólya', text: 'Chiama "teorema del limite centrale" il risultato di de Moivre e Laplace (1920), e dimostra che il cammino aleatorio semplice torna all’origine con probabilità 1 in una e due dimensioni, non in tre (1921).' },
      { year: '1922', task: false, title: 'Lindeberg', text: 'La condizione più generale per il teorema del limite centrale con incrementi indipendenti non identici, che Feller (1935) mostrerà essere anche necessaria.' },
      { year: '1924', task: true, title: 'Khinchin', text: 'La legge del logaritmo iterato per le prove di Bernoulli: le oscillazioni di S_n - np arrivano a √(2np(1 - p) ln ln n), e non oltre. È l’inviluppo dell’animazione.' },
      { year: '1929-1933', task: true, title: 'Kolmogorov', text: 'Estende la legge del logaritmo iterato (1929); nel 1933 fonda la probabilità sugli assiomi, dimostra la legge forte in generale e introduce la distanza fra funzioni di ripartizione su cui si basa il test di Kolmogorov-Smirnov.' },
      { year: '1939', task: true, title: 'Lévy', text: 'Le leggi dell’arcoseno per il moto browniano. La versione per il cammino di Rademacher, con la legge esatta della sezione 6.1, è nel libro di Feller (1950).' },
      { year: '1941-1942', task: true, title: 'Berry ed Esseen', text: 'Indipendentemente, il limite C ρ/(σ³√n) alla distanza fra la somma standardizzata e la normale: la velocità del teorema del limite centrale.' },
      { year: '1949', task: true, title: 'Metropolis e Ulam', text: 'The Monte Carlo Method: stimare probabilità e valori attesi simulando molti campioni, il metodo di questa pagina.' },
      { year: '1963', task: true, title: 'Hoeffding', text: 'La disuguaglianza esponenziale per somme di variabili limitate.' },
      { year: '1980', task: true, title: 'Jarque e Bera', text: 'Il test di normalità basato sull’asimmetria e sulla curtosi.' },
      { year: '1997', task: false, title: 'Jonsson e Olovsson', text: 'Un modello quantitativo del processo di intrusione costruito sul comportamento di attaccanti reali: il processo di penetrazione come oggetto statistico.' },
      { year: '2011', task: true, title: 'Shevtsova', text: `Abbassa la costante di Berry-Esseen per addendi identicamente distribuiti a ${IT.num(BERRY_ESSEEN_C, 4)}, il valore della sezione 5.2.` },
      { year: '2014-2018', task: true, title: 'SplitMix e xoshiro', text: 'Steele, Lea e Flood pubblicano SplitMix (2014), Blackman e Vigna i generatori xoshiro (2018): sono i numeri casuali di questa pagina.' },
    ],
    after: 'Letta in ordine, la storia di questi teoremi è la struttura di questa pagina: prima la legge dei grandi numeri per le prove di Bernoulli (1713), poi la normale per le somme di ±1 (1733), poi la generalità (Laplace, Chebyshev, Lyapunov, Lindeberg), le traiettorie (Borel, Khinchin, Lévy) e la velocità (Berry ed Esseen). La simulazione è arrivata per ultima e ha cambiato il modo di usarli: i teoremi dicono che cosa aspettarsi, la simulazione controlla se il modello è quello giusto.',
  },
  conclusion: (s) => {
    if (!s) {
      return [
        'Le tre grandezze della consegna sono la stessa variabile su tre scale, e le tre scale raccontano tre storie: S_n cresce, S_n/n si concentra su μ (legge dei grandi numeri), S_n/√n si stabilizza e, per Rademacher, diventa normale (teorema del limite centrale).',
      ];
    }
    const rows = llnRows(s, 0.05);
    const R = s.models.rademacher;
    const f = interpretationFacts(s);
    const first = rows.rademacher.find((r) => r.n >= 100) || rows.rademacher[0];
    const lastRow = rows.rademacher[rows.rademacher.length - 1];
    const d = lastOf(R).distance;
    return [
      `Le tre grandezze della consegna sono la stessa variabile su tre scale, e le tre scale raccontano tre storie. S_n cresce: per Bernoulli come np, con fluttuazioni di ordine √n, per Rademacher resta centrata sullo zero ma si allarga come √n. S_n/n si concentra: per Rademacher la probabilità di stare lontano da μ più di 0,05 scende da ${IT.num(first.exact, 3)} a n = ${IT.int(first.n)} a ${IT.small(lastRow.exact)} a n = ${IT.int(lastRow.n)}, la legge dei grandi numeri. S_n/√n si stabilizza: la sua varianza resta σ², e per Rademacher la sua legge converge a N(0, 1), con una distanza di Kolmogorov di ${IT.small(d)} a n = ${IT.int(s.params.n)}, il teorema del limite centrale.`,
      'La simulazione concorda con la teoria entro il suo errore: medie, varianze e leggi esatte non vengono rifiutate, e i rifiuti attesi sono quelli a n = 10, dove la normale non è ancora una buona approssimazione. Due cose però la simulazione non vede da sola, e servono i calcoli esatti: le probabilità più piccole di 1/m e le distanze più piccole di 1/√m. È il senso preciso in cui m va scelto in modo adatto.',
      `Per attaccanti e sistemi la lezione è doppia. Con più sistemi la quota di successi di ciascun attaccante diventa prevedibile, mentre il numero assoluto di sistemi compromessi resta incerto di √n. Con più attaccanti nessuno diventa più bravo, ma il migliore si allontana dalla media come √(2 ln m), gli eventi rari diventano probabili e quasi tutti i sistemi vengono raggiunti da qualcuno: il ${IT.pct(f.cover20)} dei sistemi già con 20 attaccanti indipendenti.`,
      'Il modello è volutamente semplice: sistemi uguali, esiti indipendenti, attaccanti che non imparano. Le sue conclusioni più robuste, la concentrazione delle frequenze, la scala √n e la crescita del caso peggiore con m, sopravvivono a sistemi diversi; cadono con vulnerabilità comuni e attaccanti che imparano, e lì la simulazione resta lo strumento per scoprire che cosa cambia.',
    ];
  },
  modelNames: { bernoulli: 'Bernoulli', rademacher: 'Rademacher' },
  quantityNames: { sum: 'S_n', mean: 'S_n/n', normalized: 'S_n/√n' },
  trajectoryNames: { sum: 'S_k', mean: 'S_k/k', normalized: 'S_k/√k' },
  tips: {
    trajectory: (hit, name) =>
      hit.kind === 'bin'
        ? said(`${name} fra ${valueIt(hit.from, hit.quantity)} e ${valueIt(hit.to, hit.quantity)} al sistema ${IT.int(hit.k)}`, [on(hit.show, 'bars') && `${IT.int(hit.count)} attaccanti su ${IT.int(hit.sample)}`, on(hit.show, 'normal') && `${IT.num(hit.expected, 1)} attesi dalla normale`])
        : said(`Sistema ${IT.int(hit.step)}`, [on(hit.show, 'first') && `${name} dell’attaccante 1 ${valueIt(hit.first, hit.quantity)}`, on(hit.show, 'band') && `media ${valueIt(hit.mean, hit.quantity)}, fascia fra ${valueIt(hit.mean - 2 * hit.sd, hit.quantity)} e ${valueIt(hit.mean + 2 * hit.sd, hit.quantity)}`], '; '),
    bin: (from, to, share, prob, normal) => {
      const d = edgeDigits(from, to);
      return said(`Da ${IT.num(from, d)} a ${IT.num(to, d)}`, [`simulazione ${IT.pct(share, 2)}`, prob !== null && `legge esatta ${IT.pct(prob, 2)}`, normal !== null && `normale ${IT.pct(normal, 2)}`]);
    },
    share: (from, to, share, prob, limit) => said(`In vantaggio fra il ${IT.pct(from, 1)} e il ${IT.pct(to, 1)} del tempo`, [`simulazione ${IT.pct(share, 2)}`, prob !== null && `legge esatta ${IT.pct(prob, 2)}`, limit !== null && `arcoseno ${IT.pct(limit, 2)}`]),
    lln: (r, show) => said(`n = ${IT.int(r.n)}`, [on(show, 'rate') && `simulata ${IT.num(r.rate, 4)} (95%: ${IT.num(r.interval[0], 4)}-${IT.num(r.interval[1], 4)})`, on(show, 'exact') && `esatta ${IT.small(r.exact)}`, on(show, 'chebyshev') && `Chebyshev ${IT.small(r.chebyshev)}`, on(show, 'hoeffding') && `Hoeffding ${IT.small(r.hoeffding)}`]),
    // pairs: [simulated, exact] for S_n, S_n/n and S_n/√n, null where hidden
    variance: (n, pairs) => said(`n = ${IT.int(n)}`, ['S_n', 'S_n/n', 'S_n/√n'].map((q, i) => pairs[i] && [pairs[i][0] !== null && `Var(${q}) ${IT.small(pairs[i][0])}`, pairs[i][1] !== null && `esatta ${IT.small(pairs[i][1])}`].filter(Boolean).join(' ')).filter(Boolean)),
    distance: (n, d, dc, bound, ks) => said(`n = ${IT.int(n)}`, [d !== null && `esatta ${IT.small(d)}`, dc !== null && `con correzione ${IT.small(dc)}`, bound !== null && `Berry-Esseen ${IT.small(bound)}`, ks !== null && `simulata ${IT.num(ks, 4)}`]),
    qq: (a, b) => `Quantile di N(0, 1) ${IT.num(a, 2)}: simulato ${IT.num(b, 2)}`,
    best: (r, show) => said(`b = ${IT.int(r.b)} (${IT.int(r.groups)} gruppi)`, [on(show, 'mean') && `simulato ${IT.num(r.mean, 2)} ± ${IT.num(1.96 * r.error, 2)}`, on(show, 'exact') && `esatto ${IT.num(r.exact, 2)}`, on(show, 'normal') && `normale ${IT.num(r.normal, 2)}`, on(show, 'asymptote') && `√(2 ln b) ${IT.num(r.asymptote, 2)}`]),
    probability: (r, show) => said(`b = ${IT.int(r.b)}`, [on(show, 'beyond') && `almeno uno oltre +3σ ${IT.pct(r.beyond)}`, on(show, 'beyondExact') && `almeno uno oltre +3σ, esatta ${IT.pct(r.beyondExact)}`, on(show, 'coverage') && `sistemi penetrati ${IT.pct(r.coverage)}`, on(show, 'coverageExact') && `sistemi penetrati, esatta ${IT.pct(r.coverageExact)}`], '; '),
  },
  download: {
    title: 'Scarica il codice',
    text: 'Il programma completo in HTML, CSS e JavaScript, senza dipendenze, in italiano e in inglese: dopo aver estratto l’archivio si apre con un doppio clic su index.html, anche offline, con le stesse simulazioni e animazioni. Con node homework3.js stampa nel terminale le tabelle, i test e un istogramma; --p, --n, --m, --seed ed --epsilon cambiano i parametri.',
    contents: 'Contenuto: index.html, style.css, homework3.js (generatore, simulazione, statistica, grafici e animazione), app.js (interfaccia e testi), README.txt.',
    zip: 'Scarica homework3',
    online: 'Apri il programma online',
  },
  standalone: {
    subtitle: 'Il punteggio di penetrazione di m attaccanti su n sistemi: legge dei grandi numeri e teorema del limite centrale.',
    course: 'Statistics, laurea magistrale in Cybersecurity, Sapienza Università di Roma',
    online: 'Versione online',
    noscript: 'Questo programma ha bisogno di JavaScript.',
  },
};

// ---------------------------------------------------------------------------
// ENGLISH
// ---------------------------------------------------------------------------

const EN = formatters('.', ',', 'n/a', '×');

const countEn = (v) => (!Number.isFinite(v) ? '∞' : v >= 1e7 ? EN.sci(v) : EN.int(v));

function testLineEn(t) {
  const F = EN;
  switch (t.kind) {
    case 'chi2':
      return `χ² = ${F.num(t.chi2, 1)} over ${F.int(t.classes)} classes (${F.int(t.df)} degrees of freedom), p = ${F.pval(t.pValue)}`;
    case 'independence':
      return `χ² = ${F.num(t.chi2, 2)} on a 2 × 2 table of ${F.int(t.N)} pairs (1 degree of freedom), Cramér’s V = ${F.num(t.cramerV, 5)}, p = ${F.pval(t.pValue)}`;
    case 'mean':
      return `mean ${F.num(t.mean, 5)} against ${F.num(t.expected, 5)}, z = ${F.num(t.z, 2)}, p = ${F.pval(t.pValue)}`;
    case 'variance':
      return `variance ${F.num(t.variance, 1)} against ${F.num(t.expected, 1)} (ratio ${F.num(t.ratio, 4)}), z = ${F.num(t.z, 2)}, p = ${F.pval(t.pValue)}`;
    case 'ks':
      return `D = ${F.num(t.D, 4)} over ${F.int(t.m)} attackers, √m D = ${F.num(t.lambda, 2)}, p = ${F.pval(t.pValue)}${t.corrected ? ' (with the continuity correction; against a discrete law the test is conservative)' : ''}`;
    case 'jb':
      return `skewness ${F.num(t.skewness, 3)}, excess kurtosis ${F.num(t.excessKurtosis, 3)}, JB = ${F.num(t.statistic, 2)} (χ² with 2 degrees of freedom), p = ${F.pval(t.pValue)}`;
    default:
      return `p = ${F.pval(t.pValue)}`;
  }
}

const valueEn = (v, quantity) => EN.num(v, DIGITS[quantity]);

const en = {
  fmt: EN,
  ui: {
    index: 'Contents',
    indexTitle: 'Homework contents',
    close: 'Close',
    backToTop: 'Back to top',
    computing: 'Simulating...',
    language: 'Language',
    error: (m) => `Error: ${m}`,
  },
  sections: {
    assignment: '0. The assignment',
    model: '1. TASK: systems, attackers and the penetration process',
    models: '1.1 The two models of the score',
    quantities: '1.2 The three quantities',
    input: '1.3 Systems, attackers and seed',
    trajectories: '1.4 The trajectories, system after system',
    verify: '1.5 Checks',
    distributions: '2. The distributions with more and more systems',
    sweep: '2.1 The histograms, point by point',
    moments: '2.2 Means and variances',
    choice: '2.3 How many attackers are needed',
    lln: '3. The law of large numbers',
    convergence: '3.1 The convergence in probability of the average score',
    bounds: '3.2 Chebyshev, Hoeffding and the normal',
    strong: '3.3 Weak law and strong law',
    variance: '4. The variance under the three normalizations',
    clt: '5. The central limit theorem',
    normal: '5.1 Rademacher: the normalized sum towards the normal',
    speed: '5.2 How fast the convergence is',
    bernoulli: '5.3 Bernoulli: what converges and what does not',
    interpretation: '6. Systems and attackers: the interpretation',
    size: '6.1 More systems',
    attackers: '6.2 More attackers',
    aggregate: '6.3 The aggregate score',
    limits: '6.4 The limits of the model',
    tests: '7. Summary of the statistical tests',
    history: '8. Historical context',
    conclusion: '9. Conclusions',
  },
  assignment: {
    intro: [
      'The assignment asks to model the penetration of m attackers on n systems with a stochastic process: at every step an attacker gets a score X_i, and the scores X_1, X_2, ... are independent and identically distributed. There are two models: Bernoulli, where X_i is 1 with probability p and 0 otherwise, and Rademacher, where it is +1 or -1 with probability 1/2, the symmetric zero-mean case. For growing n and suitable m, many trajectories are simulated and the distributions of the total score S_n, the average score S_n/n and the normalized total score S_n/√n are studied: the convergence in probability of S_n/n (law of large numbers), the variance under the three normalizations, and the convergence in distribution of S_n/√n to the standard normal in the Rademacher case (central limit theorem). Finally the trajectories are interpreted in terms of systems and attackers, discussing how the system size and the number of attackers affect the aggregate score.',
      'Section 1 makes the model precise, animates its trajectories and checks the simulator; section 2 shows the distributions of the three quantities as n grows and how many attackers each n needs; section 3 is devoted to the law of large numbers, section 4 to the variance, section 5 to the central limit theorem and the speed of the convergence; section 6 interprets the results for systems and attackers. Section 7 sums up the statistical tests, section 8 places the ideas in time and section 9 draws the conclusions. Every number is computed in the browser, and the downloadable program prints the same ones. The charts move: they zoom (ctrl + wheel, or a rectangle dragged; double click for the whole chart again), and those that follow n or the number of attackers draw the simulation point by point, with the exact values and the bounds held still as a reference.',
    ],
    originalTitle: 'The original text of the assignment',
    originalNote: 'As it was assigned. The only change is the minus sign, written "-" as everywhere on this site.',
  },
  model: {
    intro: [
      'Every attacker faces the systems one after the other: on system i it gets the score X_i, and after k systems its score is S_k = X_1 + ... + X_k. The trajectory k ↦ S_k is a random walk, and the m attackers are m independent copies of the same walk. In this reading n is the length of the trajectories, that is how many systems every attacker faces, and m is the size of the sample, that is how many trajectories are observed to estimate the distributions.',
      'The assignment does not say how n and m enter the process, and the page fixes them this way for a precise reason: the sum S_n = X_1 + ... + X_n runs over the steps of the process, so n counts the steps of an attacker, that is the systems it faces; the attackers do not appear in the sum, and they are its independent repetitions, that is the sample. The other possible reading, where for each system the scores of the m attackers are added up, is the same m × n table of outcomes read by columns: section 6.3 shows that the hits of each system obey the same theorems, with m in place of n. The conclusions therefore do not depend on the reading chosen; only the name of the index changes.',
      'The i.i.d. assumption says two things: the systems are equally hard, because every X_i has the same law, and the outcome on one system says nothing about the others, because the X_i are independent. In other words the attacker does not learn and the systems share no vulnerabilities: section 6.4 discusses how realistic that is and what changes without it.',
    ],
    formulasTitle: 'The model in formulas',
    formulas: [
      'Increments    X_1, X_2, ... i.i.d.,  E[X] = μ,  Var(X) = σ²',
      'Bernoulli     X ∈ {0, 1},    P(X = 1) = p          μ = p,  σ² = p(1 - p)',
      'Rademacher    X ∈ {-1, +1},  P(X = +1) = 1/2       μ = 0,  σ² = 1',
      'Trajectory    S_0 = 0,  S_k = S_(k-1) + X_k,  k = 1, ..., n',
      'Quantities    S_n,  S_n/n,  S_n/√n',
    ].join('\n'),
  },
  models: {
    intro: [
      'In the Bernoulli model X_i is 1 when the attacker penetrates system i and 0 when it fails: S_n counts the penetrated systems and follows the binomial law Bin(n, p), and S_n/n is the share of penetrated systems. In the Rademacher model X_i is +1 or -1: the attacker gains or loses ground with the same probability, as in an even match with the defender (access obtained or revoked, a privilege gained or lost). If K is the number of steps forward, S_n = K - (n - K) = 2K - n with K ~ Bin(n, 1/2): it is the simple symmetric random walk.',
      'The two models are close relatives: if B is 1 with probability 1/2, then 2B - 1 is Rademacher. More generally the standardization (X - μ)/σ brings any increment to mean 0 and variance 1. The Rademacher model is the case where the increment is already standardized, and this is why the assignment uses it for the central limit theorem.',
    ],
    tableTitle: (p) => `The moments of one increment, with p = ${EN.plain(p)}`,
    cols: { model: 'Model', values: 'Values', mu: 'Mean μ', variance: 'Variance σ²', rho: 'E|X - μ|³', skewness: 'Skewness' },
    after: [
      'Mean and variance are all the law of large numbers and the central limit theorem need; the moment E|X - μ|³ enters the Berry-Esseen bound on the speed of the convergence (section 5.2); the skewness, (1 - 2p)/√(p(1 - p)) for Bernoulli, explains why with p far from 1/2 the convergence to the normal is slower.',
    ],
  },
  quantities: {
    intro: [
      'For sums of independent variables means and variances add up: E[S_n] = nμ and Var(S_n) = nσ². Dividing by a constant c divides the mean and the standard deviation by c, and the variance by c². The table gives the exact values of the three quantities: the variable is always the same, only the unit in which it is measured changes.',
    ],
    tableTitle: 'Exact mean, variance and standard deviation',
    cols: { quantity: 'Quantity', mean: 'Mean', variance: 'Variance', sd: 'Standard deviation', trend: 'As n grows' },
    rows: [
      ['S_n', 'nμ', 'nσ²', 'σ√n', 'grows: for Bernoulli the mean like n and the standard deviation like √n, for Rademacher only the standard deviation'],
      ['S_n/n', 'μ', 'σ²/n', 'σ/√n', 'concentrates on μ: the variance goes to 0'],
      ['S_n/√n', 'μ√n', 'σ²', 'σ', 'the variance stays σ²: for Rademacher the law settles, for Bernoulli the mean μ√n grows without limit'],
    ],
    after: [
      'The second row is the law of large numbers, the third the central limit theorem. Dividing by n squeezes the variability, not dividing lets it grow, and √n is the only scale in between that keeps it finite and nonzero: this is why the assignment asks for exactly these three normalizations.',
    ],
  },
  input: {
    intro: `The initial values are p = ${EN.plain(DEFAULT_P)} (on average an attacker penetrates one system in ${Math.round(1 / DEFAULT_P)}), n = ${EN.int(DEFAULT_N)} systems, m = ${EN.int(DEFAULT_M)} attackers and the seed ${DEFAULT_SEED}. Every attacker has a generator of its own, xoshiro128**, whose state comes from SplitMix64 applied to the seed, the model and the number of the attacker: with the same seed the page, the animation and node homework3.js see the same attackers and print the same numbers. More systems extend the trajectories already simulated, more attackers join the first ones without changing them. Every change repeats the simulation, which with the initial values draws ${EN.int(2 * DEFAULT_N * DEFAULT_M)} increments; the time it took appears under the fields.`,
    pLabel: `Penetration probability p, Bernoulli model (from ${EN.plain(LIMITS.p[0])} to ${EN.plain(LIMITS.p[1])})`,
    pHint: 'With a decimal point or a decimal comma: 0.2 and 0,2 are the same value. The Rademacher model does not depend on p.',
    nLabel: `Systems n (from ${EN.int(LIMITS.n[0])} to ${EN.int(LIMITS.n[1])})`,
    nHint: 'The length of the trajectories. The quantities are observed at n = 1, 2, 5, 10, 20, 50, ... and at the last system.',
    mLabel: `Attackers m (from ${EN.int(LIMITS.m[0])} to ${EN.int(LIMITS.m[1])})`,
    mHint: 'The trajectories simulated for each model. A probability is estimated with an error of about 1/√m, and a distance between laws below 0.87/√m cannot be told from noise.',
    seedLabel: `Seed (from 0 to ${EN.int(LIMITS.seed[1])})`,
    seedHint: 'The same seed gives the same attackers, here and in the terminal (node homework3.js --seed ...).',
    randomSeed: 'Random seed',
    errors: {
      empty: () => 'Write a value.',
      notInteger: (t) => `"${t}" is not an integer written in decimal digits.`,
      notNumber: (t) => `"${t}" is not a number.`,
      range: (lo, hi) => `The value goes from ${lo} to ${hi}.`,
    },
    limits: {
      p: [EN.plain(LIMITS.p[0]), EN.plain(LIMITS.p[1])],
      n: [EN.int(LIMITS.n[0]), EN.int(LIMITS.n[1])],
      m: [EN.int(LIMITS.m[0]), EN.int(LIMITS.m[1])],
      seed: [EN.int(LIMITS.seed[0]), EN.int(LIMITS.seed[1])],
    },
    defaultBadge: `Initial values: p = ${EN.plain(DEFAULT_P)}, n = ${EN.int(DEFAULT_N)} systems, m = ${EN.int(DEFAULT_M)} attackers, seed ${DEFAULT_SEED}.`,
    customBadge: 'Values different from the initial ones.',
    restore: 'Restore the initial values',
    stale: 'While a field contains an error, the page uses its last valid value.',
    pending: 'Simulating with the new values: the following sections update as soon as it ends.',
    run: (s) => `Simulated ${EN.int(2 * s.params.m * s.params.n)} increments (${EN.int(s.params.m)} attackers, ${EN.int(s.params.n)} systems, 2 models) and computed the exact laws in ${EN.ms(s.ms)}.`,
  },
  trajectories: {
    intro: (shown, sample) => [
      `The animation shows the process while it happens. On the left the trajectories of the first ${EN.int(shown)} attackers, system after system, the first one in red; on the right the histogram of the values of ${EN.int(sample)} attackers at the current system, with the curve of the normal law of the same mean and standard deviation. The green band is mean ± 2 standard deviations, the dashed green line the mean and the dotted yellow lines the envelope of the law of the iterated logarithm, kμ ± σ√(2k ln ln k), in the units of the chosen quantity.`,
      'The model and the quantity can be chosen. With S_k the band widens like √k; with S_k/k it narrows around μ, and that is the law of large numbers; with S_k/√k its width stays constant, and that is the scale of the central limit theorem. The animation opens on the last system: Play starts it again from the first, One system moves one step.',
    ],
    modelLabel: 'Model',
    quantityLabel: 'Quantity',
    speedLabel: 'Speed',
    speeds: ['slow', 'normal', 'fast'],
    play: 'Play',
    pause: 'Pause',
    resume: 'Resume',
    step: 'One system',
    reset: 'From the start',
    end: 'To the end',
    legend: ['trajectories and histogram of the values', 'attacker 1', 'mean (dashed), mean ± 2σ (band), normal law (curve)', 'envelope of the iterated logarithm'],
    caption: (st, quantityName) =>
      st.k === 0
        ? `System 0 of ${EN.int(st.n)}: no system attacked yet.`
        : `System ${EN.int(st.k)} of ${EN.int(st.n)}. ${quantityName}: mean over the ${EN.int(st.sample)} attackers ${valueEn(st.mean, st.quantity)} (exact ${valueEn(st.theoryMean, st.quantity)}), standard deviation ${valueEn(st.sd, st.quantity)} (exact ${valueEn(st.theorySd, st.quantity)}); outside the band ${EN.pct(st.outside)}, against about 4.6% for a normal. Attacker 1: ${valueEn(st.first, st.quantity)}.`,
    after: [
      'Seen through S_k, the cloud of trajectories is a fan that opens like √k: for Rademacher around zero, for Bernoulli around the line kp, which at the scale of n makes the fan look like a single line. With S_k/k the same fan, divided by k, closes on μ: every attacker ends up penetrating a share of the systems close to p. With S_k/√k the trajectories stay in a band of constant width and the histogram on the right stops changing shape: it is the bell of the central limit theorem.',
      'The single trajectories, however, never calm down. They leave the band and come back, and keep doing so: the law of the iterated logarithm (Khinchin, 1924) says that their maxima grow a little faster than √k, like √(2k ln ln k), and that almost every trajectory comes close to its envelope infinitely often. The band describes the attackers at a fixed system, the envelope the path of each one.',
    ],
  },
  verify: {
    intro: 'Before trusting the simulation, its parts are compared with values computed elsewhere. The outputs of xoshiro128** and SplitMix64 and the scores of two attackers after 10,000 systems come from the reference C code of the two generators, compiled with gcc; the laws and special functions (normal, binomial, χ², Kolmogorov, arcsine, maximum of normals, Jarque-Bera) from SciPy 1.17.1.',
    summary: (ok, total) => `${ok} of ${total} checks passed.`,
    details: (n) => `Show the ${n} checks`,
    groups: { generator: 'Generator (reference C code)', functions: 'Laws and special functions (SciPy 1.17.1)' },
    cols: { check: 'Check', expected: 'Expected', result: 'Result' },
    ok: 'passed',
    failed: 'failed',
  },
  distributions: {
    intro: [
      'At fixed n the three quantities have the same shape: a histogram of S_n/n is a histogram of S_n with another axis. What sets them apart is how they change as n grows. To see it, the axis of S_n/n and that of S_n/√n stay the same for every n; the axis of S_n follows the distribution, which otherwise for small n would be a single bar at the edge.',
    ],
  },
  sweep: {
    intro: [
      'The slider chooses n among the points where the trajectories are observed; Play runs through them in order. The bars are the shares of the m attackers divided by the width of the bar, that is densities; the dashed red line is the exact law of S_n on the same bars and the green curve the normal with the same mean and variance. Every bar holds a whole number of possible values of S_n: for small n the values are few and can be seen one by one.',
    ],
    quantityLabel: 'Quantity',
    nLabel: (n) => `n = ${EN.int(n)}`,
    play: 'Play',
    pause: 'Pause',
    chart: (model, quantity, n, m) => `${model}: histogram of ${quantity} with n = ${EN.int(n)}, over the ${EN.int(m)} attackers`,
    legend: ['simulation', 'exact law of S_n', 'normal with the same mean and variance'],
    stats: (model, st, quantity) => `${model}, n = ${EN.int(st.n)}: mean ${valueEn(st.mean, quantity)} (exact ${valueEn(st.theoryMean, quantity)}), standard deviation ${valueEn(st.sd, quantity)} (exact ${valueEn(st.theorySd, quantity)}).`,
    after: [
      'With S_n the bells move and widen: for Bernoulli the mean np grows like n and the standard deviation only like √n, for Rademacher the mean stays 0 and the width grows like √n. With S_n/n the same bells narrow down to a single bar above μ: it is the convergence in probability of section 3. With S_n/√n the width stays the same: for Rademacher the bell stops moving and coincides with N(0, 1), for Bernoulli it slides to the right, because the mean p√n grows without limit.',
      'For small n none of the three looks normal: with n = 1 the law has only two values, and for Bernoulli with p far from 1/2 it is also skewed. The exact law and the simulation, instead, always agree, within the fluctuations of a sample of m attackers: it is the first check that the simulator implements the model.',
    ],
  },
  moments: {
    intro: 'The sample means and variances over the m attackers, next to the exact values. The mean of S_n/n and the variance of S_n/√n are enough: the others follow by multiplying or dividing by n.',
    tableTitle: 'Sample mean of S_n/n and sample variance of S_n/√n, exact values in brackets',
    cols: { n: 'n', bMean: 'Bernoulli: mean of S_n/n', bVar: 'Bernoulli: variance of S_n/√n', rMean: 'Rademacher: mean of S_n/n', rVar: 'Rademacher: variance of S_n/√n' },
    after: (s) => {
      const f = momentFacts(s);
      return [
        `The sample means of S_n/n are at most ${EN.num(f.meanZ, 1)} standard errors from μ, the standard error being σ/√(nm); the sample variances of S_n/√n differ from σ² by at most ${EN.pct(f.varRel)}, against a typical relative error of √(2/m) = ${EN.pct(f.expectedRel)}. These are the differences to expect from ${EN.int(s.params.m)} attackers, and the tests of section 3 check it at n = ${EN.int(s.params.n)}.`,
        'The columns already show the two theorems: the mean of S_n/n stays on μ for every n while its variance, σ²/n, falls towards zero; the variance of S_n/√n stays σ² for every n.',
      ];
    },
  },
  choice: {
    intro: [
      'The assignment asks to simulate for growing n with suitable choices of m. What is suitable depends on what one wants to see, and it can be computed before simulating: a share estimated on m attackers has an error that falls like 1/√m, so every question has a minimum number of attackers, and that number depends on n.',
    ],
    formulasTitle: 'The attackers needed, at 95%',
    formulas: [
      `${`Probability P, relative error ${EN.pct(M_TARGET.relative, 0)}`.padEnd(40)} m ≥ z² (1 - P)/(r² P) ≈ ${EN.num(M_TARGET.z ** 2 / M_TARGET.relative ** 2, 0)} (1 - P)/P`,
      `${'Distance D from the normal'.padEnd(40)} m ≥ (1/D)²;  for Rademacher D ≈ 1/√(2πn), so m ≈ 2πn ≈ ${EN.num(2 * Math.PI, 1)} n`,
      `${`Variance, relative error ${EN.pct(M_TARGET.varianceRelative, 0)}`.padEnd(40)} m ≥ 2 (z/r)² = ${EN.int(neededForVariance())}, at every n`,
    ].join('\n'),
    tableTitle: (eps, m) => `The attackers needed at every n, with ε = ${EN.num(eps, 2)}; in red when more than the ${EN.int(m)} simulated attackers are needed`,
    cols: { n: 'n', pB: 'Bernoulli: P(|S_n/n - μ| > ε)', mB: 'm needed', pR: 'Rademacher: P(|S_n/n - μ| > ε)', mR: 'm needed', d: 'Rademacher: distance D from the normal', mD: 'm needed' },
    count: (v) => countEn(v),
    after: (s, eps) => {
      const rows = choiceRows(s, eps);
      const m = s.params.m;
      const last = rows[rows.length - 1];
      const reach = (key) => {
        const n = enoughUpTo(rows, key, m);
        if (n === null) return 'for no n of the grid';
        return n === last.n ? `at every n, up to ${EN.int(n)}` : `up to n = ${EN.int(n)}`;
      };
      const mVar = neededForVariance();
      return [
        `With the ${EN.int(m)} simulated attackers the probability of the law of large numbers is estimated within ${EN.pct(M_TARGET.relative, 0)} ${reach('mB')} for Bernoulli and ${reach('mR')} for Rademacher. Beyond that the event becomes too rare for a sample: at n = ${EN.int(last.n)} it would take ${countEn(last.mB)} and ${countEn(last.mR)} attackers. The number needed grows like 1/P, and P falls exponentially with n (Hoeffding, section 3.2): for large n no m is suitable, and the probability is computed exactly from the binomial law.`,
        `The difference between S_n/√n and the normal can be seen ${reach('mD')}: the distance is about 1/√(2πn), so about 2πn attackers are needed, ${countEn(last.mD)} at n = ${EN.int(last.n)}. Here the suitable m grows in proportion to n, and with fewer attackers the simulation cannot tell S_n/√n from the normal even when the difference is there. For the variance, instead, ${EN.int(mVar)} attackers are enough at every n${m >= mVar ? `, and the ${EN.int(m)} simulated are enough` : `, more than the ${EN.int(m)} simulated`}.`,
        'No single m suits every question and every n. The page uses the same attackers at every n, so the trajectories are real trajectories and the distributions at different n are those of the same attackers further on; the table says, for each question, how far the simulation reaches and where the exact computations take over. With the m field of section 1.3 the boundary can be seen moving: four times the attackers halve the errors.',
      ];
    },
  },
  lln: {
    intro: [
      'The (weak) law of large numbers says that for every ε > 0 the probability P(|S_n/n - μ| > ε) goes to 0 as n grows: the average score converges in probability to μ. Here that probability is estimated by the share of attackers that after n systems are farther than ε from μ, and compared with the exact value, computed from the binomial law, and with two inequalities that bound it from above without knowing the law.',
    ],
  },
  convergence: {
    intro: 'The slider changes ε, and charts and table follow. The bands around the points are 95% Wilson intervals, which stay inside [0, 1] even when the observed share is 0.',
    epsilonLabel: (eps) => `Tolerance ε = ${EN.num(eps, 2)}`,
    chart: (model, eps) => `${model}: P(|S_n/n - μ| > ${EN.num(eps, 2)}) as n grows (logarithmic n axis)`,
    legend: ['simulation, with 95% Wilson interval', 'exact value', 'Chebyshev bound', 'Hoeffding bound'],
    tableTitle: (eps) => `P(|S_n/n - μ| > ${EN.num(eps, 2)}): share of attackers (95% interval) and exact value`,
    cols: { n: 'n', simulated: 'simulated (95%)', exact: 'exact' },
    after: (s, eps) => {
      const rows = llnRows(s, eps);
      const fB = llnFacts(rows.bernoulli);
      const fR = llnFacts(rows.rademacher);
      const N = EN.int(s.params.n);
      const from = (f, model) => `from n = ${EN.int(f.below)} on for ${model}`;
      let below;
      if (fB.below !== null && fR.below !== null) below = `falls below 1% ${from(fB, 'Bernoulli')} and ${from(fR, 'Rademacher')}`;
      else if (fB.below !== null) below = `falls below 1% ${from(fB, 'Bernoulli')}, while for Rademacher it does not within n = ${N}`;
      else if (fR.below !== null) below = `falls below 1% ${from(fR, 'Rademacher')}, while for Bernoulli it does not within n = ${N}`;
      else below = `does not fall below 1% within n = ${N} in either model`;
      const rise = fB.rises ? ['Bernoulli', fB.rises] : fR.rises ? ['Rademacher', fR.rises] : null;
      const sB = s.models.bernoulli.mom.sigma;
      const out = [
        `With ε = ${EN.num(eps, 2)} the exact probability ${below}. What matters is the ratio between ε and the standard deviation of one increment: the probability depends on n through ε√n/σ, and σ is ${EN.num(sB, 3)} for Bernoulli and 1 for Rademacher.`,
      ];
      if (rise) {
        out.push(`For small n the fall is not regular: for ${rise[0]} the probability goes from ${EN.num(rise[1].from.exact, 4)} at n = ${EN.int(rise[1].from.n)} to ${EN.num(rise[1].to.exact, 4)} at n = ${EN.int(rise[1].to.n)}. S_n/n only takes values ${rise[0] === 'Bernoulli' ? '1/n' : '2/n'} apart, and as long as this step is wider than ε what counts is how many values fall close to μ, not how large n is.`);
      }
      out.push(`The simulation follows the exact value as long as the probability is larger than 1/m = ${EN.small(1 / s.params.m)}; below it, almost always no attacker goes beyond ε, the observed share is 0 and only the upper end of the Wilson interval is left, ${EN.num(fB.last.interval[1], 4)}. This is the first sense in which m must be chosen suitably: estimating a probability P takes many more than 1/P attackers, and for large n what remains are the exact computation and the bounds of section 3.2.`);
      return out;
    },
  },
  bounds: {
    paras: (s, eps) => {
      const rows = llnRows(s, eps);
      const lb = rows.bernoulli[rows.bernoulli.length - 1];
      const lr = rows.rademacher[rows.rademacher.length - 1];
      const n0 = (M) => EN.int(Math.ceil(M.mom.variance / (eps * eps) - 1e-9));
      return [
        `Chebyshev’s inequality: P(|S_n/n - μ| > ε) ≤ σ²/(nε²). It is the weak law proved in one line, because Var(S_n/n) = σ²/n; it holds for any law with finite variance, but it decreases only like 1/n, and as long as n < σ²/ε² it exceeds 1 and says nothing: with ε = ${EN.num(eps, 2)} up to n = ${n0(s.models.bernoulli)} for Bernoulli and ${n0(s.models.rademacher)} for Rademacher.`,
        `Hoeffding’s inequality (1963): if the increments lie in an interval of width b - a, P(|S_n/n - μ| > ε) ≤ 2 exp(-2nε²/(b - a)²), with b - a = 1 for Bernoulli and 2 for Rademacher. It decreases exponentially, like the true probability: at n = ${EN.int(lb.n)} Chebyshev gives ${EN.small(lb.chebyshev)} and Hoeffding ${EN.small(lb.hoeffding)} for Bernoulli, against an exact value of ${EN.small(lb.exact)}; for Rademacher ${EN.small(lr.chebyshev)}, ${EN.small(lr.hoeffding)} and ${EN.small(lr.exact)}.`,
        'The normal approximates the same probability with 2(1 - Φ(ε√n/σ)): it is the central limit theorem used for the law of large numbers. At the centre of the distribution it is accurate, but in the tails its relative error grows, and there one needs the large deviation estimates (Cramér, Chernoff), which give the exact exponential rate. The two bounds always hold and the normal does not: that is the price of generality.',
      ];
    },
  },
  strong: {
    paras: [
      'The strong law of large numbers, by Borel (1909) for Bernoulli trials and by Kolmogorov (1933) in general, says more: with probability 1 the trajectory S_k/k of every attacker converges to μ. The weak law is a statement about the distribution of S_n/n at fixed n, the one of the histograms of section 2; the strong law is a statement about every trajectory, the one of the animation of section 1.4 with S_k/k: every attacker, sooner or later, enters the band μ ± ε and never leaves it again.',
      'The difference is not only formal. Convergence in probability would allow every trajectory to leave the band infinitely often, as long as more and more rarely; almost sure convergence rules that out. For a defender the first says that at a fixed time almost all attackers have a share of successes close to p, the second that each of them, from some system on, will stay close to p forever.',
    ],
  },
  variance: {
    intro: 'The variance of the three quantities, sample (dots) and exact (dashed), on logarithmic scales on both axes: a power law n^a becomes a line of slope a.',
    chart: (model) => `${model}: variance of S_n, S_n/n and S_n/√n as n grows (logarithmic scales)`,
    legend: ['S_n', 'S_n/n', 'S_n/√n', 'exact values (dashed)'],
    fitTitle: 'Slope of log Var against log n, by least squares',
    fitCols: { quantity: 'Quantity', bernoulli: 'Bernoulli', rademacher: 'Rademacher', theory: 'Theory' },
    after: (s) => {
      const fits = varianceFits(s);
      const slopes = (f) => `${EN.num(f.sum, 3)}, ${EN.num(f.mean, 3)} and ${EN.num(f.normalized, 3)} (± ${EN.num(f.error, 3)})`;
      return [
        `Var(S_n) = nσ² grows, Var(S_n/n) = σ²/n goes to zero, Var(S_n/√n) = σ² stays constant: it is the rule Var(cX) = c² Var(X) with c = 1, 1/n and 1/√n. The lines have slopes 1, -1 and 0; the estimated slopes are ${slopes(fits.bernoulli)} for Bernoulli and ${slopes(fits.rademacher)} for Rademacher.`,
        'The three estimates, however, are not three independent pieces of evidence: the sample variance of S_n/n is exactly that of S_n divided by n², so the three slopes differ by exactly 2 and 1, and the information is a single one, Var(S_n) proportional to n. The error of the slope is the least squares one, which treats the points as independent; here they are not, because at every n the attackers are the same, and the true uncertainty is somewhat larger.',
        'With any normalization n^α, Var(S_n/n^α) = σ² n^(1 - 2α): it goes to infinity for α < 1/2, to zero for α > 1/2, and stays finite and positive only for α = 1/2. √n is the only scale at which the variability of S_n stays visible, and it is the scale of the central limit theorem.',
      ];
    },
  },
  clt: {
    intro: [
      'The central limit theorem (Lindeberg and Lévy, for i.i.d. increments with finite variance) says that (S_n - nμ)/(σ√n) converges in distribution to N(0, 1): for every x, P((S_n - nμ)/(σ√n) ≤ x) → Φ(x). In the Rademacher model μ = 0 and σ = 1, so the standardized quantity is exactly S_n/√n, the case the assignment asks to study. In the Bernoulli model S_n/√n does not converge (section 5.3): what converges is the centred and scaled version, (S_n - np)/√(np(1 - p)).',
    ],
  },
  normal: {
    intro: 'Histogram and quantile-quantile plot of the standardized quantity, for every n. In the quantile-quantile plot every point compares a quantile of the simulation with the same quantile of N(0, 1): if the two laws coincide, the points lie on the diagonal. For small n the points form steps, because S_n has few values.',
    modelLabel: 'Quantity',
    models: { rademacher: 'Rademacher: S_n/√n', bernoulli: 'Bernoulli: (S_n - np)/√(np(1 - p))' },
    nLabel: (n) => `n = ${EN.int(n)}`,
    histChart: (label, n) => `${label} with n = ${EN.int(n)}: histogram and density of N(0, 1)`,
    qqChart: (label, n) => `${label} with n = ${EN.int(n)}: simulated quantiles against quantiles of N(0, 1)`,
    legend: ['simulation', 'exact law', 'N(0, 1)'],
    qqLegend: ['simulated quantiles', 'diagonal: the two laws coincide'],
    stats: (sh) => `n = ${EN.int(sh.n)}: skewness ${EN.num(sh.skewness, 3)} (exact ${EN.num(sh.theorySkewness, 3)}), excess kurtosis ${EN.num(sh.excess, 3)} (exact ${EN.num(sh.theoryExcess, 3)}); Kolmogorov distance from the normal: simulated ${EN.num(sh.ks, 4)}, exact ${EN.num(sh.distance, 4)}, exact with the continuity correction ${EN.small(sh.distanceCorrected)}.`,
    after: [
      'Two things can be seen. First: even for Rademacher, which is symmetric, the law of S_n/√n for small n is a staircase, because S_n has only n + 1 values, 2/√n apart after standardization. For even n the distribution function jumps by P(S_n = 0) ≈ √(2/(πn)) at zero, and no continuous function can stay closer to it than half the jump, about 1/√(2πn).',
      'Second: the convergence does not depend on the shape of the law of the increments. Only two values, discrete, in one case skewed: it is enough that the variance is finite, and the standardized sum becomes normal. This is what makes the normal the reference law for any aggregate score.',
    ],
  },
  speed: {
    intro: `How close to the normal is the standardized sum, for every n? The Kolmogorov distance sup_x |F_n(x) - Φ(x)| is computed exactly from the binomial law (lines) and estimated from the simulation (dots). The Berry-Esseen theorem bounds it by C E|X - μ|³/(σ³√n), with C ≤ ${EN.num(BERRY_ESSEEN_C, 4)} (Shevtsova, 2011).`,
    chart: (model) => `${model}: Kolmogorov distance from the normal as n grows (logarithmic scales)`,
    legend: ['exact', 'exact, with the continuity correction', 'Berry-Esseen bound', 'simulated (Kolmogorov-Smirnov)', 'noise of the simulation, 0.87/√m'],
    after: (s) => {
      const f = speedFacts(s);
      const p = EN.plain(s.params.p);
      return [
        `For Rademacher the exact distance is ${EN.num(f.r100.distance, 4)} at n = ${EN.int(f.n100)} and ${EN.small(f.rN.distance)} at n = ${EN.int(f.N)}: it decreases like 1/√n, and almost exactly like 1/√(2πn) ≈ 0.399/√n, half the jump at zero. The Berry-Esseen bound, ${EN.num(BERRY_ESSEEN_C, 4)}/√n, lies above it by only ${EN.pct(f.ratio, 0)}: for a two-valued law the theorem is nearly optimal. With the continuity correction, that is comparing the normal halfway between two possible values, the distance falls to ${EN.small(f.rN.corrected)}, an order 1/n: for sums of Rademacher increments the error of the normal is almost entirely due to the lattice.`,
        f.symmetric
          ? `With p = ${p} the Bernoulli binomial is symmetric too: the distance is ${EN.num(f.b100.distance, 4)} at n = ${EN.int(f.n100)}, and with the continuity correction it falls to ${EN.small(f.b100.corrected)}, as for Rademacher.`
          : `For Bernoulli with p = ${p} the distance is larger (${EN.num(f.b100.distance, 4)} at n = ${EN.int(f.n100)}), because to the lattice it adds the skewness of the binomial, (1 - 2p)/√(np(1 - p)), which the continuity correction does not remove: corrected, the distance is ${EN.num(f.b100.corrected, 4)}, still of order 1/√n.`,
        `The simulated distance follows the exact one as long as the latter exceeds the noise of the simulation, about 0.87/√m = ${EN.num(f.noise, 4)} with m = ${EN.int(s.params.m)}; below it, the dots flatten on the noise. This is the second sense in which m must be chosen suitably: seeing a difference d between two laws takes at least (1/d)² attackers, about ${EN.int(f.need)} for the exact distance at n = ${EN.int(f.N)}.`,
      ];
    },
  },
  bernoulli: {
    intro: 'For Bernoulli S_n/√n has mean p√n and variance p(1 - p): the variance stays finite, as for Rademacher, but the mean grows without limit, and the law keeps sliding to the right (section 2.1). The central limit theorem applies to the centred quantity: (S_n - np)/√n converges to N(0, p(1 - p)), and (S_n - np)/√(np(1 - p)) to N(0, 1), the de Moivre-Laplace theorem.',
    tableTitle: 'Bernoulli: the drift of S_n/√n and the fading skewness',
    cols: { n: 'n', mean: 'E[S_n/√n] = p√n', sampleMean: 'Simulated mean', skewness: 'Exact skewness', sampleSkewness: 'Simulated skewness', distance: 'Exact distance from the normal' },
    after: (s) => {
      const M = s.models.bernoulli;
      const N = s.params.n;
      return [
        `The skewness of the binomial, (1 - 2p)/√(np(1 - p)), goes to zero like 1/√n: with p = ${EN.plain(s.params.p)} it is ${EN.num(M.mom.skewness / Math.sqrt(SMALL_N), 3)} at n = ${SMALL_N} and ${EN.num(M.mom.skewness / Math.sqrt(N), 4)} at n = ${EN.int(N)}. When p is small and np stays moderate the normal approximates badly, and the binomial rather resembles the Poisson law of mean np (Poisson, 1837): with systems very hard to penetrate, the number of successes of an attacker stays small and skewed even for large n. The rule of thumb np(1 - p) ≥ 10, for using the normal, here asks for n ≥ ${EN.int(normalRule(M.mom))}.`,
        'For the interpretation the difference between the two models matters: in the Bernoulli model the drift p√n of S_n/√n is the score the attacker accumulates on average, and it is what counts; the fluctuations around it, of order 1, are the noise. In the Rademacher model there is no drift, and the fluctuations are everything.',
      ];
    },
  },
  interpretation: {
    intro: ['Back to the attackers and the systems: what changes with more systems, what with more attackers, and how the aggregate score of all of them behaves.'],
  },
  size: {
    paras: (s) => {
      const f = interpretationFacts(s);
      const W = f.walk;
      return [
        `More systems make the share predictable, not the total. In the Bernoulli model an attacker penetrates np systems on average, with a standard deviation of √(np(1 - p)): with n = ${EN.int(f.N)} they are ${EN.num(f.np, 0)} ± ${EN.num(f.sd, 1)}. In absolute terms the uncertainty grows (from ${EN.num(f.sd100, 1)} systems at n = ${EN.int(f.n100)} to ${EN.num(f.sd, 1)} at n = ${EN.int(f.N)}), in proportion it shrinks (from ${EN.pct(f.rel100)} to ${EN.pct(f.relN)} of the mean). For whoever defends a large infrastructure this is half good news: the share of compromised systems is almost certain, their number is not.`,
        `In the Rademacher model the mean is zero, but the trajectories do not stay close to zero. The typical value of |S_n| is √(2n/π) ≈ ${EN.num(f.typical, 1)}, and the maximum reached along the way has on average the same order: ${EN.num(W.maximumExact, 1)} exactly, by the reflection principle, and ${EN.num(W.maximum, 1)} in the simulation. The walk returns to zero on average only ${EN.num(W.zerosExact, 1)} times in ${EN.int(f.N)} steps (${EN.num(W.zeros, 1)} in the simulation): ties are rare, and in proportion they become rarer and rarer, like √n over n.`,
        `The arcsine law (Lévy, 1939) says how much time an attacker spends ahead. Intuition would say about half; instead the share of time ahead has density 1/(π√(x(1 - x))), high near 0 and 1 and low in the middle: whoever gets ahead tends to stay ahead for long. Among the simulated attackers, ${EN.pct(W.extreme)} stayed on the same side for more than 90% of the first ${EN.int(W.even)} systems (exact ${EN.pct(W.extremeExact)}, limit law ${EN.pct(W.extremeLimit)}), against the 20% a uniform share would give.`,
      ];
    },
    arcsineChart: (even, m) => `Rademacher: share of the first ${EN.int(even)} systems in which the attacker is ahead, over the ${EN.int(m)} attackers`,
    arcsineLegend: ['simulation', 'exact law (Feller)', 'arcsine density'],
    after: ['It is the least intuitive lesson of this section: in an even contest, an attacker ahead for thousands of systems in a row is no sign of skill, it is the normal behaviour of chance. The same holds for a defender who keeps "winning".'],
  },
  attackers: {
    intro: 'The number of attackers does not change the law of the score of each one: it changes how well that law is estimated (sections 3 and 5) and, above all, what the best one does. To see it, the m attackers of the Bernoulli model are split into groups of b, and in every group the maximum of the standardized final scores, (S_n - np)/√(np(1 - p)), is taken.',
    bestChart: (n) => `Bernoulli, n = ${EN.int(n)}: the best standardized score in a group of b attackers (logarithmic b axis)`,
    bestLegend: ['simulation: mean over the groups, 95% interval', 'exact value (binomial)', 'maximum of b standard normals', '√(2 ln b)'],
    probabilityChart: (n) => `Bernoulli, n = ${EN.int(n)}: at least one of b attackers more than 3 standard deviations above the mean, and systems penetrated by at least one of the first b`,
    probabilityLegend: ['at least one beyond +3σ: simulation', 'at least one beyond +3σ: exact', 'systems penetrated: simulation', 'systems penetrated: exact'],
    after: (s) => {
      const f = interpretationFacts(s);
      const simulated = f.row5 && f.row20 ? ` (simulated: ${EN.pct(f.row5.coverage)} and ${EN.pct(f.row20.coverage)})` : '';
      return [
        `The best of b attackers moves away from the mean slowly, like √(2 ln b): ${EN.num(f.best10, 2)} standard deviations with 10 attackers, ${EN.num(f.best100, 2)} with 100 and ${EN.num(f.best1000, 2)} with 1,000, by the exact law. For every factor 10 of extra attackers the first gains about ${EN.num((f.best1000 - f.best10) / 2, 2)} standard deviations: doubling the attackers doubles nothing.`,
        `Events that are rare for one attacker become likely for many. Going 3 standard deviations above the mean happens to a single attacker with probability ${EN.num(f.tail, 4)}, but to at least one in 100 with probability ${EN.num(f.atLeast100, 3)} and to at least one in 1,000 with ${EN.num(f.atLeast1000, 3)}. For a defender the worst case is what counts, and the worst case grows with m even though no attacker is better than the others.`,
        `The same formula gives the coverage of the systems: a system resists one attacker with probability 1 - p and b independent attackers with probability (1 - p)^b, so the share of systems penetrated by at least one of the first b is 1 - (1 - p)^b: ${EN.pct(f.cover5)} with 5 attackers and ${EN.pct(f.cover20)} with 20${simulated}. With p = ${EN.plain(f.p)}, ${EN.int(f.b95)} independent attackers are enough to reach 95% of the systems.`,
      ];
    },
  },
  aggregate: {
    paras: (s) => {
      const f = interpretationFacts(s);
      const A = f.aggregate;
      return [
        `The aggregate score of all attackers on all systems, T, the sum of all the X, is a sum of mn i.i.d. increments, and the same theorems hold with mn in place of n. For Bernoulli T has mean mnp = ${EN.int(A.expected)} and standard deviation √(mnp(1 - p)) = ${EN.num(A.sd, 1)}; the simulation gives ${EN.int(A.total)} (z = ${EN.num(A.z, 2)}). Mean and variance depend on n and m only through their product: 10 attackers on 1,000 systems and 1,000 attackers on 10 systems produce on average the same aggregate score.`,
        `The product, however, does not tell everything: the same m × n table of outcomes can be read by rows or by columns. By row, that is by attacker, the sum is S_n; by column, that is by system, it is the number of attackers that penetrated it, K_i ~ Bin(m, p). The theorems hold along the columns too, with m in place of n: per system the mean is mp = ${EN.num(A.systemMean, 1)} and the variance mp(1 - p) = ${EN.num(A.systemVariance, 1)}; over the ${EN.int(f.N)} simulated systems they are ${EN.num(A.perSystemMean, 1)} and ${EN.num(A.perSystemVariance, 1)}, and the χ² test ${f.systems.verdict === 'reject' ? 'rejects' : 'does not reject'} the binomial law (p = ${EN.pval(f.systems.pValue)}).`,
      ];
    },
    systemsChart: (n, m) => `Bernoulli: number of attackers, out of ${EN.int(m)}, that penetrated each of the ${EN.int(n)} systems`,
    systemsLegend: ['simulation', 'exact law Bin(m, p)', 'normal with the same mean and variance'],
    after: ['In short, n and m play symmetric roles in the total score and different roles in the questions that matter: n decides how predictable the share of successes of each attacker is, m how extreme the best one is and how many systems are reached by somebody.'],
  },
  limits: {
    paras: [
      'The i.i.d. model is a first approximation, useful precisely because it lets us compute everything. In reality its assumptions fail in at least four ways, and each one changes a different conclusion.',
      'Different systems. If the penetration probability depends on the system, p_i, the increments stay independent but are no longer identically distributed. The law of large numbers still holds, for the mean of the p_i, and so does the central limit theorem in the versions of Lyapunov (1901) and Lindeberg (1922), as long as no system dominates the variance: the conclusions of sections 3, 4 and 5 remain, with μ and σ² averaged over the systems.',
      'Shared vulnerabilities. If many systems share a vulnerability (the same software, the same configuration), the outcomes are correlated. With a correlation ρ between the increments, Var(S_n) = nσ²(1 + (n - 1)ρ), which grows like n², and S_n/n no longer concentrates on μ: the law of large numbers fails. It is the worst case for a defender, because diversification stops reducing the risk.',
      'Attackers that learn. If every success makes the next one easier, for example because access already obtained opens the way to lateral movement, the increments are dependent and the process resembles a Pólya urn: S_n/n still converges, but to a random limit that depends on the first steps, and two identical attackers can end with very different shares of success.',
      'Heavy-tailed scores. If a single system can be worth a huge score (a domain controller compared with a printer) and the variance is infinite, the classical central limit theorem fails: the sum is dominated by the largest values and tends to a stable law, not a normal one. In all these cases simulation remains the right tool: the model changes, not the method.',
    ],
  },
  stats: {
    verdict: { reject: 'H₀ rejected', notReject: 'H₀ not rejected' },
    expected: { reject: 'expected: rejection', notReject: 'expected: no rejection', either: 'depends on the power of the test' },
    testLine: testLineEn,
    groups: { sim: 'Generator', lln: 'Large numbers', clt: 'Central limit', walk: 'Random walk' },
    labels: {
      sim: {
        bernoulliPairs: 'Bernoulli: consecutive increments are independent (χ², 2 × 2)',
        rademacherPairs: 'Rademacher: consecutive increments are independent (χ², 2 × 2)',
        bernoulliSystems: 'Bernoulli: the hits per system follow Bin(m, p) (χ²)',
      },
      lln: {
        bernoulliMean: 'Bernoulli: the mean of S_n/n is p (z)',
        rademacherMean: 'Rademacher: the mean of S_n/n is 0 (z)',
        bernoulliVariance: 'Bernoulli: the variance of S_n is np(1 - p) (z, large samples)',
        rademacherVariance: 'Rademacher: the variance of S_n is n (z, large samples)',
      },
      clt: {
        bernoulliExact: 'Bernoulli: S_n follows its exact law Bin(n, p) (χ²)',
        rademacherExact: 'Rademacher: S_n follows its exact law 2 Bin(n, 1/2) - n (χ²)',
        rademacherNormal: 'Rademacher: S_n/√n is N(0, 1), with continuity correction (Kolmogorov-Smirnov)',
        rademacherSmall: `Rademacher: S_${SMALL_N}/√${SMALL_N} is N(0, 1), without correction (Kolmogorov-Smirnov)`,
        rademacherJb: 'Rademacher: S_n/√n has the skewness and kurtosis of a normal (Jarque-Bera)',
        bernoulliJb: 'Bernoulli: the standardized S_n has the skewness and kurtosis of a normal (Jarque-Bera)',
        bernoulliSmall: `Bernoulli: the standardized S_${SMALL_N} has the skewness and kurtosis of a normal (Jarque-Bera)`,
      },
      walk: { arcsine: 'Rademacher: the time ahead follows Feller’s arcsine law (χ²)' },
    },
  },
  tests: {
    intro: (s) => `The hypothesis tests of the page, at significance level α = ${EN.num(SIGNIFICANCE, 2)}. The generator is checked through consecutive increments and hits per system; the law of large numbers through the mean and variance at n = ${EN.int(s.params.n)}; the central limit theorem through the exact law, the normal and the moments; the walk through the arcsine law. Two tests, at n = ${SMALL_N}, have a false null hypothesis on purpose: the normal is not yet a good approximation, and their rejection is expected.`,
    cols: { subject: 'Subject', hypothesis: 'Null hypothesis H₀', p: 'p-value', verdict: 'Outcome', expected: 'Reading' },
    after: (sum, s) => {
      const out = [`${sum.rejected} of ${sum.count} tests reject the null hypothesis, ${sum.asExpected === sum.count ? 'all as expected' : `${sum.asExpected} of ${sum.count} as expected`}.`];
      const expectedFalse = EN.num(sum.nulls * SIGNIFICANCE, 2);
      const which = sum.falseRejections.map((t) => EN.pval(t.result.pValue)).join(', ');
      out.push(
        `Among the ${sum.nulls} tests with a true null hypothesis (or false by differences too small for m attackers to see), at level ${EN.num(SIGNIFICANCE, 2)} one expects on average ${expectedFalse} rejections by pure chance: ${sum.falseRejections.length === 0 ? 'here there are none' : `here there ${sum.falseRejections.length === 1 ? 'is one' : `are ${sum.falseRejections.length}`} (p = ${which})`}. Holm’s correction for multiple testing, which keeps below 5% the probability of even a single wrong rejection, compares the smallest p-value with ${EN.num(SIGNIFICANCE, 2)}/${sum.nulls} = ${EN.num(sum.holmThreshold, 4)}, the next with ${EN.num(SIGNIFICANCE, 2)}/${sum.nulls - 1} and so on: ${sum.holm === 0 ? 'no rejection survives' : `${sum.holm === 1 ? 'one rejection survives' : `${sum.holm} rejections survive`}, to be looked at as a possible flaw`}.`,
      );
      const small = s.models.rademacher.tests.smallKs;
      out.push(`One remark holds for all of them: for the same difference, the p-value depends on m. With ${EN.int(s.params.m)} attackers the Kolmogorov-Smirnov test sees distances from the normal of a few hundredths, and rejects the normality of S_${SMALL_N}/√${SMALL_N} with p = ${EN.pval(small.pValue)}; with fifty attackers the same distance, ${EN.num(small.D, 3)}, would go unnoticed. Significance and size of a difference are two different questions.`);
      return out;
    },
  },
  history: {
    intro: 'From Bernoulli trials to the generator of this page, the ideas used in the homework in chronological order.',
    legend: { task: 'used in this page', context: 'context' },
    events: [
      { year: '1654', task: false, title: 'Pascal and Fermat', text: 'The problem of points, how to divide the stakes of an interrupted game: the correspondence between Pascal and Fermat founds the calculus of probability.' },
      { year: '1713', task: true, title: 'Jacob Bernoulli', text: 'In the Ars Conjectandi, published after his death, the "golden theorem": the frequency of successes in independent trials approaches their probability. It is the first law of large numbers, and trials with two outcomes bear his name.' },
      { year: '1733', task: true, title: 'de Moivre', text: 'Approximates the binomial with p = 1/2 by the curve now called normal, then publishes it again in The Doctrine of Chances (1738): the first central limit theorem, precisely for sums of ±1 increments.' },
      { year: '1812', task: true, title: 'Laplace', text: 'In the Théorie analytique des probabilités extends the result to any p, the de Moivre-Laplace theorem of section 5.3, and to more general sums.' },
      { year: '1837', task: true, title: 'Poisson', text: 'In the Recherches sur la probabilité des jugements names the law of large numbers and derives the law of rare events, the approximation of the binomial when p is small.' },
      { year: '1853-1867', task: true, title: 'Bienaymé and Chebyshev', text: 'The inequality P(|X - μ| ≥ kσ) ≤ 1/k² and the proof of the weak law for independent variables with bounded variances: the bound of section 3.2.' },
      { year: '1889', task: true, title: 'Galton', text: 'In Natural Inheritance describes the quincunx, the board of pins he had built years before: at every row a ball bounces right or left, so every ball performs a Rademacher walk, and the heap at the bottom is the bell.' },
      { year: '1900-1901', task: true, title: 'Lyapunov', text: 'Proves the central limit theorem for independent non-identical variables, under a condition on the moments, with characteristic functions.' },
      { year: '1905', task: false, title: 'Pearson', text: 'In a letter to Nature asks for the law of the distance covered by someone taking n steps in random directions: the name random walk is born.' },
      { year: '1909', task: true, title: 'Borel', text: 'The strong law of large numbers for Bernoulli trials: almost every real number has binary digits with frequency 1/2.' },
      { year: '1920-1921', task: true, title: 'Pólya', text: 'Calls the result of de Moivre and Laplace the "central limit theorem" (1920), and proves that the simple random walk returns to the origin with probability 1 in one and two dimensions, not in three (1921).' },
      { year: '1922', task: false, title: 'Lindeberg', text: 'The most general condition for the central limit theorem with independent non-identical increments, which Feller (1935) will show to be also necessary.' },
      { year: '1924', task: true, title: 'Khinchin', text: 'The law of the iterated logarithm for Bernoulli trials: the oscillations of S_n - np reach √(2np(1 - p) ln ln n), and no further. It is the envelope of the animation.' },
      { year: '1929-1933', task: true, title: 'Kolmogorov', text: 'Extends the law of the iterated logarithm (1929); in 1933 founds probability on axioms, proves the strong law in general and introduces the distance between distribution functions on which the Kolmogorov-Smirnov test rests.' },
      { year: '1939', task: true, title: 'Lévy', text: 'The arcsine laws for Brownian motion. The version for the Rademacher walk, with the exact law of section 6.1, is in Feller’s book (1950).' },
      { year: '1941-1942', task: true, title: 'Berry and Esseen', text: 'Independently, the bound C ρ/(σ³√n) on the distance between the standardized sum and the normal: the speed of the central limit theorem.' },
      { year: '1949', task: true, title: 'Metropolis and Ulam', text: 'The Monte Carlo Method: estimating probabilities and expected values by simulating many samples, the method of this page.' },
      { year: '1963', task: true, title: 'Hoeffding', text: 'The exponential inequality for sums of bounded variables.' },
      { year: '1980', task: true, title: 'Jarque and Bera', text: 'The normality test based on skewness and kurtosis.' },
      { year: '1997', task: false, title: 'Jonsson and Olovsson', text: 'A quantitative model of the intrusion process built on the behaviour of real attackers: the penetration process as a statistical object.' },
      { year: '2011', task: true, title: 'Shevtsova', text: `Lowers the Berry-Esseen constant for identically distributed summands to ${EN.num(BERRY_ESSEEN_C, 4)}, the value of section 5.2.` },
      { year: '2014-2018', task: true, title: 'SplitMix and xoshiro', text: 'Steele, Lea and Flood publish SplitMix (2014), Blackman and Vigna the xoshiro generators (2018): they are the random numbers of this page.' },
    ],
    after: 'Read in order, the history of these theorems is the structure of this page: first the law of large numbers for Bernoulli trials (1713), then the normal for sums of ±1 (1733), then generality (Laplace, Chebyshev, Lyapunov, Lindeberg), the trajectories (Borel, Khinchin, Lévy) and the speed (Berry and Esseen). Simulation came last and changed the way they are used: the theorems say what to expect, the simulation checks whether the model is the right one.',
  },
  conclusion: (s) => {
    if (!s) {
      return [
        'The three quantities of the assignment are the same variable on three scales, and the three scales tell three stories: S_n grows, S_n/n concentrates on μ (law of large numbers), S_n/√n settles and, for Rademacher, becomes normal (central limit theorem).',
      ];
    }
    const rows = llnRows(s, 0.05);
    const R = s.models.rademacher;
    const f = interpretationFacts(s);
    const first = rows.rademacher.find((r) => r.n >= 100) || rows.rademacher[0];
    const lastRow = rows.rademacher[rows.rademacher.length - 1];
    const d = lastOf(R).distance;
    return [
      `The three quantities of the assignment are the same variable on three scales, and the three scales tell three stories. S_n grows: for Bernoulli like np, with fluctuations of order √n, for Rademacher it stays centred on zero but widens like √n. S_n/n concentrates: for Rademacher the probability of being farther than 0.05 from μ falls from ${EN.num(first.exact, 3)} at n = ${EN.int(first.n)} to ${EN.small(lastRow.exact)} at n = ${EN.int(lastRow.n)}, the law of large numbers. S_n/√n settles: its variance stays σ², and for Rademacher its law converges to N(0, 1), with a Kolmogorov distance of ${EN.small(d)} at n = ${EN.int(s.params.n)}, the central limit theorem.`,
      'The simulation agrees with the theory within its error: means, variances and exact laws are not rejected, and the expected rejections are those at n = 10, where the normal is not yet a good approximation. Two things, however, the simulation cannot see on its own, and the exact computations are needed: probabilities smaller than 1/m and distances smaller than 1/√m. That is the precise sense in which m must be chosen suitably.',
      `For attackers and systems the lesson is twofold. With more systems the share of successes of each attacker becomes predictable, while the absolute number of compromised systems stays uncertain by √n. With more attackers nobody becomes better, but the best one moves away from the mean like √(2 ln m), rare events become likely and almost all systems are reached by somebody: ${EN.pct(f.cover20)} of the systems already with 20 independent attackers.`,
      'The model is deliberately simple: equal systems, independent outcomes, attackers that do not learn. Its most robust conclusions, the concentration of the frequencies, the √n scale and the growth of the worst case with m, survive different systems; they fail with shared vulnerabilities and attackers that learn, and there simulation remains the tool to find out what changes.',
    ];
  },
  modelNames: { bernoulli: 'Bernoulli', rademacher: 'Rademacher' },
  quantityNames: { sum: 'S_n', mean: 'S_n/n', normalized: 'S_n/√n' },
  trajectoryNames: { sum: 'S_k', mean: 'S_k/k', normalized: 'S_k/√k' },
  tips: {
    trajectory: (hit, name) =>
      hit.kind === 'bin'
        ? said(`${name} between ${valueEn(hit.from, hit.quantity)} and ${valueEn(hit.to, hit.quantity)} at system ${EN.int(hit.k)}`, [on(hit.show, 'bars') && `${EN.int(hit.count)} attackers out of ${EN.int(hit.sample)}`, on(hit.show, 'normal') && `${EN.num(hit.expected, 1)} expected from the normal`])
        : said(`System ${EN.int(hit.step)}`, [on(hit.show, 'first') && `${name} of attacker 1 ${valueEn(hit.first, hit.quantity)}`, on(hit.show, 'band') && `mean ${valueEn(hit.mean, hit.quantity)}, band between ${valueEn(hit.mean - 2 * hit.sd, hit.quantity)} and ${valueEn(hit.mean + 2 * hit.sd, hit.quantity)}`], '; '),
    bin: (from, to, share, prob, normal) => {
      const d = edgeDigits(from, to);
      return said(`From ${EN.num(from, d)} to ${EN.num(to, d)}`, [`simulation ${EN.pct(share, 2)}`, prob !== null && `exact law ${EN.pct(prob, 2)}`, normal !== null && `normal ${EN.pct(normal, 2)}`]);
    },
    share: (from, to, share, prob, limit) => said(`Ahead between ${EN.pct(from, 1)} and ${EN.pct(to, 1)} of the time`, [`simulation ${EN.pct(share, 2)}`, prob !== null && `exact law ${EN.pct(prob, 2)}`, limit !== null && `arcsine ${EN.pct(limit, 2)}`]),
    lln: (r, show) => said(`n = ${EN.int(r.n)}`, [on(show, 'rate') && `simulated ${EN.num(r.rate, 4)} (95%: ${EN.num(r.interval[0], 4)}-${EN.num(r.interval[1], 4)})`, on(show, 'exact') && `exact ${EN.small(r.exact)}`, on(show, 'chebyshev') && `Chebyshev ${EN.small(r.chebyshev)}`, on(show, 'hoeffding') && `Hoeffding ${EN.small(r.hoeffding)}`]),
    // pairs: [simulated, exact] for S_n, S_n/n and S_n/√n, null where hidden
    variance: (n, pairs) => said(`n = ${EN.int(n)}`, ['S_n', 'S_n/n', 'S_n/√n'].map((q, i) => pairs[i] && [pairs[i][0] !== null && `Var(${q}) ${EN.small(pairs[i][0])}`, pairs[i][1] !== null && `exact ${EN.small(pairs[i][1])}`].filter(Boolean).join(' ')).filter(Boolean)),
    distance: (n, d, dc, bound, ks) => said(`n = ${EN.int(n)}`, [d !== null && `exact ${EN.small(d)}`, dc !== null && `corrected ${EN.small(dc)}`, bound !== null && `Berry-Esseen ${EN.small(bound)}`, ks !== null && `simulated ${EN.num(ks, 4)}`]),
    qq: (a, b) => `Quantile of N(0, 1) ${EN.num(a, 2)}: simulated ${EN.num(b, 2)}`,
    best: (r, show) => said(`b = ${EN.int(r.b)} (${EN.int(r.groups)} groups)`, [on(show, 'mean') && `simulated ${EN.num(r.mean, 2)} ± ${EN.num(1.96 * r.error, 2)}`, on(show, 'exact') && `exact ${EN.num(r.exact, 2)}`, on(show, 'normal') && `normal ${EN.num(r.normal, 2)}`, on(show, 'asymptote') && `√(2 ln b) ${EN.num(r.asymptote, 2)}`]),
    probability: (r, show) => said(`b = ${EN.int(r.b)}`, [on(show, 'beyond') && `at least one beyond +3σ ${EN.pct(r.beyond)}`, on(show, 'beyondExact') && `at least one beyond +3σ, exact ${EN.pct(r.beyondExact)}`, on(show, 'coverage') && `systems penetrated ${EN.pct(r.coverage)}`, on(show, 'coverageExact') && `systems penetrated, exact ${EN.pct(r.coverageExact)}`], '; '),
  },
  download: {
    title: 'Download the code',
    text: 'The complete program in HTML, CSS and JavaScript, with no dependencies, in Italian and English: after extracting the archive it opens with a double click on index.html, even offline, with the same simulations and animations. With node homework3.js it prints the tables, the tests and a histogram in the terminal; --p, --n, --m, --seed and --epsilon change the parameters.',
    contents: 'Contents: index.html, style.css, homework3.js (generator, simulation, statistics, charts and animation), app.js (interface and texts), README.txt.',
    zip: 'Download homework3',
    online: 'Open the program online',
  },
  standalone: {
    subtitle: 'The penetration score of m attackers on n systems: the law of large numbers and the central limit theorem.',
    course: 'Statistics, MSc in Cybersecurity, Sapienza University of Rome',
    online: 'Online version',
    noscript: 'This program needs JavaScript.',
  },
};

const HW3_TEXTS = { it, en };

return { originalAssignment, HW3_TEXTS };
})();

(function () {
'use strict';

// src/pages/statistics/hw3/standalone/app.js
// L'interfaccia del programma scaricabile, in JavaScript puro: niente React,
// niente dipendenze. Disegna le stesse sezioni della pagina del sito con gli
// stessi testi (texts.js), la stessa logica di presentazione (view.js) e gli
// stessi calcoli (homework3.js). La build (build/homework-standalone.js) lo
// unisce a view.js e texts.js in un unico app.js, uno script classico che si
// apre anche da file:// con un doppio clic su index.html.
//
// Da file:// i worker non partono: la simulazione gira qui, a fette di pochi
// millisecondi, e la pagina resta reattiva mentre i numeri arrivano; intanto
// l'animazione delle traiettorie, che non ne ha bisogno, funziona gia'.
//
// Ogni testo entra nella pagina con textContent, mai come HTML: nemmeno
// quello che si scrive nei campi puo' diventare markup.
const hw = Homework3;
const view = view$;
const { HW3_TEXTS, originalAssignment } = texts$;
const kit = kitDom$;

const HEADINGS = ['h2', 'h3', 'h4'];
const LANGUAGES = ['it', 'en'];

const PALETTES = {
  light: hw.DEFAULT_PALETTE,
  dark: {
    background: '#161616',
    text: '#d6d6d6',
    grid: '#262626',
    bars: '#7986cb',
    reference: '#ff6b81',
    highlight: '#ff6b81',
    series: ['#7986cb', '#ff6b81', '#4fb39c', '#ffca28', '#ba68c8', '#4dd0e1', '#9e9e9e'],
  },
};
const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');
const palette = () => (darkQuery.matches ? PALETTES.dark : PALETTES.light);

// I campi non devono passare per correttori o completamenti.
const PRIVATE_FIELD = {
  autocomplete: 'off',
  autocorrect: 'off',
  autocapitalize: 'none',
  spellcheck: 'false',
  'data-gramm': 'false',
  'data-lpignore': 'true',
};

// ---------------------------------------------------------------------------
// Stato
// ---------------------------------------------------------------------------

// Si apre sempre in inglese, come la pagina sul sito; IT / EN cambia lingua
// finche' la pagina resta aperta, senza salvare la scelta. Il sito, aprendo
// la versione online, passa nell'indirizzo la lingua che si stava leggendo.
function initialLanguage() {
  const fromUrl = new URLSearchParams(window.location.search).get('lang');
  return LANGUAGES.includes(fromUrl) ? fromUrl : 'en';
}

const state = {
  lang: initialLanguage(),
  fields: { ...view.DEFAULT_INPUTS },
  // l'ultimo valore valido di ogni campo, e quelli dell'ultima simulazione partita
  params: { ...view.DEFAULT_PARAMS },
  target: { ...view.DEFAULT_PARAMS },
  epsilon: hw.DEFAULT_EPSILON,
  sweep: { quantity: 'mean', g: null, playing: false },
  normal: { model: 'rademacher', g: null, playing: false },
  anim: { model: 'rademacher', quantity: 'sum', speed: 1 },
};
let text = HW3_TEXTS[state.lang];
const regions = {};
const controls = { fields: {} };
const timers = { compute: null, sweep: null, normal: null };

// I risultati gia' calcolati (gli ultimi), quelli mostrati e la simulazione in corso
const results = new Map();
const computation = { shown: null, error: null, running: null };
let animation = null;
// the chart of the kit that hosts the canvas of the animation (zoom and panning)
let animationChart = null;

// ---------------------------------------------------------------------------
// DOM: un aiutante minimo, i grafici e il loro ridisegno
// ---------------------------------------------------------------------------

/** h('p', { class: 'note', text: '...' }, child, ...): text always via textContent. */
function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') el.className = value;
    else if (key === 'text') el.textContent = value;
    else if (key === 'style') Object.assign(el.style, value);
    else if (key.startsWith('on')) el.addEventListener(key.slice(2), value);
    else el.setAttribute(key, value === true ? '' : String(value));
  }
  for (const child of children.flat(Infinity)) {
    if (child === null || child === undefined || child === false) continue;
    el.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return el;
}

const paras = (list) => list.filter(Boolean).map((t) => h('p', { text: t }));
const title = (id, level, label) => h(HEADINGS[level], { id, tabindex: -1, class: 'anchor', text: label });
const subtitle = (label) => h('p', { class: 'table-title' }, h('strong', { text: label }));
const pending = () => (computation.error ? h('p', { class: 'note', text: text.ui.error(computation.error) }) : h('p', { class: 'note pending', role: 'status', text: text.ui.computing }));
const check = (ok, label) => h('p', { class: ok ? 'check is-ok' : 'check is-bad' }, h('strong', { text: label }));
const formulas = (content, label = null) => [label && subtitle(label), h('pre', { text: content })];

// what the reader hid in the legends, by chart: a region filled anew (a step, a result) keeps it
const kept = {};
const keep = (name) => {
  if (!kept[name]) kept[name] = new Set();
  return kept[name];
};

/** The parts of the drawing covered by the hidden items of a legend. */
const partsOf = (items, hidden) => items.flatMap((item, i) => (hidden.has(i) ? item.parts || [] : []));

/**
 * The legend of a chart, or of a group of charts: { label, color? |
 * paletteKey?, dashed?, box?, parts }. Every item is a button: pressed (as
 * the page opens) its parts are on screen, released they are hidden;
 * onChange(parts) receives the hidden parts after every press. `hidden`,
 * the set of the hidden items, outlives the legend when its chart is built
 * again.
 */
function legend(items, onChange = null, hidden = new Set()) {
  const pal = palette();
  return h(
    'ul',
    { class: 'series-legend' },
    items.map((item, i) => {
      const color = item.paletteKey ? pal[item.paletteKey] : pal.series[(item.color ?? i) % pal.series.length];
      let swatch = null;
      if (item.box) swatch = 'is-box';
      else if (item.dashed) swatch = 'is-dashed';
      const button = h(
        'button',
        {
          type: 'button',
          'aria-pressed': String(!hidden.has(i)),
          class: hidden.has(i) ? 'is-off' : null,
          onclick: () => {
            if (hidden.has(i)) hidden.delete(i);
            else hidden.add(i);
            button.setAttribute('aria-pressed', String(!hidden.has(i)));
            button.classList.toggle('is-off', hidden.has(i));
            if (onChange) onChange(partsOf(items, hidden));
          },
        },
        h('span', { class: swatch, 'aria-hidden': 'true', style: { borderColor: color, backgroundColor: item.box ? color : 'transparent' } }),
        item.label,
      );
      return h('li', null, button);
    }),
  );
}

/** Hides the cells and rows of a table that belong to hidden parts (data-part), and shows the others. */
function hideParts(tableEl, parts) {
  for (const el of tableEl.querySelectorAll('[data-part]')) el.hidden = parts.includes(el.dataset.part);
}

/** Hides parts of a chart (the legend of a group of charts calls it on each of them). */
function setHidden(fig, parts) {
  fig.kit.setHidden(parts);
}

/**
 * A chart (chartkit/kitDom.js): drawn by homework3.js, with its legend
 * (`items`), its label under the pointer, the table tied to it (`link`)
 * and zoom. onHide(parts) runs when the reader hides or shows a part, for
 * the table tied to the chart, and `keep` (a set, keep(name)) remembers
 * the hidden items when the chart is built again. The charts of a group
 * share one legend (groupLegend) and have no `items`. `reveal`
 * (milliseconds a point) draws the simulation point by point, as n grows.
 */
function figure(caption, draw, data, { wide = false, tip = null, items = null, note = null, link = null, onHide = null, keep: kept = null, reveal = 0 } = {}) {
  return kit.createFigure({ label: caption, draw, data, palette: palette(), lib: hw, schedule: view.scheduleFrameJob, lang: state.lang, tip, items, note, link, onHide, keep: kept, wide, animation: reveal ? view.reveal(data, reveal) : null });
}

/** Redraws a chart in place, with new data, labels and note, without replacing its canvas; the hidden parts and the zoom stay. */
function refreshFigure(fig, caption, data, tip, note = null) {
  fig.kit.setData(data);
  fig.kit.setTip(tip);
  fig.kit.setLabel(caption);
  fig.kit.setNote(note);
}

/** Whether the figures kept for a region can be changed in place: built for the same result and language, and still on the page. */
const sameFigures = (kept, data) => !!kept.fig && kept.data === data && kept.lang === state.lang && kept.fig.isConnected;

// the histograms of 2.1 and 5.1, kept while the slider or the player moves n (their zoom too)
const sweepView = { fig: null, figs: [], data: null, lang: null };
const normalView = { fig: null, qq: null, stats: null, data: null, lang: null };

/**
 * One legend for a group of charts (the two models side by side): every
 * press hides or shows the same parts in all of them, and onHide(parts)
 * updates the table they share. The charts start with what `name` keeps.
 */
function groupLegend(name, items, figs, onHide = null) {
  const hidden = keep(name);
  const parts = partsOf(items, hidden);
  for (const fig of figs) setHidden(fig, parts);
  return legend(
    items,
    (next) => {
      for (const fig of figs) setHidden(fig, next);
      if (onHide) onHide(next);
    },
    hidden,
  );
}

/** Replaces the content of a region, releasing the charts it contained and their labels. */
function fill(region, ...nodes) {
  kit.releaseFigures(region);
  region.replaceChildren(...nodes.flat(Infinity).filter((n) => n !== null && n !== undefined && n !== false));
}

/** A table: column headers, then rows of cells, each { text | node, class?, head? } (head: a row header, th); `id` for a table tied to a chart (view.LINKED_TABLES); `columns` gives the part of a chart each column belongs to, and a row can have its own `part`: hideParts() hides them with their curve. */
function table(className, headers, rows, id = null, columns = []) {
  return h(
    'table',
    { id, class: `table ${className}` },
    h('thead', null, h('tr', null, headers.map((x, i) => h('th', { text: x, 'data-part': columns[i] || null })))),
    h(
      'tbody',
      null,
      rows.map((row) => h(
        'tr',
        { class: row.class || null, 'data-part': row.part || null },
        row.cells.map((cell, i) => h(cell.head ? 'th' : 'td', { 'data-label': cell.head ? null : headers[i], class: cell.class || null, 'data-part': columns[i] || null }, cell.node || cell.text)),
      )),
    ),
  );
}

/** The hypothesis tests of one group, with what each should say. */
function tests(group, s) {
  const expected = view.expectedVerdicts(s);
  return h(
    'div',
    { class: 'tests' },
    view.statTests(s)[group].map(([key, t]) => {
      const rejected = t.verdict === 'reject';
      return h(
        'div',
        { class: `test ${rejected ? 'is-invalid' : 'is-valid'}` },
        h(
          'p',
          { class: 'test-head' },
          h('strong', { text: text.stats.labels[group][key] }),
          ' ',
          h('span', { class: `badge ${rejected ? 'is-invalid' : 'is-valid'}`, text: text.stats.verdict[rejected ? 'reject' : 'notReject'] }),
          h('span', { class: 'note', text: ` (${text.stats.expected[expected[group][key]]})` }),
        ),
        h('p', { text: text.stats.testLine(t) }),
      );
    }),
  );
}

/** A choice among a few values (model, quantity): the pressed button is the active one. */
function choices(label, options, value, onChange) {
  const buttons = options.map(([key, name]) => h('button', { type: 'button', class: 'btn alt', 'aria-pressed': String(key === value), text: name, onclick: () => select(key) }));
  function select(key) {
    options.forEach(([k], i) => buttons[i].setAttribute('aria-pressed', String(k === key)));
    onChange(key);
  }
  return h('div', { class: 'choices', role: 'group', 'aria-label': label }, h('span', { class: 'choices-label', text: label }), buttons);
}

/** A slider on the indices of the checkpoints; set() moves it when the results or the language change. */
function slider(id, onChange) {
  const label = h('label', { for: id });
  const input = h('input', { id, type: 'range', min: 0, max: 0, step: 1, value: 0, oninput: (e) => onChange(Number(e.target.value)) });
  return {
    el: h('div', { class: 'slider' }, label, input),
    set(max, value, labelText) {
      input.max = String(max);
      input.value = String(value);
      input.disabled = max === 0 && !computation.shown;
      label.textContent = labelText;
      input.setAttribute('aria-valuetext', labelText);
    },
  };
}

const modelOptions = () => hw.MODELS.map((m) => [m, text.modelNames[m]]);

// ---------------------------------------------------------------------------
// 0. La consegna
// ---------------------------------------------------------------------------

function assignmentSection() {
  return h(
    'section',
    { class: 'section' },
    title('hw3-assignment', 0, text.sections.assignment),
    paras(text.assignment.intro),
    h(
      'details',
      { class: 'original', open: true },
      h('summary', { text: text.assignment.originalTitle }),
      h('p', { class: 'note', text: text.assignment.originalNote }),
      h('blockquote', { lang: 'en' }, originalAssignment().map((block) => h('p', { text: block.text }))),
    ),
  );
}

// ---------------------------------------------------------------------------
// 1. Il modello, i campi, l'animazione e le verifiche
// ---------------------------------------------------------------------------

function modelSection() {
  const S = text.sections;
  const I = text.input;
  const Q = text.quantities;
  regions.models = h('div');
  regions.status = h('div');
  regions.verify = h('div');
  regions.simTests = h('div');
  return h(
    'section',
    { class: 'section' },
    title('hw3-model', 0, S.model),
    paras(text.model.intro),
    formulas(text.model.formulas, text.model.formulasTitle),
    title('hw3-models', 1, S.models),
    regions.models,
    title('hw3-quantities', 1, S.quantities),
    paras(Q.intro),
    subtitle(Q.tableTitle),
    table('discussion quantities', [Q.cols.quantity, Q.cols.mean, Q.cols.variance, Q.cols.sd, Q.cols.trend], Q.rows.map((row) => ({ cells: [{ text: row[0], head: true }, { text: row[1] }, { text: row[2] }, { text: row[3] }, { text: row[4] }] }))),
    paras(Q.after),
    title('hw3-input', 1, S.input),
    h('p', { text: I.intro }),
    inputsBlock(),
    regions.status,
    title('hw3-trajectories', 1, S.trajectories),
    trajectoriesBlock(),
    title('hw3-verify', 1, S.verify),
    regions.verify,
    regions.simTests,
  );
}

function updateModels() {
  const M = text.models;
  const F = text.fmt;
  const p = state.params.p;
  fill(
    regions.models,
    paras(M.intro),
    subtitle(M.tableTitle(p)),
    table(
      'discussion models',
      [M.cols.model, M.cols.values, M.cols.mu, M.cols.variance, M.cols.rho, M.cols.skewness],
      hw.MODELS.map((model) => {
        const mom = hw.modelMoments(model, p);
        return { cells: [{ text: text.modelNames[model], head: true }, { text: model === 'bernoulli' ? '{0, 1}' : '{-1, +1}' }, { text: F.num(mom.mu, 4) }, { text: F.num(mom.variance, 4) }, { text: F.num(mom.rho, 4) }, { text: F.num(mom.skewness, 4) }] };
      }),
    ),
    paras(M.after),
  );
}

// --- 1.3 I campi ----------------------------------------------------------------

const FIELDS = [
  ['p', 'pText', 'hw3-p', 'decimal'],
  ['n', 'nText', 'hw3-n', 'numeric'],
  ['m', 'mText', 'hw3-m', 'numeric'],
  ['seed', 'seedText', 'hw3-seed', 'numeric'],
];

function inputsBlock() {
  const I = text.input;
  const labels = { p: [I.pLabel, I.pHint], n: [I.nLabel, I.nHint], m: [I.mLabel, I.mHint], seed: [I.seedLabel, I.seedHint] };
  return h(
    'div',
    { class: 'params' },
    FIELDS.map(([key, name, id, mode]) => {
      const input = h('input', { id, type: 'text', inputmode: mode, ...PRIVATE_FIELD, maxlength: view.FIELD_LENGTH[key], 'aria-describedby': `${id}-help`, oninput: (e) => changeFields({ [name]: e.target.value.slice(0, view.FIELD_LENGTH[key]) }) });
      input.value = state.fields[name];
      const help = h('p', { id: `${id}-help`, class: 'note', text: labels[key][1] });
      controls.fields[key] = { input, help, hint: labels[key][1] };
      const extra = key === 'seed' ? h('button', { type: 'button', class: 'btn alt', text: I.randomSeed, onclick: () => changeFields({ seedText: String(hw.randomSeed()) }, true) }) : null;
      return h('div', { class: 'param' }, h('label', { for: id, text: labels[key][0] }), h('span', { class: 'param-row' }, input, extra), help);
    }),
  );
}

function changeFields(patch, fromButton = false) {
  Object.assign(state.fields, patch);
  if (fromButton) syncFields();
  updateInputs();
}

function syncFields() {
  for (const [key, name] of FIELDS) {
    const field = controls.fields[key];
    if (field && field.input.value !== state.fields[name]) field.input.value = state.fields[name];
  }
}

function restore() {
  state.fields = { ...view.DEFAULT_INPUTS };
  syncFields();
  updateInputs();
}

function fieldError(r, key) {
  const I = text.input;
  if (r.ok) return null;
  if (r.error === 'range') return I.errors.range(...I.limits[key]);
  return I.errors[r.error](r.text);
}

/** The fields read again: errors, the last valid value of each, and a new simulation when they settle. */
function updateInputs() {
  const read = view.readInputs(state.fields);
  for (const [key] of FIELDS) {
    const field = controls.fields[key];
    const error = fieldError(read[key], key);
    field.input.setAttribute('aria-invalid', String(Boolean(error)));
    field.help.className = error ? 'field-error' : 'note';
    field.help.textContent = error || field.hint;
    if (error) field.help.setAttribute('role', 'alert');
    else field.help.removeAttribute('role');
  }
  const next = view.applyInputs(read, state.params);
  if (next !== state.params) {
    state.params = next;
    updateModels();
    clearTimeout(timers.compute);
    timers.compute = setTimeout(() => {
      state.target = { ...state.params };
      startComputation();
      createAnimation();
    }, 400);
  }
  updateStatus();
}

/** Under the fields: the errors, the values in use, the simulation running or the time it took. */
function updateStatus() {
  const I = text.input;
  const read = view.readInputs(state.fields);
  const badge = view.inputBadge(state.params, I);
  const waiting = computation.running || view.paramsKey(state.params) !== view.paramsKey(state.target);
  const s = computation.shown;
  fill(
    regions.status,
    !view.allValid(read) && h('p', { class: 'stale', role: 'status', text: I.stale }),
    h('p', { class: badge.known ? 'badge-line is-task' : 'badge-line is-custom' }, h('span', { text: badge.text }), badge.restore && h('button', { type: 'button', class: 'btn alt', text: I.restore, onclick: restore })),
    waiting && s && h('p', { class: 'stale', role: 'status', text: I.pending }),
    computation.error && h('p', { class: 'note', text: text.ui.error(computation.error) }),
    s && !waiting && h('p', { class: 'note', role: 'status', text: I.run(s) }),
  );
}

// --- 1.4 Le traiettorie -----------------------------------------------------------

function trajectoriesBlock() {
  const T = text.trajectories;
  regions.trajectoriesIntro = h('div');
  const button = (label, action) => h('button', { type: 'button', class: 'btn alt', text: label, onclick: () => animation && animation[action]() });
  controls.play = h('button', {
    type: 'button',
    class: 'btn',
    text: T.play,
    onclick: () => {
      if (!animation) return;
      if (animation.status().playing) animation.pause();
      else animation.play();
    },
  });
  const speed = h(
    'select',
    {
      onchange: (e) => {
        state.anim.speed = Number(e.target.value);
        if (animation) animation.setSpeed(view.ANIMATION.speeds[state.anim.speed]);
      },
    },
    T.speeds.map((name, i) => h('option', { value: i, text: name, selected: i === state.anim.speed })),
  );
  controls.canvas = h('canvas', { class: 'anim', role: 'img', 'aria-label': text.sections.trajectories });
  // the canvas in a box of the kit, as a chart of the animation of the moment (none until the simulation arrives): zoom and panning while it goes on
  const { stage, chart } = kit.createSourceStage(
    controls.canvas,
    {
      draw: (...a) => animation && animation.draw(...a),
      frame: (...a) => (animation ? animation.frame(...a) : null),
      height: (width) => Math.round(width * 0.6),
      locate: (...a) => (animation ? animation.locate(...a) : null),
    },
    { palette: palette(), lib: hw, lang: state.lang },
  );
  animationChart = chart;
  controls.caption = h('p', { class: 'caption', 'aria-live': 'polite' });
  return [
    regions.trajectoriesIntro,
    choices(T.modelLabel, modelOptions(), state.anim.model, (model) => {
      state.anim.model = model;
      createAnimation();
    }),
    choices(T.quantityLabel, hw.QUANTITIES.map((q) => [q, text.trajectoryNames[q]]), state.anim.quantity, (quantity) => {
      state.anim.quantity = quantity;
      if (animation) animation.setQuantity(quantity);
      // another quantity has another range of values: the view goes back to the whole chart
      if (animationChart) animationChart.resetView();
    }),
    h('div', { class: 'controls' }, h('label', null, T.speedLabel, speed), h('span', { class: 'buttons' }, controls.play, button(T.step, 'step'), button(T.reset, 'reset'), button(T.end, 'toEnd'))),
    // posizionato: ci stanno dentro l'evidenziazione e l'etichetta sotto il puntatore
    h('div', { class: 'figure' }, stage),
    // la legenda sotto l'animazione: le parti nascoste si ridisegnano dal primo sistema
    legend(view.legends.trajectories(text), (parts) => animation && animation.setHidden(parts), keep('trajectories')),
    controls.caption,
    paras(T.after),
  ];
}

function updateCaption(st) {
  const T = text.trajectories;
  controls.caption.textContent = T.caption(st, text.trajectoryNames[st.quantity]);
  controls.caption.setAttribute('aria-live', st.playing ? 'off' : 'polite');
  let label = T.play;
  if (st.playing) label = T.pause;
  else if (st.k > 0 && !st.done) label = T.resume;
  controls.play.textContent = label;
}

/** The animation of the attackers of the last simulation started, for the chosen model. */
function createAnimation() {
  if (animation) animation.destroy();
  animation = null;
  const canvas = controls.canvas;
  if (!canvas || !canvas.isConnected) return;
  const options = view.animationOptions(state.target, state.anim.model);
  fill(regions.trajectoriesIntro, paras(text.trajectories.intro(options.shown, options.sample)));
  animation = hw.createTrajectoryAnimation(canvas, {
    ...options,
    quantity: state.anim.quantity,
    speed: view.ANIMATION.speeds[state.anim.speed],
    palette: palette(),
    decimal: text.fmt.decimal,
    describe: view.tips.trajectory(text),
    hidden: partsOf(view.legends.trajectories(text), keep('trajectories')),
    onUpdate: updateCaption,
    requestDraw: () => animationChart && animationChart.redraw(),
  });
  // new attackers: the whole chart again
  if (animationChart) {
    animationChart.resetView();
    animationChart.redraw();
  }
}

// --- 1.5 Verifiche -----------------------------------------------------------------

let checkRows = null;

function updateVerify() {
  const V = text.verify;
  if (!checkRows) {
    fill(regions.verify, h('p', { text: V.intro }), h('p', { class: 'note pending', role: 'status', text: text.ui.computing }));
    return;
  }
  const ok = checkRows.filter((r) => r.ok).length;
  const groups = ['generator', 'functions'].map((group) => ({ group, rows: checkRows.filter((r) => r.group === group) }));
  fill(
    regions.verify,
    h('p', { text: V.intro }),
    check(ok === checkRows.length, V.summary(ok, checkRows.length)),
    h(
      'details',
      { class: 'details' },
      h('summary', { text: V.details(checkRows.length) }),
      groups.map((g) => [
        subtitle(V.groups[g.group]),
        table(
          'discussion vectors',
          [V.cols.check, V.cols.expected, V.cols.result],
          g.rows.map((r) => ({ cells: [{ text: r.name, head: true }, { node: h('code', { text: r.expected }) }, { node: h('span', { 'aria-label': r.ok ? V.ok : V.failed, text: r.ok ? '✓' : '✗' }), class: r.ok ? 'is-ok' : 'is-bad' }] })),
        ),
      ]),
    ),
  );
}

function updateSimTests() {
  const s = computation.shown;
  fill(regions.simTests, s && tests('sim', s));
}

// ---------------------------------------------------------------------------
// 2. Le distribuzioni
// ---------------------------------------------------------------------------

function distributionsSection() {
  const S = text.sections;
  const W = text.sweep;
  regions.sweep = h('div');
  regions.moments = h('div');
  regions.choice = h('div');
  controls.sweepSlider = slider('hw3-sweep-n', (g) => {
    stopPlayer('sweep');
    state.sweep.g = g;
    updateSweep();
  });
  controls.sweepPlay = h('button', { type: 'button', class: 'btn alt', text: W.play, onclick: () => togglePlayer('sweep', updateSweep) });
  return h(
    'section',
    { class: 'section' },
    title('hw3-distributions', 0, S.distributions),
    paras(text.distributions.intro),
    title('hw3-sweep', 1, S.sweep),
    paras(W.intro),
    choices(W.quantityLabel, hw.QUANTITIES.map((q) => [q, text.quantityNames[q]]), state.sweep.quantity, (quantity) => {
      state.sweep.quantity = quantity;
      updateSweep();
    }),
    h('div', { class: 'slider-row' }, controls.sweepSlider.el, controls.sweepPlay),
    regions.sweep,
    // una legenda sola per i due istogrammi, che si ridisegnano a ogni n
    legend(
      view.legends.sweep(text),
      (parts) => {
        for (const fig of regions.sweep.querySelectorAll('figure')) setHidden(fig, parts);
      },
      keep('sweep'),
    ),
    paras(W.after),
    title('hw3-moments', 1, S.moments),
    regions.moments,
    title('hw3-choice', 1, S.choice),
    regions.choice,
  );
}

/** The index shown by a player (sweep or normal): the chosen one, or its default, within the checkpoints. */
function playerIndex(name, last) {
  const fallback = name === 'normal' && computation.shown ? view.pointIndex(computation.shown.models.rademacher, 100) : last;
  const g = state[name].g === null ? fallback : state[name].g;
  return Math.min(g, last);
}

const lastIndex = () => (computation.shown ? computation.shown.models.bernoulli.points.length - 1 : 0);

function stopPlayer(name) {
  state[name].playing = false;
  clearTimeout(timers[name]);
}

function togglePlayer(name, update) {
  if (state[name].playing) {
    stopPlayer(name);
    update();
    return;
  }
  const last = lastIndex();
  if (playerIndex(name, last) >= last) state[name].g = 0;
  state[name].playing = true;
  update();
  const tick = () => {
    timers[name] = setTimeout(() => {
      if (!state[name].playing) return;
      const end = lastIndex();
      const g = Math.min(playerIndex(name, end) + 1, end);
      state[name].g = g;
      if (g >= end) state[name].playing = false;
      update();
      if (state[name].playing) tick();
    }, 1100);
  };
  tick();
}

function updateSweep() {
  const W = text.sweep;
  const s = computation.shown;
  controls.sweepPlay.textContent = state.sweep.playing ? W.pause : W.play;
  if (!s) {
    controls.sweepSlider.set(0, 0, W.nLabel(0));
    fill(regions.sweep, pending());
    return;
  }
  const last = lastIndex();
  const g = playerIndex('sweep', last);
  const q = state.sweep.quantity;
  const n = s.models.bernoulli.points[g].n;
  controls.sweepSlider.set(last, g, W.nLabel(n));
  const shown = hw.MODELS.map((model) => {
    const M = s.models[model];
    const data = view.sweepChart(M, g, q, text.fmt.decimal);
    return { caption: W.chart(text.modelNames[model], text.quantityNames[q], n, s.params.m), data, tip: view.tips.histogram(data, text.tips), note: W.stats(text.modelNames[model], view.quantityStats(M, g, q), q) };
  });
  if (sameFigures(sweepView, s)) {
    shown.forEach((c, i) => refreshFigure(sweepView.figs[i], c.caption, c.data, c.tip, c.note));
    return;
  }
  const figs = shown.map((c) => {
    const fig = figure(c.caption, hw.drawHistogram, c.data, { tip: c.tip, note: c.note });
    setHidden(fig, partsOf(view.legends.sweep(text), keep('sweep')));
    return fig;
  });
  Object.assign(sweepView, { fig: figs[0], figs, data: s, lang: state.lang });
  fill(regions.sweep, h('div', { class: 'charts' }, figs));
}

function updateMoments() {
  const M = text.moments;
  const F = text.fmt;
  const s = computation.shown;
  if (!s) {
    fill(regions.moments, pending());
    return;
  }
  const B = s.models.bernoulli.mom;
  const R = s.models.rademacher.mom;
  fill(
    regions.moments,
    h('p', { text: M.intro }),
    subtitle(M.tableTitle),
    h(
      'div',
      { class: 'scroll' },
      table(
        'compact moments',
        [M.cols.n, `${M.cols.bMean} (${F.num(B.mu, 4)})`, `${M.cols.bVar} (${F.num(B.variance, 4)})`, `${M.cols.rMean} (${F.num(R.mu, 4)})`, `${M.cols.rVar} (${F.num(R.variance, 4)})`],
        view.momentRows(s).map((r) => ({ cells: [{ text: F.int(r.n) }, { text: F.num(r.bMean, 4) }, { text: F.num(r.bVar, 4) }, { text: F.num(r.rMean, 4) }, { text: F.num(r.rVar, 4) }] })),
      ),
    ),
    paras(M.after(s)),
  );
}

/** Section 2.3: the attackers needed at every n, in red when more than the simulated ones. */
function updateChoice() {
  const C = text.choice;
  const F = text.fmt;
  const s = computation.shown;
  if (!s) {
    fill(regions.choice, pending());
    return;
  }
  const m = s.params.m;
  const need = (v) => ({ text: C.count(v), class: v > m ? 'over' : null });
  fill(
    regions.choice,
    paras(C.intro),
    formulas(C.formulas, C.formulasTitle),
    subtitle(C.tableTitle(state.epsilon, m)),
    h(
      'div',
      { class: 'scroll' },
      table(
        'compact choice',
        ['n', 'pB', 'mB', 'pR', 'mR', 'd', 'mD'].map((k) => C.cols[k]),
        view.choiceRows(s, state.epsilon).map((r) => ({ cells: [{ text: F.int(r.n) }, { text: F.small(r.pB) }, need(r.mB), { text: F.small(r.pR) }, need(r.mR), { text: F.num(r.d, 4) }, need(r.mD)] })),
      ),
    ),
    paras(C.after(s, state.epsilon)),
  );
}

// ---------------------------------------------------------------------------
// 3. La legge dei grandi numeri
// ---------------------------------------------------------------------------

function llnSection() {
  const S = text.sections;
  const C = text.convergence;
  const [lo, hi] = hw.EPSILON_RANGE;
  regions.convergence = h('div');
  regions.bounds = h('div');
  const label = h('label', { for: 'hw3-epsilon', text: C.epsilonLabel(state.epsilon) });
  const input = h('input', {
    id: 'hw3-epsilon',
    type: 'range',
    min: Math.round(lo * 100),
    max: Math.round(hi * 100),
    step: 1,
    'aria-valuetext': C.epsilonLabel(state.epsilon),
    oninput: (e) => {
      state.epsilon = Number(e.target.value) / 100;
      label.textContent = C.epsilonLabel(state.epsilon);
      input.setAttribute('aria-valuetext', label.textContent);
      updateConvergence();
      updateBounds();
      updateChoice();
    },
  });
  input.value = String(Math.round(state.epsilon * 100));
  return h(
    'section',
    { class: 'section' },
    title('hw3-lln', 0, S.lln),
    paras(text.lln.intro),
    title('hw3-convergence', 1, S.convergence),
    h('p', { text: C.intro }),
    h('div', { class: 'slider-row' }, h('div', { class: 'slider' }, label, input)),
    regions.convergence,
    title('hw3-bounds', 1, S.bounds),
    regions.bounds,
    title('hw3-strong', 1, S.strong),
    paras(text.strong.paras),
  );
}

function updateConvergence() {
  const C = text.convergence;
  const F = text.fmt;
  const s = computation.shown;
  if (!s) {
    fill(regions.convergence, pending());
    return;
  }
  const eps = state.epsilon;
  const rows = view.llnRows(s, eps);
  // la frazione, e sotto il suo intervallo al 95%
  const cell = (x) => h('span', null, F.num(x.rate, 4), h('span', { class: 'interval', text: `${F.num(x.interval[0], 4)}-${F.num(x.interval[1], 4)}` }));
  const B = text.modelNames.bernoulli;
  const R = text.modelNames.rademacher;
  // una legenda per i due grafici; la frazione simulata e quella esatta sono anche le colonne della tabella
  const figs = hw.MODELS.map((model) => figure(C.chart(text.modelNames[model], eps), hw.drawLineChart, view.llnChart(rows[model], F.decimal), { reveal: 180, tip: view.tips.lln(rows[model], text.tips), link: view.links.lln }));
  const frequencies = table(
    'compact lln',
    [C.cols.n, `${B}: ${C.cols.simulated}`, `${B}: ${C.cols.exact}`, `${R}: ${C.cols.simulated}`, `${R}: ${C.cols.exact}`],
    rows.bernoulli.map((b, i) => ({ cells: [{ text: F.int(b.n) }, { node: cell(b) }, { text: F.small(b.exact) }, { node: cell(rows.rademacher[i]) }, { text: F.small(rows.rademacher[i].exact) }] })),
    view.LINKED_TABLES.lln,
    [null, 'series:0', 'series:1', 'series:0', 'series:1'],
  );
  hideParts(frequencies, partsOf(view.legends.lln(text), keep('lln')));
  fill(
    regions.convergence,
    h('div', { class: 'charts' }, figs),
    groupLegend('lln', view.legends.lln(text), figs, (parts) => hideParts(frequencies, parts)),
    subtitle(C.tableTitle(eps)),
    h('div', { class: 'scroll' }, frequencies),
    paras(C.after(s, eps)),
    tests('lln', s),
  );
}

function updateBounds() {
  const s = computation.shown;
  fill(regions.bounds, s ? paras(text.bounds.paras(s, state.epsilon)) : pending());
}

// ---------------------------------------------------------------------------
// 4. La varianza
// ---------------------------------------------------------------------------

function varianceSection() {
  regions.variance = h('div');
  return h('section', { class: 'section' }, title('hw3-variance', 0, text.sections.variance), regions.variance);
}

function updateVariance() {
  const V = text.variance;
  const F = text.fmt;
  const s = computation.shown;
  if (!s) {
    fill(regions.variance, pending());
    return;
  }
  const fits = view.varianceFits(s);
  // una legenda per i due grafici: le tre grandezze sono anche le righe della tabella, i valori esatti la colonna della teoria
  const figs = hw.MODELS.map((model) => figure(V.chart(text.modelNames[model]), hw.drawLineChart, view.varianceChart(s.models[model], F.decimal), { reveal: 180, tip: view.tips.variance(s.models[model], text.tips) }));
  const slopes = table(
    'discussion fits',
    [V.fitCols.quantity, V.fitCols.bernoulli, V.fitCols.rademacher, V.fitCols.theory],
    hw.QUANTITIES.map((q, i) => ({
      part: `series:${2 * i}`,
      cells: [
        { text: text.quantityNames[q], head: true },
        { text: `${F.num(fits.bernoulli[q], 4)} ± ${F.num(fits.bernoulli.error, 4)}` },
        { text: `${F.num(fits.rademacher[q], 4)} ± ${F.num(fits.rademacher.error, 4)}` },
        { text: F.int(view.VARIANCE_SLOPES[q]) },
      ],
    })),
    null,
    [null, null, null, 'theory'],
  );
  hideParts(slopes, partsOf(view.legends.variance(text), keep('variance')));
  fill(
    regions.variance,
    h('p', { text: V.intro }),
    h('div', { class: 'charts' }, figs),
    groupLegend('variance', view.legends.variance(text), figs, (parts) => hideParts(slopes, parts)),
    subtitle(V.fitTitle),
    slopes,
    paras(V.after(s)),
  );
}

// ---------------------------------------------------------------------------
// 5. Il teorema del limite centrale
// ---------------------------------------------------------------------------

function cltSection() {
  const S = text.sections;
  const N = text.normal;
  regions.normal = h('div');
  regions.speed = h('div');
  regions.drift = h('div');
  controls.normalSlider = slider('hw3-clt-n', (g) => {
    stopPlayer('normal');
    state.normal.g = g;
    updateNormal();
  });
  controls.normalPlay = h('button', { type: 'button', class: 'btn alt', text: text.sweep.play, onclick: () => togglePlayer('normal', updateNormal) });
  return h(
    'section',
    { class: 'section' },
    title('hw3-clt', 0, S.clt),
    paras(text.clt.intro),
    title('hw3-normal', 1, S.normal),
    h('p', { text: N.intro }),
    choices(N.modelLabel, ['rademacher', 'bernoulli'].map((m) => [m, N.models[m]]), state.normal.model, (model) => {
      state.normal.model = model;
      updateNormal();
    }),
    h('div', { class: 'slider-row' }, controls.normalSlider.el, controls.normalPlay),
    regions.normal,
    title('hw3-speed', 1, S.speed),
    regions.speed,
    title('hw3-bernoulli', 1, S.bernoulli),
    regions.drift,
  );
}

function updateNormal() {
  const N = text.normal;
  const F = text.fmt;
  const s = computation.shown;
  controls.normalPlay.textContent = state.normal.playing ? text.sweep.pause : text.sweep.play;
  if (!s) {
    controls.normalSlider.set(0, 0, N.nLabel(0));
    fill(regions.normal, pending());
    return;
  }
  const M = s.models[state.normal.model];
  const last = lastIndex();
  const g = playerIndex('normal', last);
  const n = M.points[g].n;
  const label = N.models[state.normal.model];
  controls.normalSlider.set(last, g, N.nLabel(n));
  const hist = view.cltHistogram(M, g, F.decimal);
  const qq = view.qqData(M, g, F.decimal);
  if (sameFigures(normalView, s)) {
    refreshFigure(normalView.fig, N.histChart(label, n), hist, view.tips.histogram(hist, text.tips));
    refreshFigure(normalView.qq, N.qqChart(label, n), qq, view.tips.qq(qq, text.tips));
    normalView.stats.textContent = N.stats(view.shapeAt(M, g));
    return;
  }
  const histFig = figure(N.histChart(label, n), hw.drawHistogram, hist, { tip: view.tips.histogram(hist, text.tips), items: view.legends.clt(text), keep: keep('clt') });
  const qqFig = figure(N.qqChart(label, n), hw.drawQQ, qq, { tip: view.tips.qq(qq, text.tips), items: view.legends.qq(text), keep: keep('qq') });
  const stats = h('p', { class: 'stats', text: N.stats(view.shapeAt(M, g)) });
  Object.assign(normalView, { fig: histFig, qq: qqFig, stats, data: s, lang: state.lang });
  fill(regions.normal, h('div', { class: 'charts' }, histFig, qqFig), stats, paras(N.after), tests('clt', s));
}

function updateSpeed() {
  const P = text.speed;
  const F = text.fmt;
  const s = computation.shown;
  if (!s) {
    fill(regions.speed, pending());
    return;
  }
  // una legenda per i due grafici
  const figs = ['rademacher', 'bernoulli'].map((model) => figure(P.chart(text.modelNames[model]), hw.drawLineChart, view.distanceChart(s.models[model], s.params.m, F.decimal), { reveal: 50, tip: view.tips.distance(s.models[model], text.tips) }));
  fill(
    regions.speed,
    h('p', { text: P.intro }),
    h('div', { class: 'charts' }, figs),
    groupLegend('speed', view.legends.speed(text), figs),
    paras(P.after(s)),
  );
}

function updateDrift() {
  const D = text.bernoulli;
  const F = text.fmt;
  const s = computation.shown;
  if (!s) {
    fill(regions.drift, pending());
    return;
  }
  fill(
    regions.drift,
    h('p', { text: D.intro }),
    subtitle(D.tableTitle),
    h(
      'div',
      { class: 'scroll' },
      table(
        'compact drift',
        ['n', 'mean', 'sampleMean', 'skewness', 'sampleSkewness', 'distance'].map((k) => D.cols[k]),
        view.driftRows(s.models.bernoulli).map((r) => ({ cells: [{ text: F.int(r.n) }, { text: F.num(r.mean, 3) }, { text: F.num(r.sampleMean, 3) }, { text: F.num(r.skewness, 4) }, { text: F.num(r.sampleSkewness, 4) }, { text: F.num(r.distance, 4) }] })),
      ),
    ),
    paras(D.after(s)),
  );
}

// ---------------------------------------------------------------------------
// 6. Sistemi e attaccanti
// ---------------------------------------------------------------------------

function interpretationSection() {
  const S = text.sections;
  regions.size = h('div');
  regions.attackers = h('div');
  regions.aggregate = h('div');
  return h(
    'section',
    { class: 'section' },
    title('hw3-interpretation', 0, S.interpretation),
    paras(text.interpretation.intro),
    title('hw3-size', 1, S.size),
    regions.size,
    title('hw3-attackers', 1, S.attackers),
    regions.attackers,
    title('hw3-aggregate', 1, S.aggregate),
    regions.aggregate,
    title('hw3-limits', 1, S.limits),
    paras(text.limits.paras),
  );
}

function updateSize() {
  const Z = text.size;
  const s = computation.shown;
  if (!s) {
    fill(regions.size, pending());
    return;
  }
  const W = s.models.rademacher.walk;
  const data = view.arcsineChart(W, text.fmt.decimal);
  fill(
    regions.size,
    paras(Z.paras(s)),
    figure(Z.arcsineChart(W.even, s.params.m), hw.drawHistogram, data, { wide: true, tip: view.tips.arcsine(data, text.tips), items: view.legends.arcsine(text), keep: keep('arcsine') }),
    paras(Z.after),
    tests('walk', s),
  );
}

function updateAttackers() {
  const A = text.attackers;
  const F = text.fmt;
  const s = computation.shown;
  if (!s) {
    fill(regions.attackers, pending());
    return;
  }
  const G = s.models.bernoulli.groups;
  const n = s.params.n;
  fill(
    regions.attackers,
    h('p', { text: A.intro }),
    h(
      'div',
      { class: 'charts' },
      figure(A.bestChart(n), hw.drawLineChart, view.bestChart(G, F.decimal), { reveal: 240, tip: view.tips.best(G, text.tips), items: view.legends.best(text), keep: keep('best') }),
      figure(A.probabilityChart(n), hw.drawLineChart, view.probabilityChart(G, F.decimal), { reveal: 240, tip: view.tips.probability(G, text.tips), items: view.legends.probability(text), keep: keep('probability') }),
    ),
    paras(A.after(s)),
  );
}

function updateAggregate() {
  const G = text.aggregate;
  const s = computation.shown;
  if (!s) {
    fill(regions.aggregate, pending());
    return;
  }
  const data = view.systemsChart(s.models.bernoulli, text.fmt.decimal);
  fill(
    regions.aggregate,
    paras(G.paras(s)),
    figure(G.systemsChart(s.params.n, s.params.m), hw.drawHistogram, data, { wide: true, tip: view.tips.histogram(data, text.tips), items: view.legends.systems(text), keep: keep('systems') }),
    paras(G.after),
  );
}

// ---------------------------------------------------------------------------
// 7, 8 e 9
// ---------------------------------------------------------------------------

function testsSection() {
  regions.tests = h('div');
  return h('section', { class: 'section' }, title('hw3-tests', 0, text.sections.tests), regions.tests);
}

function updateTests() {
  const T = text.tests;
  const F = text.fmt;
  const s = computation.shown;
  if (!s) {
    fill(regions.tests, pending());
    return;
  }
  const summary = view.testSummary(s);
  fill(
    regions.tests,
    h('p', { text: T.intro(s) }),
    table(
      'discussion summary-tests',
      [T.cols.subject, T.cols.hypothesis, T.cols.p, T.cols.verdict, T.cols.expected],
      summary.all.map((t) => {
        const rejected = t.result.verdict === 'reject';
        return {
          class: rejected ? 'is-rejected' : null,
          cells: [{ text: text.stats.groups[t.group], head: true }, { text: text.stats.labels[t.group][t.key] }, { text: F.pval(t.result.pValue) }, { text: text.stats.verdict[rejected ? 'reject' : 'notReject'] }, { text: text.stats.expected[t.expected] }],
        };
      }),
    ),
    paras(T.after(summary, s)),
  );
}

function historySection() {
  const H = text.history;
  return h(
    'section',
    { class: 'section' },
    title('hw3-history', 0, text.sections.history),
    h('p', { text: H.intro }),
    h('p', { class: 'legend' }, h('span', { class: 'legend-task', text: H.legend.task }), h('span', { class: 'legend-context', text: H.legend.context })),
    h(
      'ol',
      { class: 'timeline' },
      H.events.map((e) => h('li', { class: e.task ? 'is-task' : 'is-context' }, h('span', { class: 'year', text: e.year }), h('div', null, h('strong', { text: e.title }), h('p', { text: e.text })))),
    ),
    h('p', { text: H.after }),
  );
}

function conclusionSection() {
  regions.conclusion = h('div');
  return h('section', { class: 'section' }, title('hw3-conclusion', 0, text.sections.conclusion), regions.conclusion);
}

function updateConclusion() {
  fill(regions.conclusion, paras(text.conclusion(computation.shown)));
}

// ---------------------------------------------------------------------------
// La simulazione
// ---------------------------------------------------------------------------

const message = (error) => (error instanceof Error ? error.message : String(error));

/** A generator that stops early, returning null, once its token is cancelled. */
function* cancellable(steps, token) {
  let step = steps.next();
  while (!step.done) {
    if (token.cancelled) return null;
    yield;
    step = steps.next();
  }
  return step.value;
}

// gli ultimi risultati restano in memoria (ognuno pesa circa un megabyte)
function remember(key, value) {
  results.delete(key);
  results.set(key, value);
  while (results.size > 4) results.delete(results.keys().next().value);
}

/** Simulates the parameters of state.target; the one still running for other parameters stops at its next slice. */
function startComputation() {
  const params = state.target;
  const key = view.paramsKey(params);
  if (computation.running) computation.running.token.cancelled = true;
  computation.running = null;
  if (results.has(key)) {
    computation.shown = results.get(key);
    computation.error = null;
    updateResults();
    return;
  }
  const token = { cancelled: false };
  computation.running = { key, token };
  updateStatus();
  hw.runStepsAsync(() => cancellable(hw.exploreSteps(params), token)).then(
    (value) => {
      if (token.cancelled || value === null) return;
      remember(key, value);
      computation.running = null;
      computation.shown = value;
      computation.error = null;
      updateResults();
    },
    (error) => {
      if (token.cancelled) return;
      computation.running = null;
      computation.error = message(error);
      updateResults();
    },
  );
}

function updateResults() {
  updateStatus();
  updateSimTests();
  updateSweep();
  updateMoments();
  updateChoice();
  updateConvergence();
  updateBounds();
  updateVariance();
  updateNormal();
  updateSpeed();
  updateDrift();
  updateSize();
  updateAttackers();
  updateAggregate();
  updateTests();
  updateConclusion();
}

// ---------------------------------------------------------------------------
// Indice, lingua e avvio
// ---------------------------------------------------------------------------

const dialog = document.getElementById('index-dialog');
const FOLLOW_MS = 2500;

// Porta il titolo in cima e lo segue per un paio di secondi: se nel
// frattempo qualcosa sopra cambia altezza (una sezione che finisce di
// calcolarsi), lo scorrimento riparte verso la nuova posizione. Se l'utente
// scorre da se', si smette subito di inseguire.
function scrollToSection(target) {
  const behavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth';
  const userEvents = ['wheel', 'touchstart', 'keydown', 'mousedown'];
  const started = performance.now();
  let stopped = false;
  let lastTop = target.getBoundingClientRect().top + window.scrollY;
  const stop = () => {
    stopped = true;
    userEvents.forEach((type) => window.removeEventListener(type, stop));
  };
  userEvents.forEach((type) => window.addEventListener(type, stop, { passive: true }));
  target.scrollIntoView({ behavior, block: 'start' });
  const follow = () => {
    if (stopped) return;
    if (performance.now() - started > FOLLOW_MS) {
      stop();
      return;
    }
    const top = target.getBoundingClientRect().top + window.scrollY;
    if (Math.abs(top - lastTop) > 1) {
      lastTop = top;
      target.scrollIntoView({ behavior, block: 'start' });
    }
    requestAnimationFrame(follow);
  };
  requestAnimationFrame(follow);
}

function closeIndex() {
  document.documentElement.classList.remove('index-open');
  if (dialog.open) dialog.close();
}

function goTo(id) {
  closeIndex();
  const target = document.getElementById(id);
  if (!target) return;
  target.focus({ preventScroll: true });
  scrollToSection(target);
  target.classList.remove('flash');
  void target.offsetWidth;
  target.classList.add('flash');
  target.addEventListener('animationend', () => target.classList.remove('flash'), { once: true });
}

// In cima alla pagina, con il focus sul titolo: chi usa la tastiera riparte
// da li', non dal pulsante in fondo
function backToTop() {
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  window.scrollTo({ top: 0, behavior: reduced ? 'auto' : 'smooth' });
  document.getElementById('page-title').focus({ preventScroll: true });
}

const toTopButton = () => h('p', { class: 'to-top' }, h('button', { type: 'button', class: 'btn alt', text: text.ui.backToTop, onclick: backToTop }));

function renderChrome() {
  const t = text;
  document.documentElement.lang = state.lang;
  document.title = 'Homework #3 - Statistics';
  document.getElementById('subtitle').textContent = t.standalone.subtitle;
  document.getElementById('course').textContent = t.standalone.course;
  document.getElementById('open-index').textContent = t.ui.index;
  document.getElementById('index-title').textContent = t.ui.indexTitle;
  document.querySelector('.index-close').setAttribute('aria-label', t.ui.close);
  document.getElementById('language').setAttribute('aria-label', t.ui.language);
  document.getElementById('online-label').textContent = t.standalone.online;
  for (const button of document.querySelectorAll('[data-lang]')) {
    button.setAttribute('aria-pressed', String(button.dataset.lang === state.lang));
  }
  document.getElementById('index-list').replaceChildren(
    ...view.tocEntries(t.sections).map((entry) => h('li', { class: `level-${entry.level}` }, h('button', { type: 'button', text: entry.title, onclick: () => goTo(entry.id) }))),
  );
}

function render() {
  text = HW3_TEXTS[state.lang];
  renderChrome();
  const app = document.getElementById('app');
  fill(app, assignmentSection(), modelSection(), distributionsSection(), llnSection(), varianceSection(), cltSection(), interpretationSection(), testsSection(), historySection(), conclusionSection(), toTopButton());
  updateModels();
  updateInputs();
  updateVerify();
  updateResults();
  createAnimation();
}

function boot() {
  for (const button of document.querySelectorAll('[data-lang]')) {
    button.addEventListener('click', () => {
      if (button.dataset.lang === state.lang) return;
      state.lang = LANGUAGES.includes(button.dataset.lang) ? button.dataset.lang : 'en';
      render();
    });
  }
  document.getElementById('open-index').addEventListener('click', () => {
    document.documentElement.classList.add('index-open');
    dialog.showModal();
  });
  document.querySelector('.index-close').addEventListener('click', closeIndex);
  dialog.addEventListener('close', () => document.documentElement.classList.remove('index-open'));
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) closeIndex();
  });
  // i colori dei grafici, delle legende e dell'animazione seguono il tema del sistema
  darkQuery.addEventListener('change', render);
  render();
  // le verifiche e la simulazione partono dopo il primo disegno della pagina
  setTimeout(() => {
    try {
      checkRows = hw.verifyAll();
    } catch (error) {
      checkRows = [{ group: 'functions', name: text.ui.error(message(error)), expected: '', actual: '', ok: false }];
    }
    updateVerify();
    startComputation();
  }, 50);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
})();
})();
