#!/bin/sh
# Restore SOC Suite data from an archive created by backup.sh.
#
# Overwrites the current volumes (user accounts, cache, licence) with the
# contents of the backup. The suite is stopped first so nothing writes while
# the data is being replaced, then you restart it.
#
# Usage:  ./restore.sh <soc-suite-backup-YYYYmmdd-HHMMSS.tar.gz>
set -e

PROJECT=soc-suite
ARCHIVE="$1"
if [ -z "$ARCHIVE" ] || [ ! -f "$ARCHIVE" ]; then
  echo "usage: $0 <backup-file.tar.gz>" >&2
  exit 1
fi
ARCHIVE_DIR=$(cd "$(dirname "$ARCHIVE")" && pwd)
ARCHIVE_NAME=$(basename "$ARCHIVE")

printf "This overwrites current data with '%s'. Continue? [y/N] " "$ARCHIVE_NAME"
read -r reply
case "$reply" in
  y|Y) ;;
  *) echo "Aborted."; exit 0 ;;
esac

echo "Stopping the suite..."
docker compose stop

echo "Restoring volumes..."
docker run --rm \
  -v "${PROJECT}_soc-data:/data/soc-data" \
  -v "${PROJECT}_osint-data:/data/osint-data" \
  -v "${PROJECT}_license-data:/data/license-data" \
  -v "${ARCHIVE_DIR}:/backup:ro" \
  alpine sh -c "cd /data && tar xzf /backup/${ARCHIVE_NAME}"

echo "Restore complete. Start the suite again with:  docker compose up -d"
