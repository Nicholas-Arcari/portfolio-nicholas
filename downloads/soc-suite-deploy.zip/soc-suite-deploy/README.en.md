# SOC Suite - Installation guide

> Versione italiana: `README.md`

On-premise suite for security operations: **SOC Toolkit** (phishing triage, log
analysis, IOC, YARA/Sigma, file inspector) + **OSINT Toolkit** (attack surface
and investigative OSINT). Everything runs on YOUR server: no data leaves your
infrastructure and the licence is verified locally, with no outbound
connections.

## Requirements

- A Linux server (or macOS/Windows with WSL2) with **Docker** and **Docker Compose**
- 4 GB of RAM recommended
- Internet access only for the first image download

## Installation (3 steps)

1. **Configure** the `.env` file in this folder:
   - `LICENSE_DEPLOYMENT_ID`: choose a name for this installation
     (e.g. `acme-prod-01`)
   - `AUTH_SECRET`: a random secret of at least 32 characters
     (`openssl rand -hex 32`)

2. **Start** with the included launcher: it registers the `soctoolkit` and
   `osinttoolkit` names in your machine's hosts file for you and brings the
   containers up (pulling the images and generating the HTTPS certificates on
   first start). One command:

   - Linux/macOS: `./up.sh`  (asks for your password to write the hosts file)
   - Windows: right-click `up.ps1` -> "Run with PowerShell", or
     `powershell -ExecutionPolicy Bypass -File .\up.ps1` (accept the
     administrator prompt, needed for the hosts file)

   The launcher is safe to re-run and never duplicates the hosts line. To stop
   the suite: `./down.sh` (Windows: `.\down.ps1`).

   > Manual method, as an alternative to the launcher: add the line
   > `127.0.0.1 soctoolkit osinttoolkit` to your hosts file and run
   > `docker compose up -d`. If you access it from other PCs on the network, use
   > the server's IP instead of `127.0.0.1` (or your internal DNS).

3. **Activate the licence**: open **https://soctoolkit** in your browser. The
   first time, the browser shows a security warning (the certificate is
   self-signed): accept it to proceed. The "Licence required" screen appears.

   To get the key, send an email to **arcari.nicholas0@gmail.com** with your
   `LICENSE_DEPLOYMENT_ID`: the key is delivered by email **securely and with
   tracking**, issued exclusively for your deployment. Paste it once on the
   screen: it unlocks **both** applications and stays saved (`data/license.key`).

Done. SOC Toolkit at **https://soctoolkit**, OSINT Toolkit at
**https://osinttoolkit**. The first registered user becomes the administrator.

### Removing the browser warning (optional)

The first start creates a `certs/` folder with a `ca.crt` file. Installing it
among the "trusted root certification authorities" of the machines you connect
from removes the warning. It is optional: the connection stays encrypted even if
you just accept the warning.

## Licence renewal

The licence has an expiry date. Before it expires, request a renewal at the same
email: you receive a new key to paste over the old one on the same screen. When
it expires the app locks but **no data is lost**.

## Updates

```bash
docker compose pull && docker compose up -d
```

## Auto-start after a reboot

The containers are already set to come back on their own when Docker restarts.
For that to happen after the computer reboots too, Docker just needs to start at
boot. To set it up (once):

- Linux/macOS: `./enable-autostart.sh`
- Windows: `powershell -ExecutionPolicy Bypass -File .\enable-autostart.ps1`

On Linux it enables the Docker service at boot; on Windows/macOS it sets Docker
Desktop to start at login. After that, the suite comes back up by itself every
time you turn the machine on.

## Backup and restore

Your data (users, cache and the activated licence) lives in three Docker
volumes. To save it all into a single archive:

```bash
./backup.sh
```

It creates `backups/soc-suite-backup-<date>.tar.gz`: copy it somewhere safe,
off the server. To restore from a backup:

```bash
./restore.sh backups/soc-suite-backup-<date>.tar.gz
```

Restore stops the suite, replaces the data and tells you how to start it again.

## Network exposure

The suite is already served over HTTPS by the included reverse proxy (ports 80
and 443). To access it from other PCs on the network, use the server's IP in the
clients' hosts file (or your internal DNS) and set `AUTH_SECRET` to require
login. If you wish, you can replace the self-signed certificates in `certs/`
with your own corporate certificates (same file names).

## Licence and documents

Use of the software is governed by the licence agreement in `EULA.md`, included
in this folder. By installing or using the suite you accept its terms. This
folder also contains:

- `EULA.md` - end user licence agreement (binding text); `EULA.en.md` is its
  official English translation
- `ETHICS.en.md` - lawful and ethical use policy in English (referenced by the
  EULA: the suite must only be used on systems and data you are authorised to
  test); `ETHICS.md` is the Italian version
- `THIRD_PARTY_NOTICES.md` - third-party open source components included in the
  product and their licences

## Support

Problems or questions: **arcari.nicholas0@gmail.com** (always include your
deployment id).
