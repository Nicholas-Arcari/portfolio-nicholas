# SOC Suite - Guida di installazione

> English version: `README.en.md`

Suite on-premise per security operations: **SOC Toolkit** (triage phishing,
analisi log, IOC, YARA/Sigma, file inspector) + **OSINT Toolkit** (attack
surface e OSINT investigativo). Tutto gira sul TUO server: nessun dato lascia
la tua infrastruttura e la licenza si verifica in locale, senza connessioni
verso l'esterno.

## Requisiti

- Un server Linux (o macOS/Windows con WSL2) con **Docker** e **Docker Compose**
- 4 GB di RAM consigliati
- Accesso a internet solo per il primo download delle immagini

## Installazione (3 passi)

1. **Configura** il file `.env` in questa cartella:
   - `LICENSE_DEPLOYMENT_ID`: scegli un nome per questa installazione
     (es. `acme-prod-01`)
   - `AUTH_SECRET`: un segreto casuale di almeno 32 caratteri
     (`openssl rand -hex 32`)

2. **Avvia** con lo script incluso: registra da solo i nomi `soctoolkit` e
   `osinttoolkit` nel file hosts della macchina e avvia i container (scarica le
   immagini e genera i certificati HTTPS al primo avvio). Un solo comando:

   - Linux/macOS: `./up.sh`  (chiede la password per scrivere nel file hosts)
   - Windows: tasto destro su `up.ps1` -> "Esegui con PowerShell", oppure
     `powershell -ExecutionPolicy Bypass -File .\up.ps1` (accetta il prompt di
     amministratore, serve per il file hosts)

   Lo script e' sicuro da rieseguire e non duplica la riga hosts. Per fermare la
   suite: `./down.sh` (Windows: `.\down.ps1`).

   > Metodo manuale, in alternativa allo script: aggiungi la riga
   > `127.0.0.1 soctoolkit osinttoolkit` al file hosts e lancia
   > `docker compose up -d`. Se accedi da altri PC della rete, usa l'IP del
   > server al posto di `127.0.0.1` (oppure il DNS interno).

3. **Attiva la licenza**: apri **https://soctoolkit** nel browser. La prima
   volta il browser mostra un avviso di sicurezza (il certificato e'
   self-signed): accettalo per proseguire. Comparira' la schermata "Licenza
   richiesta".

   Per ottenere la chiave invia una email a **arcari.nicholas0@gmail.com**
   indicando il tuo `LICENSE_DEPLOYMENT_ID`: la chiave viene consegnata via
   email **in maniera sicura e tracciata**, emessa esclusivamente per il tuo
   deployment. Incollala una volta nella schermata: sblocca **entrambe** le
   applicazioni e resta salvata (`data/license.key`).

Fatto. SOC Toolkit su **https://soctoolkit**, OSINT Toolkit su
**https://osinttoolkit**. Il primo utente registrato diventa amministratore.

### Togliere l'avviso del browser (opzionale)

Il primo avvio crea una cartella `certs/` con un file `ca.crt`. Installandolo
tra le "autorita' di certificazione radice attendibili" delle macchine da cui
accedi, l'avviso sparisce. E' facoltativo: la connessione resta comunque
cifrata anche accettando l'avviso.

## Rinnovo licenza

La licenza ha una scadenza. Prima della scadenza richiedi il rinnovo alla
stessa email: ricevi una chiave nuova da incollare sopra la vecchia nella
stessa schermata. Alla scadenza l'app si blocca ma **nessun dato viene perso**.

## Aggiornamenti

```bash
docker compose pull && docker compose up -d
```

## Avvio automatico dopo il riavvio del PC

I container sono gia' configurati per ripartire da soli quando Docker riparte.
Perche' questo avvenga anche dopo un riavvio del computer basta che Docker parta
all'accensione. Per configurarlo (una volta sola):

- Linux/macOS: `./enable-autostart.sh`
- Windows: `powershell -ExecutionPolicy Bypass -File .\enable-autostart.ps1`

Su Linux abilita il servizio Docker al boot; su Windows/macOS imposta Docker
Desktop per avviarsi al login. Dopo, a ogni accensione la suite torna su da
sola, senza dover rilanciare nulla.

## Backup e ripristino

I tuoi dati (utenti, cache e la licenza attivata) stanno in tre volumi Docker.
Per salvarli tutti in un unico archivio:

```bash
./backup.sh
```

Crea `backups/soc-suite-backup-<data>.tar.gz`: copialo in un luogo sicuro,
fuori dal server. Per ripristinare da un backup:

```bash
./restore.sh backups/soc-suite-backup-<data>.tar.gz
```

Il ripristino ferma la suite, sostituisce i dati e ti indica come riavviarla.

## Esposizione in rete

La suite e' gia' servita in HTTPS dal reverse proxy incluso (porte 80 e 443).
Per accedervi da altri PC della rete, usa l'IP del server nel file hosts dei
client (o il DNS interno) e imposta `AUTH_SECRET` per richiedere il login.
Volendo puoi sostituire i certificati self-signed in `certs/` con i tuoi
certificati aziendali (stessi nomi file).

## Licenza e documenti

L'utilizzo del software e' regolato dal contratto di licenza in `EULA.md`,
incluso in questa cartella. Installando o utilizzando la suite ne accetti i
termini. In questa cartella trovi anche:

- `EULA.md` - contratto di licenza con l'utente finale (testo vincolante);
  `EULA.en.md` ne e' la traduzione ufficiale in inglese
- `ETHICS.md` - condizioni di uso lecito ed etico (richiamate dall'EULA:
  la suite va usata solo su sistemi e dati per cui sei autorizzato);
  `ETHICS.en.md` ne e' la versione inglese
- `THIRD_PARTY_NOTICES.md` - componenti open source di terze parti inclusi
  nel prodotto e relative licenze

## Supporto

Problemi o domande: **arcari.nicholas0@gmail.com** (indica sempre il tuo
deployment id).
